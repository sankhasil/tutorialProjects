
package com.bosch.si.amra.entity.monitoring;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

import com.bosch.si.amra.constants.MongoConstants;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

public class AlarmRule implements Serializable
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= -8511458505919585532L;

	private String				id;

	/**
	 * name of rule
	 */
	private String				name;

	/**
	 * indicator whether the rule is active or inactive
	 */
	private Boolean				status;

	/**
	 * one of: relative humidity, total mileage, ambient temperature, load temperature, Geofence
	 */
	private String				ruleType;

	/**
	 * the upper/lower values or the area of the geofence
	 */
	private Integer				limit;

	/**
	 * depends on type of rule: °C, km/h
	 */
	private String				unit;

	/**
	 * one of: below threshold, above threshold, arriving, leaving
	 * depending on type of rule
	 */
	private String				condition;

	/**
	 * one of: low, medium, high
	 */
	private String				severity;

	/**
	 * the means of transport name
	 */
	private String				alias;

	private String				tenantId;

	private String				wagonId;

	private Date				timestamp;

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public Boolean getStatus()
	{
		return status;
	}

	public void setStatus(Boolean status)
	{
		this.status = status;
	}

	public String getRuleType()
	{
		return ruleType;
	}

	public void setRuleType(String ruleType)
	{
		this.ruleType = ruleType;
	}

	public Integer getLimit()
	{
		return limit;
	}

	public void setLimit(Integer limit)
	{
		this.limit = limit;
	}

	public String getUnit()
	{
		return unit;
	}

	public void setUnit(String unit)
	{
		this.unit = unit;
	}

	public String getCondition()
	{
		return condition;
	}

	public void setCondition(String condition)
	{
		this.condition = condition;
	}

	public String getSeverity()
	{
		return severity;
	}

	public void setSeverity(String severity)
	{
		this.severity = severity;
	}

	public String getAlias()
	{
		return alias;
	}

	public void setAlias(String alias)
	{
		this.alias = alias;
	}

	public String getTenantId()
	{
		return tenantId;
	}

	public void setTenantId(String tenantId)
	{
		this.tenantId = tenantId;
	}

	public String getWagonId()
	{
		return wagonId;
	}

	public void setWagonId(String wagonId)
	{
		this.wagonId = wagonId;
	}

	public Date getTimestamp()
	{
		return timestamp;
	}

	public void setTimestamp(Date timestamp)
	{
		this.timestamp = timestamp;
	}

	public static DBObject alarm2DBObject(AlarmRule alarmRule)
	{
		DBObject alramObject = null;
		if (alarmRule != null)
		{
			alramObject = new BasicDBObject();
			String id = alarmRule.getId();
			if (id == null)
			{
				id = UUID.randomUUID().toString();
			}
			alramObject.put(MongoConstants.ID, id);
			alramObject.put(MongoConstants.ALARM_NAME, alarmRule.getName());
			alramObject.put(MongoConstants.SORT, alarmRule.getName().toLowerCase());
			alramObject.put(MongoConstants.ALARM_ACTIVE, alarmRule.getStatus());
			alramObject.put(MongoConstants.ALARM_RULE_TYPE, alarmRule.getRuleType());
			DBObject sensorObject = new BasicDBObject();
			sensorObject.put(MongoConstants.ALARM_LIMIT, alarmRule.getLimit());
			sensorObject.put(MongoConstants.ALARM_CONDITION, alarmRule.getCondition());
			alramObject.put(MongoConstants.SENSORVALUES_ELEMENT, sensorObject);
			alramObject.put(MongoConstants.ALARM_SEVERITY, alarmRule.getSeverity());
			alramObject.put(MongoConstants.ALIAS, alarmRule.getAlias());
			alramObject.put(MongoConstants.ALIAS_TO_LOWERCASE, alarmRule.getAlias().toLowerCase());
			alramObject.put(MongoConstants.TENANT_ID, alarmRule.getTenantId());
			alramObject.put(MongoConstants.WAGON_ID, alarmRule.getWagonId());
			alramObject.put(MongoConstants.TIMESTAMP, alarmRule.getTimestamp());
		}
		return alramObject;
	}

	public static AlarmRule dbObject2Alarm(DBObject dbObject)
	{
		AlarmRule alarmRule = null;
		if (dbObject != null)
		{
			alarmRule = new AlarmRule();
			alarmRule.setId((String) dbObject.get(MongoConstants.ID));
			alarmRule.setName((String) dbObject.get(MongoConstants.ALARM_NAME));
			alarmRule.setStatus((Boolean) dbObject.get(MongoConstants.ALARM_ACTIVE));
			alarmRule.setRuleType((String) dbObject.get(MongoConstants.ALARM_RULE_TYPE));
			DBObject sensorObject = (DBObject) dbObject.get(MongoConstants.SENSORVALUES_ELEMENT);
			if (sensorObject != null)
			{
				alarmRule.setLimit((Integer) sensorObject.get(MongoConstants.ALARM_LIMIT));
				alarmRule.setCondition((String) sensorObject.get(MongoConstants.ALARM_CONDITION));
			}
			alarmRule.setSeverity((String) dbObject.get(MongoConstants.ALARM_SEVERITY));
			alarmRule.setAlias((String) dbObject.get(MongoConstants.ALIAS));
			alarmRule.setTenantId((String) dbObject.get(MongoConstants.TENANT_ID));
			alarmRule.setWagonId((String) dbObject.get(MongoConstants.WAGON_ID));
			alarmRule.setTimestamp((Date) dbObject.get(MongoConstants.TIMESTAMP));
		}
		return alarmRule;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((alias == null) ? 0 : alias.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((wagonId == null) ? 0 : wagonId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AlarmRule other = (AlarmRule) obj;
		if (alias == null)
		{
			if (other.alias != null)
				return false;
		}
		else if (!alias.equals(other.alias))
			return false;
		if (id == null)
		{
			if (other.id != null)
				return false;
		}
		else if (!id.equals(other.id))
			return false;
		if (name == null)
		{
			if (other.name != null)
				return false;
		}
		else if (!name.equals(other.name))
			return false;
		if (wagonId == null)
		{
			if (other.wagonId != null)
				return false;
		}
		else if (!wagonId.equals(other.wagonId))
			return false;
		return true;
	}
}
