/**
 * 
 */

package com.bosch.si.amra.view.overview;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.Tag;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.event.DashboardEvent.DeleteTagEvent;
import com.bosch.si.amra.event.DashboardEvent.TagAssignChangeEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.vaadin.addon.contextmenu.ContextMenu;
import com.vaadin.addon.contextmenu.ContextMenu.ContextMenuOpenListener;
import com.vaadin.server.FontAwesome;
import com.vaadin.shared.MouseEventDetails.MouseButton;
import com.vaadin.shared.ui.grid.GridConstants.Section;
import com.vaadin.ui.Button;
import com.vaadin.ui.Grid;
import com.vaadin.ui.Grid.GridContextClickEvent;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Notification.Type;

/**
 * @author ils5kor
 *
 */
public class OverviewTagGridContextMenuOpenListnerWithButtonEvents
		implements ContextMenuOpenListener
{

	private Grid		tagGrid, wagonGrid;

	private List<Tag>	tagListForGrid;

	private ContextMenu	tagContextMenu;

	public OverviewTagGridContextMenuOpenListnerWithButtonEvents(Grid tagGrid, Grid wagonGrid,
			ContextMenu tagContextMenu, List<Tag> tagListForGrid)
	{
		this.tagGrid = tagGrid;
		this.wagonGrid = wagonGrid;
		this.tagContextMenu = tagContextMenu;
		this.tagListForGrid = tagListForGrid;
	}

	@Override
	public void onContextMenuOpen(ContextMenuOpenEvent event)
	{

		GridContextClickEvent tagGridContextEvent = (GridContextClickEvent) event
				.getContextClickEvent();
		Object itemID = tagGridContextEvent.getItemId();
		tagContextMenu.removeItems();
		if (checkGridContexMenuOpenCondition(tagGridContextEvent))
		{
			tagContextMenu.addItem(
					DashboardUI.getMessageSource()
							.getMessage("view.overview.tag.toolbar.button.caption.delete"),
					FontAwesome.TRASH_O, command -> {
						if (((Tag) itemID).isAssigned())
						{
							Notification.show(
									DashboardUI.getMessageSource()
											.getMessage("view.overview.tag.notification.error"),
									Type.WARNING_MESSAGE);
						}
						else
						{
							ArrayList<Tag> tagToDelete = new ArrayList<Tag>();
							tagToDelete.add((Tag) itemID);
							deleteTags(tagToDelete, null, null);
							tagGrid.getContainerDataSource().removeItem(itemID);
							tagGrid.getSelectionModel().reset();
						}
					});
			tagContextMenu.addItem(
					DashboardUI.getMessageSource()
							.getMessage("view.overview.tag.toolbar.button.caption.edit"),
					FontAwesome.EDIT, command -> {
						tagGrid.setEditorEnabled(true);
						tagGrid.editItem(itemID);
					});
			if (wagonGrid.getSelectedRows().size() > 0)
			{
				ArrayList<Tag> tagSelected = new ArrayList<Tag>();
				tagSelected.add((Tag) itemID);
				tagContextMenu.addItem(
						DashboardUI.getMessageSource()
								.getMessage("view.overview.tag.toolbar.button.caption.assign"),
						FontAwesome.BOOKMARK, command -> {
							assignTagsToWagons(tagSelected);
						});
				if (((Tag) itemID).isAssigned())
				{
					tagContextMenu.addItem(
							DashboardUI.getMessageSource().getMessage(
									"view.overview.tag.toolbar.button.caption.unassign"),
							FontAwesome.BOOKMARK_O, command -> {
								unassignTagsFromWagons(tagSelected);
							});
				}
			}
		}

	}

	private boolean checkGridContexMenuOpenCondition(GridContextClickEvent tagGridContextEvent)
	{
		return tagGridContextEvent.getButton().equals(MouseButton.RIGHT)
				&& tagGridContextEvent.getSection().equals(Section.BODY)
				&& tagGridContextEvent.getItemId() != null && tagGrid.getSelectedRows().isEmpty();
	}

	public void assignTagsToWagons(ArrayList<Tag> tagListToAssign)
	{

		List<Tag> tagsSelectedForAssign = tagListToAssign.isEmpty() ? tagGrid.getSelectedRows()
				.stream().map(rowMapper -> (Tag) rowMapper).collect(Collectors.toList())
				: tagListToAssign;
		if (wagonGrid.getSelectedRows().size() > 0 && tagsSelectedForAssign.size() > 0)
		{
			Set<Tag> tagSetToShow = new HashSet<>();
			final List<Wagon> assginedWagons = wagonGrid.getSelectedRows().stream()
					.map(object -> (Wagon) object)
					.collect((Supplier<List<Wagon>>) ArrayList::new, (list, wagon) -> {
						List<Tag> tagListToSet = new ArrayList<>();
						tagListToSet.addAll(tagsSelectedForAssign);
						tagListToSet.removeAll(wagon.getTags());
						if (tagListToSet.size() > 0)
						{
							wagon.setTags(tagListToSet);
							list.add(wagon);
							tagSetToShow.addAll(tagListToSet);
						}
					} , (combiningList, collectedList) -> combiningList.addAll(collectedList));

			wagonGrid.setCellStyleGenerator(wagonGrid.getCellStyleGenerator());
			if (assginedWagons.size() > 0)
			{
				DashboardEventBus.post(
						new TagAssignChangeEvent(assginedWagons, tagsSelectedForAssign, true));
				Notification.show(getCommaSeparatedTagsFromTagList(
						tagSetToShow.stream().collect(Collectors.toList()))
						+ " "
						+ DashboardUI.getMessageSource()
								.getMessage("view.overview.tag.notification.assigned")
						+ " " + assginedWagons.size(), Type.TRAY_NOTIFICATION);
				tagsSelectedForAssign.forEach(rowObject -> ((Tag) rowObject).setAssigned(true));
			}
			else
			{
				Notification.show(
						getCommaSeparatedTagsFromTagList(tagsSelectedForAssign) + " "
								+ DashboardUI.getMessageSource().getMessage(
										"view.overview.tag.notification.assigned.already"),
						Type.TRAY_NOTIFICATION);
			}
			wagonGrid.getSelectionModel().reset();
			tagGrid.getSelectionModel().reset();
		}
	}

	public void unassignTagsFromWagons(ArrayList<Tag> tagListToUnassign)
	{
		List<Tag> tagsSelectedForUnassign = tagListToUnassign.isEmpty() ? tagGrid.getSelectedRows()
				.stream().map(rowMapper -> (Tag) rowMapper).collect(Collectors.toList())
				: tagListToUnassign;
		if (wagonGrid.getSelectedRows().size() > 0 && tagsSelectedForUnassign.size() > 0)
		{
			List<Wagon> filteredWagonList = wagonGrid.getSelectedRows().stream()
					.map(rowMapper -> (Wagon) rowMapper)
					.filter(wagonFilterObject -> wagonFilterObject.getTags().stream()
							.anyMatch(anyTagMatch -> tagsSelectedForUnassign.contains(anyTagMatch)))
					.collect(Collectors.toList());
			DashboardEventBus.post(
					new TagAssignChangeEvent(filteredWagonList, tagsSelectedForUnassign, false));
			filteredWagonList.forEach(
					wagonMapper -> wagonMapper.getTags().removeAll(tagsSelectedForUnassign));

			tagsSelectedForUnassign.forEach(tagToUnAssign -> {
				tagToUnAssign.setAssigned(wagonGrid.getContainerDataSource().getItemIds().stream()
						.anyMatch(wagonFilterObject -> ((Wagon) wagonFilterObject).getTags()
								.contains(tagToUnAssign)));

			});
			wagonGrid.getSelectionModel().reset();
			tagGrid.getSelectionModel().reset();
			Notification.show(getCommaSeparatedTagsFromTagList(tagsSelectedForUnassign) + " "
					+ DashboardUI.getMessageSource()
							.getMessage("view.overview.tag.notification.unassigned")
					+ " " + filteredWagonList.size(), Type.TRAY_NOTIFICATION);
		}

	}

	public void deleteTags(ArrayList<Tag> tagListToDelete, Button deleteButton, Button editButton)
	{
		List<Tag> tagsSelectedForDelete = tagListToDelete.isEmpty() ? tagGrid.getSelectedRows()
				.stream().map(rowMapper -> (Tag) rowMapper).collect(Collectors.toList())
				: tagListToDelete;
		if (tagsSelectedForDelete.size() > 0)
		{
			List<Tag> tagsNotAssigned = tagsSelectedForDelete.stream()
					.filter(tagObject -> !tagObject.isAssigned()).collect(Collectors.toList());
			if (tagsNotAssigned.size() > 0)
			{
				DashboardEventBus.post(new DeleteTagEvent(tagsNotAssigned));
				tagsNotAssigned.forEach(tagToRemove -> {
					tagGrid.getContainerDataSource().removeItem(tagToRemove);
					tagListForGrid.remove(tagToRemove);
				});
				Notification.show(
						getCommaSeparatedTagsFromTagList(tagsNotAssigned) + " "
								+ DashboardUI.getMessageSource()
										.getMessage("view.overview.tag.notification.delete"),
						Type.HUMANIZED_MESSAGE);
			}
			if (deleteButton != null)
				deleteButton.setEnabled(false);
			if (editButton != null)
				editButton.setEnabled(false);
			tagGrid.getSelectionModel().reset();
		}
		if (tagsSelectedForDelete.stream().anyMatch(tagObject -> tagObject.isAssigned()))
		{

			Notification.show(DashboardUI.getMessageSource()
					.getMessage("view.overview.tag.notification.error")
					+ "  "
					+ getCommaSeparatedTagsFromTagList(tagsSelectedForDelete.stream()
							.filter(tagObject -> tagObject.isAssigned())
							.collect(Collectors.toList())),
					Type.WARNING_MESSAGE);

		}

	}

	private String getCommaSeparatedTagsFromTagList(List<Tag> listOfTags)
	{
		return listOfTags.stream().map(tagMapper -> tagMapper.getTagName())
				.reduce((firstTag, secondTag) -> firstTag + "," + secondTag).get();
	}

}
