
package com.bosch.si.amra.view.role;

import java.util.List;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.component.WagonUserAssignmentWindow;
import com.bosch.si.amra.constants.role.UserRolesConstants;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.WagonUser;
import com.bosch.si.amra.entity.WagonUsers;
import com.bosch.si.amra.event.DashboardEvent.BrowserResizeEvent;
import com.bosch.si.amra.event.DashboardEvent.GetAllUsersEvent;
import com.bosch.si.amra.event.DashboardEvent.ReceivedAllUsersEvent;
import com.bosch.si.amra.event.DashboardEvent.UserToWagonAssignedEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.im.login.Role;
import com.bosch.si.amra.im.login.Role.Roles;
import com.bosch.si.amra.view.role.listener.RoleTableListener;
import com.google.common.eventbus.Subscribe;
import com.vaadin.data.Container.Filter;
import com.vaadin.data.Container.Filterable;
import com.vaadin.data.Property;
import com.vaadin.data.Property.ValueChangeEvent;
import com.vaadin.data.util.filter.Or;
import com.vaadin.data.util.filter.SimpleStringFilter;
import com.vaadin.event.FieldEvents.TextChangeEvent;
import com.vaadin.event.FieldEvents.TextChangeListener;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.event.ShortcutListener;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Page;
import com.vaadin.server.Responsive;
import com.vaadin.server.VaadinSession;
import com.vaadin.ui.Button;
import com.vaadin.ui.CheckBox;
import com.vaadin.ui.Component;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.TextField;
import com.vaadin.ui.TreeTable;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

@Role ({ Roles.FLEETADMIN, Roles.SYSTEMADMIN })
@SuppressWarnings ("serial")
public class RoleView extends VerticalLayout implements View
{
	private TextField		filter;

	private final TreeTable	treeTable	= new TreeTable();

	private Button			editWagonUserRoles;

	private final User		user		= (User) VaadinSession.getCurrent()
			.getAttribute(User.class.getName());

	private final CheckBox	expandAll	= new CheckBox();;

	public RoleView()
	{
		setSizeFull();
		addStyleName("role");
		DashboardEventBus.register(this);

		addComponent(buildToolbar());

		buildTable();
		addComponent(treeTable);
		setExpandRatio(treeTable, 1);
	}

	@Override
	public void detach()
	{
		super.detach();
		// This view gets re-instantiated every time it's navigated to so we'll
		// need to clean up references to it on detach.
		DashboardEventBus.unregister(this);
	}

	private Component buildToolbar()
	{
		HorizontalLayout header = new HorizontalLayout();
		header.addStyleName("viewheader");
		header.setSpacing(true);
		Responsive.makeResponsive(header);

		Label title = new Label(DashboardUI.getMessageSource().getMessage("view.role.caption"));
		title.setSizeUndefined();
		title.addStyleName(ValoTheme.LABEL_H1);
		title.addStyleName(ValoTheme.LABEL_NO_MARGIN);
		header.addComponent(title);

		HorizontalLayout tools = new HorizontalLayout(buildFilter());
		editWagonUserRoles = new Button(FontAwesome.EDIT);
		editWagonUserRoles.setDescription(
				DashboardUI.getMessageSource().getMessage("view.role.edit.tooltip"));
		editWagonUserRoles.addClickListener(event -> {
			if (treeTable.getValue() instanceof WagonUsers)
			{
				DashboardEventBus.post(
						new GetAllUsersEvent(user, ((WagonUsers) treeTable.getValue()).getId()));
			}
			else
			{
				DashboardEventBus.post(new GetAllUsersEvent(user,
						((WagonUser) treeTable.getValue()).getWagonId()));
			}
		});
		editWagonUserRoles.setEnabled(false);
		CheckBox expandAll = buildExpandAllCheckBox();
		tools.addComponents(editWagonUserRoles, expandAll);
		tools.setSpacing(true);
		tools.addStyleName("toolbar");
		header.addComponent(tools);

		return header;
	}

	private Component buildFilter()
	{
		filter = new TextField();
		filter.addTextChangeListener(new TextChangeListener()
		{
			@Override
			public void textChange(final TextChangeEvent event)
			{
				filter(event.getText(), event.getText().isEmpty() ? true : false);
			}
		});

		filter.setInputPrompt(DashboardUI.getMessageSource().getMessage("view.role.input.filter"));
		filter.setIcon(FontAwesome.SEARCH);
		filter.addStyleName(ValoTheme.TEXTFIELD_INLINE_ICON);
		filter.addShortcutListener(new ShortcutListener("Clear", KeyCode.ESCAPE, null)
		{
			@Override
			public void handleAction(Object sender, Object target)
			{
				filter.setValue("");
				filter(filter.getValue(), true);
			}
		});
		return filter;
	}

	private void filter(String value, boolean collapsed)
	{
		Filterable data = (Filterable) treeTable.getContainerDataSource();
		data.removeAllContainerFilters();
		if (value != null && !value.isEmpty())
		{
			Filter filter = new Or(
					new SimpleStringFilter(UserRolesConstants.ALIAS, value, true, false),
					new SimpleStringFilter(UserRolesConstants.DISPONENTS, value, true, false));
			data.addContainerFilter(filter);
			expandAll.setEnabled(false);
		}
		else
		{
			expandAll.setEnabled(true);
			createContainer(DashboardUI.getDisponentsRolesDataProvider()
					.getUsers2WagonAssignment(user.getTenant()));
		}
		for (Object itemId : treeTable.getContainerDataSource().getItemIds())
		{
			treeTable.setCollapsed(itemId, collapsed);
		}
	}

	public CheckBox buildExpandAllCheckBox()
	{
		// final CheckBox expandAll = new CheckBox();
		expandAll.addStyleName(ValoTheme.BUTTON_ICON_ONLY);
		expandAll.setImmediate(true);
		expandAll.setValue(true);
		expandAll.addStyleName("checkBox");
		expandAll.setDescription(
				DashboardUI.getMessageSource().getMessage("view.role.expand.tooltip"));
		expandAll.addValueChangeListener(new Property.ValueChangeListener()
		{
			@Override
			public void valueChange(ValueChangeEvent event)
			{
				boolean collapsed = (boolean) event.getProperty().getValue();
				for (Object itemId : treeTable.getContainerDataSource().getItemIds())
				{
					treeTable.setCollapsed(itemId, collapsed);
				}
				expandAll.setDescription(DashboardUI.getMessageSource().getMessage(
						collapsed ? "view.role.expand.tooltip" : "view.role.collapse.tooltip"));
			}
		});
		return expandAll;
	}

	private TreeTable buildTable()
	{
		configureTreeTableStyle();
		configureContainerProperties();
		configureColumns();
		configureTreeTable();
		createContainer(DashboardUI.getDisponentsRolesDataProvider()
				.getUsers2WagonAssignment(user.getTenant()));

		RoleTableListener listener = new RoleTableListener(this);
		treeTable.addValueChangeListener(listener);
		treeTable.addItemClickListener(listener);
		treeTable.setCellStyleGenerator(new RoleTableCellStyleGenerator());

		return treeTable;
	}

	private void configureTreeTableStyle()
	{
		treeTable.addStyleName(ValoTheme.TABLE_BORDERLESS);
		treeTable.addStyleName(ValoTheme.TABLE_NO_HORIZONTAL_LINES);
		treeTable.addStyleName(ValoTheme.TABLE_COMPACT);
	}

	private void configureTreeTable()
	{
		treeTable.setSizeFull();
		treeTable.setSelectable(true);
		treeTable.setColumnCollapsingAllowed(true);
		treeTable.setColumnReorderingAllowed(true);
		treeTable.setMultiSelect(false);
		treeTable.setCacheRate(5);
		treeTable.setImmediate(true);
		treeTable.setSortAscending(false);
	}

	private void configureContainerProperties()
	{
		treeTable.addContainerProperty(UserRolesConstants.ALIAS, String.class, null);
		treeTable.addContainerProperty(UserRolesConstants.WAGON_TYPE, String.class, null);
		treeTable.addContainerProperty(UserRolesConstants.DISPONENTS, String.class, null);
		treeTable.setSortContainerPropertyId(UserRolesConstants.ALIAS);
	}

	private void configureColumns()
	{
		treeTable.setColumnCollapsible(UserRolesConstants.ALIAS, false);
		treeTable.setColumnCollapsible(UserRolesConstants.WAGON_TYPE, false);
		treeTable.setColumnCollapsible(UserRolesConstants.DISPONENTS, false);
		treeTable.setVisibleColumns(UserRolesConstants.PROPERTY_IDS);
		for (Object propertyId : UserRolesConstants.PROPERTY_IDS)
		{
			treeTable.setColumnHeader(propertyId, DashboardUI.getMessageSource()
					.getMessage("view.role.columnheader." + ((String) propertyId).toLowerCase()));
		}
		treeTable.setColumnExpandRatio(UserRolesConstants.ALIAS, 1.0f);
		treeTable.setColumnExpandRatio(UserRolesConstants.WAGON_TYPE, 1.0f);
		treeTable.setColumnExpandRatio(UserRolesConstants.DISPONENTS, 2.0f);
	}

	private void createContainer(List<WagonUsers> disponents)
	{
		if (disponents != null && disponents.size() > 0)
		{
			treeTable.removeAllItems();
			for (WagonUsers parent : disponents)
			{
				treeTable.addItem(new Object[] { parent.getAlias(), parent.getTypeName(), null },
						parent);
				treeTable.setChildrenAllowed(parent, true);
				for (WagonUser wagonUser : parent.getDisponents())
				{
					treeTable.addItem(new Object[] { null, null, wagonUser.getDescription() },
							wagonUser);
					treeTable.setParent(wagonUser, parent);
					treeTable.setChildrenAllowed(wagonUser, false);
				}

				for (WagonUser wagonUser : parent.getEndcustomers())
				{
					treeTable.addItem(new Object[] { null, null, wagonUser.getDescription() },
							wagonUser);
					treeTable.setParent(wagonUser, parent);
					treeTable.setChildrenAllowed(wagonUser, false);
				}
			}
		}
	}

	private boolean defaultColumnsVisible()
	{
		boolean result = true;
		for (String propertyId : UserRolesConstants.DEFAULT_COLLAPSIBLE)
		{
			if (treeTable.isColumnCollapsed(
					propertyId) == Page.getCurrent().getBrowserWindowWidth() < 800)
			{
				result = false;
			}
		}
		return result;
	}

	@Subscribe
	public void browserResized(BrowserResizeEvent event)
	{
		if (defaultColumnsVisible())
		{
			for (String propertyId : UserRolesConstants.DEFAULT_COLLAPSIBLE)
			{
				treeTable.setColumnCollapsed(propertyId,
						Page.getCurrent().getBrowserWindowWidth() < 800);
			}
		}
	}

	@Subscribe
	public void editSelectedWagon(ReceivedAllUsersEvent event)
	{
		List<WagonUser> availableUsers = event.getUsers();
		String selectedWagonId = event.getSelectedWagonId();
		List<WagonUser> assignedDisponents = DashboardUI.getDisponentsRolesDataProvider()
				.getAssignedDisponentsForWagon(user.getTenant(), selectedWagonId);
		List<WagonUser> assignedEndCustomers = DashboardUI.getDisponentsRolesDataProvider()
				.getAssignedEndCustomersForWagon(user.getTenant(), selectedWagonId);

		WagonUserAssignmentWindow wagonUserAssignmentWindow = new WagonUserAssignmentWindow(
				selectedWagonId);
		wagonUserAssignmentWindow.setContainerDataSource(availableUsers, assignedDisponents,
				assignedEndCustomers);

		DashboardUI.getCurrent().addWindow(wagonUserAssignmentWindow);
	}

	@Subscribe
	public void assignmentSuccessful(UserToWagonAssignedEvent event)
	{
		createContainer(DashboardUI.getDisponentsRolesDataProvider()
				.getUsers2WagonAssignment(user.getTenant()));
		Notification.show(DashboardUI.getMessageSource().getMessage("view.role.success"));
	}

	public void valueChange()
	{
		editWagonUserRoles.setEnabled(treeTable.isRoot(treeTable.getValue()));
	}

	@Override
	public void enter(ViewChangeEvent event)
	{
	}
}