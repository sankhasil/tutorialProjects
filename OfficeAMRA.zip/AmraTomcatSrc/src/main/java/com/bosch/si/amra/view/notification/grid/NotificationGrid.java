
package com.bosch.si.amra.view.notification.grid;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.component.converter.AddressConverter;
import com.bosch.si.amra.component.converter.TimestampConverter;
import com.bosch.si.amra.component.filter.TimestampFilter;
import com.bosch.si.amra.constants.notification.NotificationConstants;
import com.bosch.si.amra.entity.notification.Notification;
import com.bosch.si.amra.entity.notification.Notification.Priority;
import com.bosch.si.amra.view.notification.NotificationTableCellStyleGenerator;
import com.bosch.si.amra.view.notification.converter.PriorityConverter;
import com.bosch.si.amra.view.notification.filter.PositionFilter;
import com.bosch.si.amra.view.notification.filter.ReasonFilter;
import com.vaadin.data.Container;
import com.vaadin.data.Container.Filter;
import com.vaadin.data.util.GeneratedPropertyContainer;
import com.vaadin.data.util.filter.SimpleStringFilter;
import com.vaadin.shared.data.sort.SortDirection;
import com.vaadin.ui.AbstractComponent;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.Grid;
import com.vaadin.ui.TextField;
import com.vaadin.ui.themes.ValoTheme;

/**
 * @author toa1wa3
 *
 */
public class NotificationGrid extends Grid
{
	/**
	 * Serial version uid
	 */
	private static final long				serialVersionUID					= 1023946823453151108L;

	private Map<AbstractComponent, Object>	componentToPidMap					= new HashMap<>();

	private static final int				TIMESTAMP_COLUMN_WIDTH				= 220;

	private static final int				PRIORITY_COLUMN_WIDTH				= 146;

	private static final int				LATITUDE_AND_LONGITUDE_COLUMN_WIDTH	= 119;

	private static final int				ADDRESS_COLUMN_WIDTH				= 394;

	public NotificationGrid(final Container.Indexed dataSource)
	{
		super(dataSource);
		setSizeFull();
		addStyleName(ValoTheme.TABLE_BORDERLESS);
		addStyleName(ValoTheme.TABLE_NO_HORIZONTAL_LINES);
		addStyleName(ValoTheme.TABLE_COMPACT);
		setImmediate(true);
		setResponsive(true);
		setEditorEnabled(false);
		removeAllColumns();
		setColumns(NotificationConstants.PROPERTY_IDS);
		setColumnOrder(NotificationConstants.PROPERTY_IDS);
		setColumnReorderingAllowed(true);
		setSelectionMode(SelectionMode.MULTI);
		sort(NotificationConstants.TIMESTAMP, SortDirection.DESCENDING);
		HeaderRow filterRow = appendHeaderRow();
		addFilterRow(filterRow);
		for (Object propertyId : NotificationConstants.PROPERTY_IDS)
		{
			getColumn(propertyId)
					.setHeaderCaption(
							DashboardUI.getMessageSource()
									.getMessage("view.notification.columnheader."
											+ ((String) propertyId).toLowerCase()))
					.setHidable(true);
		}
		setCellStyleGenerator(new NotificationTableCellStyleGenerator());
		getColumn(NotificationConstants.TIMESTAMP).setConverter(new TimestampConverter())
				.setWidth(TIMESTAMP_COLUMN_WIDTH);
		getColumn(NotificationConstants.PRIORITY).setConverter(new PriorityConverter())
				.setWidth(PRIORITY_COLUMN_WIDTH);
		getColumn(NotificationConstants.STREET_CITY).setConverter(new AddressConverter())
				.setWidth(ADDRESS_COLUMN_WIDTH);
		getColumn(NotificationConstants.LATITUDE).setWidth(LATITUDE_AND_LONGITUDE_COLUMN_WIDTH);
		getColumn(NotificationConstants.LONGITUDE).setWidth(LATITUDE_AND_LONGITUDE_COLUMN_WIDTH);
	}

	public Map<AbstractComponent, Object> getComponentToPidMap()
	{
		return componentToPidMap;
	}

	private void addFilterRow(HeaderRow filterRow)
	{

		for (Object pid : NotificationConstants.PROPERTY_IDS)
		{

			HeaderCell cell = filterRow.getCell(pid);

			AbstractComponent filterField;

			if (pid.equals(NotificationConstants.TIMESTAMP))
			{
				filterField = new TimestampFilter<Notification>(pid, this);
			}
			else if (pid.equals(NotificationConstants.PRIORITY))
			{
				filterField = new PriorityFilter(pid, this);
			}
			else
			{
				filterField = new NotificationFilter(pid, this);
			}
			componentToPidMap.put(filterField, pid);
			cell.setComponent(filterField);
		}
	}

	private static class NotificationFilter extends TextField
	{
		/**
		 * Serial version uid
		 */
		private static final long serialVersionUID = 2925003614554210480L;

		public NotificationFilter(Object pid, NotificationGrid notificationGrid)
		{
			setWidth("100%");
			setHeight("75%");
			setNullRepresentation("");
			setNullSettingAllowed(true);
			addTextChangeListener(change -> {
				GeneratedPropertyContainer notificationGridContainer = (GeneratedPropertyContainer) notificationGrid
						.getContainerDataSource();
				if (pid != null)
				{
					List<Filter> removedFilter = notificationGridContainer.getContainerFilters()
							.stream().filter(filter -> filter.appliesToProperty(pid))
							.collect(Collectors.toList());
					removedFilter.stream().forEach(filterToBeRemoved -> notificationGridContainer
							.removeContainerFilter(filterToBeRemoved));
					if (!change.getText().isEmpty())
					{
						if (pid.equals(NotificationConstants.REASON))
							notificationGridContainer.addContainerFilter(
									new ReasonFilter(pid, change.getText(), true, false));
						else if (pid.equals(NotificationConstants.LATITUDE)
								|| pid.equals(NotificationConstants.LONGITUDE))
							notificationGridContainer
									.addContainerFilter(new PositionFilter(pid, change.getText()));
						else
							notificationGridContainer.addContainerFilter(
									new SimpleStringFilter(pid, change.getText(), true, false));
					}
				}
			});
		}
	}

	private static class PriorityFilter extends ComboBox
	{
		/**
		 * Serial version uid
		 */
		private static final long serialVersionUID = 7408529949272361694L;

		public PriorityFilter(Object pid, NotificationGrid notificationGrid)
		{
			List<Priority> priorityValues = Arrays.asList(Priority.values());
			addItems(priorityValues);
			setWidth("100%");
			setHeight("75%");
			setItemCaptionMode(ItemCaptionMode.EXPLICIT);
			setNullSelectionAllowed(true);
			priorityValues.forEach(
					priority -> setItemCaption(priority, DashboardUI.getMessageSource().getMessage(
							"view.notification.priority." + priority.name().toLowerCase().trim())));
			addValueChangeListener(event -> {
				GeneratedPropertyContainer notificationGridContainer = (GeneratedPropertyContainer) notificationGrid
						.getContainerDataSource();
				List<Filter> removedFilter = notificationGridContainer.getContainerFilters()
						.stream().filter(filter -> filter.appliesToProperty(pid))
						.collect(Collectors.toList());
				removedFilter.stream().forEach(filterToBeRemoved -> notificationGridContainer
						.removeContainerFilter(filterToBeRemoved));
				if (event.getProperty().getValue() != null)
					notificationGridContainer.addContainerFilter(new SimpleStringFilter(pid,
							event.getProperty().getValue().toString(), true, false));
			});
		}
	}
}
