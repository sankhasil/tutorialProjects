
package com.bosch.si.amra.provider;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.constants.UIConstants;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.entity.report.MileageValue;
import com.bosch.si.amra.entity.report.SensorValue;
import com.mongodb.AggregationOutput;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

@Component
public class AggregationDataProvider
{

	private static final String		TENANT_ID_MUST_NOT_BE_NULL	= "Tenant id must not be null";

	private static final Logger		logger						= LoggerFactory
			.getLogger(AggregationDataProvider.class);

	private final SimpleDateFormat	format						= new SimpleDateFormat("yy-MM-dd");

	SimpleDateFormat				dateFormatUTC				= new SimpleDateFormat(
			"yy-MM-dd HH:mm:ss");

	public Map<String, List<MileageValue>> getMileage(String tenantId, List<String> wagonIds,
			Date startDate)
	{
		if (tenantId == null || tenantId.isEmpty() || wagonIds == null || wagonIds.isEmpty()
				|| startDate == null)
		{
			throw new IllegalArgumentException(TENANT_ID_MUST_NOT_BE_NULL);
		}

		format.setTimeZone(TimeZone.getTimeZone("UTC"));

		Map<String, List<MileageValue>> mileageReportMap = new HashMap<>();

		AggregationOutput mileageCursor = aggreagteMileage(tenantId, wagonIds, startDate);

		if (mileageCursor != null && mileageCursor.results() != null)
		{
			for (Iterator<DBObject> iterator = mileageCursor.results().iterator(); iterator
					.hasNext();)
			{
				List<MileageValue> mileageValues = new ArrayList<>();
				DBObject mileageObject = iterator.next();
				DBObject id = (DBObject) mileageObject.get(MongoConstants.ID);
				String alias = (String) id.get(MongoConstants.ALIAS);
				BasicDBList values = (BasicDBList) mileageObject.get("values");
				for (Object value : values)
				{
					try
					{
						DBObject valueObject = (DBObject) value;
						MileageValue mileageValue = new MileageValue(
								format.parse((String) valueObject.get("date")),
								(Integer) valueObject.get("mileage"));
						mileageValues.add(mileageValue);
					}
					catch (ParseException e)
					{
						logger.debug("Failured parsing date", e);
					}
				}
				mileageReportMap.put(alias, mileageValues);
			}
		}
		return mileageReportMap;
	}

	public Map<String, List<SensorValue>> getSensorValues(String tenantId, List<String> wagonIds,
			Date startDate)
	{
		if (tenantId == null || tenantId.isEmpty() || wagonIds == null || wagonIds.isEmpty()
				|| startDate == null)
		{
			throw new IllegalArgumentException(TENANT_ID_MUST_NOT_BE_NULL);
		}

		dateFormatUTC.setTimeZone(TimeZone.getTimeZone("UTC"));

		Map<String, List<SensorValue>> sensorReportMap = new HashMap<>();

		AggregationOutput sensorCursor = aggregateSensorData(tenantId, wagonIds, startDate);

		if (sensorCursor != null && sensorCursor.results() != null)
		{
			for (Iterator<DBObject> iterator = sensorCursor.results().iterator(); iterator
					.hasNext();)
			{
				List<SensorValue> sensorValues = new ArrayList<>();
				DBObject sensorObject = iterator.next();
				DBObject id = (DBObject) sensorObject.get(MongoConstants.ID);
				String alias = (String) id.get(MongoConstants.ALIAS);
				BasicDBList values = (BasicDBList) sensorObject.get("values");

				for (Object value : values)
				{
					DBObject valueObject = (DBObject) value;
					SensorValue sensorValue = new SensorValue();
					String timestamp = (String) valueObject.get("date") + " "
							+ (String) valueObject.get("time");
					try
					{
						sensorValue.setTimestamp(dateFormatUTC.parse(timestamp));
						BasicDBList humidityList = (BasicDBList) valueObject
								.get(MongoConstants.HUMIDITY);
						if (humidityList != null && !humidityList.isEmpty())
						{
							Double humidity = (Double) humidityList.get(0);
							sensorValue.setHumidity(humidity.intValue());
						}

						BasicDBList deviceTemperatureList = (BasicDBList) valueObject
								.get(MongoConstants.DEVICE_TEMPERATURE);
						if (deviceTemperatureList != null && !deviceTemperatureList.isEmpty())
						{
							Integer deviceTemperature = (Integer) deviceTemperatureList.get(0);
							sensorValue.setTemperature(deviceTemperature);
						}

						BasicDBList humidityTemperatureList = (BasicDBList) valueObject
								.get(MongoConstants.HUMIDITY_TEMPERATURE);
						if (humidityTemperatureList != null && !humidityTemperatureList.isEmpty())
						{
							Double setHumidityTemperature = (Double) humidityTemperatureList.get(0);
							sensorValue.setHumidityTemperature(setHumidityTemperature.intValue());
						}

						BasicDBList cityList = (BasicDBList) valueObject.get("city");
						if (cityList != null && cityList.size() > 0)
						{
							String city = (String) cityList.get(0);
							sensorValue.setCity(city != null ? city : "");
						}
						else
						{
							sensorValue.setCity("");
						}

						sensorValues.add(sensorValue);
					}
					catch (ParseException e)
					{
						logger.debug("Failured parsing date", e);
					}
				}
				sensorReportMap.put(alias, sensorValues);
			}
		}
		return sensorReportMap;
	}

	public List<Wagon> getTopFiveMileage(User user)
	{
		if (user == null)
			throw new IllegalArgumentException(TENANT_ID_MUST_NOT_BE_NULL);
		if (user.getTenant() == null || user.getTenant().isEmpty())
			throw new IllegalArgumentException(TENANT_ID_MUST_NOT_BE_NULL);
		List<Wagon> topFiveMileageWagons = new ArrayList<>();

		AggregationOutput telematicCursor = aggregateMileage(user);
		Map<String, Integer> mapOffset = buildOffsetMap(telematicCursor);

		if (telematicCursor != null && telematicCursor.results() != null)
		{
			for (Iterator<DBObject> iterator = telematicCursor.results().iterator(); iterator
					.hasNext();)
			{
				DBObject telematicObject = iterator.next();
				String alias = (String) telematicObject.get(MongoConstants.ID);
				Integer mileage = (Integer) telematicObject.get("mileage");
				if (mapOffset.containsKey(alias) && mapOffset.get(alias) != null)
					mileage = mileage + mapOffset.get(alias);
				Wagon topFiveMileageWagon = new Wagon();
				topFiveMileageWagon.setAlias(alias);
				topFiveMileageWagon.setMileage(mileage);
				topFiveMileageWagons.add(topFiveMileageWagon);
			}
		}
		if (topFiveMileageWagons.size() > 0)
		{
			topFiveMileageWagons.sort((Wagon w1, Wagon w2) -> w2.getMileage() - w1.getMileage());

			topFiveMileageWagons = topFiveMileageWagons.size() >= 5
					? topFiveMileageWagons.subList(0, 5) : topFiveMileageWagons;
			return topFiveMileageWagons;
		}
		else
			return topFiveMileageWagons;
	}

	private Map<String, Integer> buildOffsetMap(AggregationOutput aggregate)
	{
		BasicDBList wagonList = new BasicDBList();
		for (Iterator<DBObject> iterator = aggregate.results().iterator(); iterator.hasNext();)
		{
			DBObject telematicObject = iterator.next();
			String alias = (String) telematicObject.get(MongoConstants.ID);
			wagonList.add(alias);
		}

		DBObject obj = new BasicDBObject("$in", wagonList);

		DBObject criteria = new BasicDBObject(MongoConstants.ALIAS, obj);
		DBObject isExists = new BasicDBObject("$exists", true);
		criteria.put(MongoConstants.OFFSET, isExists);
		DBObject projection = new BasicDBObject(MongoConstants.ALIAS, 1);
		projection.put(MongoConstants.OFFSET, 1);
		projection.put(MongoConstants.ID, 0);
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB eventDatabase = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection wagonCollection = eventDatabase
				.getCollection(DashboardUI.getWagonCollection());
		DBCursor cursor = wagonCollection.find(criteria, projection);

		Map<String, Integer> offsetMap = new HashMap<String, Integer>();
		for (Iterator<DBObject> iterator = cursor.iterator(); iterator.hasNext();)
		{
			DBObject telematicObject = iterator.next();
			offsetMap.put((String) telematicObject.get(MongoConstants.ALIAS),
					(Integer) telematicObject.get(MongoConstants.OFFSET));
		}

		return offsetMap;
	}

	/**
	 * Groups the summarized mileage per day for the given box id under the given tenant from the
	 * start date
	 *
	 * @param tenantId
	 * @param wagonIds
	 * @param startDate
	 * @return Mileage per day for given box id
	 */
	private AggregationOutput aggreagteMileage(String tenantId, List<String> wagonIds,
			Date startDate)
	{
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB eventDatabase = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection mileageCollection = eventDatabase
				.getCollection(DashboardUI.getMongoMileageCollection());

		BasicDBList matchWagonIds = new BasicDBList();
		matchWagonIds.addAll(wagonIds);
		DBObject wagonIdMatch = new BasicDBObject("$in", matchWagonIds);
		DBObject matchData = new BasicDBObject(MongoConstants.WAGON_ID, wagonIdMatch);
		matchData.put(MongoConstants.TENANT_ID, tenantId);
		matchData.put(MongoConstants.DATE, new BasicDBObject("$gte", format.format(startDate)));
		DBObject match = new BasicDBObject("$match", matchData);

		DBObject group = new BasicDBObject(MongoConstants.WAGON_ID, "$WI");
		group.put(MongoConstants.DATE, "$DA");
		group.put(MongoConstants.ALIAS, "$" + MongoConstants.ALIAS);
		DBObject groupData = new BasicDBObject(MongoConstants.ID, group);
		groupData.put("KM", new BasicDBObject("$sum", "$KM"));
		DBObject groupOne = new BasicDBObject("$group", groupData);

		DBObject finalGroupId = new BasicDBObject(MongoConstants.WAGON_ID,
				"$" + MongoConstants.ID + "." + MongoConstants.WAGON_ID);
		finalGroupId.put(MongoConstants.ALIAS,
				"$" + MongoConstants.ID + "." + MongoConstants.ALIAS);
		DBObject finalGroup = new BasicDBObject(MongoConstants.ID, finalGroupId);
		DBObject addedData = new BasicDBObject("date", "$_id.DA");
		addedData.put("mileage", "$KM");
		DBObject addToSet = new BasicDBObject("$addToSet", addedData);
		finalGroup.put("values", addToSet);
		DBObject groupTwo = new BasicDBObject("$group", finalGroup);

		AggregationOutput aggregate = mileageCollection
				.aggregate(Arrays.asList(match, groupOne, groupTwo));
		return aggregate;
	}

	private AggregationOutput aggregateSensorData(String tenantId, List<String> wagonIds,
			Date startDate)
	{
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB eventDatabase = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection eventCollection = eventDatabase
				.getCollection(DashboardUI.getEventCollection());

		BasicDBList matchWagonIds = new BasicDBList();
		matchWagonIds.addAll(wagonIds);
		DBObject wagonIdMatch = new BasicDBObject("$in", matchWagonIds);
		DBObject matchData = new BasicDBObject(MongoConstants.WAGON_ID, wagonIdMatch);
		matchData.put(MongoConstants.TENANT_ID, tenantId);
		matchData.put("D.DA", new BasicDBObject("$gte", format.format(startDate)));
		matchData.put("D.GF", new BasicDBObject("$eq", 3));
		DBObject match = new BasicDBObject("$match", matchData);

		DBObject idData = new BasicDBObject(MongoConstants.WAGON_ID, "$WI");
		idData.put(MongoConstants.DATE, "$D.DA");
		idData.put(MongoConstants.TIME, "$D.TM");
		idData.put(MongoConstants.ALIAS, "$" + MongoConstants.ALIAS);
		DBObject id = new BasicDBObject(MongoConstants.ID, idData);
		DBObject sensorData = new BasicDBObject(MongoConstants.HUMIDITY, "$D.HM");
		sensorData.put(MongoConstants.DEVICE_TEMPERATURE, "$D.DT");
		sensorData.put(MongoConstants.HUMIDITY_TEMPERATURE, "$D.HT");
		sensorData.put("city", "$address.address_components.locality");
		DBObject addToSet = new BasicDBObject("$addToSet", sensorData);
		id.put("values", addToSet);
		DBObject group = new BasicDBObject("$group", id);

		DBObject finalGroupId = new BasicDBObject(MongoConstants.WAGON_ID, "$_id.WI");
		finalGroupId.put(MongoConstants.ALIAS, "$_id.alias");
		DBObject finalGroup = new BasicDBObject(MongoConstants.ID, finalGroupId);
		DBObject addedData = new BasicDBObject("date", "$_id.DA");
		addedData.put("time", "$_id.TM");
		addedData.put(MongoConstants.HUMIDITY, "$values.HM");
		addedData.put(MongoConstants.DEVICE_TEMPERATURE, "$values.DT");
		addedData.put(MongoConstants.HUMIDITY_TEMPERATURE, "$values.HT");
		addedData.put("city", "$values.city");
		DBObject add = new BasicDBObject("$addToSet", addedData);
		finalGroup.put("values", add);
		DBObject groupTwo = new BasicDBObject("$group", finalGroup);

		AggregationOutput aggregate = eventCollection
				.aggregate(Arrays.asList(match, group, groupTwo));

		return aggregate;
	}

	/**
	 * Returns the mileage for all the wagons the given tenant grouped by the box id
	 *
	 * @param user
	 * @return The aggregate mileages for the the wagons for given tenantId
	 */
	private AggregationOutput aggregateMileage(User user)
	{
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB intializeMongoDatabase = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection mileageCollection = intializeMongoDatabase
				.getCollection(DashboardUI.getMongoMileageCollection());
		DBObject find = new BasicDBObject(MongoConstants.TENANT_ID, user.getTenant());
		DataProviderInitializer.restrictData(user, find, MongoConstants.WAGON_ID);
		DBObject match = new BasicDBObject("$match", find);
		DBObject groupData = new BasicDBObject(MongoConstants.ID, "$" + MongoConstants.ALIAS);
		groupData.put("mileage", new BasicDBObject("$sum", "$KM"));
		DBObject group = new BasicDBObject("$group", groupData);
		AggregationOutput aggregate = mileageCollection.aggregate(Arrays.asList(match, group));

		return aggregate;
	}

	public Wagon getMaximumHumidity(User user)
	{
		AggregationOutput humidityCursor = aggregateMaximumSparkValue(user, "D.HM",
				new Double(UIConstants.LOWERLIMIT_HUMIDITY),
				new Double(UIConstants.UPPERLIMIT_HUMIDITY));
		if (humidityCursor != null && humidityCursor.results().iterator().hasNext())
		{
			DBObject humidityObject = humidityCursor.results().iterator().next();
			DBObject data = (DBObject) humidityObject.get(MongoConstants.DATA_ELEMENT);
			if (data.containsField(MongoConstants.HUMIDITY))
			{
				Wagon humidityWagon = new Wagon();
				humidityWagon.setAlias((String) humidityObject.get(MongoConstants.ALIAS));
				humidityWagon.setHumidity(((Double) data.get(MongoConstants.HUMIDITY)).intValue());
				return humidityWagon;
			}
		}
		return null;

	}

	public Wagon getMaximumAmbientTemperature(User user)
	{
		AggregationOutput ambientTemperatureCursor = aggregateMaximumSparkValue(user, "D.DT", null,
				null);
		if (ambientTemperatureCursor != null
				&& ambientTemperatureCursor.results().iterator().hasNext())
		{
			DBObject ambientTemperatureObject = ambientTemperatureCursor.results().iterator()
					.next();
			DBObject data = (DBObject) ambientTemperatureObject.get(MongoConstants.DATA_ELEMENT);
			if (data.containsField(MongoConstants.DEVICE_TEMPERATURE))
			{
				Wagon ambientTemperatureWagon = new Wagon();
				ambientTemperatureWagon
						.setAlias((String) ambientTemperatureObject.get(MongoConstants.ALIAS));
				ambientTemperatureWagon.setTemperature(
						((Integer) data.get(MongoConstants.DEVICE_TEMPERATURE)).intValue());
				return ambientTemperatureWagon;
			}
		}
		return null;

	}

	public Wagon getMaximumPayloadTemperature(User user)
	{
		AggregationOutput payloadTemperatureCursor = aggregateMaximumSparkValue(user, "D.HT",
				new Integer(UIConstants.LOWERLIMIT_HUMIDITYTEMPERATURE),
				new Integer(UIConstants.UPPERLIMIT_HUMIDITYTEMPERATURE));
		if (payloadTemperatureCursor != null
				&& payloadTemperatureCursor.results().iterator().hasNext())
		{
			DBObject payloadTemperatureObject = payloadTemperatureCursor.results().iterator()
					.next();
			DBObject data = (DBObject) payloadTemperatureObject.get(MongoConstants.DATA_ELEMENT);
			if (data.containsField(MongoConstants.HUMIDITY_TEMPERATURE))
			{
				Wagon payloadTemperatureWagon = new Wagon();
				payloadTemperatureWagon
						.setAlias((String) payloadTemperatureObject.get(MongoConstants.ALIAS));
				payloadTemperatureWagon.setHumidityTemperature(
						((Double) data.get(MongoConstants.HUMIDITY_TEMPERATURE)).intValue());
				return payloadTemperatureWagon;
			}
		}
		return null;

	}

	private AggregationOutput aggregateMaximumSparkValue(User user, String sensorKey,
			Number lowerLimit, Number upperLimit)
	{
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB intializeMongoDatabase = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection currentCollection = intializeMongoDatabase
				.getCollection(DashboardUI.getMongoCurrentCollection());

		DBObject tenantAndLimitMatch = new BasicDBObject(MongoConstants.TENANT_ID,
				user.getTenant());
		DataProviderInitializer.restrictData(user, tenantAndLimitMatch, MongoConstants.ID);
		if (lowerLimit != null && upperLimit != null)
		{
			DBObject bounds = new BasicDBObject("$gte", lowerLimit.intValue());
			bounds.put("$lte", upperLimit.intValue());
			tenantAndLimitMatch.put(sensorKey, bounds);
		}
		DBObject match = new BasicDBObject("$match", tenantAndLimitMatch);

		DBObject sort = new BasicDBObject("$sort", new BasicDBObject(sensorKey, -1));

		DBObject limit = new BasicDBObject("$limit", 1);

		return currentCollection.aggregate(Arrays.asList(match, sort, limit));
	}

}
