
package com.bosch.si.amra.view.configuration;

import java.util.List;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.component.grid.ConfigurationGrid;
import com.bosch.si.amra.entity.configuration.Configuration;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.ui.Window;

class ConfigurationEditWindow extends Window
{
	private static final long serialVersionUID = -177961654168592482L;

	ConfigurationEditWindow(ConfigurationGrid configGrid, List<Configuration> configurations)
	{
		super(DashboardUI.getMessageSource().getMessage("view.configuration.subwindow.caption"));
		center();
		setModal(true);
		setWidth("30%");
		setHeight("90%");
		addCloseShortcut(KeyCode.ESCAPE, null);
		setId("window");
		EditConfigurationTabSheet tabSheet = new EditConfigurationTabSheet(this, configGrid,
				configurations);
		setContent(tabSheet);
	}
}
