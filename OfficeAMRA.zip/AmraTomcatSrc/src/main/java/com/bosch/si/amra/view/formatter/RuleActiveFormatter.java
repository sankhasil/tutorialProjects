
package com.bosch.si.amra.view.formatter;

import com.bosch.si.amra.entity.rule.Rule;
import com.vaadin.data.Property;
import com.vaadin.server.FontAwesome;

public class RuleActiveFormatter extends PropertyFormatter
{

	@Override
	public String format(Object rowId, Property<?> property, String result)
	{
		Rule rule = (Rule) rowId;
		return (rule.getActive() != null && rule.getActive())
				? new String(Character.toChars(FontAwesome.CHECK.getCodepoint()))
				: new String(Character.toChars(FontAwesome.TIMES.getCodepoint()));
	}

}
