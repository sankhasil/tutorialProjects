
package com.bosch.si.amra.view.notification.filter;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.notification.NotificationConstants;
import com.vaadin.data.Container.Filter;
import com.vaadin.data.Item;
import com.vaadin.data.Property;
import com.vaadin.server.Page;

/**
 * This filter is used to filter the reason in the notification view. We have to distinguish between
 * a "normal" reason
 * which is stored as rule name and the shunting shock detections. Therefore we have to have a look
 * if the provided property contains shunting shock detected or the rule name. For the rule name the
 * the name is taken into account but for shunting shock detected we have to transoform it to the
 * specific language and take this into account.
 *
 * @author toa1wa3
 *
 */
public class ReasonFilter implements Filter
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID		= 5257659475402316032L;

	private static final String	SHUNTING_SHOCK_DETECTED	= "shunting_shock_detected";

	private static final String	DOOR_OPENED_DETECTED	= "door_opened_detected";

	private static final String	DECIMAL_PATTERN			= "0.0";

	final Object				propertyId;

	final String				filterString;

	final boolean				ignoreCase;

	final boolean				onlyMatchPrefix;

	public ReasonFilter(Object propertyId, String filterString, boolean ignoreCase,
			boolean onlyMatchPrefix)
	{
		this.propertyId = propertyId;
		this.filterString = ignoreCase ? filterString.toLowerCase() : filterString;
		this.ignoreCase = ignoreCase;
		this.onlyMatchPrefix = onlyMatchPrefix;
	}

	@Override
	public boolean passesFilter(Object itemId, Item item) throws UnsupportedOperationException
	{
		final Property<?> p = item.getItemProperty(NotificationConstants.REASON);
		if (p == null)
		{
			return false;
		}
		Object propertyValue = p.getValue();
		if (propertyValue == null)
		{
			return false;
		}
		String value = "";
		if (propertyValue.toString().toLowerCase().contains(SHUNTING_SHOCK_DETECTED)
				|| propertyValue.toString().toLowerCase().equals(DOOR_OPENED_DETECTED))
		{
			value = DashboardUI.getMessageSource()
					.getMessage(
							"view.notification.reason." + propertyValue.toString().toLowerCase())
					.toLowerCase();
			if (propertyValue.toString().toLowerCase().contains(SHUNTING_SHOCK_DETECTED))
			{
				final Property<?> shockValueProperty = item
						.getItemProperty(NotificationConstants.SHOCK_VALUE);
				Object shockValuePropertyValue = shockValueProperty.getValue();
				if (shockValuePropertyValue != null)
					value += " (" + getNumberFormat().format(shockValuePropertyValue).toString()
							+ "G)";
			}
		}
		else
		{
			value = ignoreCase ? propertyValue.toString().toLowerCase() : propertyValue.toString();
		}
		if (onlyMatchPrefix)
		{
			if (!value.startsWith(filterString))
			{
				return false;
			}
		}
		else
		{
			if (!value.contains(filterString))
			{
				return false;
			}
		}
		return true;
	}

	@Override
	public boolean appliesToProperty(Object propertyId)
	{
		return this.propertyId.equals(propertyId);
	}

	private NumberFormat getNumberFormat()
	{
		return new DecimalFormat(DECIMAL_PATTERN,
				new DecimalFormatSymbols(Page.getCurrent().getWebBrowser().getLocale()));
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((filterString == null) ? 0 : filterString.hashCode());
		result = prime * result + (ignoreCase ? 1231 : 1237);
		result = prime * result + (onlyMatchPrefix ? 1231 : 1237);
		result = prime * result + ((propertyId == null) ? 0 : propertyId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ReasonFilter other = (ReasonFilter) obj;
		if (filterString == null)
		{
			if (other.filterString != null)
				return false;
		}
		else if (!filterString.equals(other.filterString))
			return false;
		if (ignoreCase != other.ignoreCase)
			return false;
		if (onlyMatchPrefix != other.onlyMatchPrefix)
			return false;
		if (propertyId == null)
		{
			if (other.propertyId != null)
				return false;
		}
		else if (!propertyId.equals(other.propertyId))
			return false;
		return true;
	}

	public Object getPropertyId()
	{
		return propertyId;
	}

	public String getFilterString()
	{
		return filterString;
	}

	public boolean isIgnoreCase()
	{
		return ignoreCase;
	}

	public boolean isOnlyMatchPrefix()
	{
		return onlyMatchPrefix;
	}
}
