
package com.bosch.si.amra.provider.notification;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Component;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.constants.UIConstants;
import com.bosch.si.amra.constants.notification.NotificationConstants;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.notification.Notification;
import com.bosch.si.amra.provider.DataProviderInitializer;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

@Component
public class NotificationDataProvider
{
	private static final long UNIX_TIME_FIRST_JANUARY_2016_MILLS = 1451606400 * 1000L;

	public List<Notification> getNotifications(User user, boolean topFive, boolean acknowledged)
	{
		if (user == null)
			throw new IllegalArgumentException(UIConstants.USER_MUST_NOT_BE_NULL);
		if (user.getTenant() == null || user.getTenant().isEmpty())
			throw new IllegalArgumentException(UIConstants.TENANT_ID_MUST_NOT_BE_NULL);
		DBCursor notificationCursor = getNotificationCursor(user, topFive, acknowledged);
		return createNotificationsList(user, notificationCursor);
	}

	private DBCursor getNotificationCursor(User user, boolean topFive, boolean acknowledged)
	{
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection notificationCollection = db
				.getCollection(DashboardUI.getNotificationCollection());

		DBObject find = new BasicDBObject(MongoConstants.TENANT_ID, user.getTenant());
		if (!acknowledged)
		{
			find.put(NotificationConstants.ACKNOWLEDGED, acknowledged);
		}
		DataProviderInitializer.restrictData(user, find, MongoConstants.WAGON_ID);
		DBObject orderByTimestamp = new BasicDBObject();
		orderByTimestamp.put("D.TU", -1);

		if (topFive)
		{
			return notificationCollection.find(find).sort(orderByTimestamp).limit(5);
		}
		else
		{
			return notificationCollection.find(find).sort(orderByTimestamp);
		}
	}

	public List<Notification> createNotificationsList(User user, DBCursor notificationCursor)
	{
		List<Notification> notifications = new ArrayList<Notification>();
		while (notificationCursor.hasNext())
		{
			DBObject notificationFromDB = notificationCursor.next();
			Notification notification = Notification.dbObject2Notification(notificationFromDB);
			if (matchCriterias(user, notification))
			{
				notifications.add(notification);
			}
		}
		return notifications;
	}

	public int getUnreadNotificationsCount(User user)
	{
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection collection = db.getCollection(DashboardUI.getNotificationCollection());

		DBObject notApprovedNotifications = new BasicDBObject(MongoConstants.TENANT_ID,
				user.getTenant());
		DataProviderInitializer.restrictData(user, notApprovedNotifications,
				MongoConstants.WAGON_ID);
		notApprovedNotifications.put(NotificationConstants.ACKNOWLEDGED, false);

		DBCursor notificationCursor = collection.find(notApprovedNotifications);
		int notificationCount = 0;
		while (notificationCursor.hasNext())
		{
			DBObject notificationFromDB = notificationCursor.next();
			Notification notification = Notification.dbObject2Notification(notificationFromDB);
			if (matchCriterias(user, notification))
			{
				notificationCount++;
			}
		}

		return notificationCount;
	}

	boolean matchCriterias(User user, Notification notification)
	{
		return checkDateGeneralCriteria(notification)
				&& checkDateEndcustomerCriteria(user, notification);
	}

	private boolean checkDateGeneralCriteria(Notification notification)
	{
		return notification.isGpsFixed() ? true
				: notification.getTimestamp().after(new Date(UNIX_TIME_FIRST_JANUARY_2016_MILLS));

	}

	private boolean checkDateEndcustomerCriteria(User user, Notification notification)
	{
		if (user.isEndcustomer() && !user.isDisponent() && !user.isAdmin() && !user.isSuperAdmin())
		{
			if (notification.getTimestamp() != null
					&& !notification.getTimestamp().after(DataProviderInitializer
							.getWagonActivationTime(notification.getWagonId(), user.getId())))
			{
				// notification timestamp is outside activation time
				return false;
			}
		}
		return true;
	}
}
