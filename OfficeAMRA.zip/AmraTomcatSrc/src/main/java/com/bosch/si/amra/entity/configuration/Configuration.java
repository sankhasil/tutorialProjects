
package com.bosch.si.amra.entity.configuration;

import java.io.Serializable;
import java.util.UUID;

import com.bosch.si.amra.constants.MongoConstants;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

/**
 * Represents a Configuration object for a wagon
 * 
 * @author toa1wa3
 * 
 */
public class Configuration implements Serializable
{

	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= 2010850061759645297L;

	private String				id;

	private String				alias;

	private Integer				flashData;

	private String				status;

	private boolean				humidity;

	private boolean				humidityTemperature;

	private boolean				temperature;

	private boolean				deviceTemperature;

	private Double				shockX;

	private Double				shockY;

	private Double				shockZ;

	private boolean				routing;

	private Integer				gpsMoving;

	private Integer				gpsTimeBased;

	private Integer				gsmMoving;

	private Integer				gsmTimeBased;

	private String				wagonId;

	private String				tenantId;

	private Long				boxId;

	private Integer				bumpDuration;

	private Integer				aquisitionFrequency;

	public Configuration()
	{
		// empty constructor
	}

	public Configuration(String id, String alias, Integer flashData, String status,
			boolean humidity, boolean humidityTemperature, boolean temperature,
			boolean deviceTemperature, Double shockX, Double shockY, Double shockZ, boolean routing,
			Integer gpsMoving, Integer gpsTimeBased, Integer gsmMoving, Integer gsmTimeBased,
			Integer bumpDuration, Integer aquisitionFrequency, String wagonId, String tenantId,
			Long boxId)
	{
		super();
		this.id = id;
		this.alias = alias;
		this.flashData = flashData;
		this.status = status;
		this.humidity = humidity;
		this.humidityTemperature = humidityTemperature;
		this.temperature = temperature;
		this.deviceTemperature = deviceTemperature;
		this.shockX = shockX;
		this.shockY = shockY;
		this.shockZ = shockZ;
		this.routing = routing;
		this.gpsMoving = gpsMoving;
		this.gpsTimeBased = gpsTimeBased;
		this.gsmMoving = gsmMoving;
		this.gsmTimeBased = gsmTimeBased;
		this.wagonId = wagonId;
		this.tenantId = tenantId;
		this.boxId = boxId;
		this.bumpDuration = bumpDuration;
		this.aquisitionFrequency = aquisitionFrequency;
	}

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public String getAlias()
	{
		return alias;
	}

	public void setAlias(String alias)
	{
		this.alias = alias;
	}

	public boolean isHumidity()
	{
		return humidity;
	}

	public void setHumidity(boolean humidity)
	{
		this.humidity = humidity;
	}

	public boolean isHumidityTemperature()
	{
		return humidityTemperature;
	}

	public void setHumidityTemperature(boolean humidityTemperature)
	{
		this.humidityTemperature = humidityTemperature;
	}

	public boolean isTemperature()
	{
		return temperature;
	}

	public void setTemperature(boolean temperature)
	{
		this.temperature = temperature;
	}

	public boolean isDeviceTemperature()
	{
		return deviceTemperature;
	}

	public void setDeviceTemperature(boolean deviceTemperature)
	{
		this.deviceTemperature = deviceTemperature;
	}

	public boolean isRouting()
	{
		return routing;
	}

	public void setRouting(boolean routing)
	{
		this.routing = routing;
	}

	public Integer getGpsMoving()
	{
		return gpsMoving;
	}

	public void setGpsMoving(Integer gpsMoving)
	{
		this.gpsMoving = gpsMoving;
	}

	public Integer getGpsTimeBased()
	{
		return gpsTimeBased;
	}

	public void setGpsTimeBased(Integer gpsTimeBased)
	{
		this.gpsTimeBased = gpsTimeBased;
	}

	public Integer getGsmMoving()
	{
		return gsmMoving;
	}

	public void setGsmMoving(Integer gsmMoving)
	{
		this.gsmMoving = gsmMoving;
	}

	public Integer getGsmTimeBased()
	{
		return gsmTimeBased;
	}

	public void setGsmTimeBased(Integer gsmTimeBased)
	{
		this.gsmTimeBased = gsmTimeBased;
	}

	public String getWagonId()
	{
		return wagonId;
	}

	public void setWagonId(String wagonId)
	{
		this.wagonId = wagonId;
	}

	public String getTenantId()
	{
		return tenantId;
	}

	public void setTenantId(String tenantId)
	{
		this.tenantId = tenantId;
	}

	public Integer getFlashData()
	{
		return flashData;
	}

	public void setFlashData(Integer flashData)
	{
		this.flashData = flashData;
	}

	public String getStatus()
	{
		return status;
	}

	public void setStatus(String status)
	{
		this.status = status;
	}

	public Double getShockX()
	{
		return shockX;
	}

	public void setShockX(Double shockX)
	{
		this.shockX = shockX;
	}

	public Double getShockY()
	{
		return shockY;
	}

	public void setShockY(Double shockY)
	{
		this.shockY = shockY;
	}

	public Double getShockZ()
	{
		return shockZ;
	}

	public void setShockZ(Double shockZ)
	{
		this.shockZ = shockZ;
	}

	public Long getBoxId()
	{
		return boxId;
	}

	public void setBoxId(Long boxId)
	{
		this.boxId = boxId;
	}

	public Integer getBumpDuration()
	{
		return bumpDuration;
	}

	public void setBumpDuration(Integer bumpDuration)
	{
		this.bumpDuration = bumpDuration;
	}

	public Integer getAquisitionFrequency()
	{
		return aquisitionFrequency;
	}

	public void setAquisitionFrequency(Integer aquisitionFrequency)
	{
		this.aquisitionFrequency = aquisitionFrequency;
	}

	public static Configuration dbObject2Configuration(DBObject dbOBject)
	{
		Configuration configuration = null;
		if (dbOBject != null)
		{
			configuration = new Configuration();
			configuration.setId((String) dbOBject.get(MongoConstants.ID));
			configuration.setAlias((String) dbOBject.get(MongoConstants.ALIAS));
			configuration.setFlashData((Integer) dbOBject.get(MongoConstants.FLASH_DATA));
			configuration.setHumidity((Boolean) dbOBject.get(MongoConstants.HUMIDITY));
			configuration.setHumidityTemperature(
					(Boolean) dbOBject.get(MongoConstants.HUMIDITY_TEMPERATURE));
			configuration.setTemperature((Boolean) dbOBject.get(MongoConstants.TEMPERATURE));
			configuration.setDeviceTemperature(
					(Boolean) dbOBject.get(MongoConstants.DEVICE_TEMPERATURE));
			configuration.setRouting((Boolean) dbOBject.get(MongoConstants.ROUTING));
			configuration.setShockX((Double) dbOBject.get(MongoConstants.SHOCK_X));
			configuration.setShockY((Double) dbOBject.get(MongoConstants.SHOCK_Y));
			configuration.setShockZ((Double) dbOBject.get(MongoConstants.SHOCK_Z));
			configuration.setGpsMoving((Integer) dbOBject.get(MongoConstants.GPS_MOVING));
			configuration.setGpsTimeBased((Integer) dbOBject.get(MongoConstants.GPS_TIME_BASED));
			configuration.setGsmMoving((Integer) dbOBject.get(MongoConstants.GSM_MOVING));
			configuration.setGsmTimeBased((Integer) dbOBject.get(MongoConstants.GSM_TIME_BASED));
			configuration.setWagonId((String) dbOBject.get(MongoConstants.WAGON_ID));
			configuration.setStatus((String) dbOBject.get(MongoConstants.STATUS));
			configuration.setTenantId((String) dbOBject.get(MongoConstants.TENANT_ID));
			configuration.setBoxId((Long) dbOBject.get(MongoConstants.BOX_ID));
			if (dbOBject.get(MongoConstants.BUMP_DURATION) != null)
				configuration.setBumpDuration((Integer) dbOBject.get(MongoConstants.BUMP_DURATION));
			if (dbOBject.get(MongoConstants.AQUITION_FREQUENCY) != null)
				configuration.setBumpDuration(
						(Integer) dbOBject.get(MongoConstants.AQUITION_FREQUENCY));
		}
		return configuration;
	}

	public static DBObject configuration2dbObject(Configuration configuration)
	{
		DBObject configurationObject = null;
		if (configuration != null)
		{
			configurationObject = new BasicDBObject();
			String id = configuration.getId();
			if (id == null)
			{
				id = UUID.randomUUID().toString();
			}
			configurationObject.put(MongoConstants.ID, id);
			configurationObject.put(MongoConstants.ALIAS, configuration.getAlias());
			configurationObject.put(MongoConstants.SORT, configuration.getAlias().toLowerCase());
			configurationObject.put(MongoConstants.FLASH_DATA, configuration.getFlashData());
			configurationObject.put(MongoConstants.STATUS, configuration.getStatus());
			configurationObject.put(MongoConstants.HUMIDITY, configuration.isHumidity());
			configurationObject.put(MongoConstants.HUMIDITY_TEMPERATURE,
					configuration.isHumidityTemperature());
			configurationObject.put(MongoConstants.TEMPERATURE, configuration.isTemperature());
			configurationObject.put(MongoConstants.DEVICE_TEMPERATURE,
					configuration.isDeviceTemperature());
			configurationObject.put(MongoConstants.SHOCK_X, configuration.getShockX());
			configurationObject.put(MongoConstants.SHOCK_Y, configuration.getShockY());
			configurationObject.put(MongoConstants.SHOCK_Z, configuration.getShockZ());
			configurationObject.put(MongoConstants.ROUTING, configuration.isRouting());
			configurationObject.put(MongoConstants.GPS_MOVING, configuration.getGpsMoving());
			configurationObject.put(MongoConstants.GPS_TIME_BASED, configuration.getGpsTimeBased());
			configurationObject.put(MongoConstants.GSM_MOVING, configuration.getGsmMoving());
			configurationObject.put(MongoConstants.GSM_TIME_BASED, configuration.getGsmTimeBased());
			configurationObject.put(MongoConstants.TENANT_ID, configuration.getTenantId());
			configurationObject.put(MongoConstants.WAGON_ID, configuration.getWagonId());
			configurationObject.put(MongoConstants.BOX_ID, configuration.getBoxId());
			configurationObject.put(MongoConstants.BUMP_DURATION, configuration.getBumpDuration());
			configurationObject.put(MongoConstants.AQUITION_FREQUENCY,
					configuration.getAquisitionFrequency());

		}
		return configurationObject;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((alias == null) ? 0 : alias.hashCode());
		result = prime * result
				+ ((aquisitionFrequency == null) ? 0 : aquisitionFrequency.hashCode());
		result = prime * result + ((boxId == null) ? 0 : boxId.hashCode());
		result = prime * result + ((bumpDuration == null) ? 0 : bumpDuration.hashCode());
		result = prime * result + (deviceTemperature ? 1231 : 1237);
		result = prime * result + ((flashData == null) ? 0 : flashData.hashCode());
		result = prime * result + ((gpsMoving == null) ? 0 : gpsMoving.hashCode());
		result = prime * result + ((gpsTimeBased == null) ? 0 : gpsTimeBased.hashCode());
		result = prime * result + ((gsmMoving == null) ? 0 : gsmMoving.hashCode());
		result = prime * result + ((gsmTimeBased == null) ? 0 : gsmTimeBased.hashCode());
		result = prime * result + (humidity ? 1231 : 1237);
		result = prime * result + (humidityTemperature ? 1231 : 1237);
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + (routing ? 1231 : 1237);
		result = prime * result + ((shockX == null) ? 0 : shockX.hashCode());
		result = prime * result + ((shockY == null) ? 0 : shockY.hashCode());
		result = prime * result + ((shockZ == null) ? 0 : shockZ.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + (temperature ? 1231 : 1237);
		result = prime * result + ((tenantId == null) ? 0 : tenantId.hashCode());
		result = prime * result + ((wagonId == null) ? 0 : wagonId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Configuration other = (Configuration) obj;
		if (alias == null)
		{
			if (other.alias != null)
				return false;
		}
		else if (!alias.equals(other.alias))
			return false;
		if (aquisitionFrequency == null)
		{
			if (other.aquisitionFrequency != null)
				return false;
		}
		else if (!aquisitionFrequency.equals(other.aquisitionFrequency))
			return false;
		if (boxId == null)
		{
			if (other.boxId != null)
				return false;
		}
		else if (!boxId.equals(other.boxId))
			return false;
		if (bumpDuration == null)
		{
			if (other.bumpDuration != null)
				return false;
		}
		else if (!bumpDuration.equals(other.bumpDuration))
			return false;
		if (deviceTemperature != other.deviceTemperature)
			return false;
		if (flashData == null)
		{
			if (other.flashData != null)
				return false;
		}
		else if (!flashData.equals(other.flashData))
			return false;
		if (gpsMoving == null)
		{
			if (other.gpsMoving != null)
				return false;
		}
		else if (!gpsMoving.equals(other.gpsMoving))
			return false;
		if (gpsTimeBased == null)
		{
			if (other.gpsTimeBased != null)
				return false;
		}
		else if (!gpsTimeBased.equals(other.gpsTimeBased))
			return false;
		if (gsmMoving == null)
		{
			if (other.gsmMoving != null)
				return false;
		}
		else if (!gsmMoving.equals(other.gsmMoving))
			return false;
		if (gsmTimeBased == null)
		{
			if (other.gsmTimeBased != null)
				return false;
		}
		else if (!gsmTimeBased.equals(other.gsmTimeBased))
			return false;
		if (humidity != other.humidity)
			return false;
		if (humidityTemperature != other.humidityTemperature)
			return false;
		if (id == null)
		{
			if (other.id != null)
				return false;
		}
		else if (!id.equals(other.id))
			return false;
		if (routing != other.routing)
			return false;
		if (shockX == null)
		{
			if (other.shockX != null)
				return false;
		}
		else if (!shockX.equals(other.shockX))
			return false;
		if (shockY == null)
		{
			if (other.shockY != null)
				return false;
		}
		else if (!shockY.equals(other.shockY))
			return false;
		if (shockZ == null)
		{
			if (other.shockZ != null)
				return false;
		}
		else if (!shockZ.equals(other.shockZ))
			return false;
		if (status == null)
		{
			if (other.status != null)
				return false;
		}
		else if (!status.equals(other.status))
			return false;
		if (temperature != other.temperature)
			return false;
		if (tenantId == null)
		{
			if (other.tenantId != null)
				return false;
		}
		else if (!tenantId.equals(other.tenantId))
			return false;
		if (wagonId == null)
		{
			if (other.wagonId != null)
				return false;
		}
		else if (!wagonId.equals(other.wagonId))
			return false;
		return true;
	}

}
