
package com.bosch.si.amra.view.configuration;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.component.grid.ConfigurationGrid;
import com.bosch.si.amra.constants.configuration.ConfigurationConstants;
import com.bosch.si.amra.entity.Tag;
import com.bosch.si.amra.view.configuration.converter.IntervalConverter;
import com.vaadin.data.Container.Filter;
import com.vaadin.data.Item;
import com.vaadin.data.Property;
import com.vaadin.data.util.GeneratedPropertyContainer;
import com.vaadin.data.util.filter.SimpleStringFilter;
import com.vaadin.shared.ui.combobox.FilteringMode;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.TextField;

public class ConfigurationGridFilterComponent
{
	public static class ConfigurationGeneralFilterHeader extends TextField
	{
		private static final long serialVersionUID = -7896430335958233908L;

		public ConfigurationGeneralFilterHeader(Object pid, ConfigurationGrid configurationGrid)
		{
			setNullRepresentation("");
			setNullSettingAllowed(true);
			addTextChangeListener(change -> {
				GeneratedPropertyContainer configurationGridContainer = (GeneratedPropertyContainer) configurationGrid
						.getContainerDataSource();
				clearContainerFilters(pid, configurationGridContainer);
				if (!change.getText().isEmpty())
				{
					configurationGridContainer.addContainerFilter(new GeneratedStringFilter(pid,
							change.getText(), configurationGridContainer));
				}
			});
			addValueChangeListener(event -> {
				GeneratedPropertyContainer configurationGridContainer = (GeneratedPropertyContainer) configurationGrid
						.getContainerDataSource();
				clearContainerFilters(pid, configurationGridContainer);
				if (event.getProperty().getValue() != null)
				{
					configurationGridContainer.addContainerFilter(new GeneratedStringFilter(pid,
							event.getProperty().getValue().toString(), configurationGridContainer));
				}
			});
		}
	}

	public static class IntervalFilterHeader extends TextField
	{
		private static final long serialVersionUID = 5789397813690696414L;

		public IntervalFilterHeader(Object pid, ConfigurationGrid configurationGrid)
		{
			setNullRepresentation("");
			setNullSettingAllowed(true);
			addTextChangeListener(change -> {
				GeneratedPropertyContainer configurationGridContainer = (GeneratedPropertyContainer) configurationGrid
						.getContainerDataSource();
				clearContainerFilters(pid, configurationGridContainer);

				if (!change.getText().isEmpty())
				{
					configurationGridContainer
							.addContainerFilter(new IntervalFilter(pid, change.getText()));
				}
			});
			addValueChangeListener(event -> {
				GeneratedPropertyContainer configurationGridContainer = (GeneratedPropertyContainer) configurationGrid
						.getContainerDataSource();
				clearContainerFilters(pid, configurationGridContainer);
				if (event.getProperty().getValue() != null)
				{
					configurationGridContainer.addContainerFilter(
							new IntervalFilter(pid, event.getProperty().getValue().toString()));
				}
			});
		}
	}

	private static final class IntervalFilter implements Filter
	{
		private static final long	serialVersionUID	= 7697492180753622828L;

		private final Object		propertyId;

		private final String		intervalFilter;

		public IntervalFilter(Object propertyId, String intervalFilter)
		{
			this.propertyId = propertyId;
			this.intervalFilter = intervalFilter;
		}

		@Override
		public boolean passesFilter(Object itemId, Item item) throws UnsupportedOperationException
		{
			final Property<?> p = item.getItemProperty(propertyId);
			if (p == null)
			{
				return false;
			}
			Integer propertyValue = (Integer) p.getValue();
			if (propertyValue == null)
			{
				return false;
			}

			String propertyString = new IntervalConverter().convertToPresentation(propertyValue,
					null, null);
			return propertyString.contains(intervalFilter);
		}

		@Override
		public boolean appliesToProperty(Object propertyId)
		{
			return propertyId != null && this.propertyId.equals(propertyId);
		}
	}

	public static class GeneratedStringFilter implements Filter
	{
		private static final long					serialVersionUID	= -3298576224869841145L;

		private final Object						propertyId;

		private final String						filterString;

		private final GeneratedPropertyContainer	configurationGridContainer;

		public GeneratedStringFilter(Object propertyId, String filterString,
				GeneratedPropertyContainer configurationGridContainer)
		{
			this.propertyId = propertyId;
			this.filterString = filterString.toLowerCase();
			this.configurationGridContainer = configurationGridContainer;
		}

		@Override
		public boolean passesFilter(Object itemId, Item item)
		{
			Item generatedPorpertyItem = configurationGridContainer.getItem(itemId);
			Property<?> p = generatedPorpertyItem.getItemProperty(propertyId);
			if (p == null)
			{
				return false;
			}
			Object propertyValue = p.getValue();
			if (propertyValue == null)
			{
				return false;
			}
			final String value = propertyValue.toString().toLowerCase();

			if (!value.contains(filterString))
			{
				return false;
			}

			return true;
		}

		@Override
		public boolean appliesToProperty(Object propertyId)
		{
			return this.propertyId.equals(propertyId);
		}
	}

	public static class BooleanFilterHeader extends ComboBox
	{
		private static final long serialVersionUID = -2190992172938957653L;

		public BooleanFilterHeader(Object pid, ConfigurationGrid configurationGrid)
		{
			setItemStyleGenerator(new ComboBox.ItemStyleGenerator()
			{
				private static final long serialVersionUID = 6956051211377787408L;

				@Override
				public String getStyle(ComboBox source, Object itemId)
				{
					return "combobox";
				}
			});

			addItem(ConfigurationConstants.ON);
			addItem(ConfigurationConstants.OFF);

			setTextInputAllowed(false);
			setFilteringMode(FilteringMode.CONTAINS);
			setRequired(true);
			addValueChangeListener(event -> {
				GeneratedPropertyContainer configurationGridContainer = (GeneratedPropertyContainer) configurationGrid
						.getContainerDataSource();
				clearContainerFilters(pid, configurationGridContainer);
				String value = (String) event.getProperty().getValue();

				if (value != null)
				{
					String filter = value.equals(ConfigurationConstants.ON)
							? Boolean.TRUE.toString() : Boolean.FALSE.toString();
					configurationGridContainer
							.addContainerFilter(new SimpleStringFilter(pid, filter, true, false));
					setStyleName("combobox");
				}
			});
			setId("booleanFilterComboBox");
		}
	}

	public static class TagFilterHeader extends TextField
	{
		private static final long serialVersionUID = 3257141396875678912L;

		public TagFilterHeader(Object pid, ConfigurationGrid configurationGrid)
		{
			setNullRepresentation("");
			setNullSettingAllowed(true);
			setDescription(DashboardUI.getMessageSource()
					.getMessage("view.overview.columnheader.tags.filter.inputprompt"));
			addTextChangeListener(change -> {
				GeneratedPropertyContainer configurationGridContainer = (GeneratedPropertyContainer) configurationGrid
						.getContainerDataSource();
				clearContainerFilters(pid, configurationGridContainer);
				if (!change.getText().isEmpty())
				{
					configurationGridContainer.addContainerFilter(
							new TagListFilter(pid, change.getText(), configurationGridContainer));
				}
			});
			addValueChangeListener(event -> {
				GeneratedPropertyContainer configurationGridContainer = (GeneratedPropertyContainer) configurationGrid
						.getContainerDataSource();
				clearContainerFilters(pid, configurationGridContainer);
				if (event.getProperty().getValue() != null)
				{
					configurationGridContainer.addContainerFilter(new TagListFilter(pid,
							event.getProperty().getValue().toString(), configurationGridContainer));
				}
			});
		}
	}

	private static final class TagListFilter implements Filter
	{
		private static final long					serialVersionUID	= 1699471046445442177L;

		private final Object						propertyId;

		private final List<String>					filterStringCommaSeparated;

		private final GeneratedPropertyContainer	configurationGridContainer;

		public TagListFilter(Object propertyId, String filterStringCommaSeparated,
				GeneratedPropertyContainer configurationGridContainer)
		{
			this.propertyId = propertyId;
			this.filterStringCommaSeparated = (List<String>) Arrays
					.asList(filterStringCommaSeparated.toLowerCase().split(","));
			this.configurationGridContainer = configurationGridContainer;
		}

		@SuppressWarnings ("unchecked")
		@Override
		public boolean passesFilter(Object itemId, Item item) throws UnsupportedOperationException
		{
			Item generatedPorpertyItem = configurationGridContainer.getItem(itemId);
			final Property<?> p = generatedPorpertyItem.getItemProperty(propertyId);
			if (p == null)
			{
				return false;
			}
			Object propertyValue = p.getValue();
			if (propertyValue == null
					|| !p.getType().equals((Class<List<Tag>>) (Class<?>) List.class))
			{
				return false;
			}
			final List<String> valueList = ((ArrayList<Tag>) propertyValue).stream()
					.map(tagMapper -> tagMapper.getTagName().toLowerCase())
					.collect(Collectors.toList());

			return valueList.containsAll(filterStringCommaSeparated);
		}

		@Override
		public boolean appliesToProperty(Object propertyId)
		{
			return propertyId != null && this.propertyId.equals(propertyId);
		}
	}

	// utility method to clear filters having specified pid
	static void clearContainerFilters(Object pid,
			GeneratedPropertyContainer configurationGridContainer)
	{
		Optional<Filter> customfilter = configurationGridContainer.getContainerFilters().stream()
				.filter(filter -> filter.appliesToProperty(pid)).findFirst();
		if (customfilter.isPresent())
		{
			configurationGridContainer.removeContainerFilter(customfilter.get());
		}
	}
}
