
package com.bosch.si.amra.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.bosch.si.amra.constants.MongoConstants;
import com.mongodb.BasicDBList;
import com.mongodb.DBObject;

public class WagonUsers implements Serializable
{
	private static final long	serialVersionUID	= -378733939401483337L;

	private String				id;

	private String				alias;

	private String				typeName;

	private List<WagonUser>	disponents;

	private List<WagonUser>	endcustomers;

	public WagonUsers()
	{

	}

	public WagonUsers(String id, String alias, String typeName)
	{
		this.id = id;
		this.alias = alias;
		this.typeName = typeName;
	}

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public String getAlias()
	{
		return alias;
	}

	public void setAlias(String alias)
	{
		this.alias = alias;
	}

	public String getTypeName()
	{
		return typeName;
	}

	public void setTypeName(String typeName)
	{
		this.typeName = typeName;
	}

	public List<WagonUser> getDisponents()
	{
		return disponents;
	}

	public void setDisponents(List<WagonUser> disponents)
	{
		this.disponents = disponents;
	}

	public List<WagonUser> getEndcustomers()
	{
		return endcustomers;
	}

	public void setEndcustomers(List<WagonUser> endcustomers)
	{
		this.endcustomers = endcustomers;
	}

	public static WagonUsers dbObject2Disponent(DBObject disponentObject)
	{
		WagonUsers parentDisponent = null;
		if (disponentObject != null)
		{
			DBObject wagonTypeObject = (DBObject) disponentObject.get(MongoConstants.WAGON_TYPE);
			parentDisponent = new WagonUsers((String) disponentObject.get(MongoConstants.ID),
					(String) disponentObject.get(MongoConstants.ALIAS),
					(String) wagonTypeObject.get(MongoConstants.WAGON_TYPE_NAME));
			parentDisponent.setDisponents(buildChildDisponents(disponentObject, disponentObject));
			parentDisponent
					.setEndcustomers(buildChildEndcustomers(disponentObject, disponentObject));
		}
		return parentDisponent;
	}

	private static List<WagonUser> buildChildDisponents(DBObject parentObject,
			DBObject disponentObject)
	{
		List<WagonUser> childDisponents = new ArrayList<>();
		if (disponentObject.containsField(MongoConstants.DISPONENTS))
		{
			for (Object disponentChildObject : (BasicDBList) disponentObject
					.get(MongoConstants.DISPONENTS))
			{
				// Need to add wagon id an alias because the underlying vaadin container does not
				// allow
				// a same object twice as item id. And it might be that a disponent is responsible
				// for
				// several wagons and therefore the id and name of the disponent is not unique and
				// the
				// hash code is the same. To make the disponent wagon unique we add the wagon id and
				// the
				// alias, because within a wagon the same disponent can't be assigned twice
				DBObject disponentChild = (DBObject) disponentChildObject;
				WagonUser childDisponent = new WagonUser(
						(String) disponentChild.get(MongoConstants.ID),
						(String) disponentChild.get(MongoConstants.ALIAS), false, null,
						(String) parentObject.get(MongoConstants.ID),
						(String) parentObject.get(MongoConstants.ALIAS));
				childDisponents.add(childDisponent);
			}
		}

		return childDisponents;
	}

	private static List<WagonUser> buildChildEndcustomers(DBObject parentObject,
			DBObject endCustomerObject)
	{
		List<WagonUser> childEndCustomers = new ArrayList<>();
		if (endCustomerObject.containsField(MongoConstants.ENDCUSTOMERS))
		{
			for (Object endCustomerChildObject : (BasicDBList) endCustomerObject
					.get(MongoConstants.ENDCUSTOMERS))
			{
				// Need to add wagon id an alias because the underlying vaadin container does not
				// allow
				// a same object twice as item id. And it might be that a disponent is responsible
				// for
				// several wagons and therefore the id and name of the disponent is not unique and
				// the
				// hash code is the same. To make the disponent wagon unique we add the wagon id and
				// the
				// alias, because within a wagon the same disponent can't be assigned twice
				DBObject endCustomerChild = (DBObject) endCustomerChildObject;
				WagonUser endCustomer = new WagonUser(
						(String) endCustomerChild.get(MongoConstants.ID),
						(String) endCustomerChild.get(MongoConstants.ALIAS), true,
						new Date((Long) endCustomerChild.get(MongoConstants.ACTIVATION_TIME)),
						(String) parentObject.get(MongoConstants.ID),
						(String) parentObject.get(MongoConstants.ALIAS));
				childEndCustomers.add(endCustomer);
			}
		}

		return childEndCustomers;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((disponents == null) ? 0 : disponents.hashCode());
		result = prime * result + ((endcustomers == null) ? 0 : endcustomers.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((typeName == null) ? 0 : typeName.hashCode());
		result = prime * result + ((alias == null) ? 0 : alias.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		WagonUsers other = (WagonUsers) obj;
		if (disponents == null)
		{
			if (other.disponents != null)
				return false;
		}
		else if (!disponents.equals(other.disponents))
			return false;
		if (endcustomers == null)
		{
			if (other.endcustomers != null)
				return false;
		}
		else if (!endcustomers.equals(other.endcustomers))
			return false;
		if (id == null)
		{
			if (other.id != null)
				return false;
		}
		else if (!id.equals(other.id))
			return false;
		if (typeName == null)
		{
			if (other.typeName != null)
				return false;
		}
		else if (!typeName.equals(other.typeName))
			return false;
		if (alias == null)
		{
			if (other.alias != null)
				return false;
		}
		else if (!alias.equals(other.alias))
			return false;

		return true;
	}
}
