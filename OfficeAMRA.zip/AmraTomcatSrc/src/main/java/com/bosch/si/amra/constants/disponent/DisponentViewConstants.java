
package com.bosch.si.amra.constants.disponent;

public class DisponentViewConstants
{
	public static final double		TIMESTAMP_COLUMN_WIDTH			= 246.0;

	public static final double		COLLECT_CAUSE_COLUMN_WIDTH		= 49.0;

	public static final double		STREET_AND_CITY_COLUMN_WIDTH	= 302.0;

	public static final double		COUNTRY_COLUMN_WIDTH			= 181.0;

	public static final String		TIMESTAMP						= "timestamp";

	public static final String		COLLECT_CAUSE					= "collectCause";

	public static final String		STREET_AND_CITY					= "address.streetAndCity";

	public static final String		COUNTRY							= "address.country";

	public static final Object[]	PROPERTY_IDS					= { TIMESTAMP, COLLECT_CAUSE,
			STREET_AND_CITY, COUNTRY };

}
