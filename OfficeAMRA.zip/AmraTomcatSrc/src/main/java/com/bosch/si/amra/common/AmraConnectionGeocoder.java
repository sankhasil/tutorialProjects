
package com.bosch.si.amra.common;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.springframework.web.client.RestTemplate;
import org.vaadin.addons.locationtextfield.GeocodedLocation;
import org.vaadin.addons.locationtextfield.GeocodingException;
import org.vaadin.addons.locationtextfield.LocationProvider;
import org.vaadin.addons.locationtextfield.LocationType;

import com.tandogan.geostuff.opencagedata.GeocodeRepositoryImpl;
import com.tandogan.geostuff.opencagedata.entity.GeocodeResponse;
import com.tandogan.geostuff.opencagedata.entity.OpencageComponent;
import com.tandogan.geostuff.opencagedata.entity.OpencageGeometry;
import com.tandogan.geostuff.opencagedata.entity.OpencageResult;
import com.tandogan.geostuff.opencagedata.entity.OpencageStatus;

/**
 * Custom abstraction for {@link LocationProvider}.
 * This Geocoder can be used with a proxy or without a proxy. Concrete implementations must provide
 * proxy information if the need it
 *
 * @author toa1wa3
 *
 * @param <T> GeocodedLocation
 */
public class AmraConnectionGeocoder<T extends GeocodedLocation> implements LocationProvider<T>
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= 4741414634152470045L;

	private int					limit;

	private boolean				useProxy;

	private String				host;

	private int					port;

	protected String			language			= "en";

	private String				url;

	private String				apiKey;

	public Collection<T> geocode(String address) throws GeocodingException
	{
		final Set<T> locations = new LinkedHashSet<T>();
		RestTemplate restTemplate = new RestTemplate();

		if (useProxy)
			restTemplate.setRequestFactory(GeocodeRepositoryImpl.setProxy(host, port));

		GeocodeRepositoryImpl testable = new GeocodeRepositoryImpl(restTemplate, url, apiKey);

		GeocodeResponse response = testable.query(address, 1, language);
		Collection<T> locs = createLocations(response, address);

		if (this.limit > 0 && locs.size() > this.limit)
		{
			List<T> list = new ArrayList<T>(locs);
			locations.addAll(list.subList(0, this.limit));
		}
		else
		{
			locations.addAll(locs);
		}

		return (Collection<T>) locations;
	}

	public int getLimit()
	{
		return this.limit;
	}

	public void setLimit(int limit)
	{
		this.limit = limit;
	}

	public boolean isUseProxy()
	{
		return useProxy;
	}

	public AmraConnectionGeocoder<T> setUseProxy(boolean useProxy)
	{
		this.useProxy = useProxy;
		return this;
	}

	public String getHost()
	{
		return host;
	}

	public AmraConnectionGeocoder<T> setHost(String host)
	{
		this.host = host;
		return this;
	}

	public int getPort()
	{
		return port;
	}

	public AmraConnectionGeocoder<T> setPort(int port)
	{
		this.port = port;
		return this;
	}

	public String getLanguage()
	{
		return language;
	}

	public AmraConnectionGeocoder<T> setLanguage(String language)
	{
		this.language = language;
		return this;
	}

	public String getUrl()
	{
		return url;
	}

	public AmraConnectionGeocoder<T> setUrl(String url)
	{
		this.url = url;
		return this;
	}

	public String getApiKey()
	{
		return apiKey;
	}

	public AmraConnectionGeocoder<T> setApiKey(String apiKey)
	{
		this.apiKey = apiKey;
		return this;
	}

	@SuppressWarnings ("unchecked")
	private Collection<T> createLocations(GeocodeResponse response, String originalAddress)
	{
		final Collection<T> locations = new LinkedHashSet<T>();
		OpencageStatus status = response.getStatus();
		if ("OK".equals(status.getMessage()) && "200".equals(status.getCode()))
		{
			List<OpencageResult> results = response.getResults();
			boolean ambiguous = results.size() > 1;
			int limit = results.size();
			if (this.getLimit() > 0)
				limit = Math.min(this.getLimit(), limit);

			results.forEach(result -> {
				GeocodedLocation loc = new GeocodedLocation();
				loc.setAmbiguous(ambiguous);
				loc.setOriginalAddress(originalAddress);
				loc.setGeocodedAddress(result.getFormatted());
				OpencageComponent components = result.getComponents();
				if (components.getCity() != null && !components.getCity().isEmpty())
					loc.setLocality(components.getCity());
				if (components.getCity() == null && components.getTown() != null
						&& !components.getTown().isEmpty())
					loc.setLocality(components.getTown());
				if (components.getCountry() != null && !components.getCountry().isEmpty())
					loc.setCountry(components.getCountry());
				if (components.getCounty() != null && !components.getCounty().isEmpty())
					loc.setAdministrativeAreaLevel2(components.getCounty());
				if (components.getState() != null && !components.getState().isEmpty())
					loc.setAdministrativeAreaLevel1(components.getState());
				if (components.getPostcode() != null && !components.getPostcode().isEmpty())
					loc.setPostalCode(components.getPostcode());
				if (components.getRoad() != null && !components.getRoad().isEmpty())
				{
					loc.setRoute(components.getRoad());
					loc.setType(LocationType.ROUTE);
				}
				if (components.getHouseNumber() != null && !components.getHouseNumber().isEmpty())
				{
					loc.setStreetNumber(components.getHouseNumber());
					loc.setType(LocationType.ROUTE);
				}
				OpencageGeometry geometry = result.getGeometry();
				loc.setLat(geometry.getLatitude());
				loc.setLon(geometry.getLongitude());
				locations.add((T) loc);
			});
		}
		return locations;
	}
}
