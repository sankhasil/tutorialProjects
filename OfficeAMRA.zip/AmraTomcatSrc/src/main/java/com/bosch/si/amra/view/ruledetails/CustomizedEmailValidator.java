
package com.bosch.si.amra.view.ruledetails;

import com.vaadin.data.validator.EmailValidator;

public class CustomizedEmailValidator extends EmailValidator
{
	private static final long serialVersionUID = 1L;

	public CustomizedEmailValidator(String errorMessage)
	{
		super(errorMessage);
	}

	@Override
	public void validate(Object value) throws InvalidValueException
	{
		if (value.toString() != null && !value.toString().isEmpty())
		{
			String emails[] = value.toString().trim().split(",");
			for (String email : emails)
			{
				super.validate(email);
			}
		}
	}
}
