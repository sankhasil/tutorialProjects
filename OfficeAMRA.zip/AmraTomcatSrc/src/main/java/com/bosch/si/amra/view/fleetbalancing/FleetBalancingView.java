
package com.bosch.si.amra.view.fleetbalancing;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.common.UserSettingsStorer;
import com.bosch.si.amra.component.filter.TimestampFilter;
import com.bosch.si.amra.component.grid.OverviewGrid;
import com.bosch.si.amra.constants.UIConstants;
import com.bosch.si.amra.constants.overview.OverviewConstants;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.event.DashboardEvent.FleetBalancingFillChartEvent;
import com.bosch.si.amra.event.DashboardEvent.FleetBalancingGetEvent;
import com.bosch.si.amra.event.DashboardEvent.MaximizeDashboardPanelEvent;
import com.bosch.si.amra.event.DashboardEvent.MinimizeDashboardPanelEvent;
import com.bosch.si.amra.event.DashboardEvent.SaveUserSettingsEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.im.login.Role;
import com.bosch.si.amra.im.login.Role.Roles;
import com.bosch.si.amra.presenter.fleetbalancing.FleetBalancingType;
import com.bosch.si.amra.view.UserNotification;
import com.bosch.si.amra.view.overview.OverviewContainer;
import com.bosch.si.amra.view.overview.OverviewGridFilterComponent.OverviewFilter;
import com.bosch.si.amra.view.overview.OverviewGridFilterComponent.OverviewTagFilter;
import com.bosch.si.amra.view.overview.OverviewGridFilterComponent.SearchFilter;
import com.google.common.eventbus.Subscribe;
import com.vaadin.addon.charts.Chart;
import com.vaadin.addon.charts.model.ChartType;
import com.vaadin.addon.charts.model.Configuration;
import com.vaadin.addon.charts.model.DataSeries;
import com.vaadin.addon.charts.model.DataSeriesItem;
import com.vaadin.addon.charts.model.PlotOptionsSeries;
import com.vaadin.addon.charts.model.Stacking;
import com.vaadin.addon.charts.model.Tooltip;
import com.vaadin.addon.charts.model.XAxis;
import com.vaadin.addon.charts.model.YAxis;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.event.ShortcutListener;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.server.Page;
import com.vaadin.server.Responsive;
import com.vaadin.server.VaadinSession;
import com.vaadin.shared.ui.datefield.Resolution;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.Component;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.DateField;
import com.vaadin.ui.Grid.SelectionMode;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Panel;
import com.vaadin.ui.UI;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

@Role ({ Roles.FLEETADMIN, Roles.SYSTEMADMIN })
@SuppressWarnings ("serial")
public class FleetBalancingView extends Panel implements View
{
	private final User				user							= (User) VaadinSession
			.getCurrent().getAttribute(User.class.getName());

	private final int				ADDITIONAL_Y_WIDTH_PERCENTAGE	= 5;

	private List<Wagon>				wagons;

	private final VerticalLayout	root;

	private CssLayout				fleetBalancingPanels;

	private ComboBox				amountOfWagons;

	private DateField				startDate, endDate;

	private OverviewGrid			overviewGrid;

	private Chart					fleetBalancingChart;

	public FleetBalancingView()
	{
		wagons = DashboardUI.getDataProvider().getWagonsWithCurrentValues(user);

		addStyleName(ValoTheme.PANEL_BORDERLESS);
		setSizeFull();
		DashboardEventBus.register(this);

		root = new VerticalLayout();
		root.setSizeFull();
		root.setMargin(true);
		root.addStyleName("fleet-balancing-view");
		setContent(root);
		Responsive.makeResponsive(root);

		root.addComponent(buildHeader());

		Component content = buildContent();
		root.addComponent(content);
		root.setExpandRatio(content, 1);

		addShortcutListener(new ShortcutListener("Clear", KeyCode.ESCAPE, null)
		{
			@SuppressWarnings ("unchecked")
			@Override
			public void handleAction(Object sender, Object target)
			{
				BeanItemContainer<Wagon> container = (BeanItemContainer<Wagon>) overviewGrid
						.getContainerDataSource();
				if (target != null && target instanceof OverviewFilter)
					((OverviewFilter) target).setValue(null);
				else if (target != null && target instanceof TimestampFilter)
					((DateField) target).setValue(null);
				else if (target != null && target instanceof OverviewTagFilter)
					((OverviewTagFilter) target).setValue(null);
				else if (target != null && target instanceof SearchFilter)
					((SearchFilter) target).setValue("");
				Object pid = overviewGrid.getComponentToPidMap().get(target);
				if (pid != null)
					container.removeContainerFilters(pid);
			}
		});
	}

	private Component buildHeader()
	{
		HorizontalLayout header = new HorizontalLayout();
		header.addStyleName("viewheader");
		header.setSpacing(true);

		Label titleLabel = new Label(
				DashboardUI.getMessageSource().getMessage("view.fleet.balancing.caption"));
		titleLabel.setSizeUndefined();
		titleLabel.addStyleName(ValoTheme.LABEL_H1);
		titleLabel.addStyleName(ValoTheme.LABEL_NO_MARGIN);
		header.addComponent(titleLabel);

		HorizontalLayout tools = new HorizontalLayout();
		tools.setSpacing(true);
		tools.addStyleName("toolbar");
		header.addComponent(tools);

		return header;
	}

	private Component buildContent()
	{
		fleetBalancingPanels = new CssLayout();
		fleetBalancingPanels.addStyleName("fleet-balancing-panels");
		Responsive.makeResponsive(fleetBalancingPanels);

		fleetBalancingPanels.addComponent(buildHeaderBar());
		fleetBalancingPanels.addComponent(buildOverview());
		fleetBalancingPanels.addComponent(buildChart());

		return fleetBalancingPanels;
	}

	private Component buildHeaderBar()
	{
		HorizontalLayout layout = new HorizontalLayout();
		layout.setWidth(100, Unit.PERCENTAGE);
		layout.setSpacing(true);

		amountOfWagons = buildAmountOfWagonsComboBox();
		startDate = new DateField(DashboardUI.getMessageSource()
				.getMessage("view.fleet.balancing.start.date.caption"));
		startDate.setDateFormat(DashboardUI.getMessageSource().getMessage("date.format.picker"));
		startDate.setResolution(Resolution.DAY);
		startDate.setLocale(UI.getCurrent().getLocale());
		startDate.setImmediate(true);
		startDate.setLenient(true);
		startDate.setParseErrorMessage(
				DashboardUI.getMessageSource().getMessage("view.fleet.balancing.wrong.date"));
		startDate.setValidationVisible(true);
		startDate.setDateOutOfRangeMessage(
				DashboardUI.getMessageSource().getMessage("view.fleet.balancing.wrong.period"));
		startDate.setRangeEnd(new Date());

		endDate = new DateField(
				DashboardUI.getMessageSource().getMessage("view.fleet.balancing.end.date.caption"));
		endDate.setDateFormat(DashboardUI.getMessageSource().getMessage("date.format.picker"));
		endDate.setResolution(Resolution.DAY);
		endDate.setLocale(UI.getCurrent().getLocale());
		endDate.setImmediate(true);
		endDate.setLenient(true);
		endDate.setParseErrorMessage(
				DashboardUI.getMessageSource().getMessage("view.fleet.balancing.wrong.date"));
		endDate.setValidationVisible(true);
		endDate.setDateOutOfRangeMessage(
				DashboardUI.getMessageSource().getMessage("view.fleet.balancing.wrong.period"));

		Button calculateButton = buildCalculateButton();
		startDate.addValueChangeListener(event -> {
			endDate.setRangeStart((Date) event.getProperty().getValue());
			startDate.setRangeEnd(endDate.getValue());
			calculateButton.setEnabled(startDate.isValid() && endDate.isValid());
			endDate.setRangeStart(null);
		});

		endDate.addValueChangeListener(event -> {
			endDate.setRangeStart(startDate.getValue());
			startDate.setRangeEnd((Date) event.getProperty().getValue());
			calculateButton.setEnabled(startDate.isValid() && endDate.isValid());
			startDate.setRangeEnd(null);
		});

		layout.addComponents(amountOfWagons, startDate, endDate, calculateButton);
		layout.setComponentAlignment(calculateButton, Alignment.MIDDLE_RIGHT);
		return layout;
	}

	private ComboBox buildAmountOfWagonsComboBox()
	{
		ComboBox amountOfWagons = new ComboBox(DashboardUI.getMessageSource()
				.getMessage("view.fleet.balancing.amount.display.caption"));
		amountOfWagons.addStyleName("leftMargin");
		amountOfWagons.addItems(20, 50, 100);
		return amountOfWagons;
	}

	private Button buildCalculateButton()
	{
		Button calculateButton = new Button(DashboardUI.getMessageSource()
				.getMessage("view.fleet.balancing.calculate.caption"));
		calculateButton.addStyleName("rightMargin");
		calculateButton.addClickListener(listener -> {
			if (isRequiredInformationAvailable())
			{
				List<Wagon> wagons = overviewGrid.getSelectedRows().stream()
						.map(wagonMapper -> (Wagon) wagonMapper).collect(Collectors.toList());
				DashboardEventBus.post(new FleetBalancingGetEvent(user.getTenant(), wagons,
						(int) amountOfWagons.getValue(), startDate.getValue(), endDate.getValue()));
			}
			else
				new UserNotification("view.fleet.balancing.missing.input", 2000, false);
		});
		return calculateButton;
	}

	private boolean isRequiredInformationAvailable()
	{
		return amountOfWagons.getValue() != null && startDate.getValue() != null
				&& endDate.getValue() != null
				&& startDate.getValue().compareTo(endDate.getValue()) <= 0
				&& overviewGrid.getSelectedRows().size() > 0;
	}

	private Component buildOverview()
	{
		OverviewContainer overviewContainer = new OverviewContainer(wagons);
		overviewContainer.addNestedContainerProperty(OverviewConstants.WAGON_TYPE_NAME);
		overviewContainer.addNestedContainerProperty(OverviewConstants.STREET_CITY);
		overviewContainer.addNestedContainerProperty(OverviewConstants.COUNTRY);
		overviewContainer.addNestedContainerProperty(OverviewConstants.TAGS);
		overviewGrid = new OverviewGrid(overviewContainer, wagons);
		overviewGrid.setSelectionMode(SelectionMode.MULTI);
		overviewGrid.setCaption(
				DashboardUI.getMessageSource().getMessage("view.fleet.balancing.overview.caption"));
		Arrays.asList(OverviewGrid.getColumnIds(user)).forEach(propertyId -> {
			String propertyName = (String) propertyId;
			overviewGrid.getDefaultHeaderRow().getCell(propertyName).setHtml(
					DashboardUI.getMessageSource().getMessage("view.disponent.columnheader."
							+ propertyName.toString().toLowerCase()));
		});
		overviewGrid.getColumn(OverviewConstants.HUMIDITY).setHidden(true);
		overviewGrid.getColumn(OverviewConstants.DEVICE_TEMPERATURE).setHidden(true);
		overviewGrid.getColumn(OverviewConstants.HUMIDITY_TEMPERATURE).setHidden(true);
		overviewGrid.getColumn(OverviewConstants.BATTERY_LEVEL).setHidden(true);
		return new FleetBalancingContentWrapper().createContentWrapper(overviewGrid,
				"view.fleet.balancing.overview.help", "fleet-balancing-panel-full-slot", 40);
	}

	private Component buildChart()
	{
		fleetBalancingChart = new Chart(ChartType.BAR);
		fleetBalancingChart.setSizeFull();
		fleetBalancingChart.setCaption(
				DashboardUI.getMessageSource().getMessage("view.fleet.balancing.caption"));

		Configuration conf = fleetBalancingChart.getConfiguration();
		conf.setTitle("");

		XAxis xPositiveAxis = buildXAxis(false, true);
		XAxis xNegativeAxis = buildXAxis(false, false);
		xNegativeAxis.setLinkedTo(xPositiveAxis);

		YAxis yaxis = new YAxis();
		conf.addyAxis(yaxis);

		Tooltip tooltip = new Tooltip();
		tooltip.setFormatter(
				DashboardUI.getMessageSource().getMessage("view.fleet.balancing.tooltip"));
		conf.setTooltip(tooltip);

		// Configure plot options
		PlotOptionsSeries plot = new PlotOptionsSeries();
		plot.setStacking(Stacking.NORMAL);
		conf.setPlotOptions(plot);
		return new FleetBalancingContentWrapper().createContentWrapper(fleetBalancingChart,
				"view.fleet.balancing.balancing.tooltip", "fleet-balancing-panel-slot", 56);
	}

	private XAxis buildXAxis(boolean reversed, boolean opposite)
	{
		XAxis xAxis = new XAxis();
		xAxis.setTitle(
				DashboardUI.getMessageSource().getMessage("view.fleet.balancing.xaxis.title"));
		xAxis.setReversed(reversed);
		xAxis.setOpposite(opposite);
		xAxis.getLabels().setStep(1);
		fleetBalancingChart.getConfiguration().addxAxis(xAxis);
		return xAxis;
	}

	@Override
	public void enter(ViewChangeEvent event)
	{
		Page.getCurrent().getStyles().add(
				".v-filterselect-leftMargin {margin-left: 8px;} .v-caption-leftMargin {margin-left: 8px;}");
		Page.getCurrent().getStyles()
				.add(".v-button-rightMargin {margin-right: 8px; margin-top: 20px;}");
	}

	@Subscribe
	public void maximizePanel(MaximizeDashboardPanelEvent event)
	{
		for (Iterator<Component> it = fleetBalancingPanels.iterator(); it.hasNext();)
		{
			Component c = it.next();
			c.removeStyleName("max");
			c.setVisible(false);
		}
		event.getPanel().addStyleName("max");
		event.getPanel().setVisible(true);

		for (Iterator<Component> it = root.iterator(); it.hasNext();)
		{
			it.next().setVisible(false);
		}
		fleetBalancingPanels.setVisible(true);
	}

	@Subscribe
	public void minimizePanel(MinimizeDashboardPanelEvent event)
	{
		for (Iterator<Component> it = fleetBalancingPanels.iterator(); it.hasNext();)
		{
			Component c = it.next();
			c.removeStyleName("max");
			c.setVisible(true);
		}

		for (Iterator<Component> it = root.iterator(); it.hasNext();)
		{
			it.next().setVisible(true);
		}
	}

	@Subscribe
	public void fillChartInformation(FleetBalancingFillChartEvent event)
	{
		if (event != null)
		{
			fleetBalancingChart.getConfiguration().setSeries(new ArrayList<>());
			Map<FleetBalancingType, List<Wagon>> balancingMap = event.getBalancingMap();
			List<Wagon> positives = balancingMap.get(FleetBalancingType.POSITIVES);
			List<Wagon> negatives = balancingMap.get(FleetBalancingType.NEGATIVES);
			int average = event.getAverage();
			int maxWagonCount = Math.max(positives.size(), negatives.size());
			int maxMileageDeviation = event.getMaxMileageDeviation();

			String[] positivesCategories = buildCategories(positives, maxWagonCount);
			fleetBalancingChart.getConfiguration().getxAxis(0).setCategories(positivesCategories);

			String[] negativesCategories = buildCategories(negatives, maxWagonCount);
			fleetBalancingChart.getConfiguration().getxAxis(1).setCategories(negativesCategories);

			YAxis yAxis = fleetBalancingChart.getConfiguration().getyAxis(0);
			yAxis.setTitle(DashboardUI.getMessageSource()
					.getMessage("view.fleet.balancing.yaxis.title", average));
			if (positives.size() > 0 || negatives.size() > 0)
			{
				int maxYValue = Math.abs(maxMileageDeviation);
				maxYValue += maxYValue * ADDITIONAL_Y_WIDTH_PERCENTAGE / 100;
				yAxis.setMin(-1 * maxYValue);
				yAxis.setMax(maxYValue);
			}

			buildDataSeries(
					DashboardUI.getMessageSource()
							.getMessage("view.fleet.balancing.negative.series", negatives.size()),
					negativesCategories, negatives);
			buildDataSeries(
					DashboardUI.getMessageSource()
							.getMessage("view.fleet.balancing.positive.series", positives.size()),
					positivesCategories, positives);
			fleetBalancingChart.drawChart();
		}
		else
			new UserNotification("view.fleet.balancing.missing.input", 2000, false);
	}

	private String[] buildCategories(List<Wagon> wagons, int maxWagons)
	{
		List<String> initialList = wagons.stream().map(Wagon::getAlias)
				.collect(Collectors.toList());
		int gap = maxWagons - initialList.size();
		if (gap > 0)
		{
			for (int i = 0; i < gap; i++)
				initialList.add(0, "");
		}
		return initialList.toArray(new String[0]);
	}

	private void buildDataSeries(String seriesName, String[] categories, List<Wagon> wagons)
	{
		DataSeries series = new DataSeries();
		series.setName(seriesName);
		long emptyLabels = Arrays.stream(categories).filter(name -> name.matches("")).count();
		for (int i = 0; i < emptyLabels; i++)
		{
			series.add(new DataSeriesItem("", null));
		}
		wagons.stream().forEach(wagon -> {
			DataSeriesItem item = new DataSeriesItem(wagon.getAlias(), wagon.getMileageDeviation());
			series.add(item);
		});
		fleetBalancingChart.getConfiguration().addSeries(series);
	}

	@Subscribe
	public void saveSessionData(SaveUserSettingsEvent event)
	{
		UserSettingsStorer.saveSessionUserSettings(overviewGrid,
				UIConstants.FLEET_BALANCING_VIEW_SESSION_OBJECT);
	}

	@Override
	public void attach()
	{
		super.attach();
		UserSettingsStorer.fetchSessionUserSettings(overviewGrid,
				UIConstants.FLEET_BALANCING_VIEW_SESSION_OBJECT, OverviewGrid.getColumnIds(user));
	}

	@Override
	public void detach()
	{
		super.detach();
		DashboardEventBus.unregister(this);
		UserSettingsStorer.saveSessionUserSettings(overviewGrid,
				UIConstants.FLEET_BALANCING_VIEW_SESSION_OBJECT);
	}
}
