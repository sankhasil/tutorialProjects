
package com.bosch.si.amra.presenter.role;

import java.io.Serializable;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.entity.WagonUser;
import com.bosch.si.amra.event.DashboardEvent.AssignUserToWagonsEvent;
import com.bosch.si.amra.event.DashboardEvent.UserToWagonAssignedEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.provider.DataProviderInitializer;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.WriteResult;

/**
 * Presenter for saving users to wagon assignment
 *
 * @author toa1wa3
 *
 */
@Component
public class RolePresenterImpl implements Serializable, RolePresenter
{
	private static final long	serialVersionUID	= 4538974592115412915L;

	private static final Logger	logger				= LoggerFactory
			.getLogger(RolePresenterImpl.class);

	@Override
	public WriteResult[] saveUser2WagonAssignment(AssignUserToWagonsEvent event)
	{
		List<WagonUser> selectedUsers = event.getSelectedUsers();
		String selectedWagonId = event.getSelectedWagonId();
		if (selectedWagonId == null)
		{
			throw new IllegalArgumentException("Selected wagon must not be null");
		}

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject criteria = new BasicDBObject(MongoConstants.ID, selectedWagonId);
		BasicDBList disponents2Assign = new BasicDBList();
		BasicDBList endcustomers2Assign = new BasicDBList();
		for (WagonUser wagon2User : selectedUsers)
		{
			if (wagon2User.isEndCustomer())
			{
				endcustomers2Assign.add(WagonUser.user2DBObject(wagon2User));
			}
			else
			{
				disponents2Assign.add(WagonUser.user2DBObject(wagon2User));
			}
		}

		DBObject updateDisponents = new BasicDBObject("$set",
				new BasicDBObject(MongoConstants.DISPONENTS, disponents2Assign));
		logger.debug("Saved wagon 2 disponent assignment: {}", updateDisponents);

		DBObject updateEndCustomers = new BasicDBObject("$set",
				new BasicDBObject(MongoConstants.ENDCUSTOMERS, endcustomers2Assign));
		logger.debug("Saved wagon 2 endCustomer assignment: {}", updateEndCustomers);

		DashboardEventBus.post(new UserToWagonAssignedEvent(selectedUsers, selectedWagonId));

		WriteResult[] result = new WriteResult[2];
		result[0] = wagonCollection.update(criteria, updateDisponents, false, false);
		result[1] = wagonCollection.update(criteria, updateEndCustomers, false, false);
		return result;
	}

	private DBCollection getCollection(String collectionName)
	{
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection collection = db.getCollection(collectionName);
		return collection;
	}

}
