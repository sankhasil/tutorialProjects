
package com.bosch.si.amra.view.report;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.entity.report.MileageValue;
import com.bosch.si.amra.entity.report.SensorValue;
import com.bosch.si.amra.event.DashboardEvent.MaximizeDashboardPanelEvent;
import com.bosch.si.amra.event.DashboardEvent.MinimizeDashboardPanelEvent;
import com.bosch.si.amra.event.DashboardEvent.ReportEvent;
import com.bosch.si.amra.event.DashboardEvent.ReportMileageUpdateEvent;
import com.bosch.si.amra.event.DashboardEvent.ReportSensorUpdateEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.im.login.Role;
import com.bosch.si.amra.im.login.Role.Roles;
import com.google.common.eventbus.Subscribe;
import com.vaadin.addon.charts.Chart;
import com.vaadin.addon.charts.ChartOptions;
import com.vaadin.addon.charts.ChartSelectionEvent;
import com.vaadin.addon.charts.LegendItemClickEvent;
import com.vaadin.addon.charts.LegendItemClickListener;
import com.vaadin.addon.charts.model.AbstractSeries;
import com.vaadin.addon.charts.model.AxisType;
import com.vaadin.addon.charts.model.ChartType;
import com.vaadin.addon.charts.model.Configuration;
import com.vaadin.addon.charts.model.ContainerDataSeries;
import com.vaadin.addon.charts.model.Lang;
import com.vaadin.addon.charts.model.PlotOptionsColumn;
import com.vaadin.addon.charts.model.PlotOptionsLine;
import com.vaadin.addon.charts.model.Series;
import com.vaadin.addon.charts.model.ZoomType;
import com.vaadin.data.Container;
import com.vaadin.data.Property.ValueChangeEvent;
import com.vaadin.data.Property.ValueChangeListener;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.event.ShortcutListener;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Page;
import com.vaadin.server.Responsive;
import com.vaadin.server.VaadinSession;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.Component;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.MenuBar;
import com.vaadin.ui.MenuBar.Command;
import com.vaadin.ui.MenuBar.MenuItem;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Notification.Type;
import com.vaadin.ui.Panel;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

@SuppressWarnings ("serial")
@Role ({ Roles.USER, Roles.FLEETADMIN, Roles.SYSTEMADMIN })
public class ReportView extends Panel implements View
{
	private static final int			ONE_HOUR	= 3600 * 1000;

	private static final int			ONE_DAY		= 24 * ONE_HOUR;

	private final VerticalLayout		root;

	private ComboBox					wagonSelect;

	private CssLayout					dashboardPanels;

	private Chart						mileageChart;

	private Chart						accumulatedChart;

	private Chart						temperatureChart;

	private Chart						humidityChart;

	private Button						clear;

	private final Chart[]				charts;

	private final ReportChartListener	mileageListener;

	private final ReportChartListener	temperatureListener;

	private MenuItem					resetZoom;

	private final User					user		= (User) VaadinSession.getCurrent()
			.getAttribute(User.class.getName());

	public ReportView()
	{
		setSizeFull();
		addStyleName("sales");
		DashboardEventBus.register(this);

		root = new VerticalLayout();
		root.setSizeFull();
		root.setMargin(true);
		root.addStyleName("dashboard-view");
		setContent(root);
		Responsive.makeResponsive(root);

		root.addComponent(buildHeader());

		initWagonSelect();

		initializeCharts();
		charts = new Chart[] { mileageChart, accumulatedChart, temperatureChart, humidityChart };
		mileageListener = new ReportChartListener(Arrays.copyOfRange(charts, 0, 2));
		temperatureListener = new ReportChartListener(Arrays.copyOfRange(charts, 2, 4));

		Component content = buildContent();
		root.addComponent(content);
		root.setExpandRatio(content, 1);
	}

	private Component buildHeader()
	{
		HorizontalLayout header = new HorizontalLayout();
		header.addStyleName("viewheader");
		header.setSpacing(true);
		Responsive.makeResponsive(header);

		Label titleLabel = new Label(
				DashboardUI.getMessageSource().getMessage("view.report.caption"));
		titleLabel.setSizeUndefined();
		titleLabel.addStyleName(ValoTheme.LABEL_H1);
		titleLabel.addStyleName(ValoTheme.LABEL_NO_MARGIN);
		header.addComponents(titleLabel, buildToolbar());

		return header;
	}

	private Component buildToolbar()
	{
		HorizontalLayout toolbar = new HorizontalLayout();
		toolbar.addStyleName("toolbar");
		toolbar.setSpacing(true);

		clear = new Button(DashboardUI.getMessageSource().getMessage("view.report.clear"));
		clear.setIcon(FontAwesome.TRASH_O);
		clear.addStyleName(ValoTheme.BUTTON_ICON_ONLY);
		clear.setEnabled(false);

		wagonSelect = new ComboBox();
		wagonSelect.setItemCaptionPropertyId("alias");
		wagonSelect.addShortcutListener(new ShortcutListener(
				DashboardUI.getMessageSource().getMessage("view.report.add"), KeyCode.ENTER, null)
		{
			@Override
			public void handleAction(Object sender, Object target)
			{
				Wagon wagon = (Wagon) wagonSelect.getValue();
				DashboardEventBus.post(new ReportEvent(user.getTenant(), Arrays.asList(wagon)));
			}
		});

		final Button add = new Button(DashboardUI.getMessageSource().getMessage("view.report.add"));
		add.setEnabled(false);
		add.addStyleName(ValoTheme.BUTTON_PRIMARY);
		add.addStyleName(ValoTheme.BUTTON_ICON_ONLY);
		add.setIcon(FontAwesome.PLUS);

		CssLayout group = new CssLayout(wagonSelect, add);
		group.addStyleName(ValoTheme.LAYOUT_COMPONENT_GROUP);
		toolbar.addComponent(group);

		wagonSelect.addValueChangeListener(new ValueChangeListener()
		{
			@Override
			public void valueChange(ValueChangeEvent event)
			{

				add.setEnabled(event.getProperty().getValue() != null);

			}
		});

		clear.addClickListener(new ClickListener()
		{
			@Override
			public void buttonClick(ClickEvent event)
			{
				for (Chart chart : charts)
				{
					chart.getConfiguration().setSeries(new ArrayList<Series>());
					// chart.getConfiguration().getSeries().clear();
					chart.drawChart();
				}
				// Set all reset zoom menu items visible
				mileageListener.resetZoom();
				temperatureListener.resetZoom();
				initWagonSelect();
				clear.setEnabled(false);
			}
		});
		toolbar.addComponent(clear);

		add.addClickListener(new ClickListener()
		{
			@Override
			public void buttonClick(ClickEvent event)
			{
				Wagon wagon = (Wagon) wagonSelect.getValue();
				DashboardEventBus.post(new ReportEvent(user.getTenant(), Arrays.asList(wagon)));
			}
		});

		return toolbar;
	}

	private void initWagonSelect()
	{
		Collection<Wagon> wagons = DashboardUI.getDataProvider().getWagonsShort(user);
		Container wagonContainer = new BeanItemContainer<>(Wagon.class, wagons);
		wagonSelect.setContainerDataSource(wagonContainer);
	}

	private void initializeCharts()
	{
		mileageChart = new Chart(ChartType.COLUMN);
		accumulatedChart = new Chart(ChartType.LINE);
		temperatureChart = new Chart(ChartType.LINE);
		humidityChart = new Chart(ChartType.LINE);
	}

	private Component buildContent()
	{
		dashboardPanels = new CssLayout();
		dashboardPanels.addStyleName("dashboard-panels");
		Responsive.makeResponsive(dashboardPanels);
		dashboardPanels.addComponent(buildMileageChart());
		dashboardPanels.addComponent(buildTemperatureChart());
		dashboardPanels.addComponent(buildAccumulatedMileageChart());
		dashboardPanels.addComponent(buildHumidityChart());
		configureCharts();

		return dashboardPanels;
	}

	private Component buildMileageChart()
	{
		mileageChart
				.setCaption(DashboardUI.getMessageSource().getMessage("view.report.chart.mileage"));
		mileageChart.setSizeFull();
		mileageChart.setImmediate(true);
		mileageChart.addLegendItemClickListener(new ReportChartLegenClickListener());
		mileageChart.addChartSelectionListener(mileageListener);

		Component mileageChartComponent = createContentWrapper(mileageChart,
				"view.report.chart.mileage.help");
		mileageListener.addResetZoom(resetZoom);

		return mileageChartComponent;
	}

	private Component buildAccumulatedMileageChart()
	{
		accumulatedChart.setCaption(
				DashboardUI.getMessageSource().getMessage("view.report.chart.accumulated.mileage"));
		accumulatedChart.setSizeFull();
		accumulatedChart.setImmediate(true);
		accumulatedChart.addLegendItemClickListener(new ReportChartLegenClickListener());
		accumulatedChart.addChartSelectionListener(mileageListener);

		Component accumulatedMileageChartComponent = createContentWrapper(accumulatedChart,
				"view.report.chart.accumulated.mileage.help");
		mileageListener.addResetZoom(resetZoom);
		return accumulatedMileageChartComponent;
	}

	private Component buildTemperatureChart()
	{

		temperatureChart.setCaption(
				DashboardUI.getMessageSource().getMessage("view.report.chart.temperature"));
		temperatureChart.setSizeFull();
		temperatureChart.setImmediate(true);
		temperatureChart.addLegendItemClickListener(new ReportChartLegenClickListener());
		temperatureChart.addChartSelectionListener(temperatureListener);

		Component temperatureChartComponent = createContentWrapper(temperatureChart,
				"view.report.chart.temperature.help");
		temperatureListener.addResetZoom(resetZoom);

		return temperatureChartComponent;
	}

	private Component buildHumidityChart()
	{
		humidityChart.setCaption(
				DashboardUI.getMessageSource().getMessage("view.report.chart.humidity"));
		humidityChart.setImmediate(true);
		humidityChart.setSizeFull();
		humidityChart.setId("humidity");
		humidityChart.addLegendItemClickListener(new ReportChartLegenClickListener());
		humidityChart.addChartSelectionListener(temperatureListener);

		Component humidityChartComponent = createContentWrapper(humidityChart,
				"view.report.chart.humidity.help");
		temperatureListener.addResetZoom(resetZoom);

		return humidityChartComponent;
	}

	private Component createContentWrapper(final Component content, final String code)
	{
		final CssLayout slot = new CssLayout();
		slot.setWidth("100%");
		slot.addStyleName("dashboard-panel-slot");

		CssLayout card = new CssLayout();
		card.setWidth("100%");
		card.addStyleName(ValoTheme.LAYOUT_CARD);

		HorizontalLayout toolbar = new HorizontalLayout();
		toolbar.addStyleName("dashboard-panel-toolbar");
		toolbar.setWidth("100%");

		Label caption = new Label(content.getCaption());
		caption.addStyleName(ValoTheme.LABEL_H4);
		caption.addStyleName(ValoTheme.LABEL_COLORED);
		caption.addStyleName(ValoTheme.LABEL_NO_MARGIN);
		content.setCaption(null);

		MenuBar tools = new MenuBar();
		tools.addStyleName(ValoTheme.MENUBAR_BORDERLESS);
		resetZoom = tools.addItem("", FontAwesome.SEARCH_MINUS, new Command()
		{
			@SuppressWarnings ("unchecked")
			@Override
			public void menuSelected(MenuItem selectedItem)
			{
				Chart chart = (Chart) content;
				Collection<ReportChartListener> listeners = (Collection<ReportChartListener>) chart
						.getListeners(ChartSelectionEvent.class);
				for (ReportChartListener listener : listeners)
				{
					listener.resetZoom();
				}
			}
		});
		resetZoom.setStyleName("icon-only");
		resetZoom.setVisible(false);
		MenuItem help = tools.addItem("", FontAwesome.QUESTION_CIRCLE, new Command()
		{
			@Override
			public void menuSelected(MenuItem selectedItem)
			{
				Notification.show(DashboardUI.getMessageSource().getMessage("slot.help"),
						DashboardUI.getMessageSource().getMessage(code), Type.HUMANIZED_MESSAGE);
			}
		});
		help.setStyleName("icon-only");
		MenuItem max = tools.addItem("", FontAwesome.EXPAND, new Command()
		{

			@Override
			public void menuSelected(MenuItem selectedItem)
			{
				if (!slot.getStyleName().contains("max"))
				{
					selectedItem.setIcon(FontAwesome.COMPRESS);
					DashboardEventBus.post(new MaximizeDashboardPanelEvent(slot));
				}
				else
				{
					slot.removeStyleName("max");
					selectedItem.setIcon(FontAwesome.EXPAND);
					DashboardEventBus.post(new MinimizeDashboardPanelEvent(slot));
				}
			}
		});
		max.setStyleName("icon-only");
		MenuItem root = tools.addItem("", FontAwesome.COG, null);
		root.addItem("Configure", new Command()
		{
			@Override
			public void menuSelected(MenuItem selectedItem)
			{
				Notification.show("Not implemented in this demo");
			}
		});
		root.addSeparator();
		root.addItem("Close", new Command()
		{
			@Override
			public void menuSelected(MenuItem selectedItem)
			{
				Notification.show("Not implemented in this demo");
			}
		});

		toolbar.addComponents(caption, tools);
		toolbar.setExpandRatio(caption, 1);
		toolbar.setComponentAlignment(caption, Alignment.MIDDLE_LEFT);

		card.addComponents(toolbar, content);
		slot.addComponent(card);
		return slot;
	}

	private void configureCharts()
	{
		configureChart(mileageChart, ONE_DAY, "view.report.chart.mileage.y", "km",
				"date.format.chart.mileage");
		configureChart(accumulatedChart, ONE_DAY, "view.report.chart.accumulated.mileage.y", "km",
				"date.format.chart.mileage");
		configureSensorChart(temperatureChart, ONE_HOUR, "view.report.chart.temperature.y", "°C",
				"date.format.chart");
		configureSensorChart(humidityChart, ONE_HOUR, "view.report.chart.humidity.y", "\u0025",
				"date.format.chart");
		Page.getCurrent().getJavaScript().execute("Highcharts.setOptions({\n" + "    global: {\n"
				+ "        useUTC: false\n" + "    }\n" + "});");
	}

	private void configureChart(Chart chart, int minRange, String title, String unit,
			String dateFormat)
	{
		String format = DashboardUI.getMessageSource().getMessage(dateFormat);
		Configuration config = chart.getConfiguration();
		config.getChart().setZoomType(ZoomType.X);
		config.setTitle("");
		config.getxAxis().setMinRange(minRange);
		config.getxAxis().setType(AxisType.DATETIME);
		config.getxAxis().getLabels().setEnabled(true);

		config.getyAxis().setTitle(DashboardUI.getMessageSource().getMessage(title));
		config.getyAxis().setStartOnTick(false);
		config.getyAxis().setShowFirstLabel(false);

		config.getTooltip().setUseHTML(true);

		String city = "";
		if (chart == humidityChart || chart == temperatureChart)
		{
			city = "<tr><td>' + this.point.custom + '</td></tr>";
		}

		config.getTooltip().setFormatter(
				"function() {return '<table><tr><td><b>' + this.series.name + ': </b></td></tr><tr><td> ' + this.y + ' "
						+ " " + unit + "</td></tr>" + city + "<tr><td>' + Highcharts.dateFormat('"
						+ "" + format + "" + "', new Date(this.x)) + '</td></tr></table>'; }");
		configureAxisLabelAccordingToLanguage();
	}

	private void configureSensorChart(Chart chart, int minRange, String title, String unit,
			String dateFormat)
	{
		String JSON_CONFIG = "{plotOptions: {series: {connectNulls: true, turboThreshold : 0}}}";
		chart.setJsonConfig(JSON_CONFIG);
		configureChart(chart, minRange, title, unit, dateFormat);
	}

	private void configureAxisLabelAccordingToLanguage()
	{
		Lang lang = new Lang();
		String months = DashboardUI.getMessageSource().getMessage("chart.months");
		lang.setMonths(months.split(","));
		String shortMonths = DashboardUI.getMessageSource().getMessage("chart.months.short");
		lang.setShortMonths(shortMonths.split(","));
		String weekdays = DashboardUI.getMessageSource().getMessage("chart.weekdays");
		lang.setWeekdays(weekdays.split(","));
		lang.setNoData(DashboardUI.getMessageSource().getMessage("no.data"));

		ChartOptions.get().setLang(lang);
	}

	@Subscribe
	public void addMileageDataSet(ReportMileageUpdateEvent event)
	{
		if (wagonSelect.getValue() != null)
		{
			wagonSelect.setValue(null);

		}
		for (String alias : event.getMileageMap().keySet())
		{
			Wagon wagon = new Wagon();
			wagon.setAlias(alias);
			wagonSelect.removeItem(wagon);
		}
		fillMileageCharts(event.getMileageMap(), event.getOffsetValues());
		clear.setEnabled(true);

	}

	private void fillMileageCharts(Map<String, List<MileageValue>> mileage,
			Map<String, Integer> offsetValues)
	{
		Calendar instance = getCalendar(Calendar.YEAR);
		if (mileage != null && mileage.size() > 0)
		{
			for (String alias : mileage.keySet())
			{
				fillMileageChart(alias, instance.getTime(), mileage.get(alias));
				fillAccumulatedMileageChart(alias, instance.getTime(), mileage.get(alias),
						offsetValues);
			}
			mileageChart.drawChart();
			accumulatedChart.drawChart();
		}
	}

	private void fillMileageChart(String alias, Date startPoint, List<MileageValue> mileage)
	{
		Collections.sort(mileage, new DateComparator());
		ContainerDataSeries series = createMileageContainer(alias, mileage);

		PlotOptionsColumn plotOptionsColumn = new PlotOptionsColumn();
		plotOptionsColumn.setPointStart(startPoint);
		plotOptionsColumn.setPointInterval(ONE_DAY);
		series.setPlotOptions(plotOptionsColumn);

		mileageChart.getConfiguration().addSeries(series);
	}

	private void fillAccumulatedMileageChart(String alias, Date startPoint,
			List<MileageValue> mileage, Map<String, Integer> offsetValues)
	{
		Collections.sort(mileage, new DateComparator());
		List<MileageValue> mileageValues = createAccumulatedDataSeries(mileage,
				offsetValues.get(alias));
		ContainerDataSeries series = createMileageContainer(alias, mileageValues);

		series.setPlotOptions(createPlotOptionsLine(startPoint, ONE_DAY));

		accumulatedChart.getConfiguration().addSeries(series);
	}

	/**
	 * Calculates the accumulated mileage. The next two entries are added and assigned to the next
	 * date, e.g. [{14-01-01, 10},{14-01-02, 20},{14-01-03,30}] leads to [{14-01-01, 10},{14-01-02,
	 * 30}, {14-01-03, 60}]
	 *
	 * @param mileage
	 *            list of mileage values
	 * @return Calculated the accumulated mileage
	 */
	private List<MileageValue> createAccumulatedDataSeries(List<MileageValue> mileage,
			Integer offsetValue)
	{
		List<MileageValue> accumulatedMileages = new ArrayList<>();
		Iterator<MileageValue> iterator = mileage.iterator();
		MileageValue firstOne = iterator.next();
		Integer accumulated = (offsetValue != null) ? firstOne.getMileage() + offsetValue
				: firstOne.getMileage();

		accumulatedMileages.add(new MileageValue(firstOne.getDate(), accumulated));
		while (iterator.hasNext())
		{
			MileageValue nextOne = iterator.next();
			Integer nextMileage = nextOne.getMileage();
			accumulated += nextMileage;
			accumulatedMileages.add(new MileageValue(nextOne.getDate(), accumulated));
			firstOne = nextOne;
		}
		return accumulatedMileages;
	}

	private ContainerDataSeries createMileageContainer(String alias, List<MileageValue> mileage)
	{
		BeanItemContainer<MileageValue> container = new BeanItemContainer<>(MileageValue.class,
				mileage);
		ContainerDataSeries series = new ContainerDataSeries(container);
		series.setName(alias);
		series.setXPropertyId("date");
		series.setYPropertyId("mileage");
		return series;
	}

	@Subscribe
	public void addSensorDataSet(ReportSensorUpdateEvent event)
	{
		fillSensorCharts(event.getSensorMap());
	}

	private void fillSensorCharts(Map<String, List<SensorValue>> sensorMap)
	{
		Calendar instance = getCalendar(Calendar.MONTH);
		if (sensorMap != null && sensorMap.size() > 0)
		{
			for (String alias : sensorMap.keySet())
			{
				fillTemperatureChart(
						alias + " ("
								+ DashboardUI.getMessageSource()
										.getMessage("view.dashboard.temperature")
								+ ")",
						instance.getTime(), sensorMap.get(alias));
				fillHumidityTemperatureChart(
						alias + " ("
								+ DashboardUI.getMessageSource()
										.getMessage("view.dashboard.humidity_temperature")
								+ ")",
						instance.getTime(), sensorMap.get(alias));
				fillHumidityChart(alias, instance.getTime(), sensorMap.get(alias));
			}
			temperatureChart.drawChart();
			humidityChart.drawChart();
		}
	}

	private void fillTemperatureChart(String alias, Date startPoint, List<SensorValue> sensorValues)
	{
		SensorContainer container = new TemperatureContainer();
		ContainerDataSeries series = container.createSensorContainer(alias, startPoint,
				sensorValues, "temperature");
		temperatureChart.getConfiguration().addSeries(series);
	}

	private void fillHumidityTemperatureChart(String alias, Date startPoint,
			List<SensorValue> sensorValues)
	{
		SensorContainer container = new HumidityTemperatureContainer();
		ContainerDataSeries series = container.createSensorContainer(alias, startPoint,
				sensorValues, "humidityTemperature");
		temperatureChart.getConfiguration().addSeries(series);
	}

	private void fillHumidityChart(String alias, Date startPoint, List<SensorValue> sensorValues)
	{
		SensorContainer container = new HumidityContainer();
		ContainerDataSeries series = container.createSensorContainer(alias, startPoint,
				sensorValues, "humidity");
		humidityChart.getConfiguration().addSeries(series);
	}

	private PlotOptionsLine createPlotOptionsLine(Date pointStart, int interval)
	{
		PlotOptionsLine plotOptionsLine = new PlotOptionsLine();
		plotOptionsLine.setPointStart(pointStart);
		plotOptionsLine.setPointInterval(interval);
		return plotOptionsLine;
	}

	private Calendar getCalendar(int field)
	{
		Calendar instance = Calendar.getInstance();
		instance.add(field, -1);
		instance.set(Calendar.HOUR_OF_DAY, 0);
		instance.set(Calendar.MINUTE, 0);
		instance.set(Calendar.SECOND, 0);
		return instance;
	}

	@Override
	public void enter(ViewChangeEvent event)
	{
	}

	@Override
	public void detach()
	{
		super.detach();
		DashboardEventBus.unregister(this);
	}

	@Subscribe
	public void maximizePanel(MaximizeDashboardPanelEvent event)
	{
		for (Iterator<Component> it = dashboardPanels.iterator(); it.hasNext();)
		{
			Component c = it.next();
			c.removeStyleName("max");
			c.setVisible(false);
		}
		event.getPanel().addStyleName("max");
		event.getPanel().setVisible(true);

		for (Iterator<Component> it = root.iterator(); it.hasNext();)
		{
			it.next().setVisible(false);
		}
		dashboardPanels.setVisible(true);
	}

	private void setAllSeriesVisible()
	{
		for (Chart chart : charts)
		{
			for (Series series : chart.getConfiguration().getSeries())
			{
				AbstractSeries chartSeries = (AbstractSeries) series;
				chartSeries.setVisible(true);
			}
		}
	}

	@Subscribe
	public void minimizePanel(MinimizeDashboardPanelEvent event)
	{
		setAllSeriesVisible();
		event.getPanel().setVisible(false);
		for (Iterator<Component> it = dashboardPanels.iterator(); it.hasNext();)
		{
			Component c = it.next();
			c.removeStyleName("max");
			c.setVisible(true);
		}

		for (Iterator<Component> it = root.iterator(); it.hasNext();)
		{
			it.next().setVisible(true);
		}
	}

	static class DateComparator implements Comparator<MileageValue>
	{
		@Override
		public int compare(MileageValue o1, MileageValue o2)
		{
			return o1.getDate().compareTo(o2.getDate());
		}
	}

	static class TimestampComparator implements Comparator<SensorValue>
	{
		@Override
		public int compare(SensorValue o1, SensorValue o2)
		{
			return o1.getTimestamp().compareTo(o2.getTimestamp());
		}
	}

	private class ReportChartLegenClickListener implements LegendItemClickListener
	{
		@Override
		public void onClick(LegendItemClickEvent event)
		{
			AbstractSeries series = (AbstractSeries) event.getSeries();
			series.setVisible(!series.isVisible());
			List<Chart> chartList = Arrays.asList(charts);
			for (Chart chart : chartList)
			{
				for (Series anotherSeries : chart.getConfiguration().getSeries())
				{
					String nameSubstring = anotherSeries.getName();
					if (anotherSeries.getName().contains("("))
					{
						nameSubstring = anotherSeries.getName().substring(0,
								anotherSeries.getName().indexOf("("));
					}
					if (series.getName().trim().contains(nameSubstring.trim()))
					{
						((AbstractSeries) anotherSeries).setVisible(series.isVisible());
					}
				}
			}
		}
	}

}
