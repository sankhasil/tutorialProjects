
package com.bosch.si.amra.component.grid;

import java.util.Map;

import com.vaadin.data.Container.Indexed;
import com.vaadin.ui.AbstractComponent;
import com.vaadin.ui.Grid;

public abstract class GridComponent extends Grid
{
	GridComponent(Indexed container)
	{
		super(container);
	}

	public abstract Map<AbstractComponent, Object> getComponentToPidMap();
}
