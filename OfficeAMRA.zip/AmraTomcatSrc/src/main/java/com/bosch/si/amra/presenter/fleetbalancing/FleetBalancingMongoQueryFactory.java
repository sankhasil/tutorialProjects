
package com.bosch.si.amra.presenter.fleetbalancing;

import static com.bosch.si.amra.constants.MongoConstants.ALIAS;
import static com.bosch.si.amra.constants.MongoConstants.DIVIDE;
import static com.bosch.si.amra.constants.MongoConstants.FIRST;
import static com.bosch.si.amra.constants.MongoConstants.GREATER_THAN_EQUALS;
import static com.bosch.si.amra.constants.MongoConstants.GROUP;
import static com.bosch.si.amra.constants.MongoConstants.ID;
import static com.bosch.si.amra.constants.MongoConstants.IN;
import static com.bosch.si.amra.constants.MongoConstants.LESS_THAN_EQUALS;
import static com.bosch.si.amra.constants.MongoConstants.MATCH;
import static com.bosch.si.amra.constants.MongoConstants.MILEAGE;
import static com.bosch.si.amra.constants.MongoConstants.PROJECT;
import static com.bosch.si.amra.constants.MongoConstants.SORT;
import static com.bosch.si.amra.constants.MongoConstants.SUBTRACT;
import static com.bosch.si.amra.constants.MongoConstants.SUM;
import static com.bosch.si.amra.constants.MongoConstants.TENANT_ID;
import static com.bosch.si.amra.constants.MongoConstants.WAGON_ID;
import static com.bosch.si.amra.constants.fleetbalancing.FleetBalancingConstants.DEVIATION;
import static com.bosch.si.amra.constants.fleetbalancing.FleetBalancingConstants.MILEAGE_SUM;
import static com.bosch.si.amra.constants.fleetbalancing.FleetBalancingConstants.TOTAL_MILEAGE;

import java.util.List;
import java.util.stream.Collectors;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.provider.DataProviderInitializer;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

public final class FleetBalancingMongoQueryFactory
{
	public static DBObject match(String tenantId, List<Wagon> wagons, String startDate,
			String endDate)
	{
		DBObject tenantAndWagonMatch = new BasicDBObject(TENANT_ID, tenantId);
		BasicDBList wagonIdIn = new BasicDBList();
		wagonIdIn.addAll(wagons.stream().map(wagon -> wagon.getId()).collect(Collectors.toList()));
		tenantAndWagonMatch.put(WAGON_ID, new BasicDBObject("$" + IN, wagonIdIn));
		DBObject dateMatch = new BasicDBObject("$" + GREATER_THAN_EQUALS, startDate);
		dateMatch.put("$" + LESS_THAN_EQUALS, endDate);
		tenantAndWagonMatch.put(MongoConstants.DATE, dateMatch);
		return new BasicDBObject(MATCH, tenantAndWagonMatch);
	}

	public static DBObject groupMileageSum()
	{
		DBObject innerGroup = new BasicDBObject(ID, "$" + TENANT_ID);
		innerGroup.put(MILEAGE_SUM, new BasicDBObject("$" + SUM, "$" + MILEAGE));
		return new BasicDBObject(GROUP, innerGroup);
	}

	public static DBObject projectTotalSum(int amountOfWagons)
	{
		DBObject divide = new BasicDBObject(TOTAL_MILEAGE, FleetBalancingMongoQueryFactory
				.projectionMethod("$" + MILEAGE_SUM, amountOfWagons, DIVIDE));
		return new BasicDBObject(PROJECT, divide);
	}

	private static DBObject projectionMethod(String key, Object value, String methodName)
	{
		BasicDBList keysToCheckForNull = new BasicDBList();
		keysToCheckForNull.add(key);
		keysToCheckForNull.add(value);
		return new BasicDBObject(methodName, keysToCheckForNull);
	}

	public static DBObject groupDeviationMileage()
	{
		DBObject groupingObject = new BasicDBObject(ID, "$" + WAGON_ID);
		groupingObject.put(MILEAGE_SUM, new BasicDBObject("$" + SUM, "$" + MILEAGE));
		groupingObject.put(ALIAS, new BasicDBObject("$" + FIRST, "$" + ALIAS));
		return new BasicDBObject(GROUP, groupingObject);
	}

	public static DBObject projectDeviationMileage(int average)
	{
		DBObject projectionObject = new BasicDBObject(ALIAS, "$" + ALIAS);
		projectionObject.put(DEVIATION, projectionMethod("$" + MILEAGE_SUM, average, SUBTRACT));
		return new BasicDBObject(PROJECT, projectionObject);
	}

	public static DBObject sortDeviationMileage()
	{
		return new BasicDBObject("$" + SORT,
				new BasicDBObject(DEVIATION, MongoConstants.DESCENDING_ORDER));
	}

	public static DBCollection getCollection(String collectionName)
	{
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection collection = db.getCollection(collectionName);
		return collection;
	}
}
