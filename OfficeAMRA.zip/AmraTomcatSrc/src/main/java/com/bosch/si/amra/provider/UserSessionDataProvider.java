
package com.bosch.si.amra.provider;

import org.springframework.stereotype.Component;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.UserSettingsConfiguration;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

/**
 * UserSessionDataProvider which fetch and update the user data retrieved to and from the Mongo DB
 *
 * @author SKS9KOR
 *
 */
@Component
public class UserSessionDataProvider
{
	public DBObject getUserSettings(User user)
	{
		DBCollection userSessionCollection = getCollection(
				DashboardUI.getMongoUserSessionCollection());
		DBObject find = new BasicDBObject(MongoConstants.ID, user.getId());
		DBObject sessionDataObject = userSessionCollection.findOne(find);
		return sessionDataObject;
	}

	public void updateUserSettings(User user, UserSettingsConfiguration configuration,
			String documentKey)
	{
		if (null != configuration)
		{
			DBCollection userSessionCollection = getCollection(
					DashboardUI.getMongoUserSessionCollection());
			DBObject updatedSettings = UserSettingsConfiguration.config2DBObject(configuration);
			DBObject update = new BasicDBObject(documentKey, updatedSettings);
			DBObject set = new BasicDBObject("$set", update);
			DBObject match = new BasicDBObject(MongoConstants.TENANT_ID, user.getTenant());
			match.put(MongoConstants.ID, user.getId());
			userSessionCollection.update(match, set, true, false);
		}
	}

	public UserSettingsConfiguration fetchCurrentUserSettings(DBObject sessionDataObject,
			String documentKey)
	{
		return sessionDataObject != null
				? UserSettingsConfiguration.dBObject2Config(sessionDataObject, documentKey) : null;
	}

	private DBCollection getCollection(String collectionName)
	{
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection collection = db.getCollection(collectionName);
		return collection;
	}
}
