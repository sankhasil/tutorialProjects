
package com.bosch.si.amra.presenter.fleetbalancing;

import static com.bosch.si.amra.constants.MongoConstants.ALIAS;
import static com.bosch.si.amra.constants.MongoConstants.ID;
import static com.bosch.si.amra.constants.fleetbalancing.FleetBalancingConstants.DEVIATION;
import static com.bosch.si.amra.constants.fleetbalancing.FleetBalancingConstants.TOTAL_MILEAGE;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.TimeZone;

import org.springframework.stereotype.Component;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.event.DashboardEvent.FleetBalancingFillChartEvent;
import com.bosch.si.amra.event.DashboardEvent.FleetBalancingGetEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.mongodb.AggregationOutput;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;

/**
 * The presenter implementation to get the balancing map
 * 
 * @author toa1wa3
 *
 */
@Component
public class FleetBalancingPresenterImpl implements Serializable, FleetBalancingPresenter
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= 1L;

	private String				tenantId;

	private List<Wagon>			wagons;

	private String				startDate, endDate;

	private int					average;

	@Override
	public FleetBalancingFillChartEvent getBalancingMap(FleetBalancingGetEvent event)
	{
		checkParameterForNull(event);
		Integer limit = event.getLimit();
		if (tenantId.isEmpty() || startDate.isEmpty() || endDate.isEmpty())
			throw new IllegalArgumentException("Passed parameter must not be empty");

		Map<FleetBalancingType, List<Wagon>> fleetBalancingMap = new HashMap<>();
		if (wagons.size() > 0)
		{
			average = calculateAverage();
			List<Wagon> positives = new ArrayList<>();
			List<Wagon> negatives = new ArrayList<>();
			List<Wagon> listWithMileageDeviation = getListWithMileageDeviation();
			for (Wagon fleetBalancingWagon : listWithMileageDeviation)
			{
				if (fleetBalancingWagon.getMileageDeviation() > 0)
					positives.add(fleetBalancingWagon);
				else
					negatives.add(fleetBalancingWagon);
			}
			// Reverse the positives list due to ordering issues. For the UI the top most mileage
			// must be at the end of the list. Also the top most negative wagon must be at the end
			// of the list because the UI is building the list from bottom to top and expects the
			// lower first and the top last
			Collections.reverse(positives);
			fleetBalancingMap.put(FleetBalancingType.POSITIVES,
					positives.subList(Math.max(0, positives.size() - limit), positives.size()));
			fleetBalancingMap.put(FleetBalancingType.NEGATIVES,
					negatives.subList(Math.max(0, negatives.size() - limit), negatives.size()));

			int maxMileageDeviation = Math
					.max(Math.abs(listWithMileageDeviation.get(0).getMileageDeviation()),
							Math.abs(listWithMileageDeviation
									.get(listWithMileageDeviation.size() - 1)
									.getMileageDeviation()));
			FleetBalancingFillChartEvent fleetBalancingFillChartEvent = new FleetBalancingFillChartEvent(
					fleetBalancingMap, average, maxMileageDeviation);
			DashboardEventBus.post(fleetBalancingFillChartEvent);
			return fleetBalancingFillChartEvent;
		}
		return null;
	}

	private void checkParameterForNull(FleetBalancingGetEvent event)
	{
		checkForNull(event);
		tenantId = event.getTenantId();
		checkForNull(tenantId);
		wagons = event.getWagons();
		checkForNull(wagons);
		checkForNull(event.getStartDate());
		startDate = parseDate(event.getStartDate());
		checkForNull(startDate);
		checkForNull(event.getEndDate());
		endDate = parseDate(event.getEndDate());
		checkForNull(endDate);
		checkForNull(event.getLimit());
	}

	private void checkForNull(Object parameter)
	{
		if (Objects.isNull(parameter))
			throw new IllegalArgumentException("Parameter must not be null");
	}

	private String parseDate(Date date)
	{
		SimpleDateFormat dateFormatUTC = new SimpleDateFormat("yy-MM-dd");
		dateFormatUTC.setTimeZone(TimeZone.getTimeZone("UTC"));

		return dateFormatUTC.format(date);
	}

	private int calculateAverage()
	{
		DBCollection mileageCollection = FleetBalancingMongoQueryFactory
				.getCollection(DashboardUI.getMongoMileageCollection());

		AggregationOutput averageOutput = mileageCollection.aggregate(Arrays.asList(
				FleetBalancingMongoQueryFactory.match(tenantId, wagons, startDate, endDate),
				FleetBalancingMongoQueryFactory.groupMileageSum(),
				FleetBalancingMongoQueryFactory.projectTotalSum(wagons.size())));
		if (isOutputValid(averageOutput))
			return ((Number) averageOutput.results().iterator().next().get(TOTAL_MILEAGE))
					.intValue();
		return 0;
	}

	private List<Wagon> getListWithMileageDeviation()
	{
		DBCollection mileageCollection = FleetBalancingMongoQueryFactory
				.getCollection(DashboardUI.getMongoMileageCollection());

		List<Wagon> fleetBalancingWagons = createFleetBalancingWagons(mileageCollection);
		addWagonsWithoutMileageToList(fleetBalancingWagons);
		return fleetBalancingWagons;
	}

	private List<Wagon> createFleetBalancingWagons(DBCollection mileageCollection)
	{
		List<Wagon> fleetBalancingWagons = new ArrayList<>();
		AggregationOutput deviationOutput = mileageCollection.aggregate(Arrays.asList(
				FleetBalancingMongoQueryFactory.match(tenantId, wagons, startDate, endDate),
				FleetBalancingMongoQueryFactory.groupDeviationMileage(),
				FleetBalancingMongoQueryFactory.projectDeviationMileage(average),
				FleetBalancingMongoQueryFactory.sortDeviationMileage()));
		if (isOutputValid(deviationOutput))
		{
			Iterator<DBObject> iterator = deviationOutput.results().iterator();
			while (iterator.hasNext())
			{
				DBObject outputObject = iterator.next();
				String id = (String) outputObject.get(ID);
				String alias = (String) outputObject.get(ALIAS);
				Integer mileageDeviation = (Integer) outputObject.get(DEVIATION);
				fleetBalancingWagons.add(new Wagon(id, alias, mileageDeviation));
			}
		}
		return fleetBalancingWagons;
	}

	private void addWagonsWithoutMileageToList(List<Wagon> fleetBalancingWagons)
	{
		if (wagons.size() != fleetBalancingWagons.size())
		{
			for (Wagon wagon : wagons)
			{
				if (!fleetBalancingWagons.contains(wagon))
					fleetBalancingWagons
							.add(new Wagon(wagon.getId(), wagon.getAlias(), 0 - average));
			}
		}
	}

	private static boolean isOutputValid(AggregationOutput output)
	{
		return output != null && output.results() != null && output.results().iterator() != null
				&& output.results().iterator().hasNext();
	}
}
