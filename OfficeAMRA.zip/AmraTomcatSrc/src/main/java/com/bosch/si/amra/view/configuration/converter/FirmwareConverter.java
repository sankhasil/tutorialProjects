
package com.bosch.si.amra.view.configuration.converter;

import java.util.Locale;

import com.vaadin.data.util.converter.StringToIntegerConverter;

public class FirmwareConverter extends StringToIntegerConverter
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= 3932165119138324283L;

	private final int			min;

	private final int			max;

	public FirmwareConverter(int min, int max)
	{
		this.min = min;
		this.max = max;
	}

	@Override
	public Integer convertToModel(String value, Class<? extends Integer> targetType, Locale locale)
			throws com.vaadin.data.util.converter.Converter.ConversionException
	{
		Integer convertedValue = super.convertToModel(value, targetType, locale);
		if (value == null || value.isEmpty())
			return null;
		if (convertedValue != null)
		{
			if (convertedValue < min)
				return min;
			if (convertedValue > max)
				return max;
			return convertedValue;
		}
		throw new ConversionException("Could not convert '" + value + "' to "
				+ Integer.class.getName() + ": value out of range");
	}
}
