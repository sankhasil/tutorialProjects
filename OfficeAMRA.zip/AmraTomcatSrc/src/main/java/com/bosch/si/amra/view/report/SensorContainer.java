
package com.bosch.si.amra.view.report;

import java.util.Collections;
import java.util.Date;
import java.util.List;

import com.bosch.si.amra.entity.report.SensorValue;
import com.bosch.si.amra.view.report.ReportView.TimestampComparator;
import com.vaadin.addon.charts.model.ContainerDataSeries;
import com.vaadin.addon.charts.model.PlotOptionsLine;
import com.vaadin.data.util.BeanItemContainer;

/**
 * Abstract sensor container for encapsulating the common creation steps. Specific steps are
 * implemented in the extended classes via the abstract
 * method isNull
 * 
 * @author toa1wa3
 *
 */
public abstract class SensorContainer
{
	private static final int	ONE_HOUR	= 3600 * 1000;

	public final ContainerDataSeries createSensorContainer(String alias, Date startPoint,
			List<SensorValue> sensorValues, String yProperty)
	{
		Collections.sort(sensorValues, new TimestampComparator());
		BeanItemContainer<SensorValue> container = new BeanItemContainer<>(SensorValue.class);
		for (SensorValue sensor : sensorValues)
		{
			if (isNull(sensor))
			{
				container.addBean(sensor);
			}
		}
		ContainerDataSeries series = new ContainerDataSeries(container);
		series.addAttributeToPropertyIdMapping("custom", "city");
		series.setName(alias);
		series.setXPropertyId("timestamp");
		series.setYPropertyId(yProperty);
		series.setPlotOptions(createPlotOptionsLine(startPoint, ONE_HOUR));
		return series;
	}

	private PlotOptionsLine createPlotOptionsLine(Date pointStart, int interval)
	{
		PlotOptionsLine plotOptionsLine = new PlotOptionsLine();
		plotOptionsLine.setPointStart(pointStart);
		plotOptionsLine.setPointInterval(interval);
		return plotOptionsLine;
	}

	public abstract boolean isNull(SensorValue value);
}
