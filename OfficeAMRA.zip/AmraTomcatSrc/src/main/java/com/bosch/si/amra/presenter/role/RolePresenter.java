
package com.bosch.si.amra.presenter.role;

import com.bosch.si.amra.event.DashboardEvent.AssignUserToWagonsEvent;
import com.google.common.eventbus.Subscribe;
import com.mongodb.WriteResult;

/**
 * Interface for {@link RolePresenterImpl}. This is need for Spring because the actual
 * bean instance is a JDK dynamic proxy which implements ths interface and calls the concrete
 * implementation
 *
 * @author toa1wa3
 *
 */
public interface RolePresenter
{
	/**
	 * Saves assigned users (disponent or/and endcustomer) to wagon in wagon collection.
	 * 
	 * @param event
	 *            contains users to save.
	 * @return array with save result, first element is result from disponent user save, second is
	 *         the result from endcustomer user save.
	 */
	@Subscribe
	public WriteResult[] saveUser2WagonAssignment(AssignUserToWagonsEvent event);
}
