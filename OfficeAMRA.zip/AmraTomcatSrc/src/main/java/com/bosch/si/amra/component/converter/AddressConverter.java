
package com.bosch.si.amra.component.converter;

import java.util.Locale;

import com.bosch.si.amra.DashboardUI;
import com.vaadin.data.util.converter.Converter;

/**
 * Displays a human readable text for not available addresses
 *
 * @author toa1wa3
 *
 */
public class AddressConverter implements Converter<String, String>
{
	/**
	 * Serial version uid
	 */
	private static final long serialVersionUID = 3460442238946853956L;

	@Override
	public String convertToModel(String value, Class<? extends String> targetType, Locale locale)
			throws com.vaadin.data.util.converter.Converter.ConversionException
	{
		return null;
	}

	@Override
	public String convertToPresentation(String value, Class<? extends String> targetType,
			Locale locale) throws com.vaadin.data.util.converter.Converter.ConversionException
	{
		if (value != null && !value.isEmpty())
		{
			return value;
		}
		return DashboardUI.getMessageSource().getMessage("not.available");
	}

	@Override
	public Class<String> getModelType()
	{
		return String.class;
	}

	@Override
	public Class<String> getPresentationType()
	{
		return String.class;
	}

}
