
package com.bosch.si.amra.provider;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.constants.UIConstants;
import com.bosch.si.amra.entity.LatLong;
import com.bosch.si.amra.entity.Tag;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.entity.WagonType;
import com.bosch.si.amra.entity.notification.Address;
import com.mongodb.AggregationOutput;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;

public class DataProviderInitializer
{
	private static final String	WAGON_IDS					= "wagonIds";

	private static final Logger	logger						= LoggerFactory
			.getLogger(DataProviderInitializer.class);

	private static final String	TENANT_ID_MUST_NOT_BE_NULL	= "Tenant id must not be null";

	private static MongoClient	mongoClient;

	/**
	 * A list of wagons for the corresponding tenant. Throws an IllegalArgumentException if the
	 * tenantId is null or empty
	 *
	 * @param user
	 *            returning the wagons belonging to user's tenant
	 * @return A wagon list
	 */
	public static List<Wagon> getWagons(User user)
	{
		if (user == null)
			throw new IllegalArgumentException(UIConstants.USER_MUST_NOT_BE_NULL);
		if (user.getTenant() == null || user.getTenant().isEmpty())
			throw new IllegalArgumentException(UIConstants.TENANT_ID_MUST_NOT_BE_NULL);

		DBCollection collection = getCollection(DashboardUI.getWagonCollection());

		DBObject match = new BasicDBObject(MongoConstants.TENANT_ID, user.getTenant());
		restrictData(user, match, MongoConstants.ID);

		DBCursor wagonCursor = collection.find(match)
				.sort(new BasicDBObject(MongoConstants.SORT, 1));

		return createWagonList(wagonCursor);
	}

	public static List<Wagon> getWagonsShort(User user)
	{
		if (user == null)
			throw new IllegalArgumentException(UIConstants.USER_MUST_NOT_BE_NULL);
		if (user.getTenant() == null || user.getTenant().isEmpty())
			throw new IllegalArgumentException(UIConstants.TENANT_ID_MUST_NOT_BE_NULL);

		DBCollection collection = getCollection(DashboardUI.getWagonCollection());
		DBObject match = new BasicDBObject(MongoConstants.TENANT_ID, user.getTenant());
		restrictData(user, match, MongoConstants.ID);
		BasicDBObject includeProjection = new BasicDBObject();
		includeProjection.put(MongoConstants.ALIAS, 1);
		includeProjection.put(MongoConstants.BOX_ID, 1);
		includeProjection.put(MongoConstants.ID, 1);
		includeProjection.put(MongoConstants.OFFSET, 1);
		DBCursor wagonCursor = collection.find(match, includeProjection)
				.sort(new BasicDBObject(MongoConstants.SORT, 1));
		return createWagonList(wagonCursor);
	}

	private static List<Wagon> createWagonList(DBCursor wagonCursor)
	{
		List<Wagon> wagonList = new ArrayList<Wagon>();

		while (wagonCursor.hasNext())
		{
			DBObject wagonObject = wagonCursor.next();
			Wagon wagon = Wagon.dbObject2Wagon(wagonObject);
			wagonList.add(wagon);
		}

		return wagonList;
	}

	/**
	 * A list of wagon types for the specific tenant
	 *
	 * @param tenantId
	 *            the tenantId for retrieving the wagon types
	 * @return A wagon type list
	 */
	public static List<WagonType> getWagonTypes(String tenantId)
	{
		if (tenantId == null || tenantId.isEmpty())
			throw new IllegalArgumentException(TENANT_ID_MUST_NOT_BE_NULL);

		DBCollection collection = getCollection(DashboardUI.getWagonTypeCollection());

		DBObject match = new BasicDBObject(MongoConstants.TENANT_ID, tenantId);

		DBCursor wagonTypeCursor = collection.find(match);

		List<WagonType> wagonTypeList = new ArrayList<WagonType>();

		while (wagonTypeCursor.hasNext())
		{
			DBObject wagonTypeObject = wagonTypeCursor.next();
			WagonType wagonType = WagonType.dbObject2WagonType(wagonTypeObject);
			wagonTypeList.add(wagonType);
		}

		return wagonTypeList;
	}

	/**
	 * Returns a list of wagon with all current values and mileage data set
	 *
	 * @param user
	 *            the user for retrieving the CurrentValues for the wagons
	 * @return a list of wagon with all current values and mileage data set
	 */
	public static List<Wagon> getCurrentValuesForWagons(User user)
	{
		DBCollection collection = getCollection(DashboardUI.getMongoCurrentCollection());
		List<Wagon> wagons = new ArrayList<Wagon>();
		String tenantId = user.getTenant();

		BasicDBObject find = new BasicDBObject(MongoConstants.TENANT_ID, tenantId);
		restrictData(user, find, MongoConstants.ID);

		DBCursor wagonObjects = collection.find(find);
		if (wagonObjects != null)
		{
			while (wagonObjects.hasNext())
			{
				DBObject wagonObject = wagonObjects.next();
				String wagonId = (String) wagonObject.get(MongoConstants.ID);
				Date wagonTimestamp = getTimestamp(wagonObject);
				if (user.isEndcustomer() && !user.isDisponent() && !user.isAdmin()
						&& !user.isSuperAdmin())
				{
					if (wagonTimestamp != null
							&& !wagonTimestamp.after(getWagonActivationTime(wagonId, user.getId())))
					{
						// skip this one as is outside activation time
						continue;
					}
				}
				wagons.add(createWagon(wagonId, wagonObject, tenantId));
			}
		}
		return wagons;
	}

	/**
	 * Gets list of Tags for specific tenant.
	 *
	 * @param user
	 *            user that tenant will be used as matching criteria
	 * @return List of tags belonging to a tenant
	 */
	public static List<Tag> getTagsForTenant(User user)
	{
		DBCollection collection = getCollection(DashboardUI.getMongoTagCollection());
		List<Tag> tags = new ArrayList<Tag>();
		String tenantId = user.getTenant();

		BasicDBObject find = new BasicDBObject(MongoConstants.TENANT_ID, tenantId);
		DBCursor tagDbObjects = collection.find(find);

		if (tagDbObjects != null)
		{
			while (tagDbObjects.hasNext())
			{
				DBObject tagDbObject = tagDbObjects.next();
				Tag tag = Tag.dbObject2Tag(tagDbObject);

				tags.add(tag);
			}
		}
		return tags;
	}

	/**
	 * Appends a restriction to the wagon Ids depending on which collection the restriction is made
	 *
	 * @param user
	 *            the user for checking its permissions
	 * @param find
	 *            the find statement, which is used for extension
	 * @param key
	 *            the database Id
	 */
	public static void restrictData(User user, DBObject find, String key)
	{
		if (!user.isAdmin() && !user.isSuperAdmin())
		{
			BasicDBList wagonIds = getRetrictedWagonIds(user.getTenant(), user.getId(),
					user.isEndcustomer() && !user.isDisponent());
			find.put(key, new BasicDBObject("$in", wagonIds));
		}
	}

	public static Wagon createWagonWithTelematicData(DBObject wagonObject)
	{
		DBObject dataElement = (DBObject) wagonObject.get(MongoConstants.DATA_ELEMENT);
		Double latValue = (Double) dataElement.get(MongoConstants.LATITUDE);
		Double lonValue = (Double) dataElement.get(MongoConstants.LONGITUDE);
		Wagon wagon = new Wagon();
		wagon.setId((String) wagonObject.get(MongoConstants.ID));
		wagon.setTimestamp(getTimestamp(wagonObject));
		wagon.setAddress(getAddress(wagonObject));
		wagon.setCollectCause(getCollectCause(wagonObject));
		if (latValue != null && lonValue != null)
		{
			wagon.setLatLong(new LatLong(latValue, lonValue));
		}
		return wagon;
	}

	/**
	 * Sets the values from the current collection for this wagon object
	 *
	 * @param wagonId
	 *            The wagon the values should be set to
	 * @param tenantId
	 *            The tenant the wagon belongs to
	 * @return The wagon with the current values
	 */
	public static Wagon getCurrentValuesForWagon(String wagonId, String tenantId)
	{
		DBCollection collection = getCollection(DashboardUI.getMongoCurrentCollection());

		DBObject wagonObject = collection.findOne(new BasicDBObject(MongoConstants.ID, wagonId));
		if (wagonObject != null)
		{
			return createWagon(wagonId, wagonObject, tenantId);
		}
		return null;
	}

	public static Wagon createWagon(String wagonId, DBObject wagonObject, String tenantId)
	{
		Wagon wagon = new Wagon();

		setWagonInfo(wagonObject, wagon);
		setWagonType(wagonObject, wagon);
		setWagonTag(wagonObject, wagon);
		setTelematicDataForWagon(wagonObject, wagon);
		setMileageForWagon(wagonObject, wagon);
		setMileageOffsetForWagon(wagonObject, wagon);
		wagon.setAddress(getAddress(wagonObject));

		return wagon;
	}

	public static void setWagonInfo(DBObject wagonObject, Wagon wagon)
	{
		wagon.setId((String) wagonObject.get(MongoConstants.ID));
		wagon.setAlias((String) wagonObject.get(MongoConstants.ALIAS));
		wagon.setBoxId((Long) wagonObject.get(MongoConstants.BOX_ID));
		wagon.setTenantId((String) wagonObject.get(MongoConstants.TENANT_ID));
	}

	public static void setWagonType(DBObject wagonObject, Wagon wagon)
	{
		DBObject wagonTypeObject = (DBObject) wagonObject.get(MongoConstants.WAGON_TYPE);

		WagonType wagonType = WagonType.dbObject2WagonType(wagonTypeObject);
		wagon.setWagonType(wagonType);
	}

	public static void setWagonTag(DBObject wagonObject, Wagon wagon)
	{
		BasicDBList wagonTagList = (BasicDBList) wagonObject.get(MongoConstants.WAGON_TAG);
		ArrayList<Tag> tagListAssignedToWagon = new ArrayList<Tag>();
		StringBuilder tagArr = new StringBuilder();
		int count = 0;
		if (wagonTagList != null && !wagonTagList.isEmpty())
		{
			for (Object eachTag : wagonTagList)
			{
				count++;
				Tag tag = Tag.dbObjectShort2Tag((DBObject) eachTag);
				tagListAssignedToWagon.add(tag);
				tagArr.append(tag.getTagName());
				if (count < wagonTagList.size())
					tagArr.append(',');
			}
		}
		wagon.setTags(tagListAssignedToWagon);
	}

	public static void setTelematicDataForWagon(DBObject nextTelematicData, Wagon entity)
	{
		setCurrentPosition(nextTelematicData, entity);

		Date timestamp = getTimestamp(nextTelematicData);
		entity.setTimestamp(timestamp);

		Date timestampLastContact = getTimestampContact(nextTelematicData);
		entity.setTimestampContact(timestampLastContact);

		Integer humidity = getHumidty(nextTelematicData);
		entity.setHumidity(humidity);

		Integer temparature = getTemparature(nextTelematicData);
		entity.setTemperature(temparature);

		Integer humidityTemperature = getHumidityTemparature(nextTelematicData);
		entity.setHumidityTemperature(humidityTemperature);
	}

	public static void setCurrentPosition(DBObject nextTelematicData, Wagon entity)
	{
		LatLong latLong = getCurrentPosition(nextTelematicData);
		entity.setLatLong(latLong);
	}

	private static LatLong getCurrentPosition(DBObject dbObject)
	{
		DBObject data = (DBObject) dbObject.get(MongoConstants.DATA_ELEMENT);
		if (data.containsField(MongoConstants.LATITUDE)
				&& data.containsField(MongoConstants.LONGITUDE)
				&& data.containsField(MongoConstants.UNIX_TIME))
		{
			Double latitude = (Double) data.get(MongoConstants.LATITUDE);
			Double longitude = (Double) data.get(MongoConstants.LONGITUDE);
			LatLong latLong = new LatLong(latitude, longitude);
			latLong.setTimestamp(getTimestamp(dbObject));
			return latLong;
		}
		return null;
	}

	private static Date getTimestamp(DBObject nextTelematicData)
	{
		DBObject data = (DBObject) nextTelematicData.get(MongoConstants.DATA_ELEMENT);
		if (data.containsField(MongoConstants.UNIX_TIME))
		{
			Number unixTime = (Number) data.get(MongoConstants.UNIX_TIME);
			return new Date(unixTime.longValue() * 1000L);
		}
		return null;
	}

	private static Date getTimestampContact(DBObject nextTelematicData)
	{
		DBObject data = (DBObject) nextTelematicData.get(MongoConstants.DATA_ELEMENT);
		if (data.containsField(MongoConstants.UNIX_TIME_LAST_CONTACT))
		{
			return new Date((Integer) data.get(MongoConstants.UNIX_TIME_LAST_CONTACT) * 1000L);
		}
		return null;
	}

	private static Integer getHumidty(DBObject nextTelematicData)
	{
		DBObject data = (DBObject) nextTelematicData.get(MongoConstants.DATA_ELEMENT);
		if (data.containsField(MongoConstants.HUMIDITY))
		{
			Double humidity = (Double) data.get(MongoConstants.HUMIDITY);
			return humidity.intValue();
		}
		return null;
	}

	private static Integer getTemparature(DBObject nextTelematicData)
	{
		DBObject data = (DBObject) nextTelematicData.get(MongoConstants.DATA_ELEMENT);
		if (data.containsField(MongoConstants.DEVICE_TEMPERATURE))
		{
			Integer temperature = (Integer) data.get(MongoConstants.DEVICE_TEMPERATURE);
			return temperature.intValue();
		}
		return null;
	}

	private static Integer getHumidityTemparature(DBObject nextTelematicData)
	{
		DBObject data = (DBObject) nextTelematicData.get(MongoConstants.DATA_ELEMENT);
		if (data.containsField(MongoConstants.HUMIDITY_TEMPERATURE))
		{
			Double humidityTemperature = (Double) data.get(MongoConstants.HUMIDITY_TEMPERATURE);
			return humidityTemperature.intValue();
		}
		return null;
	}

	public static void setMileageForWagon(DBObject wagonObject, Wagon wagon)
	{
		Integer mileage = (Integer) wagonObject.get(MongoConstants.MILEAGE);
		Integer mileageOffset = (Integer) wagonObject.get(MongoConstants.OFFSET);
		if (mileageOffset == null)
			wagon.setMileage(mileage);
		else if (mileage == null && mileageOffset != null)
			wagon.setMileage(mileageOffset);
		else if (mileage != null && mileageOffset != null)
			wagon.setMileage(mileage + mileageOffset);
	}

	public static void setMileageOffsetForWagon(DBObject wagonObject, Wagon wagon)
	{
		wagon.setMileageOffset((Integer) wagonObject.get(MongoConstants.OFFSET));
	}

	public static Address getAddress(DBObject wagonObject)
	{
		DBObject addressObject = (DBObject) wagonObject.get(MongoConstants.ADDRESS);
		DBObject addressComponents = (DBObject) addressObject
				.get(MongoConstants.ADDRESS_COMPONENTS);
		Address address = new Address();
		if (addressComponents != null)
		{
			String formattedAddress = addressObject.containsField(MongoConstants.FORMATTED_ADDRESS)
					? (String) addressObject.get(MongoConstants.FORMATTED_ADDRESS) : "";
			String street = addressComponents.containsField(MongoConstants.ADDRESS_ROUTE)
					? (String) addressComponents.get(MongoConstants.ADDRESS_ROUTE) : "";
			String number = addressComponents.containsField(MongoConstants.ADDRESS_STREET_NUMBER)
					? (String) addressComponents.get(MongoConstants.ADDRESS_STREET_NUMBER) : "";
			String postalCode = addressComponents.containsField(MongoConstants.ADDRESS_POSTAL_CODE)
					? (String) addressComponents.get(MongoConstants.ADDRESS_POSTAL_CODE) : "";
			String city = addressComponents.containsField(MongoConstants.ADDRESS_LOCALITY)
					? (String) addressComponents.get(MongoConstants.ADDRESS_LOCALITY) : "";
			String country = addressComponents.containsField(MongoConstants.ADDRESS_COUNTRY)
					? (String) addressComponents.get(MongoConstants.ADDRESS_COUNTRY) : "";
			address.setFormattedAddress(formattedAddress.trim());
			address.setStreet(street.trim() + " " + number.trim());
			address.setCity(postalCode.trim() + " " + city.trim());
			address.setCountry(country.trim());
			String streetAndNumber = !address.getStreet().trim().isEmpty() ? address.getStreet()
					: "";
			String postalAndCity = !address.getCity().trim().isEmpty() ? address.getCity() : "";
			String comma = streetAndNumber.isEmpty() || postalAndCity.isEmpty() ? "" : ", ";
			address.setStreetAndCity(streetAndNumber + comma + postalAndCity);
		}
		return address;
	}

	private static Integer getCollectCause(DBObject wagonObject)
	{
		DBObject data = (DBObject) wagonObject.get(MongoConstants.DATA_ELEMENT);
		if (data.containsField(MongoConstants.COLLECT_CAUSE))
		{
			return (Integer) data.get(MongoConstants.COLLECT_CAUSE);
		}
		return null;
	}

	public static WagonType getWagonType(String tenantId, final String wagonTypeId)
	{
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection collection = db.getCollection(DashboardUI.getWagonTypeCollection());

		DBObject match = new BasicDBObject(MongoConstants.TENANT_ID, tenantId);
		match.put(MongoConstants.ID, wagonTypeId);
		DBObject wagonTypeObject = collection.findOne(match);

		WagonType wagonType = WagonType.dbObject2WagonType(wagonTypeObject);
		return wagonType;
	}

	/**
	 * Gets activation time of a user with endcustomer role over specific wagon.
	 *
	 * @param wagonId
	 *            wagon unique identifier
	 * @param endCustomerId
	 *            user identifier
	 * @return specific date or null if no such user exists
	 */
	public static Date getWagonActivationTime(String wagonId, String endCustomerId)
	{
		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject match = new BasicDBObject();
		match.put(MongoConstants.ID, wagonId);
		DBObject wagonObject = wagonCollection.findOne(match);

		if (wagonObject != null)
		{
			BasicDBList endcustomers = (BasicDBList) wagonObject.get(MongoConstants.ENDCUSTOMERS);
			if (endcustomers != null)
			{
				for (Object endcustomerObj : endcustomers)
				{
					DBObject endcustomer = (DBObject) endcustomerObj;
					String currEndCustomerId = (String) endcustomer.get(MongoConstants.ID);
					if (endCustomerId.equals(currEndCustomerId))
					{
						return new Date((Long) endcustomer.get(MongoConstants.ACTIVATION_TIME));
					}
				}
			}
		}
		return null;
	}

	public static void createMongoClient() throws UnknownHostException
	{
		MongoCredential credential = MongoCredential.createMongoCRCredential(
				DashboardUI.getMongoUsername(), DashboardUI.getMongoDatabase(),
				DashboardUI.getMongoPassword().toCharArray());
		mongoClient = new MongoClient(
				new ServerAddress(DashboardUI.getMongoHost(), DashboardUI.getMongoPort()),
				Arrays.asList(credential));
	}

	public static void closeMongoClient()
	{
		if (mongoClient != null)
		{
			mongoClient.close();
			mongoClient = null;
		}
	}

	public static MongoClient getMongoClient()
	{
		if (mongoClient == null)
		{
			try
			{
				createMongoClient();
			}
			catch (UnknownHostException e)
			{
				logger.error("Could not find host", e);
			}
		}

		return mongoClient;
	}

	private static BasicDBList getRetrictedWagonIds(String tenantId, String userId,
			boolean isEndCustomer)
	{
		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());

		DBObject matcher = new BasicDBObject(MongoConstants.TENANT_ID, tenantId);
		String userKey;
		if (isEndCustomer)
		{
			userKey = MongoConstants.ENDCUSTOMERS + "." + MongoConstants.ID;
		}
		else
		{
			userKey = MongoConstants.DISPONENTS + "." + MongoConstants.ID;
		}
		matcher.put(userKey, userId);
		DBObject match = new BasicDBObject("$match", matcher);

		DBObject groupId = new BasicDBObject(MongoConstants.ID, "");
		groupId.put(WAGON_IDS, new BasicDBObject("$addToSet", "$" + MongoConstants.ID));
		DBObject group = new BasicDBObject("$group", groupId);

		AggregationOutput aggregate = wagonCollection.aggregate(Arrays.asList(match, group));

		if (aggregate != null && aggregate.results() != null)
		{
			Iterator<DBObject> iterator = aggregate.results().iterator();
			while (iterator.hasNext())
			{
				DBObject next = iterator.next();
				return (BasicDBList) next.get(WAGON_IDS);
			}
		}
		return new BasicDBList();
	}

	/**
	 * Returns a collection with the specified name.
	 * 
	 * @param collectionName
	 *            The name of desired collection
	 * @return A {@link DBCollection}
	 */
	public static DBCollection getCollection(String collectionName)
	{
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection collection = db.getCollection(collectionName);
		return collection;
	}
}
