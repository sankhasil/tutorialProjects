
package com.bosch.si.amra.provider.configuration;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.constants.UIConstants;
import com.bosch.si.amra.constants.configuration.ConfigurationConstants;
import com.bosch.si.amra.entity.configuration.Configuration;
import com.bosch.si.amra.provider.DataProviderInitializer;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

@Component
public class ConfigurationDataProvider
{
	private String	tenantId;

	public List<Configuration> getConfigurations(String tenantId)
	{
		if (tenantId == null || tenantId.isEmpty())
		{
			throw new IllegalArgumentException(UIConstants.TENANT_ID_MUST_NOT_BE_NULL);
		}
		this.tenantId = tenantId;
		DBCursor configCursor = getConfigurationsCursor();
		return createConfigurationsList(configCursor);
	}

	private DBCursor getConfigurationsCursor()
	{
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection configurationCollection = db.getCollection(DashboardUI
				.getConfigurationCollection());

		return configurationCollection.find(new BasicDBObject(MongoConstants.TENANT_ID, tenantId))
				.sort(new BasicDBObject(MongoConstants.SORT, 1));
	}

	public List<Configuration> createConfigurationsList(DBCursor configurationCursor)
	{
		List<Configuration> configurations = new ArrayList<Configuration>();
		while (configurationCursor.hasNext())
		{
			DBObject configurationFromDB = configurationCursor.next();
			Configuration configuration = new Configuration();
			configuration.setId((String) configurationFromDB.get(MongoConstants.ID));
			configuration.setAlias((String) configurationFromDB.get(ConfigurationConstants.ALIAS));
			configuration
					.setFlashData((Integer) configurationFromDB.get(MongoConstants.FLASH_DATA));
			configuration.setStatus((String) configurationFromDB.get(MongoConstants.STATUS));
			configuration.setHumidity((Boolean) configurationFromDB.get(MongoConstants.HUMIDITY));
			configuration.setHumidityTemperature((Boolean) configurationFromDB
					.get(MongoConstants.HUMIDITY_TEMPERATURE));
			configuration.setTemperature((Boolean) configurationFromDB
					.get(MongoConstants.TEMPERATURE));
			configuration.setDeviceTemperature((Boolean) configurationFromDB
					.get(MongoConstants.DEVICE_TEMPERATURE));
			configuration.setRouting((Boolean) configurationFromDB.get(MongoConstants.ROUTING));
			configuration.setShockX((Double) configurationFromDB.get(MongoConstants.SHOCK_X));
			configuration.setShockY((Double) configurationFromDB.get(MongoConstants.SHOCK_Y));
			configuration.setShockZ((Double) configurationFromDB.get(MongoConstants.SHOCK_Z));
			configuration
					.setGpsMoving((Integer) configurationFromDB.get(MongoConstants.GPS_MOVING));
			configuration.setGpsTimeBased((Integer) configurationFromDB
					.get(MongoConstants.GPS_TIME_BASED));
			configuration
					.setGsmMoving((Integer) configurationFromDB.get(MongoConstants.GSM_MOVING));
			configuration.setGsmTimeBased((Integer) configurationFromDB
					.get(MongoConstants.GSM_TIME_BASED));
			configuration.setTenantId((String) configurationFromDB.get(MongoConstants.TENANT_ID));
			configuration.setWagonId((String) configurationFromDB.get(MongoConstants.WAGON_ID));
			configuration.setBoxId((Long) configurationFromDB.get(MongoConstants.BOX_ID));
			configurations.add(configuration);
		}
		return configurations;
	}
}
