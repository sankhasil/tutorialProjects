
package com.bosch.si.amra.constants.role;

public class UserRolesConstants
{
	public static final String		ALIAS				= "wagonAlias";

	public static final String		WAGON_TYPE			= "typeName";

	public static final String		DISPONENTS			= "name";

	public static final String[]	DEFAULT_COLLAPSIBLE	= {};

	public static final Object[]	PROPERTY_IDS		= { ALIAS, WAGON_TYPE, DISPONENTS };
}
