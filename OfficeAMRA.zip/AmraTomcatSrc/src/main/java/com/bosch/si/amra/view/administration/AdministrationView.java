
package com.bosch.si.amra.view.administration;

import java.util.Iterator;
import java.util.List;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.component.CouplingPanel;
import com.bosch.si.amra.component.WagonConfigurationPanel;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.entity.WagonType;
import com.bosch.si.amra.event.DashboardEvent.ClearValueEvent;
import com.bosch.si.amra.event.DashboardEvent.MaximizeDashboardPanelEvent;
import com.bosch.si.amra.event.DashboardEvent.MinimizeDashboardPanelEvent;
import com.bosch.si.amra.event.DashboardEvent.WagonSelectedEvent;
import com.bosch.si.amra.event.DashboardEvent.WagonTypeDeleteEvent;
import com.bosch.si.amra.event.DashboardEvent.WagonTypeEvent;
import com.bosch.si.amra.event.DashboardEvent.WagonTypeStatusEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.im.login.Role;
import com.bosch.si.amra.im.login.Role.Roles;
import com.bosch.si.amra.presenter.administration.AdministrationPresenterImpl;
import com.google.common.eventbus.Subscribe;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Page;
import com.vaadin.server.Responsive;
import com.vaadin.server.VaadinSession;
import com.vaadin.ui.AbstractTextField.TextChangeEventMode;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.Component;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.MenuBar;
import com.vaadin.ui.MenuBar.MenuItem;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Notification.Type;
import com.vaadin.ui.Panel;
import com.vaadin.ui.Table;
import com.vaadin.ui.Table.Align;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

@Role ({ Roles.FLEETADMIN, Roles.SYSTEMADMIN })
@SuppressWarnings ("serial")
public class AdministrationView extends Panel implements View
{

	public static final String		EDIT_ID		= "dashboard-edit";

	public static final String		TITLE_ID	= "dashboard-title";

	private static final String		TYPE_NAME	= "typeName";

	private Label					titleLabel;

	private CssLayout				dashboardPanels;

	private final VerticalLayout	root;

	private WagonConfigurationPanel	wagonConfiguration;

	private TextField				transportName;

	private final User				user		= (User) VaadinSession.getCurrent()
			.getAttribute(User.class.getName());

	private final List<WagonType>	wagonTypes;

	private final List<Wagon>		wagons;

	private WagonType				selectedWagonType;

	private Button					deleteWagonTypeButton;

	private Button					addWagonTypeButton;

	private Table					table;

	public AdministrationView()
	{
		wagonTypes = DashboardUI.getDataProvider().getWagonTypes(user.getTenant());
		wagons = DashboardUI.getDataProvider().getWagons(user);

		addStyleName(ValoTheme.PANEL_BORDERLESS);
		setSizeFull();
		DashboardEventBus.register(this);

		root = new VerticalLayout();
		root.setSizeFull();
		root.setMargin(true);
		root.addStyleName("dashboard-view");
		setContent(root);
		Responsive.makeResponsive(root);

		root.addComponent(buildToolbar());

		Component content = buildContent();
		root.addComponent(content);
		root.setExpandRatio(content, 1);
	}

	@Override
	public void detach()
	{
		super.detach();

		DashboardEventBus.unregister(this);
	}

	private Component buildToolbar()
	{
		HorizontalLayout header = new HorizontalLayout();
		header.addStyleName("viewheader");
		header.setSpacing(true);

		titleLabel = new Label(
				DashboardUI.getMessageSource().getMessage("view.administration.caption"));
		titleLabel.setId(TITLE_ID);
		titleLabel.setSizeUndefined();
		titleLabel.addStyleName(ValoTheme.LABEL_H1);
		titleLabel.addStyleName(ValoTheme.LABEL_NO_MARGIN);
		header.addComponents(titleLabel);

		HorizontalLayout headerLayout = new HorizontalLayout(buildClearAllFields());
		headerLayout.setSpacing(true);
		headerLayout.addStyleName("toolbar");

		header.addComponent(headerLayout);

		return header;
	}

	private Button buildClearAllFields()
	{
		final Button clearAllFields = new Button(
				DashboardUI.getMessageSource().getMessage("view.administration.button.clear"));
		clearAllFields.setDescription(DashboardUI.getMessageSource()
				.getMessage("view.administration.button.clear.tooltip"));
		clearAllFields.setIcon(FontAwesome.ERASER);
		clearAllFields.addStyleName(ValoTheme.BUTTON_ICON_ONLY);
		clearAllFields.addClickListener(listner -> {
			DashboardEventBus.post(new ClearValueEvent());
		});
		return clearAllFields;
	}

	private Component buildContent()
	{
		dashboardPanels = new CssLayout();
		dashboardPanels.addStyleName("dashboard-panels");
		Responsive.makeResponsive(dashboardPanels);

		dashboardPanels.addComponent(buildCreateWagon());
		dashboardPanels.addComponent(buildCoupling());
		dashboardPanels.addComponent(buildMeansOfTransport());

		return dashboardPanels;
	}

	private Component buildCreateWagon()
	{
		wagonConfiguration = new WagonConfigurationPanel(true, wagonTypes);
		wagonConfiguration.setCaption(DashboardUI.getMessageSource()
				.getMessage("view.administration.create.wagon.caption"));

		Wagon createdWagon = new Wagon();
		createdWagon.setTenantId(user.getTenant());
		wagonConfiguration.fillDetails(new WagonSelectedEvent(createdWagon));

		return createContentWrapper(wagonConfiguration);
	}

	private Component buildCoupling()
	{
		final CouplingPanel couplingPanel = new CouplingPanel(wagons);
		couplingPanel.setCaption(
				DashboardUI.getMessageSource().getMessage("view.administration.coupling.caption"));

		return createContentWrapper(couplingPanel);
	}

	private Component buildMeansOfTransport()
	{
		final VerticalLayout mainLayout = new VerticalLayout();
		mainLayout.setSizeFull();
		mainLayout.setSpacing(true);
		mainLayout.setCaption(
				DashboardUI.getMessageSource().getMessage("view.administration.transport.caption"));

		Component topComponent = buildTopComponent();
		Component tableComponent = buildTableComponent();
		tableComponent.setSizeFull();
		mainLayout.addComponent(topComponent);
		mainLayout.addComponent(tableComponent);

		mainLayout.setExpandRatio(topComponent, 1);
		mainLayout.setExpandRatio(tableComponent, 4);

		return createContentWrapper(mainLayout);
	}

	private Component buildTopComponent()
	{
		final HorizontalLayout meansOfTransport = new HorizontalLayout();
		meansOfTransport.setSizeFull();
		meansOfTransport.setSpacing(true);
		transportName = new TextField(
				DashboardUI.getMessageSource().getMessage("view.administration.transport.caption"));
		transportName.setImmediate(true);
		transportName.setRequired(true);
		transportName.setRequiredError(
				DashboardUI.getMessageSource().getMessage("view.administration.required.error"));
		transportName.setWidth("100%");
		transportName.setTextChangeEventMode(TextChangeEventMode.EAGER);

		addWagonTypeButton = new Button();
		addWagonTypeButton.addStyleName(ValoTheme.BUTTON_ICON_ONLY);
		addWagonTypeButton.setIcon(FontAwesome.PLUS);
		addWagonTypeButton.setEnabled(false);
		addWagonTypeButton.setDescription(DashboardUI.getMessageSource()
				.getMessage("view.administration.addmeansoftransport"));
		addWagonTypeButton.addClickListener(event -> {
			WagonType wagonType = new WagonType();
			wagonType.setTypeName(transportName.getValue());
			wagonType.setTenantId(user.getTenant());
			DashboardEventBus.post(new WagonTypeEvent(wagonType, user.getTenant()));
		});

		deleteWagonTypeButton = new Button();
		deleteWagonTypeButton.addStyleName(ValoTheme.BUTTON_ICON_ONLY);
		deleteWagonTypeButton.setIcon(FontAwesome.TRASH_O);
		deleteWagonTypeButton.setEnabled(false);
		deleteWagonTypeButton.setDescription(DashboardUI.getMessageSource()
				.getMessage("view.administration.removemeansoftransport"));
		deleteWagonTypeButton.addClickListener(event -> {
			if (selectedWagonType != null)
			{
				// post the removal event notifying interested parties
				DashboardEventBus
						.post(new WagonTypeDeleteEvent(selectedWagonType, user.getTenant()));
			}
		});

		final HorizontalLayout tools = new HorizontalLayout(addWagonTypeButton,
				deleteWagonTypeButton);
		tools.setSpacing(true);
		tools.addStyleName("toolbar");

		transportName.addTextChangeListener(event -> {
			boolean isTextEmpty = event.getText().trim().isEmpty();
			transportName.setValidationVisible(isTextEmpty);
			addWagonTypeButton.setEnabled(!isTextEmpty);
		});
		meansOfTransport.addComponent(transportName);
		meansOfTransport.addComponent(tools);
		meansOfTransport.setComponentAlignment(tools, Alignment.MIDDLE_RIGHT);

		return meansOfTransport;
	}

	private Component buildTableComponent()
	{
		table = new Table();
		table.setSizeFull();
		table.addStyleName(ValoTheme.TABLE_SMALL);
		table.setImmediate(true);
		table.setSelectable(true);
		if (wagonTypes != null && wagonTypes.size() > 0)
		{
			table.setContainerDataSource(new BeanItemContainer<>(WagonType.class, wagonTypes));
			table.setVisibleColumns(TYPE_NAME);
			table.setSortContainerPropertyId(TYPE_NAME);
			table.setColumnHeaders(DashboardUI.getMessageSource()
					.getMessage("view.administration.columnheader.typename"));
			table.setColumnAlignment(TYPE_NAME, Align.CENTER);

			table.addItemClickListener(itemClickEvent -> {
				selectedWagonType = (WagonType) itemClickEvent.getItemId();
				deleteWagonTypeButton.setEnabled(selectedWagonType != null);
			});
		}

		return table;
	}

	private Component createContentWrapper(Component content)
	{
		final CssLayout slot = new CssLayout();
		slot.setWidth("100%");
		slot.addStyleName("dashboard-panel-slot");

		CssLayout card = new CssLayout();
		card.setWidth("100%");
		card.addStyleName(ValoTheme.LAYOUT_CARD);

		HorizontalLayout toolbar = new HorizontalLayout();
		toolbar.addStyleName("dashboard-panel-toolbar");
		toolbar.setWidth("100%");

		Label caption = new Label(content.getCaption());
		caption.addStyleName(ValoTheme.LABEL_H4);
		caption.addStyleName(ValoTheme.LABEL_COLORED);
		caption.addStyleName(ValoTheme.LABEL_NO_MARGIN);
		content.setCaption(null);

		MenuBar tools = new MenuBar();
		tools.addStyleName(ValoTheme.MENUBAR_BORDERLESS);
		MenuItem max = tools.addItem("", FontAwesome.EXPAND, selectedItem -> {
			if (!slot.getStyleName().contains("max"))
			{
				selectedItem.setIcon(FontAwesome.COMPRESS);
				DashboardEventBus.post(new MaximizeDashboardPanelEvent(slot));
			}
			else
			{
				slot.removeStyleName("max");
				selectedItem.setIcon(FontAwesome.EXPAND);
				DashboardEventBus.post(new MinimizeDashboardPanelEvent(slot));
			}
		});
		max.setStyleName("icon-only");

		toolbar.addComponents(caption, tools);
		toolbar.setExpandRatio(caption, 1);
		toolbar.setComponentAlignment(caption, Alignment.MIDDLE_LEFT);

		card.addComponents(toolbar, content);
		slot.addComponent(card);
		return slot;
	}

	@Override
	public void enter(ViewChangeEvent event)
	{

	}

	@Subscribe
	public void maximizePanel(MaximizeDashboardPanelEvent event)
	{
		for (Iterator<Component> it = dashboardPanels.iterator(); it.hasNext();)
		{
			Component c = it.next();
			c.removeStyleName("max");
			c.setVisible(false);
		}
		event.getPanel().addStyleName("max");
		event.getPanel().setVisible(true);

		for (Iterator<Component> it = root.iterator(); it.hasNext();)
		{
			it.next().setVisible(false);
		}
		dashboardPanels.setVisible(true);
	}

	@Subscribe
	public void minimizePanel(MinimizeDashboardPanelEvent event)
	{
		for (Iterator<Component> it = dashboardPanels.iterator(); it.hasNext();)
		{
			Component c = it.next();
			c.removeStyleName("max");
			c.setVisible(true);
		}

		for (Iterator<Component> it = root.iterator(); it.hasNext();)
		{
			it.next().setVisible(true);
		}
	}

	/**
	 * Called from {@link AdministrationPresenterImpl} {@code saveWagonType()} or
	 * {@code deleteWagonType()}
	 *
	 * @param event
	 *            {@link WagonTypeStatusEvent}
	 */
	@Subscribe
	public void showWagonTypeStatusEvent(WagonTypeStatusEvent event)
	{
		Notification erroNotification = null;

		switch (event.getStatus())
		{
			case OK_ADDED:
				table.addItem(event.getWagonType());
				transportName.setValue("");
				addWagonTypeButton.setEnabled(false);
				break;

			case OK_REMOVED:
				table.removeItem(event.getWagonType());
				deleteWagonTypeButton.setEnabled(false);
				break;

			case ERROR_EXISTING_TRANSPORT_TYPE:
				erroNotification = new Notification(DashboardUI.getMessageSource()
						.getMessage("view.administration.type.not.unique"), Type.WARNING_MESSAGE);
				break;

			case ERROR_USED_TRANSPORT_TYPE:
				erroNotification = new Notification(
						DashboardUI.getMessageSource().getMessage("view.administration.type.used"),
						Type.WARNING_MESSAGE);
				break;
		}

		if (erroNotification != null)
		{
			erroNotification.setDelayMsec(1000);
			erroNotification.show(Page.getCurrent());
		}
	}
}
