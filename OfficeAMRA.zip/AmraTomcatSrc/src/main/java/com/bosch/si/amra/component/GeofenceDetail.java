
package com.bosch.si.amra.component;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.event.DashboardEventBus;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Component;
import com.vaadin.ui.Label;
import com.vaadin.ui.TextArea;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

public class GeofenceDetail extends VerticalLayout
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= -6353012927476142162L;

	private final String		titleName;

	private TextArea			editableContent;

	private Label				readOnlyContent;

	public GeofenceDetail(String titleName)
	{
		DashboardEventBus.register(this);

		this.titleName = titleName;

		setSizeUndefined();
		addStyleName("detail");
		setDefaultComponentAlignment(Alignment.TOP_CENTER);

		addComponent(buildTitle());
		addComponent(buildReadOnlyContent());
		buildEditableContent();
	}

	private Label buildTitle()
	{
		Label title = new Label(DashboardUI.getMessageSource().getMessage(titleName));
		title.setSizeUndefined();
		title.addStyleName(ValoTheme.LABEL_SMALL);
		title.addStyleName(ValoTheme.LABEL_LIGHT);

		return title;
	}

	private Component buildReadOnlyContent()
	{
		readOnlyContent = new Label();
		readOnlyContent.addStyleName(ValoTheme.LABEL_LARGE);
		readOnlyContent.addStyleName("align-center");
		readOnlyContent.addStyleName("word-wrapping");
		readOnlyContent.setWidth("90%");
		return readOnlyContent;
	}

	private Component buildEditableContent()
	{
		editableContent = new TextArea();
		editableContent.setRows(2);
		editableContent.setSizeFull();
		editableContent.addStyleName(ValoTheme.LABEL_LARGE);
		editableContent.addStyleName(ValoTheme.TEXTAREA_ALIGN_CENTER);
		editableContent.setImmediate(true);
		editableContent.setPropertyDataSource(readOnlyContent);
		return editableContent;
	}

	public void setGeofenceDetail(String geofenceDetail)
	{
		readOnlyContent.setValue(geofenceDetail);
	}

	public String getGeofenceDetail()
	{
		return editableContent.getValue();
	}

	public void clearGeofenceDetail()
	{
		readOnlyContent.setValue("");
		editableContent.setValue("");
	}

	public void replaceContent(boolean edit)
	{
		if (edit)
		{
			replaceComponent(readOnlyContent, editableContent);
		}
		else
		{
			replaceComponent(editableContent, readOnlyContent);
		}
	}
}
