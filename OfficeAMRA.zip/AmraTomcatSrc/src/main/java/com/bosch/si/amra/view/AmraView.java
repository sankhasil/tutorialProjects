
package com.bosch.si.amra.view;

import com.bosch.si.amra.view.administration.AdministrationView;
import com.bosch.si.amra.view.configuration.ConfigurationView;
import com.bosch.si.amra.view.dashboard.DashboardView;
import com.bosch.si.amra.view.details.DetailsView;
import com.bosch.si.amra.view.disponent.DisponentView;
import com.bosch.si.amra.view.export.ExportView;
import com.bosch.si.amra.view.fleetbalancing.FleetBalancingView;
import com.bosch.si.amra.view.geofence.GeofenceView;
import com.bosch.si.amra.view.notification.NotificationView;
import com.bosch.si.amra.view.overview.OverviewView;
import com.bosch.si.amra.view.report.ReportView;
import com.bosch.si.amra.view.role.RoleView;
import com.bosch.si.amra.view.rule.RuleView;
import com.vaadin.navigator.View;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Resource;

public enum AmraView
{
	DASHBOARD("dashboard", DashboardView.class, FontAwesome.HOME, false), DISPONENT("disponent",
			DisponentView.class, FontAwesome.USER,
			false), OVERVIEW("overview", OverviewView.class, FontAwesome.TABLE, false), DETAILS(
					"details", DetailsView.class, FontAwesome.INFO_CIRCLE, false), REPORT("report",
							ReportView.class, FontAwesome.BAR_CHART_O,
							false), BALANCING("fleet.balancing", FleetBalancingView.class,
									FontAwesome.BALANCE_SCALE, false), GEOFENCE("geofence",
											GeofenceView.class, FontAwesome.GLOBE,
											false), NOTIFICATION("notification",
													NotificationView.class, FontAwesome.BELL,
													false), CONF("configuration",
															ConfigurationView.class,
															FontAwesome.COG, false), EXPORT(
																	"export", ExportView.class,
																	FontAwesome.TABLE, false), RULE(
																			"rule", RuleView.class,
																			FontAwesome.LEGAL,
																			false), ROLE("role",
																					RoleView.class,
																					FontAwesome.USERS,
																					false), ADMINISTRATION(
																							"administration",
																							AdministrationView.class,
																							FontAwesome.COGS,
																							false);
	private final String				viewName;

	private final Class<? extends View>	viewClass;

	private final Resource				icon;

	private final boolean				stateful;

	private AmraView(String viewName, Class<? extends View> viewClass, Resource icon,
			boolean stateful)
	{
		this.viewName = viewName;
		this.viewClass = viewClass;
		this.icon = icon;
		this.stateful = stateful;
	}

	public boolean isStateful()
	{
		return stateful;
	}

	public String getViewName()
	{
		return viewName;
	}

	public Class<? extends View> getViewClass()
	{
		return viewClass;
	}

	public Resource getIcon()
	{
		return icon;
	}

}
