
package com.bosch.si.amra.view.configuration;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.vaadin.dialogs.ConfirmDialog;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.component.grid.ConfigurationGrid;
import com.bosch.si.amra.constants.configuration.ConfigurationConstants;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.configuration.Configuration;
import com.bosch.si.amra.event.DashboardEvent.ConfigurationsSaveEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.view.configuration.converter.IntervalConverter;
import com.vaadin.data.Item;
import com.vaadin.data.Validator.InvalidValueException;
import com.vaadin.data.util.converter.StringToDoubleConverter;
import com.vaadin.data.util.converter.StringToIntegerConverter;
import com.vaadin.data.validator.DoubleRangeValidator;
import com.vaadin.data.validator.IntegerRangeValidator;
import com.vaadin.data.validator.StringLengthValidator;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Page;
import com.vaadin.server.VaadinSession;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.GridLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.OptionGroup;
import com.vaadin.ui.TextField;
import com.vaadin.ui.UI;
import com.vaadin.ui.themes.ValoTheme;

public class ConfigurationEditLayout extends GridLayout
{
	private static final long		serialVersionUID					= 4323352977640784313L;

	private static final Logger		logger								= LoggerFactory
			.getLogger(ConfigurationEditLayout.class);

	private static final int		ROWS								= 17;

	private static final int		COLUMNS								= 4;

	/*
	 * GRID_LAYOUT_MAX_ROWS is equal to the no of columns of grid or table in configuration view for
	 * super admin
	 */
	private static final int		GRID_LAYOUT_MAX_ROWS				= 16;

	private static final int		GRID_LAYOUT_MAX_COLUMNS				= 3;

	private static final int		RADIO_BUTTONS_ROW_RANGE_MIN			= 1;

	private static final int		RADIO_BUTTONS_ROW_RANGE_MAX			= 5;

	private static final int		TEXT_FEILD_ROW_RANGE_MIN			= 6;

	private static final int		SHOCK_TEXT_FEILD_ROW_RANGE_MIN		= 6;

	private static final int		SHOCK_TEXT_FEILD_ROW_RANGE_MAX		= 8;

	private static final int		INTERVAL_TEXT_FEILD_ROW_RANGE_MIN	= 9;

	private static final int		INTERVAL_TEXT_FEILD_ROW_RANGE_MAX	= 12;

	private static final int		FIRMWARE_TEXT_FEILD_ROW_RANGE_VALUE	= 13;

	private static final int		STATUS_TEXT_FEILD_ROW_RANGE_VALUE	= 14;

	private static final int		RESET_RADIO_BUTTONS_ROW_RANGE		= 5;

	private static final int		LABEL_COLUMN						= 0;

	private static final int		COMPONENT_COLUMN					= 1;

	private static final int		RADIO_RESET_BUTTONS_COLUMN			= 2;

	private final User				user								= (User) VaadinSession
			.getCurrent().getAttribute(User.class.getName());

	private int						maxInputFeildsRows, actionButtonsLocation;

	private ConfigurationGrid		configurationGrid;

	private List<Configuration>		configurations;

	private ConfigurationEditWindow	configurationEditWindow;

	private List<Configuration>		selectedConfigurations				= new ArrayList<Configuration>();

	ConfigurationEditLayout(ConfigurationEditWindow configurationEditWindow,
			ConfigurationGrid configurationGrid, List<Configuration> configurations)
	{
		this.configurationGrid = configurationGrid;
		this.configurations = configurations;
		this.configurationEditWindow = configurationEditWindow;
		setColumns(COLUMNS);
		setRows(ROWS);
		setSpacing(true);
		buildGridLayout();
	}

	/**
	 * Builds the columns of the sub windows as grid Layout.
	 */
	private void buildGridLayout()
	{
		for (Object id : configurationGrid.getSelectedRows())
		{
			Item item = configurationGrid.getContainerDataSource().getItem(id);
			String alias = (String) item.getItemProperty(ConfigurationConstants.ALIAS).getValue();

			// normally the configuration should always be found
			Configuration config = configurations.stream()
					.filter(filter -> filter.getAlias().equals(alias)).findFirst().get();
			selectedConfigurations.add(config);
		}

		maxInputFeildsRows = user.isSuperAdmin() ? GRID_LAYOUT_MAX_ROWS - 2
				: GRID_LAYOUT_MAX_ROWS - 4;
		for (int column = 0; column < GRID_LAYOUT_MAX_COLUMNS; column++)
		{
			if (column == LABEL_COLUMN)
			{
				buildGridLayoutFirstColumn(column, maxInputFeildsRows);

			}
			else if (column == COMPONENT_COLUMN)
			{
				buildGridLayoutSecondColumn(column, maxInputFeildsRows);
			}
			else if (column == RADIO_RESET_BUTTONS_COLUMN)
			{
				buildGridLayoutThirdColumn(column, maxInputFeildsRows);
			}

		}
		actionButtonsLocation = user.isSuperAdmin() ? GRID_LAYOUT_MAX_ROWS
				: GRID_LAYOUT_MAX_ROWS - 2;
		buildButtonLayout(actionButtonsLocation);
	}

	private void buildGridLayoutFirstColumn(int column, int maxRows)
	{
		for (int row = 1; row <= maxRows; row++)
		{
			Label label = new Label();
			// Editable columns starts from humidity
			label.setValue(DashboardUI.getMessageSource()
					.getMessage(ConfigurationConstants.SUBWINDOW_COMPONENT_CAPTION
							+ ConfigurationConstants.PROPERTY_IDS[row + 2]));
			addComponent(label, column, row);
			setComponentAlignment(label, Alignment.MIDDLE_LEFT);
		}
	}

	private void buildGridLayoutSecondColumn(int column, int maxRows)
	{
		for (int row = RADIO_BUTTONS_ROW_RANGE_MIN; row <= RADIO_BUTTONS_ROW_RANGE_MAX; row++)
		{
			OptionGroup optionGroup = new OptionGroup();
			optionGroup.addItems("On", "Off");
			optionGroup.addStyleName("horizontal");
			addComponent(optionGroup, column, row);
			setComponentAlignment(optionGroup, Alignment.BOTTOM_RIGHT);
		}
		for (int row = TEXT_FEILD_ROW_RANGE_MIN; row <= maxRows; row++)
		{
			if (row >= SHOCK_TEXT_FEILD_ROW_RANGE_MIN && row <= SHOCK_TEXT_FEILD_ROW_RANGE_MAX)
			{
				String errorEditShockMessage = String.format(
						Page.getCurrent().getWebBrowser().getLocale(),
						DashboardUI.getMessageSource()
								.getMessage("view.configuration.shock.notvalid"),
						DashboardUI.getShockMin(), DashboardUI.getShockMax());
				TextField shockTextField = new TextField();
				shockTextField.setWidth("100%");
				shockTextField.setConversionError(errorEditShockMessage);
				shockTextField.addValidator(new DoubleRangeValidator(errorEditShockMessage,
						DashboardUI.getShockMin(), DashboardUI.getShockMax()));
				shockTextField.setConverter(new StringToDoubleConverter());
				shockTextField
						.setStyleName(ConfigurationConstants.STYLE_EDIT_TAB_TEXT_FIELD_RIGHT_ALIGN);
				// the next method is used as otherwise if empty string is entered it is
				// shown 'red null' during validation instead of 'red empty string'
				shockTextField.setNullRepresentation("");
				addComponent(shockTextField, column, row);
			}
			else if (row >= INTERVAL_TEXT_FEILD_ROW_RANGE_MIN
					&& row <= INTERVAL_TEXT_FEILD_ROW_RANGE_MAX)
			{
				IntervalConverter intervalConverter = new IntervalConverter();
				TextField intervalTextField = new TextField();
				String errorEditIntervalMessage = String.format(
						DashboardUI.getMessageSource()
								.getMessage("view.configuration.interval.notvalid"),
						intervalConverter.convertToPresentation(
								ConfigurationConstants.MINIMUM_INTERVAL, String.class,
								Page.getCurrent().getWebBrowser().getLocale()),
						intervalConverter.convertToPresentation(
								ConfigurationConstants.MAXIMUM_INTERVAL, String.class,
								Page.getCurrent().getWebBrowser().getLocale()));
				intervalTextField.setConversionError(errorEditIntervalMessage);
				intervalTextField
						.setStyleName(ConfigurationConstants.STYLE_EDIT_TAB_TEXT_FIELD_RIGHT_ALIGN);
				intervalTextField.addValidator(new IntegerRangeValidator(errorEditIntervalMessage,
						ConfigurationConstants.MINIMUM_INTERVAL,
						ConfigurationConstants.MAXIMUM_INTERVAL));
				intervalTextField.setConverter(intervalConverter);

				addComponent(intervalTextField, column, row);
			}
			else if (row == FIRMWARE_TEXT_FEILD_ROW_RANGE_VALUE)
			{
				String errorEditFlashDataMessage = String.format(
						DashboardUI.getMessageSource()
								.getMessage("view.configuration.firmware.notvalid"),
						ConfigurationConstants.MINIMUM_FW_VERSION,
						ConfigurationConstants.MAXIMUM_FW_VERSION);
				TextField versionTextField = new TextField();
				versionTextField.setConversionError(errorEditFlashDataMessage);
				versionTextField
						.setStyleName(ConfigurationConstants.STYLE_EDIT_TAB_TEXT_FIELD_RIGHT_ALIGN);
				versionTextField.addValidator(new IntegerRangeValidator(errorEditFlashDataMessage,
						ConfigurationConstants.MINIMUM_FW_VERSION,
						ConfigurationConstants.MAXIMUM_FW_VERSION));
				// the next method is used as otherwise if empty string is entered it is
				// shown 'red null' during validation instead of 'red empty string'
				versionTextField.setNullRepresentation("");
				versionTextField.setConverter(new StringToIntegerConverter());
				addComponent(versionTextField, column, row);

			}
			else if (row == STATUS_TEXT_FEILD_ROW_RANGE_VALUE)
			{
				String errorEditStatusMessage = String.format(
						DashboardUI.getMessageSource()
								.getMessage("view.configuration.status.notvalid"),
						ConfigurationConstants.MAXIMUM_STATUS);
				TextField statusTextField = new TextField();
				statusTextField.setConversionError(errorEditStatusMessage);
				statusTextField
						.setStyleName(ConfigurationConstants.STYLE_EDIT_TAB_TEXT_FIELD_RIGHT_ALIGN);
				statusTextField.addValidator(new StringLengthValidator(errorEditStatusMessage,
						ConfigurationConstants.MINIMUM_STATUS - 1,
						ConfigurationConstants.MAXIMUM_STATUS, false));
				addComponent(statusTextField, column, row);
			}
		}
	}

	private void buildGridLayoutThirdColumn(int column, int maxRows)
	{
		for (int row = 1; row <= RESET_RADIO_BUTTONS_ROW_RANGE; row++)
		{
			Button button = new Button();
			button.setIcon(FontAwesome.ERASER);
			button.addStyleName("radio-reset-button");
			button.setDescription(DashboardUI.getMessageSource()
					.getMessage(ConfigurationConstants.RESET_CAPTION));
			resetRadioButton(button, row);
			addComponent(button, RADIO_RESET_BUTTONS_COLUMN, row);
			setComponentAlignment(button, Alignment.MIDDLE_CENTER);
		}

		for (int row = TEXT_FEILD_ROW_RANGE_MIN; row <= maxRows; row++)
		{
			Label label = new Label();
			// Editable columns starts from humidity
			label.setValue(DashboardUI.getMessageSource()
					.getMessage(ConfigurationConstants.SUBWINDOW_COMPONENT_CAPTION
							+ ConfigurationConstants.PROPERTY_IDS[row + 2] + ".units"));
			addComponent(label, column, row);
			setComponentAlignment(label, Alignment.MIDDLE_LEFT);
		}
	}

	private void buildButtonLayout(int position)
	{
		Button refresh = new Button();
		Button save = new Button();
		HorizontalLayout buttonLayout = new HorizontalLayout();
		buttonLayout.setSpacing(true);
		refresh.setIcon(FontAwesome.REFRESH);
		refresh.addStyleName(ValoTheme.BUTTON_ICON_ONLY);
		refresh.setDescription(
				DashboardUI.getMessageSource().getMessage(ConfigurationConstants.RESET_TOOLTIP));
		save.setIcon(FontAwesome.SAVE);
		save.addStyleName(ValoTheme.BUTTON_ICON_ONLY);
		save.setDescription(
				DashboardUI.getMessageSource().getMessage(ConfigurationConstants.SAVE_TOOLTIP));
		refresh.addClickListener(listener -> {
			refreshSubWindow();
		});
		save.addClickListener(listener -> {
			try
			{
				if (validateInputFields() == false)
				{
					saveConfigurationValues();
				}
				else
				{
					com.vaadin.ui.Notification.show(DashboardUI.getMessageSource()
							.getMessage("view.configuration.subwindow.form.status"));
				}
			}
			catch (InvalidValueException e)
			{
				logger.debug("[Validation] Failed User input.", e.getMessage());
			}
		});
		buttonLayout.addComponent(save);
		buttonLayout.addComponent(refresh);
		addComponent(buttonLayout, COMPONENT_COLUMN, position);
	}

	private void resetRadioButton(Button button, int row)
	{
		button.addClickListener(listener -> {
			OptionGroup optionGroup = (OptionGroup) getComponent(COMPONENT_COLUMN, row);
			optionGroup.clear();
		});
	}

	private void refreshSubWindow()
	{

		for (int row = RADIO_BUTTONS_ROW_RANGE_MIN; row <= RADIO_BUTTONS_ROW_RANGE_MAX; row++)
		{
			OptionGroup optionGroup = (OptionGroup) getComponent(COMPONENT_COLUMN, row);
			optionGroup.clear();
		}

		for (int row = TEXT_FEILD_ROW_RANGE_MIN; row <= maxInputFeildsRows; row++)
		{
			TextField textField = (TextField) getComponent(1, row);
			textField.clear();
		}
	}

	/**
	 * Validates the user's values for the corresponding input fields in configuration edit form.
	 *
	 * @return true - if form is empty, false - otherwise.
	 * @throws InvalidValueException
	 *             - Exception during validation of some input field.
	 */
	private Boolean validateInputFields() throws InvalidValueException
	{
		Boolean isEmpty = true;

		for (int row = RADIO_BUTTONS_ROW_RANGE_MIN; row <= RADIO_BUTTONS_ROW_RANGE_MAX; row++)
		{
			OptionGroup optionGroup = (OptionGroup) getComponent(COMPONENT_COLUMN, row);
			if (!optionGroup.isEmpty())
			{
				isEmpty = false;
				break;
			}
		}

		for (int row = TEXT_FEILD_ROW_RANGE_MIN; row <= maxInputFeildsRows; row++)
		{
			TextField textField = (TextField) getComponent(1, row);

			textField.setValidationVisible(true);
			textField.validate();
			if (!textField.isEmpty())
			{
				isEmpty = false;
			}
		}
		return isEmpty;
	}

	private void saveConfigurationValues()
	{
		ConfirmDialog.show(this.getUI(), "",
				DashboardUI.getMessageSource()
						.getMessage("view.configuration.subwindow.dialog.confirm"),
				DashboardUI.getMessageSource().getMessage("view.dashboard.ok"),
				DashboardUI.getMessageSource().getMessage("view.dashboard.cancel"), dialog -> {

					if (dialog.isConfirmed())
					{
						selectedConfigurations = getNewConfiguarationValues(selectedConfigurations);
						DashboardEventBus.post(new ConfigurationsSaveEvent(selectedConfigurations,
								user.getTenant()));

						configurationGrid.setSortOrder(configurationGrid.getSortOrder());
						UI.getCurrent().removeWindow(configurationEditWindow);
					}
				});
	}

	/**
	 * Sets the values of the selected rows configurations to new values provided in the
	 * form.
	 *
	 * @param configurations
	 *            current configurations
	 * @return list of edited configurations
	 */
	private List<Configuration> getNewConfiguarationValues(List<Configuration> configurations)
	{
		for (int row = RADIO_BUTTONS_ROW_RANGE_MIN; row <= RADIO_BUTTONS_ROW_RANGE_MAX; row++)
		{
			OptionGroup optionGroup = (OptionGroup) getComponent(COMPONENT_COLUMN, row);
			if (!optionGroup.isEmpty())
			{
				for (Configuration configuration : configurations)
				{
					switch (row)
					{
						case 1:
							configuration.setHumidity(
									Boolean.valueOf(optionGroup.getValue().toString().equals("On")
											? "true" : "false"));

							break;
						case 2:
							configuration.setHumidityTemperature(
									Boolean.valueOf(optionGroup.getValue().toString().equals("On")
											? "true" : "false"));
							break;
						case 3:
							configuration.setTemperature(
									Boolean.valueOf(optionGroup.getValue().toString().equals("On")
											? "true" : "false"));
							break;
						case 4:
							configuration.setDeviceTemperature(
									Boolean.valueOf(optionGroup.getValue().toString().equals("On")
											? "true" : "false"));

							break;
						case 5:
							configuration.setRouting(
									Boolean.valueOf(optionGroup.getValue().toString().equals("On")
											? "true" : "false"));

							break;

						default:
							break;
					}
				}
			}

		}
		for (int row = TEXT_FEILD_ROW_RANGE_MIN; row <= maxInputFeildsRows; row++)
		{
			TextField textField = (TextField) getComponent(COMPONENT_COLUMN, row);
			IntervalConverter intervalConverter = new IntervalConverter();
			if (!textField.isEmpty())
			{
				for (Configuration configuration : configurations)
				{
					switch (row)
					{
						case 6:
							configuration.setShockX(parseShockValue(textField));
							break;
						case 7:
							configuration.setShockY(parseShockValue(textField));
							break;
						case 8:
							configuration.setShockZ(parseShockValue(textField));
							break;
						case 9:
							configuration.setGpsMoving(intervalConverter.convertToModel(
									textField.getValue(), Integer.class,
									Page.getCurrent().getWebBrowser().getLocale()));
							break;
						case 10:
							intervalConverter = new IntervalConverter();
							configuration.setGpsTimeBased(intervalConverter.convertToModel(
									textField.getValue(), Integer.class,
									Page.getCurrent().getWebBrowser().getLocale()));
							break;
						case 11:
							intervalConverter = new IntervalConverter();
							configuration.setGsmMoving(intervalConverter.convertToModel(
									textField.getValue(), Integer.class,
									Page.getCurrent().getWebBrowser().getLocale()));
							break;
						case 12:
							intervalConverter = new IntervalConverter();
							configuration.setGsmTimeBased(intervalConverter.convertToModel(
									textField.getValue(), Integer.class,
									Page.getCurrent().getWebBrowser().getLocale()));
							break;
						case 13:
							configuration.setFlashData(parseFlashData(textField));
							break;
						case 14:
							configuration.setStatus(textField.getValue());
							break;

						default:
							break;
					}
				}
			}
		}
		return configurations;
	}

	private Double parseShockValue(TextField textField)
	{
		Double shockValue = null;
		try
		{
			if (textField != null)
			{
				NumberFormat decimalFormat = DecimalFormat
						.getInstance(Page.getCurrent().getWebBrowser().getLocale());
				shockValue = decimalFormat.parse(textField.getValue()).doubleValue();
			}
		}
		catch (ParseException e)
		{
			logger.error("Excpetion while parsing shock value." + e);
		}
		return shockValue;
	}

	private Integer parseFlashData(TextField textField)
	{
		Integer flashData = null;
		try
		{
			if (textField != null)
			{
				NumberFormat integerFormat = NumberFormat
						.getIntegerInstance(Page.getCurrent().getWebBrowser().getLocale());
				flashData = integerFormat.parse(textField.getValue()).intValue();
			}
		}
		catch (ParseException e)
		{
			logger.error("Excpetion while parsing flash data value." + e);
		}
		return flashData;
	}
}
