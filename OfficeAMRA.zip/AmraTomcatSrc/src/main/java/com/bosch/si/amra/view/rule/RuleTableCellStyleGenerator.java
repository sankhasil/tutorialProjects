
package com.bosch.si.amra.view.rule;

import com.bosch.si.amra.constants.rule.RuleConstants;
import com.bosch.si.amra.entity.rule.Rule;
import com.vaadin.ui.Table;
import com.vaadin.ui.Table.CellStyleGenerator;

public class RuleTableCellStyleGenerator implements CellStyleGenerator
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= 7290076311751662781L;

	@Override
	public String getStyle(Table source, Object itemId, Object propertyId)
	{
		Rule rule = (Rule) itemId;
		if (RuleConstants.RULE_NAME.equals(propertyId))
		{
			if (rule.getWagons() != null && !rule.getWagons().isEmpty())
			{
				return "coupled";
			}
		}
		if (RuleConstants.RULE_SEVERITY.equals(propertyId))
		{
			if (rule != null)
			{
				switch (rule.getSeverity())
				{
					case RED:
						return "red";
					case YELLOW:
						return "yellow";
					case GREEN:
						return "green";
					default:
						break;
				}
			}
		}
		if (RuleConstants.RULE_ACTIVE.equals(propertyId))
		{
			return rule.getActive() ? "on" : "off";
		}
		return null;
	}

}
