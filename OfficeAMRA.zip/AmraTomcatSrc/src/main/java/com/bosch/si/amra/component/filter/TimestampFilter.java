
package com.bosch.si.amra.component.filter;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.time.DateUtils;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.event.DashboardEvent.MapFilterEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.vaadin.data.Container.Filter;
import com.vaadin.data.Container.Filterable;
import com.vaadin.data.Item;
import com.vaadin.data.Property;
import com.vaadin.ui.DateField;
import com.vaadin.ui.Grid;

public class TimestampFilter<BEANTYPE> extends DateField
{
	/**
	 * Serial version uid
	 */
	private static final long serialVersionUID = 7657672589186832488L;

	public TimestampFilter(Object pid, Grid grid)
	{
		setWidth("100%");
		setHeight("75%");
		setDateFormat(DashboardUI.getMessageSource().getMessage("date.format.picker"));
		addValueChangeListener(event -> {
			Filterable container = (Filterable) grid.getContainerDataSource();
			List<Filter> removedFilter = container.getContainerFilters().stream()
					.filter(filter -> filter.appliesToProperty(pid)).collect(Collectors.toList());
			removedFilter.stream().forEach(
					filterToBeRemoved -> container.removeContainerFilter(filterToBeRemoved));
			if (event.getProperty().getValue() != null)
			{
				container.addContainerFilter(
						new DateFilter(pid, (Date) event.getProperty().getValue()));
			}
			DashboardEventBus.post(new MapFilterEvent());
		});
	}

	private static final class DateFilter implements Filter
	{
		/**
		 * Serial version uid
		 */
		private static final long	serialVersionUID	= -6164661003076759509L;

		private final Object		propertyId;

		private final Date			filterDate;

		public DateFilter(Object propertyId, Date filterDate)
		{
			this.propertyId = propertyId;
			this.filterDate = filterDate;
		}

		@Override
		public boolean passesFilter(Object itemId, Item item) throws UnsupportedOperationException
		{
			final Property<?> p = item.getItemProperty(propertyId);
			if (p == null)
			{
				return false;
			}
			Object propertyValue = p.getValue();
			if (propertyValue == null || !p.getType().equals(Date.class))
			{
				return false;
			}

			Date value = (Date) p.getValue();
			Calendar dateCalendar = Calendar.getInstance();
			dateCalendar.setTime(value);

			Calendar filterCalendar = Calendar.getInstance();
			filterCalendar.setTime(filterDate);

			return DateUtils.isSameDay(dateCalendar, filterCalendar);
		}

		@Override
		public boolean appliesToProperty(Object propertyId)
		{
			return propertyId != null && propertyId.equals(this.propertyId);
		}
	}
}
