
package com.bosch.si.amra.view.notification;

import java.util.HashMap;
import java.util.Map;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.common.GoogleMapUtilFactory;
import com.bosch.si.amra.constants.notification.NotificationConstants;
import com.bosch.si.amra.constants.rule.RuleConstants;
import com.bosch.si.amra.entity.LatLong;
import com.bosch.si.amra.entity.notification.Notification;
import com.vaadin.server.ThemeResource;
import com.vaadin.tapio.googlemaps.client.LatLon;
import com.vaadin.tapio.googlemaps.client.overlays.GoogleMapInfoWindow;
import com.vaadin.tapio.googlemaps.client.overlays.GoogleMapMarker;
import com.vaadin.ui.Label;
import com.vaadin.ui.MenuBar;
import com.vaadin.ui.MenuBar.MenuItem;
import com.vaadin.ui.themes.ValoTheme;

/**
 * Builds the menu items for the map toolbar to be able to filter according to the priority or
 * reason
 *
 * @author toa1wa3
 *
 */
public class NotificationViewMap
{
	public Label buildCaptionLabel()
	{
		Label caption = new Label(
				DashboardUI.getMessageSource().getMessage("view.notification.map"));
		caption.addStyleName(ValoTheme.LABEL_H4);
		caption.addStyleName(ValoTheme.LABEL_COLORED);
		caption.addStyleName(ValoTheme.LABEL_NO_MARGIN);
		return caption;
	}

	/**
	 * Creates the menu items and puts them in a map which is needed for deciding which filter
	 * criteria should be applied
	 *
	 * @param menuBar
	 *            the menuBar to add the items
	 * @return Map with all menu items and their string representation for either reason or priority
	 */
	public Map<MenuItem, String> buildToolbar(MenuBar menuBar)
	{
		Map<MenuItem, String> menuItems = new HashMap<>();

		menuBar.addStyleName(ValoTheme.MENUBAR_BORDERLESS);
		MenuItem bumper = menuBar.addItem("",
				new ThemeResource("img/notification/shunting_shock_detected.png"), null);
		bumper.setCheckable(true);
		bumper.setChecked(true);
		MenuItem humidity = menuBar.addItem("", new ThemeResource("img/notification/hm.png"), null);
		humidity.setCheckable(true);
		humidity.setChecked(true);
		MenuItem humidityTemperature = menuBar.addItem("",
				new ThemeResource("img/notification/ht.png"), null);
		humidityTemperature.setCheckable(true);
		humidityTemperature.setChecked(true);
		MenuItem deviceTemperature = menuBar.addItem("",
				new ThemeResource("img/notification/dt.png"), null);
		deviceTemperature.setCheckable(true);
		deviceTemperature.setChecked(true);
		MenuItem mileage = menuBar.addItem("", new ThemeResource("img/notification/km.png"), null);
		mileage.setCheckable(true);
		mileage.setChecked(true);
		MenuItem geofence = menuBar.addItem("", new ThemeResource("img/notification/geofence.png"),
				null);
		geofence.setCheckable(true);
		geofence.setChecked(true);
		MenuItem general = menuBar.addItem("",
				new ThemeResource("img/notification/general_notification.png"), null);
		general.setCheckable(true);
		general.setChecked(true);

		MenuItem doorOpenedStatus = menuBar.addItem("",
				new ThemeResource("img/notification/door_opened_detected.png"), null);
		doorOpenedStatus.setCheckable(true);
		doorOpenedStatus.setChecked(true);

		MenuItem doorClosedStatus = menuBar.addItem("",
				new ThemeResource("img/notification/door_closed_detected.png"), null);
		doorClosedStatus.setCheckable(true);
		doorClosedStatus.setChecked(true);

		MenuItem temperatureMinMaxRange = menuBar.addItem("",
				new ThemeResource("img/notification/htr.png"), null);
		temperatureMinMaxRange.setCheckable(true);
		temperatureMinMaxRange.setChecked(true);

		menuItems.put(bumper, "SHUNTING_SHOCK_DETECTED");
		menuItems.put(humidity, "HM");
		menuItems.put(humidityTemperature, "HT");
		menuItems.put(deviceTemperature, "DT");
		menuItems.put(mileage, "KM");
		menuItems.put(geofence, "GEOFENCE");
		menuItems.put(general, "GENERAL_NOTIFICATION");
		menuItems.put(doorOpenedStatus, "DOOR_OPENED");
		menuItems.put(doorClosedStatus, "DOOR_CLOSED");
		menuItems.put(temperatureMinMaxRange, RuleConstants.HUMIDITY_TEMPERATURE_RANGE);
		return menuItems;
	}

	public GoogleMapMarker buildNotificationMarker(Notification notification)
	{
		if (notification != null && notification.isGpsFixed())
		{
			LatLon notificationPosition = GoogleMapUtilFactory
					.buildLocation(new LatLong(notification.getLatitude().doubleValue(),
							notification.getLongitude().doubleValue()));
			GoogleMapMarker notificationMarker = GoogleMapUtilFactory
					.buildGoogleMapMarker(notificationPosition, notification.getAlias());
			notificationMarker.setDraggable(false);
			notificationMarker.setIconUrl("VAADIN/themes/dashboard/img/notification/"
					+ markerToIcon(notification.getRule().getRuleType()).toLowerCase() + ".png");
			return notificationMarker;
		}
		return null;
	}

	private String markerToIcon(String ruleType)
	{
		if (NotificationConstants.MAP_RULETYPE_TO_ICON.containsKey(ruleType))
		{
			return NotificationConstants.MAP_RULETYPE_TO_ICON.get(ruleType);
		}
		return "GENERAL_NOTIFICATION";
	}

	public GoogleMapInfoWindow buildNotificationMarkerWindow(GoogleMapMarker notificationMarker,
			Notification notification)
	{
		return GoogleMapUtilFactory.buildNotificationMarkerWindow(notificationMarker, notification);
	}
}
