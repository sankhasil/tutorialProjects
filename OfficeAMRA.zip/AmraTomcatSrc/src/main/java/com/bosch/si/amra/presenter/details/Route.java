
package com.bosch.si.amra.presenter.details;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.bosch.si.amra.entity.LatLong;
import com.vaadin.tapio.googlemaps.client.LatLon;

public class Route implements Serializable
{

	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= 336130652732219835L;

	private List<LatLon>		route				= new ArrayList<>();

	private List<LatLong>		positions			= new ArrayList<>();

	public List<LatLon> getRoute()
	{
		return route;
	}

	public void setRoute(List<LatLon> route)
	{
		this.route = route;
	}

	public List<LatLong> getPositions()
	{
		return positions;
	}

	public void setPositions(List<LatLong> positions)
	{
		this.positions = positions;
	}
}
