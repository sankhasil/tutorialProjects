
package com.bosch.si.amra.view.rule;

import java.util.Arrays;
import java.util.Collection;

import com.bosch.si.amra.constants.rule.RuleConstants;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.rule.Rule;
import com.bosch.si.amra.event.DashboardEvent.RuleSortAndFilterEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.server.VaadinSession;
import com.vaadin.ui.TextField;

public class RuleContainer extends BeanItemContainer<Rule>
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= -13111694770151710L;

	private final User			user;

	private final TextField		filter;

	public RuleContainer(Collection<Rule> collection, TextField filter)
	{
		super(Rule.class, collection);
		user = (User) VaadinSession.getCurrent().getAttribute(User.class.getName());
		this.filter = filter;
	}

	@Override
	public void sort(Object[] propertyId, boolean[] ascending)
	{
		final boolean sortAscending = ascending[0];
		final Object sortContainerPropertyId = propertyId[0];

		DashboardEventBus.post(new RuleSortAndFilterEvent(user.getTenant(),
				(String) sortContainerPropertyId, !sortAscending, filter.getValue()));
	}

	@Override
	public Collection<?> getSortableContainerPropertyIds()
	{
		return Arrays.asList(Arrays.copyOfRange(RuleConstants.PROPERTY_IDS, 0,
				RuleConstants.PROPERTY_IDS.length - 1));
	}
}
