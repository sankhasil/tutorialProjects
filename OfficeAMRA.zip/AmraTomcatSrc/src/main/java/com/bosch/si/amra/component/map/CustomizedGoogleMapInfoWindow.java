
package com.bosch.si.amra.component.map;

import java.util.Date;

import com.bosch.si.amra.entity.notification.Address;
import com.vaadin.tapio.googlemaps.client.overlays.GoogleMapInfoWindow;
/*
 * The CustomizedInfoWindows class extending GoogleMapInfoWindow specifically created for
 * setting and retrieving the alias of the Infowindows which was not there in GoogleMapInfoWindow
 * 
 * @author sks9kor
 */
import com.vaadin.tapio.googlemaps.client.overlays.GoogleMapMarker;

public class CustomizedGoogleMapInfoWindow extends GoogleMapInfoWindow
{

	private static final long	serialVersionUID	= 1L;

	private String				alias				= null;

	private Date				timestamp;

	private Address				address;

	public CustomizedGoogleMapInfoWindow(String content)
	{
		super(content);

	}

	public CustomizedGoogleMapInfoWindow(String content, GoogleMapMarker anchorMarker)
	{
		super(content);
		super.setAnchorMarker(anchorMarker);
	}

	public String getAlias()
	{
		return alias;
	}

	public void setAlias(String alias)
	{
		this.alias = alias;
	}

	public Date getTimestamp()
	{
		return timestamp;
	}

	public CustomizedGoogleMapInfoWindow setTimestamp(Date timestamp)
	{
		this.timestamp = timestamp;
		return this;
	}

	public Address getAddress()
	{
		return address;
	}

	public CustomizedGoogleMapInfoWindow setAddress(Address address)
	{
		this.address = address;
		return this;
	}
}
