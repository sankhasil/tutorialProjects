
package com.bosch.si.amra.view.details;

import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.common.GoogleMapUtilFactory;
import com.bosch.si.amra.component.MapLayout;
import com.bosch.si.amra.component.OpenInfoWindowOnMarkerClickListener;
import com.bosch.si.amra.component.Sparkline;
import com.bosch.si.amra.component.grid.HistoryGrid;
import com.bosch.si.amra.component.map.CustomizedGoogleMapInfoWindow;
import com.bosch.si.amra.constants.overview.OverviewConstants;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.event.DashboardEvent;
import com.bosch.si.amra.event.DashboardEvent.MaximizeDashboardPanelEvent;
import com.bosch.si.amra.event.DashboardEvent.MinimizeDashboardPanelEvent;
import com.bosch.si.amra.event.DashboardEvent.WagonDetailsEvent;
import com.bosch.si.amra.event.DashboardEvent.WagonSelectedEvent;
import com.bosch.si.amra.event.DashboardEvent.WagonSetEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.im.login.Role;
import com.bosch.si.amra.im.login.Role.Roles;
import com.bosch.si.amra.view.UserNotification;
import com.bosch.si.amra.view.common.DetailsContentWrapper;
import com.bosch.si.amra.view.overview.OverviewView;
import com.google.common.eventbus.Subscribe;
import com.vaadin.data.Container;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.server.Page;
import com.vaadin.server.Responsive;
import com.vaadin.server.VaadinSession;
import com.vaadin.tapio.googlemaps.client.LatLon;
import com.vaadin.tapio.googlemaps.client.overlays.GoogleMapMarker;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.Component;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.Grid;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Panel;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

@Role ({ Roles.USER, Roles.FLEETADMIN, Roles.SYSTEMADMIN })
@SuppressWarnings ("serial")
public class DetailsView extends Panel implements View
{
	public static final String				EDIT_ID		= "dashboard-edit";

	public static final String				TITLE_ID	= "dashboard-title";

	private Label							wagonTypeLabel;

	private Label							timestampLabel;

	private ComboBox						wagonSelect;

	private CssLayout						dashboardPanels;

	private final VerticalLayout			root;

	private Sparkline						mileageSparkline;

	private Sparkline						temperatureSparkline;

	private Sparkline						humidityTemperatureSparkline;

	private Sparkline						humiditySparkline;

	private Grid							telematicGrid;

	private GoogleMapMarker					mapMarker;

	private CustomizedGoogleMapInfoWindow	amraBoxInfoWindow;

	private MapLayout						mapLayout;

	private final DetailsContentWrapper		wrapper		= new DetailsContentWrapper();

	private final User						user		= (User) VaadinSession.getCurrent()
			.getAttribute(User.class.getName());

	public DetailsView()
	{
		addStyleName(ValoTheme.PANEL_BORDERLESS);
		setSizeFull();
		DashboardEventBus.register(this);

		root = new VerticalLayout();
		root.setSizeFull();
		root.setMargin(true);
		root.addStyleName("dashboard-view");
		setContent(root);
		Responsive.makeResponsive(root);

		root.addComponent(buildHeader());

		root.addComponent(buildSparklines());

		Component content = buildContent();
		root.addComponent(content);
		root.setExpandRatio(content, 1);
	}

	@Override
	public void detach()
	{
		super.detach();

		DashboardEventBus.unregister(this);
	}

	private Component buildHeader()
	{
		HorizontalLayout header = new HorizontalLayout();
		header.addStyleName("viewheader");
		header.setSpacing(true);

		VerticalLayout verticalLayout = new VerticalLayout();
		verticalLayout.addStyleName("details");
		verticalLayout.setSpacing(true);

		Label titleLabel = new Label(
				DashboardUI.getMessageSource().getMessage("view.details.caption"));
		titleLabel.setId(TITLE_ID);
		titleLabel.setSizeUndefined();
		titleLabel.addStyleName(ValoTheme.LABEL_H1);
		titleLabel.addStyleName(ValoTheme.LABEL_NO_MARGIN);

		wagonTypeLabel = new Label();
		wagonTypeLabel.setId(TITLE_ID);
		wagonTypeLabel.setSizeUndefined();
		wagonTypeLabel.addStyleName(ValoTheme.LABEL_H3);
		wagonTypeLabel.addStyleName(ValoTheme.LABEL_NO_MARGIN);

		timestampLabel = new Label();
		timestampLabel.setId("timestamp");
		timestampLabel.setSizeUndefined();
		timestampLabel.addStyleName(ValoTheme.LABEL_SMALL);
		timestampLabel.addStyleName(ValoTheme.LABEL_NO_MARGIN);

		verticalLayout.addComponents(titleLabel, wagonTypeLabel, timestampLabel);

		header.addComponents(verticalLayout, buildToolbar());

		return header;
	}

	private Component buildToolbar()
	{
		HorizontalLayout toolbar = new HorizontalLayout();
		toolbar.addStyleName("toolbar");
		toolbar.setSpacing(true);

		Container container = new BeanItemContainer<>(Wagon.class,
				DashboardUI.getDataProvider().getWagonsShort(user));
		wagonSelect = new ComboBox(
				DashboardUI.getMessageSource().getMessage("view.details.combobox.caption"),
				container);
		wagonSelect.setItemCaptionPropertyId("alias");

		wagonSelect.addValueChangeListener(event -> {
			mapLayout.setWagon((Wagon) wagonSelect.getValue());
			DashboardEventBus.post(new DashboardEvent.ShowDetailsForWagonEvent(
					(Wagon) event.getProperty().getValue(), user.getTenant()));
		});
		wagonSelect.setImmediate(true);
		wagonSelect.setNullSelectionAllowed(false);

		toolbar.addComponent(wagonSelect);
		toolbar.setImmediate(true);

		return toolbar;
	}

	private Component buildSparklines()
	{
		CssLayout sparks = new CssLayout();
		sparks.addStyleName("sparks");
		sparks.setWidth("100%");
		Responsive.makeResponsive(sparks);

		mileageSparkline = new Sparkline("view.dashboard.mileage", "KM", null, null, null);
		sparks.addComponent(mileageSparkline);

		temperatureSparkline = new Sparkline("view.dashboard.temperature", "°C", null, null, null);
		sparks.addComponent(temperatureSparkline);

		humiditySparkline = new Sparkline("view.dashboard.humidity",
				DashboardUI.getMessageSource().getMessage("percent"), null, null, null);
		sparks.addComponent(humiditySparkline);

		humidityTemperatureSparkline = new Sparkline("view.dashboard.humidity_temperature", "°C",
				null, null, null);
		sparks.addComponent(humidityTemperatureSparkline);

		return sparks;
	}

	private Component buildContent()
	{
		dashboardPanels = new CssLayout();
		dashboardPanels.addStyleName("dashboard-panels");
		Responsive.makeResponsive(dashboardPanels);

		dashboardPanels.addComponent(buildTelematic());
		dashboardPanels.addComponent(buildMap());

		return dashboardPanels;
	}

	private Component buildTelematic()
	{
		BeanItemContainer<Wagon> telematicContainer = new BeanItemContainer<Wagon>(Wagon.class);
		telematicContainer.addNestedContainerProperty(OverviewConstants.STREET_CITY);
		telematicContainer.addNestedContainerProperty(OverviewConstants.COUNTRY);
		telematicGrid = new HistoryGrid(telematicContainer);
		telematicGrid.addSelectionListener(listener -> {
			mapLayout.getGoogleMapInfoWindows().forEach(infowindow -> {
				mapLayout.getGoogleMap().closeInfoWindow(infowindow);
			});
			if (listener.getSelected().isEmpty())
			{
				mapLayout.getGoogleMap().clearMarkers();
				if (mapLayout.getPolyline() != null)
					mapLayout.getGoogleMap().removePolyline(mapLayout.getPolyline());

			}
			else
			{
				Wagon wagon = (Wagon) telematicGrid.getSelectedRow();
				if (wagon != null)
				{
					if (wagon.getLatLong() != null)
					{
						LatLon latLon = new LatLon(wagon.getLatLong().getLat(),
								wagon.getLatLong().getLng());
						mapLayout.getGoogleMap().clearMarkers();
						if (mapLayout.getPolyline() != null)
							mapLayout.getGoogleMap().removePolyline(mapLayout.getPolyline());
						if (amraBoxInfoWindow != null)
							mapLayout.getGoogleMap().closeInfoWindow(amraBoxInfoWindow);
						Wagon selectedWagon = (Wagon) wagonSelect.getValue();
						mapMarker = GoogleMapUtilFactory.buildGoogleMapMarker(latLon,
								selectedWagon.getAlias());
						amraBoxInfoWindow = GoogleMapUtilFactory.buildGoogleMapSmallInfoWindow(
								selectedWagon.getAlias(), wagon.getTimestamp(), latLon);
						OpenInfoWindowOnMarkerClickListener infoWindowOpener = new OpenInfoWindowOnMarkerClickListener(
								mapLayout.getGoogleMap(), mapMarker, amraBoxInfoWindow);
						mapLayout.getGoogleMap().addMarkerClickListener(infoWindowOpener);
						mapLayout.getGoogleMap().addMarker(mapMarker);
						mapLayout.getGoogleMap().setCenter(latLon);
					}
					else
						Notification.show(DashboardUI.getMessageSource()
								.getMessage("view.disponent.no.latlong.data"));
				}
			}
		});

		return wrapper.createContentWrapper(telematicGrid,
				"view.details.telematic.history.tooltip");
	}

	private Component buildMap()
	{
		mapLayout = new MapLayout();
		mapLayout.setId("mapLayout");
		return wrapper.createContentWrapper(mapLayout, "view.details.map.help");
	}

	/**
	 * Called from {@link OverviewView} {@code showDetailsForSelection()}
	 *
	 * @param event
	 *            {@link WagonDetailsEvent}
	 */
	@Subscribe
	public void showDetailsFromOverview(WagonDetailsEvent event)
	{
		Collection<Wagon> wagons = event.getWagons();
		wagonSelect.setContainerDataSource(new BeanItemContainer<>(Wagon.class, wagons));

		Wagon selectedWagon = wagons.iterator().next();
		wagonSelect.select(selectedWagon);
	}

	@SuppressWarnings ("unchecked")
	@Subscribe
	public void fillTelematicData(WagonSetEvent event)
	{
		List<Wagon> wagons = event.getWagons();
		BeanItemContainer<Wagon> container = (BeanItemContainer<Wagon>) telematicGrid
				.getContainerDataSource();
		container.removeAllItems();
		container.addAll(wagons);
	}

	/**
	 * Called from {@link DetailsView}
	 *
	 * @param event
	 *            {@link WagonSelectedEvent}
	 */
	@Subscribe
	public void fillDetails(WagonSelectedEvent event)
	{
		Wagon wagon = event.getWagon();
		if (wagon != null)
		{
			fillDetailInformation(wagon);
			fillSparkLines(wagon);
		}
		else
		{
			clearValues();
			fillSparkLines(null);
			new UserNotification("no.data", 1000, false);
		}
	}

	private void fillDetailInformation(Wagon wagon)
	{
		clearValues();

		String alias = wagon.getAlias();
		String wagonTypeName = wagon.getWagonType() != null ? wagon.getWagonType().getTypeName()
				: "";
		wagonTypeLabel.setValue(alias + " " + wagonTypeName);

		if (wagon.getTimestamp() != null)
		{
			SimpleDateFormat dateFormat = new SimpleDateFormat(
					DashboardUI.getMessageSource().getMessage("date.format"));
			dateFormat.setTimeZone(DashboardUI.getUserTimeZone());
			String date = dateFormat.format(wagon.getTimestamp());
			timestampLabel
					.setValue(DashboardUI.getMessageSource().getMessage("view.details.lastupdate")
							+ " " + date);
		}
	}

	private void clearValues()
	{
		wagonTypeLabel.setValue("");
		timestampLabel.setValue("");
	}

	private void fillSparkLines(Wagon wagon)
	{
		clearSparklines();

		String alias = DashboardUI.getMessageSource().getMessage("view.details.noinformation");
		if (wagon != null)
			alias = wagon.getAlias();

		String value = getValue(wagon != null ? wagon.getMileage() : null);
		mileageSparkline.setValues(alias, value, "KM", null);

		value = getValue(wagon != null ? wagon.getTemperature() : null);
		temperatureSparkline.setValues(alias, value, "°C", null);

		value = getValue(wagon != null ? wagon.getHumidity() : null);
		humiditySparkline.setValues(alias, value,
				DashboardUI.getMessageSource().getMessage("percent"), null);

		value = getValue(wagon != null ? wagon.getHumidityTemperature() : null);
		humidityTemperatureSparkline.setValues(alias, value, "°C", null);
	}

	private void clearSparklines()
	{
		mileageSparkline.clearValues();
		temperatureSparkline.clearValues();
		humiditySparkline.clearValues();
		humidityTemperatureSparkline.clearValues();
	}

	private String getValue(Integer sensorValue)
	{
		return sensorValue != null ? String.valueOf(sensorValue) : null;
	}

	@Override
	public void enter(ViewChangeEvent event)
	{
		Page.getCurrent().getStyles().add(".gm-style-iw + div {display: block;}");
	}

	@Subscribe
	public void maximizePanel(MaximizeDashboardPanelEvent event)
	{
		for (Iterator<Component> it = dashboardPanels.iterator(); it.hasNext();)
		{
			Component c = it.next();
			c.removeStyleName("max");
			c.setVisible(false);
		}
		event.getPanel().addStyleName("max");
		event.getPanel().setVisible(true);

		for (Iterator<Component> it = root.iterator(); it.hasNext();)
		{
			it.next().setVisible(false);
		}
		dashboardPanels.setVisible(true);
	}

	@Subscribe
	public void minimizePanel(MinimizeDashboardPanelEvent event)
	{
		for (Iterator<Component> it = dashboardPanels.iterator(); it.hasNext();)
		{
			Component c = it.next();
			c.removeStyleName("max");
			c.setVisible(true);
		}

		for (Iterator<Component> it = root.iterator(); it.hasNext();)
		{
			it.next().setVisible(true);
		}
	}
}
