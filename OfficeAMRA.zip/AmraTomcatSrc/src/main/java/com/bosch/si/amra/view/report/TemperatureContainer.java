
package com.bosch.si.amra.view.report;

import com.bosch.si.amra.entity.report.SensorValue;

/**
 * Concrete temperature container implementation of sensor container
 * 
 * @author toa1wa3
 *
 */
public class TemperatureContainer extends SensorContainer
{
	@Override
	public boolean isNull(SensorValue value)
	{
		return value.getTemperature() != null;
	}
}
