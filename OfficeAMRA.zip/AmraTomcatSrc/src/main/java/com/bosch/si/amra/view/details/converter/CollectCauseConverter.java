
package com.bosch.si.amra.view.details.converter;

import java.util.Locale;

import com.vaadin.data.util.converter.StringToIntegerConverter;
import com.vaadin.server.FontAwesome;

/**
 * Converts the collect cause in a humand readable column.
 * The collect cause contains a number from 0-16. This number is transformed into a bitmask.
 * <ul>
 * <li><b>2nd</b> bit set: <i>Trip ended</i></li>
 * <li><b>4th</b> bit set: <i>Trip started</i></li>
 * </ul>
 *
 * @author toa1wa3
 *
 */
public class CollectCauseConverter extends StringToIntegerConverter
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= 4001121789195553006L;

	private static final int	TRIP_ENDED_BIT		= 2;

	private static final int	TRIP_STARTED_BIT	= 4;

	@Override
	public String convertToPresentation(Integer value, Class<? extends String> targetType,
			Locale locale) throws com.vaadin.data.util.converter.Converter.ConversionException
	{
		if (value != null)
		{
			StringBuffer buffer = new StringBuffer();

			if (((value.intValue() >>> TRIP_ENDED_BIT) & 1) == 1)
				buffer.append(FontAwesome.STOP.getHtml());
			else if (((value.intValue() >>> TRIP_STARTED_BIT) & 1) == 1)
				buffer.append(FontAwesome.PLAY.getHtml());
			return buffer.toString();
		}
		return "";
	}
}
