
package com.bosch.si.amra.view.formatter;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.rule.Rule;
import com.vaadin.data.Property;

public class RuleTypeFormatter extends PropertyFormatter
{
	@Override
	public String format(Object rowId, Property<?> property, String result)
	{
		Rule rule = (Rule) rowId;
		return rule.getRuleType() != null
				? new String(DashboardUI.getMessageSource()
						.getMessage("view.alarm.selecttype." + rule.getRuleType().toLowerCase()))
				: result;
	}
}
