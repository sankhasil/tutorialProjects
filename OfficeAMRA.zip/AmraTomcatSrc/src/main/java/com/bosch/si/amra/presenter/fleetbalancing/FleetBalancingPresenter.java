
package com.bosch.si.amra.presenter.fleetbalancing;

import com.bosch.si.amra.event.DashboardEvent.FleetBalancingFillChartEvent;
import com.bosch.si.amra.event.DashboardEvent.FleetBalancingGetEvent;
import com.google.common.eventbus.Subscribe;

public interface FleetBalancingPresenter
{
	/**
	 * Retrieves the event for wagons which are greater than the average mileage and for wagons
	 * which
	 * are less than the average mileage
	 * 
	 * @param event
	 *            The event fired from the event bus
	 * @return FleetBalancingFillChartEvent containing the map with {@link FleetBalancingType} as
	 *         key indicating negative or positive chart data, the average mileage and the maximum
	 *         deviation
	 */
	@Subscribe
	public FleetBalancingFillChartEvent getBalancingMap(FleetBalancingGetEvent event);
}
