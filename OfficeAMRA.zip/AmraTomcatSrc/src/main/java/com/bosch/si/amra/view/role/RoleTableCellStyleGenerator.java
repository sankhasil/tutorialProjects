
package com.bosch.si.amra.view.role;

import com.bosch.si.amra.constants.role.UserRolesConstants;
import com.bosch.si.amra.entity.WagonUsers;
import com.vaadin.ui.Table;
import com.vaadin.ui.Table.CellStyleGenerator;

public class RoleTableCellStyleGenerator implements CellStyleGenerator
{
	private static final long serialVersionUID = 7290076311751662781L;

	@Override
	public String getStyle(Table source, Object itemId, Object propertyId)
	{
		if (itemId instanceof WagonUsers)
		{
			if (UserRolesConstants.ALIAS.equals(propertyId))
			{
				WagonUsers users2Wagon = (WagonUsers) itemId;
				if (users2Wagon.getDisponents().size() > 0
						|| users2Wagon.getEndcustomers().size() > 0)
				{
					return "assigned";
				}
			}
		}
		return null;
	}
}
