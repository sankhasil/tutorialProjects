
package com.bosch.si.amra.view.formatter;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.rule.Rule;
import com.vaadin.data.Property;

public class RuleSeverityFormatter extends PropertyFormatter
{
	@Override
	public String format(Object rowId, Property<?> property, String result)
	{
		Rule rule = (Rule) rowId;
		if (rule.getSeverity() != null)
		{
			result = DashboardUI.getMessageSource().getMessage(
					"view.alarm.selectseverity." + rule.getSeverity().name().toLowerCase());
		}
		return result;
	}
}
