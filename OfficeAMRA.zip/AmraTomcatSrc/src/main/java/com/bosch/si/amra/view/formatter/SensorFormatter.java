
package com.bosch.si.amra.view.formatter;

import com.bosch.si.amra.entity.configuration.Configuration;
import com.vaadin.data.Property;
import com.vaadin.server.FontAwesome;

public class SensorFormatter extends PropertyFormatter
{
	@Override
	public String format(Object rowId, Property<?> property, String result)
	{
		if (rowId instanceof Configuration)
		{
			Object value2 = property.getValue();
			boolean status = (boolean) value2;
			return new String(status ? Character.toChars(FontAwesome.CHECK.getCodepoint())
					: Character.toChars(FontAwesome.TIMES.getCodepoint()));
		}
		return result;
	}
}
