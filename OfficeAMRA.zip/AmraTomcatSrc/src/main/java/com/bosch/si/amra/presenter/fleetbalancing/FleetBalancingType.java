
package com.bosch.si.amra.presenter.fleetbalancing;

public enum FleetBalancingType
{
	POSITIVES, NEGATIVES;
}
