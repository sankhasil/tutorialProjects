
package com.bosch.si.amra.view.common;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.common.GoogleMapUtilFactory;
import com.bosch.si.amra.component.MapLayout;
import com.bosch.si.amra.event.DashboardEvent.MaximizeDashboardPanelEvent;
import com.bosch.si.amra.event.DashboardEvent.MinimizeDashboardPanelEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Page;
import com.vaadin.server.Page.Styles;
import com.vaadin.tapio.googlemaps.GoogleMap;
import com.vaadin.tapio.googlemaps.client.overlays.GoogleMapInfoWindow;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Component;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.MenuBar;
import com.vaadin.ui.MenuBar.Command;
import com.vaadin.ui.MenuBar.MenuItem;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Notification.Type;
import com.vaadin.ui.themes.ValoTheme;

public abstract class ContentWrapper
{
	private static final String			ICON_ONLY					= "icon-only";

	private static final String			MAPLAYOUT					= "mapLayout";

	private static final String			MAX							= "max";

	private MenuItem					markerToggle;

	private MenuItem					onOffSwitch;

	private GoogleMap					googleMap;

	private List<GoogleMapInfoWindow>	googleMapInfoWindows		= new ArrayList<>();

	private List<GoogleMapInfoWindow>	fullGoogleMapInfoWindows	= new ArrayList<>();

	private boolean						isRoutingEnabled;

	@SuppressWarnings ("serial")
	public Component createContentWrapper(Component content, final String code)
	{

		final CssLayout slot = createSlot();

		final CssLayout card = createCard();

		HorizontalLayout toolbar = new HorizontalLayout();
		toolbar.addStyleName("dashboard-panel-toolbar");
		toolbar.setWidth("100%");

		Label caption = new Label(content.getCaption());
		caption.addStyleName(ValoTheme.LABEL_H4);
		caption.addStyleName(ValoTheme.LABEL_COLORED);
		caption.addStyleName(ValoTheme.LABEL_NO_MARGIN);
		content.setCaption(null);

		MenuBar tools = new MenuBar();
		tools.addStyleName(ValoTheme.MENUBAR_BORDERLESS);
		MenuItem help = tools.addItem("", FontAwesome.QUESTION_CIRCLE, new Command()
		{
			@Override
			public void menuSelected(MenuItem selectedItem)
			{
				Notification notification = new Notification(
						DashboardUI.getMessageSource().getMessage("slot.help"),
						DashboardUI.getMessageSource().getMessage(code), Type.HUMANIZED_MESSAGE);
				notification.setHtmlContentAllowed(true);
				notification.show(Page.getCurrent());
			}
		});
		help.setStyleName(ICON_ONLY);
		if (content.getId() != null && MAPLAYOUT.equalsIgnoreCase(content.getId()))
		{
			MapLayout mapLayout = (MapLayout) content;
			markerToggle = tools.addItem("", FontAwesome.MAP_MARKER, new Command()
			{

				@Override
				public void menuSelected(MenuItem selectedItem)
				{
					setVariablesFromMapLayout(mapLayout);
					toggleMarkerOrInfoWindow(selectedItem);
				}

			});
			markerToggle.setStyleName(ICON_ONLY);
			markerToggle.setEnabled(false);
			mapLayout.setMarkerToggle(markerToggle);
			markerToggle.setVisible(DashboardUI.getDETAILS_MAP_MARKER_BUTTON_FLAG());
			onOffSwitch = tools.addItem("", FontAwesome.BAN, new Command()
			{
				@Override
				public void menuSelected(MenuItem selectedItem)
				{
					setVariablesFromMapLayout(mapLayout);
					switchMarkersOnAndOff(selectedItem);
				}
			});
			onOffSwitch.setStyleName(ICON_ONLY);
			onOffSwitch.setEnabled(false);
			mapLayout.setOnOffSwitch(onOffSwitch);
			onOffSwitch.setVisible(DashboardUI.getDETAILS_MAP_MARKER_BUTTON_FLAG());
		}
		MenuItem max = tools.addItem("", FontAwesome.EXPAND, new Command()
		{

			@Override
			public void menuSelected(MenuItem selectedItem)
			{
				if (!slot.getStyleName().contains(MAX))
				{
					selectedItem.setIcon(FontAwesome.COMPRESS);
					DashboardEventBus.post(new MaximizeDashboardPanelEvent(slot));
				}
				else
				{
					slot.removeStyleName(MAX);
					selectedItem.setIcon(FontAwesome.EXPAND);
					DashboardEventBus.post(new MinimizeDashboardPanelEvent(slot));
				}
			}
		});
		max.setStyleName(ICON_ONLY);
		MenuItem root = tools.addItem("", FontAwesome.COG, null);
		root.addItem("Configure", new Command()
		{
			@Override
			public void menuSelected(MenuItem selectedItem)
			{
				Notification.show("Not implemented in this demo");
			}
		});
		root.addSeparator();
		root.addItem("Close", new Command()
		{
			@Override
			public void menuSelected(MenuItem selectedItem)
			{
				Notification.show("Not implemented in this demo");
			}
		});

		toolbar.addComponents(caption, tools);
		toolbar.setExpandRatio(caption, 1);
		toolbar.setComponentAlignment(caption, Alignment.MIDDLE_LEFT);

		card.addComponents(toolbar, content);
		slot.addComponent(card);
		return slot;
	}

	private void toggleMarkerOrInfoWindow(MenuItem selectedItem)
	{
		if (!selectedItem.isChecked())
		{
			selectedItem.setChecked(true);
			clearMarkers();
			addInfoWindowsOnly();
		}
		else
		{
			selectedItem.setChecked(false);
			googleMapInfoWindows.forEach(infoWindow -> googleMap.closeInfoWindow(infoWindow));
			addMarkers();
		}
	}

	private void switchMarkersOnAndOff(MenuItem selectedItem)
	{

		if (!selectedItem.isChecked())
		{
			selectedItem.setChecked(true);
			markerToggle.setEnabled(false);
			clearMarkers();
			googleMapInfoWindows.forEach(googleMapInfoWindow -> {
				googleMap.closeInfoWindow(googleMapInfoWindow);
			});
			if (isRoutingEnabled)
			{
				if (markerToggle.isChecked())
					googleMap.openInfoWindow(getLastElementOfList(googleMapInfoWindows));
				else
					googleMap.addMarker(
							getLastElementOfList(fullGoogleMapInfoWindows).getAnchorMarker());
			}
		}
		else
		{
			selectedItem.setChecked(false);
			markerToggle.setEnabled(true);
			if (markerToggle.isChecked())
				addInfoWindowsOnly();
			else
				addMarkers();
		}
	}

	private void clearMarkers()
	{
		fullGoogleMapInfoWindows.forEach(infoWindow -> {
			googleMap.closeInfoWindow(infoWindow);
			googleMap.removeMarker(infoWindow.getAnchorMarker());
		});
	}

	private void addInfoWindowsOnly()
	{
		Styles styles = Page.getCurrent().getStyles();
		styles.add(".gm-style-iw + div {display: none;}");
		if (isRoutingEnabled)
		{
			getLastElementOfList(googleMapInfoWindows).setLatestInfoWindow(true);
			getLastElementOfList(googleMapInfoWindows).setzIndex(
					getLastElementOfList(googleMapInfoWindows).getAnchorMarker().getzIndex());
		}

		googleMapInfoWindows.forEach(googleMapInfoWindow -> {
			if (!googleMap.isInfoWindowOpen(googleMapInfoWindow))
			{
				googleMap.openInfoWindow(googleMapInfoWindow);

			}
		});

		autoZoom(googleMapInfoWindows);
	}

	private void addMarkers()
	{
		Styles styles = Page.getCurrent().getStyles();
		styles.add(".gm-style-iw + div {display: block;}");
		fullGoogleMapInfoWindows.forEach(googleMapInfoWindow -> {
			googleMap.closeInfoWindow(googleMapInfoWindow);
			googleMap.addMarker(googleMapInfoWindow.getAnchorMarker());
		});
		autoZoom(fullGoogleMapInfoWindows);
	}

	private void autoZoom(List<GoogleMapInfoWindow> infoWindos)
	{
		GoogleMapUtilFactory.autoZoomMap(infoWindos.stream()
				.map(infoWindows -> infoWindows.getPosition()).collect(Collectors.toList()),
				googleMap);
	}

	private void setVariablesFromMapLayout(MapLayout mapLayout)
	{
		if (googleMap == null)
		{
			googleMap = mapLayout.getGoogleMap();
			fullGoogleMapInfoWindows = mapLayout.getFullGoogleMapInfoWindows();
			googleMapInfoWindows = mapLayout.getGoogleMapInfoWindows();
			isRoutingEnabled = mapLayout.isRouteingEnabled();
		}
	}

	private GoogleMapInfoWindow getLastElementOfList(List<GoogleMapInfoWindow> mapWindowList)
	{
		return mapWindowList.get(mapWindowList.size() - 1);
	}

	public abstract CssLayout createSlot();

	public abstract CssLayout createCard();
}
