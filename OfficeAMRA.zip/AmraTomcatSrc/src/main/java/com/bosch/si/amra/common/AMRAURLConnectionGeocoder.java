
package com.bosch.si.amra.common;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.vaadin.addons.locationtextfield.GeocodedLocation;
import org.vaadin.addons.locationtextfield.GeocodingException;
import org.vaadin.addons.locationtextfield.LocationProvider;

/**
 * Will be deleted when we use Opencage data
 *
 * @author toa1wa3
 *
 * @param <T>
 *            The geocoded location
 */
public abstract class AMRAURLConnectionGeocoder<T extends GeocodedLocation>
		implements LocationProvider<T>
{

	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= 3189387559487874842L;

	private int					limit;

	protected boolean			isProxyUsed;

	protected int				port;

	protected String			host;

	public Collection<T> geocode(String address) throws GeocodingException
	{
		final Set<T> locations = new LinkedHashSet<T>();
		BufferedReader reader = null;
		try
		{
			String addr = getURL(address);
			URL url = new URL(addr);
			URLConnection con;
			if (isProxyUsed)
			{
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(host, port));
				con = url.openConnection(proxy);
			}
			else
				con = url.openConnection();
			con.setDoOutput(true);
			con.connect();
			reader = new BufferedReader(new InputStreamReader(con.getInputStream(), getEncoding()));
			final StringBuilder builder = new StringBuilder();
			String line;
			while ((line = reader.readLine()) != null)
				builder.append(line);
			Collection<T> locs = createLocations(address, builder.toString());
			if (this.limit > 0 && locs.size() > this.limit)
			{
				List<T> list = new ArrayList<T>(locs);
				locations.addAll(list.subList(0, this.limit));
			}
			else
			{
				locations.addAll(locs);
			}
		}
		catch (Exception e)
		{
			throw new GeocodingException(e.getMessage(), e);
		}
		finally
		{
			if (reader != null)
			{
				try
				{
					reader.close();
				}
				catch (IOException e)
				{
					// ignore
				}
			}
		}
		return locations;
	}

	/**
	 * Encoding the response stream is to be expected. Default is UTF-8. Override in subclass as
	 * necessary.
	 *
	 * @return UTF-8 encoding
	 */
	protected String getEncoding()
	{
		return "UTF-8";
	}

	/**
	 * Retrieve the full URL to fetch
	 *
	 * @param address
	 *            input address
	 * @return full URL
	 * @throws java.io.UnsupportedEncodingException
	 *             if subclass uses {@link java.net.URLEncoder} and it fails
	 */
	protected abstract String getURL(String address) throws UnsupportedEncodingException;

	/**
	 * Creates {@link org.vaadin.addons.locationtextfield.GeocodedLocation} objects from response
	 * stream
	 *
	 * @param address
	 *            input address
	 * @param input
	 *            response stream as string
	 * @return collection of {@link org.vaadin.addons.locationtextfield.GeocodedLocation} objects
	 * @throws GeocodingException
	 *             throws org.vaadin.addons.locationtextfield.GeocodingException
	 */
	protected abstract Collection<T> createLocations(String address, String input)
			throws GeocodingException;

	/**
	 * Max number of results; default is0 which means unbounded
	 *
	 * @return the limit
	 */
	public int getLimit()
	{
		return this.limit;
	}

	public void setLimit(int limit)
	{
		this.limit = limit;
	}

}
