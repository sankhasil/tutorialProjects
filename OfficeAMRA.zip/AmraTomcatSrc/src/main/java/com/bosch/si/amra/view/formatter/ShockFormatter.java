
package com.bosch.si.amra.view.formatter;

import com.vaadin.data.Property;
import com.vaadin.server.Page;

public class ShockFormatter extends PropertyFormatter
{
	@Override
	public String format(Object rowId, Property<?> property, String result)
	{
		return String.format(Page.getCurrent().getWebBrowser().getLocale(), "%.1f",
				property.getValue());
	}
}
