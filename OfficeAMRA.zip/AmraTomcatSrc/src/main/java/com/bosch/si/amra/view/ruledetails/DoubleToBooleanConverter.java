
package com.bosch.si.amra.view.ruledetails;

import java.util.Locale;

import com.vaadin.data.util.converter.Converter;

public class DoubleToBooleanConverter implements Converter<Double, Boolean>
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= 5886242610097884744L;

	@Override
	public Boolean convertToModel(Double value, Class<? extends Boolean> targetType, Locale locale)
			throws com.vaadin.data.util.converter.Converter.ConversionException
	{
		if (value != null && value == 0.0)
		{
			return false;
		}
		return true;
	}

	@Override
	public Double convertToPresentation(Boolean value, Class<? extends Double> targetType,
			Locale locale) throws com.vaadin.data.util.converter.Converter.ConversionException
	{
		if (value != null && value.booleanValue() == true)
		{
			return 1.0;
		}
		return 0.0;
	}

	@Override
	public Class<Boolean> getModelType()
	{
		return Boolean.class;
	}

	@Override
	public Class<Double> getPresentationType()
	{
		return Double.class;
	}

}
