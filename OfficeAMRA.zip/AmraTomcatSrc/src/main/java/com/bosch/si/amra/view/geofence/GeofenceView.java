
package com.bosch.si.amra.view.geofence;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.vaadin.addons.locationtextfield.GeocodedLocation;
import org.vaadin.addons.locationtextfield.LocationProvider;
import org.vaadin.addons.locationtextfield.LocationTextField;
import org.vaadin.addons.locationtextfield.LocationType;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.common.AMRAGoogleGeocoder;
import com.bosch.si.amra.common.AmraConnectionGeocoder;
import com.bosch.si.amra.common.GoogleMapUtilFactory;
import com.bosch.si.amra.component.GeofenceDetail;
import com.bosch.si.amra.component.OpenInfoWindowOnMarkerClickListener;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.entity.geofence.Geofence;
import com.bosch.si.amra.event.DashboardEvent.ClearValueEvent;
import com.bosch.si.amra.event.DashboardEvent.GeofenceDeleteEvent;
import com.bosch.si.amra.event.DashboardEvent.GeofenceDeletedEvent;
import com.bosch.si.amra.event.DashboardEvent.GeofenceSaveEvent;
import com.bosch.si.amra.event.DashboardEvent.GeofenceSelectEvent;
import com.bosch.si.amra.event.DashboardEvent.GeofenceSelectedEvent;
import com.bosch.si.amra.event.DashboardEvent.MaximizeDashboardPanelEvent;
import com.bosch.si.amra.event.DashboardEvent.MinimizeDashboardPanelEvent;
import com.bosch.si.amra.event.DashboardEvent.NotSuccessfulEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.im.login.Role;
import com.bosch.si.amra.im.login.Role.Roles;
import com.bosch.si.amra.view.UserNotification;
import com.google.common.eventbus.Subscribe;
import com.vaadin.data.Container;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Page;
import com.vaadin.server.Responsive;
import com.vaadin.server.VaadinSession;
import com.vaadin.tapio.googlemaps.GoogleMap;
import com.vaadin.tapio.googlemaps.client.LatLon;
import com.vaadin.tapio.googlemaps.client.overlays.GoogleMapInfoWindow;
import com.vaadin.tapio.googlemaps.client.overlays.GoogleMapMarker;
import com.vaadin.tapio.googlemaps.client.overlays.GoogleMapPolygon;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.Component;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Panel;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

@Role ({ Roles.USER, Roles.FLEETADMIN, Roles.SYSTEMADMIN })
@SuppressWarnings ("serial")
public class GeofenceView extends Panel implements View
{

	private static final String						LOCATION_STYLE_NAME			= "place-search";

	private static final String						LOCATION_HEIGHT				= "30px";

	private static final String						LOCATION_WIDTH				= "234px";

	public static final String						EDIT_ID						= "dashboard-edit";

	public static final String						TITLE_ID					= "dashboard-title";

	private ComboBox								geofenceSelect;

	private CssLayout								dashboardPanels;

	private final VerticalLayout					root;

	private HorizontalLayout						toolbar;

	private Button									createGeofence;

	private Button									saveGeofence;

	private Button									editGeofence;

	private Button									cancelGeofence;

	private Button									deleteGeofence;

	private Button									copyGeofence;

	private GeofenceDetail							name;

	private GeofenceDetail							description;

	private GeofenceDetail							timestamp;

	private GoogleMap								googleMap;

	private GoogleMapPolygon						geofence;

	private GeofenceMapListener						listener;

	private LocationTextField<GeocodedLocation>		locationTextField;

	private List<GoogleMapInfoWindow>				googleMapInfoWindows		= new ArrayList<>();

	private List<GoogleMapInfoWindow>				fullGoogleMapInfoWindows	= new ArrayList<>();

	private List<GeofenceContentWrapperListener>	listeners					= new ArrayList<>();

	private final User								user						= (User) VaadinSession
			.getCurrent().getAttribute(User.class.getName());

	public GeofenceView()
	{
		addStyleName(ValoTheme.PANEL_BORDERLESS);
		setSizeFull();
		DashboardEventBus.register(this);

		root = new VerticalLayout();
		root.setSizeFull();
		root.setMargin(true);
		root.addStyleName("dashboard-view");
		setContent(root);
		Responsive.makeResponsive(root);

		root.addComponent(buildHeader());

		root.addComponent(buildGeofenceDetails());

		Component content = buildContent();
		root.addComponent(content);
		root.setExpandRatio(content, 1);
	}

	@Override
	public void detach()
	{
		super.detach();

		DashboardEventBus.unregister(this);
	}

	private Component buildHeader()
	{
		HorizontalLayout header = new HorizontalLayout();
		header.addStyleName("viewheader");
		header.setSpacing(true);

		Label titleLabel = new Label(
				DashboardUI.getMessageSource().getMessage("view.geofence.caption"));
		titleLabel.setId(TITLE_ID);
		titleLabel.setSizeUndefined();
		titleLabel.addStyleName(ValoTheme.LABEL_H1);
		titleLabel.addStyleName(ValoTheme.LABEL_NO_MARGIN);

		header.addComponents(titleLabel, buildToolbar());

		return header;
	}

	private Component buildToolbar()
	{
		toolbar = new HorizontalLayout();
		toolbar.addStyleName("toolbar");
		toolbar.setSpacing(true);

		geofenceSelect = new ComboBox();
		geofenceSelect.setInputPrompt(
				DashboardUI.getMessageSource().getMessage("view.geofence.combobox.caption"));
		geofenceSelect.setItemCaptionPropertyId("name");
		geofenceSelect.setNullSelectionAllowed(false);

		geofenceSelect.addValueChangeListener(event -> {
			editGeofence.setEnabled(true);
			copyGeofence.setEnabled(true);
			deleteGeofence.setEnabled(true);
			Geofence geofence = (Geofence) event.getProperty().getValue();
			if (geofence != null)
			{
				callListener();
				locationTextField.reset();
				DashboardEventBus.post(new GeofenceSelectEvent(geofence.getId()));
			}
		});

		List<Geofence> geofenceNames = DashboardUI.getGeofenceDataProvider()
				.getGeofencesForDisplaying(user.getTenant());
		Container container = new BeanItemContainer<>(Geofence.class, geofenceNames);
		geofenceSelect.setContainerDataSource(container);
		geofenceSelect.setImmediate(true);

		createGeofence = buildCreateGeofence();
		saveGeofence = buildSaveGeofence();
		editGeofence = buildEditGeofence();
		cancelGeofence = buildCancelGeofence();
		copyGeofence = buildCopyGeofence();
		deleteGeofence = buildDeleteGeofence();

		toolbar.addComponents(geofenceSelect, createGeofence, editGeofence, copyGeofence,
				deleteGeofence);
		toolbar.setImmediate(true);

		return toolbar;
	}

	private Button buildCreateGeofence()
	{
		final Button createGeofenceButton = buildButton("view.geofence.button.create.caption",
				"view.geofence.button.create.tooltip");
		createGeofenceButton.setIcon(FontAwesome.PLUS);
		createGeofenceButton.addClickListener(new ClickListener()
		{

			@Override
			public void buttonClick(ClickEvent event)
			{
				listener = new GeofenceMapListener(googleMap, new ArrayList<LatLon>(),
						new ArrayList<GoogleMapMarker>());
				unselectGeofence();
				clearSparklines();
				clearMapForCreation();
				addMapListener();
				switchToEditableMode();
				callListener();
				locationTextField.reset();
				copyGeofence.setEnabled(false);
				geofence = new GoogleMapPolygon(listener.getGeofenceCoordinates(), "#FE2E2E", 0.8,
						"#0000FF", 0.5, 3);
				googleMap.addPolygonOverlay(geofence);
			}
		});
		return createGeofenceButton;
	}

	private Button buildSaveGeofence()
	{
		final Button saveGeofenceButton = buildButton("view.geofence.button.save.caption",
				"view.geofence.button.save.tooltip");
		saveGeofenceButton.setIcon(FontAwesome.SAVE);
		saveGeofenceButton.addClickListener(new ClickListener()
		{
			@Override
			public void buttonClick(ClickEvent event)
			{
				Geofence geofence = new Geofence();
				if (geofenceSelect.getValue() != null)
				{
					geofence = (Geofence) geofenceSelect.getValue();
				}
				fillGeofence(geofence);
				DashboardEventBus.post(new GeofenceSaveEvent(geofence, user.getTenant()));
			}
		});
		return saveGeofenceButton;
	}

	private Button buildEditGeofence()
	{
		final Button editGeofenceButton = buildButton("view.geofence.button.edit.caption",
				"view.geofence.button.edit.tooltip");
		editGeofenceButton.setIcon(FontAwesome.EDIT);
		editGeofenceButton.addClickListener(new ClickListener()
		{
			@Override
			public void buttonClick(ClickEvent event)
			{
				addMapListener();
				switchToEditableMode();
				callListener();
				copyGeofence.setEnabled(false);
			}
		});
		editGeofenceButton.setEnabled(false);
		return editGeofenceButton;
	}

	private Button buildDeleteGeofence()
	{
		final Button deleteGeofenceButton = buildButton("view.geofence.button.delete.caption",
				"view.geofence.button.delete.tooltip");
		deleteGeofenceButton.setIcon(FontAwesome.TRASH_O);
		deleteGeofenceButton.addClickListener(new ClickListener()
		{
			@Override
			public void buttonClick(ClickEvent event)
			{
				if (geofenceSelect.getValue() != null)
				{
					Geofence geofence = (Geofence) geofenceSelect.getValue();
					removeGeofence(geofence);
				}
			}
		});
		deleteGeofenceButton.setEnabled(false);
		return deleteGeofenceButton;
	}

	private void removeGeofence(Geofence geofence)
	{
		DashboardEventBus.post(new GeofenceDeleteEvent(geofence));
	}

	private Button buildCancelGeofence()
	{
		final Button cancelGeofenceButton = buildButton("view.geofence.button.cancel.caption",
				"view.geofence.button.cancel.tooltip");
		cancelGeofenceButton.setIcon(FontAwesome.TIMES);
		cancelGeofenceButton.addClickListener(new ClickListener()
		{
			@Override
			public void buttonClick(ClickEvent event)
			{
				switchToReadOnlyMode();
				removeMapListener();
				if (geofenceSelect.getValue() != null)
				{
					editGeofence.setEnabled(true);
					copyGeofence.setEnabled(true);
					Geofence geofence = (Geofence) geofenceSelect.getValue();
					if (geofence != null)
					{
						DashboardEventBus.post(new GeofenceSelectEvent(geofence.getId()));
					}
				}
				else
				{
					clearSparklines();
					clearMapForCancelling();
					editGeofence.setEnabled(false);
					copyGeofence.setEnabled(false);
					deleteGeofence.setEnabled(false);
				}
			}
		});
		return cancelGeofenceButton;
	}

	private Button buildCopyGeofence()
	{
		final Button copyGeofenceButton = buildButton("view.geofence.button.copy.caption",
				"view.geofence.button.copy.tooltip");
		copyGeofenceButton.setIcon(FontAwesome.COPY);
		copyGeofenceButton.addClickListener(new ClickListener()
		{
			@Override
			public void buttonClick(ClickEvent event)
			{
				unselectGeofence();
				addMapListener();
				switchToEditableMode();
				locationTextField.reset();
				copyGeofence.setEnabled(false);
			}
		});
		copyGeofenceButton.setEnabled(false);
		return copyGeofenceButton;
	}

	private Button buildButton(String caption, String description)
	{
		final Button button = new Button(DashboardUI.getMessageSource().getMessage(caption));
		button.setDescription(DashboardUI.getMessageSource().getMessage(description));
		button.addStyleName(ValoTheme.BUTTON_ICON_ONLY);
		return button;
	}

	private void unselectGeofence()
	{
		if (geofenceSelect.getValue() != null)
		{
			geofenceSelect.unselect(geofenceSelect.getValue());
		}
	}

	private void addMapListener()
	{
		googleMap.addMapClickListener(listener);
		googleMap.addMarkerClickListener(listener);
		googleMap.addMarkerDragListener(listener);

		for (GoogleMapMarker marker : googleMap.getMarkers())
		{
			marker.setDraggable(true);
		}
	}

	private void removeMapListener()
	{
		googleMap.removeMapClickListener(listener);
		googleMap.removeMarkerClickListener(listener);
		googleMap.removeMarkerDragListener(listener);
	}

	private void switchToEditableMode()
	{
		name.replaceContent(true);
		description.replaceContent(true);
		toolbar.replaceComponent(createGeofence, saveGeofence);
		toolbar.replaceComponent(editGeofence, cancelGeofence);
		geofenceSelect.setEnabled(false);
	}

	private void switchToReadOnlyMode()
	{
		name.replaceContent(false);
		description.replaceContent(false);
		toolbar.replaceComponent(saveGeofence, createGeofence);
		toolbar.replaceComponent(cancelGeofence, editGeofence);
		geofenceSelect.setEnabled(true);
	}

	private Geofence fillGeofence(Geofence geofence)
	{
		geofence.setName(name.getGeofenceDetail());
		geofence.setDescription(description.getGeofenceDetail());
		geofence.setPositions(listener.getGeofenceCoordinates());
		geofence.setTenantId(user.getTenant());
		geofence.setTimestamp(Calendar.getInstance(DashboardUI.getUserTimeZone()).getTime());
		return geofence;
	}

	private void callListener()
	{
		listeners.forEach(listener -> listener.geofenceEditListener());
	}

	private Component buildGeofenceDetails()
	{
		CssLayout sparks = new CssLayout();
		sparks.addStyleName("geofence");
		sparks.setWidth("100%");
		Responsive.makeResponsive(sparks);

		name = new GeofenceDetail("view.geofence.name");
		sparks.addComponent(name);

		description = new GeofenceDetail("view.geofence.description");
		sparks.addComponent(description);

		timestamp = new GeofenceDetail("view.geofence.timestamp");
		sparks.addComponent(timestamp);

		return sparks;
	}

	private Component buildContent()
	{
		dashboardPanels = new CssLayout();
		dashboardPanels.addStyleName("dashboard-panels");
		Responsive.makeResponsive(dashboardPanels);
		dashboardPanels.addComponent(buildMap());

		return dashboardPanels;
	}

	private Component buildMap()
	{
		CssLayout verticalLayout = new CssLayout();
		verticalLayout.setSizeFull();
		verticalLayout
				.setCaption(DashboardUI.getMessageSource().getMessage("view.geofence.caption"));

		Responsive.makeResponsive(verticalLayout);

		googleMap = new GoogleMap(DashboardUI.getGoogleAPIKey(), "", "");
		googleMap.setStyleName("geofence-map");
		googleMap.setSizeFull();
		googleMap.setSizeFull();
		googleMap.setMinZoom(1);
		googleMap.setMaxZoom(21);
		googleMap.setZoom(7);
		// Center at Stuttgart
		googleMap.setCenter(new LatLon(48.7833, 9.1833));
		googleMap.clearMarkers();
		googleMap.setHeight(98, Unit.PERCENTAGE);

		// Will be deleted as soon as we only use open cage data
		LocationProvider<GeocodedLocation> geocoder = new AMRAGoogleGeocoder(DashboardUI.getHost(),
				DashboardUI.getPort(), Boolean.valueOf(DashboardUI.isProxyUsed()),
				Page.getCurrent().getWebBrowser().getLocale().getLanguage());
		geocoder.setLimit(15);
		if (Boolean.valueOf(DashboardUI.isOpenCageDataUsed()))
			geocoder = buildGeocoder();

		verticalLayout.addComponents(buildLocationTextField(geocoder), googleMap);

		fillLocationMap();

		GeofenceContentWrapper geofenceContentWrapper = new GeofenceContentWrapper(
				googleMapInfoWindows, fullGoogleMapInfoWindows, googleMap, locationTextField,
				geofenceSelect);
		Component googleMapSlot = geofenceContentWrapper.createContentWrapper(verticalLayout,
				"view.geofence.maps.help");
		addGeofenceContentWrapperListener(geofenceContentWrapper);
		GoogleMapUtilFactory.buildJavaScriptFunction();

		return googleMapSlot;
	}

	private AmraConnectionGeocoder<GeocodedLocation> buildGeocoder()
	{
		final AmraConnectionGeocoder<GeocodedLocation> geocoder = new AmraConnectionGeocoder<>();
		geocoder.setLimit(15);
		geocoder.setUseProxy(Boolean.valueOf(DashboardUI.isProxyUsed()))
				.setHost(DashboardUI.getHost()).setPort(DashboardUI.getPort())
				.setLanguage(Page.getCurrent().getWebBrowser().getLocale().getLanguage())
				.setUrl(DashboardUI.getOpencageUrl()).setApiKey(DashboardUI.getOpencageApiKey());
		return geocoder;
	}

	private LocationTextField<GeocodedLocation> buildLocationTextField(
			final LocationProvider<GeocodedLocation> geocoder)
	{
		locationTextField = LocationTextField.<GeocodedLocation> newBuilder().withDelayMillis(500)
				.withMinimumQueryCharacters(3).withType(GeocodedLocation.class)
				.withLocationProvider(geocoder).withWidth(LOCATION_WIDTH)
				.withHeight(LOCATION_HEIGHT).withImmediate(true).build();
		locationTextField.setIcon(FontAwesome.SEARCH);
		locationTextField.addStyleName(LOCATION_STYLE_NAME);
		locationTextField.addLocationValueChangeListener(event -> {
			GeocodedLocation loc = (GeocodedLocation) event.getProperty().getValue();
			if (loc != null)
			{
				geofenceSelect.clear();
				googleMap.setCenter(new LatLon(loc.getLat(), loc.getLon()));
				if (loc.getType() != null && (loc.getType().equals(LocationType.ROUTE)
						|| loc.getType().equals(LocationType.STREET_ADDRESS)))
					googleMap.setZoom(18);
				else
					googleMap.setZoom(12);
			}
			else
				Notification.show(DashboardUI.getMessageSource().getMessage("no.data"));
		});
		return locationTextField;
	}

	private void fillLocationMap()
	{
		List<LatLon> positions = new ArrayList<LatLon>();
		List<Wagon> wagons = DashboardUI.getDataProvider().getWagonsWithCurrentValues(user);
		for (Wagon wagon : wagons)
		{
			if (wagon.getLatLong() != null)
			{
				LatLon location = GoogleMapUtilFactory.buildLocation(wagon.getLatLong());
				positions.add(location);

				displaySmallInfoWindows(googleMap, wagon, location);
				createMarkersWithInfoWindows(googleMap, wagon, location);
			}
		}
		GoogleMapUtilFactory.autoZoomMap(positions, googleMap);
	}

	private void displaySmallInfoWindows(GoogleMap googleMap, Wagon wagon, LatLon location)
	{
		GoogleMapInfoWindow amraBoxInfoWindow = GoogleMapUtilFactory
				.buildGoogleMapSmallInfoWindow(wagon.getAlias(), wagon.getTimestamp(), location);
		amraBoxInfoWindow.setAutoPanDisabled(true);
		googleMapInfoWindows.add(amraBoxInfoWindow);
		googleMap.openInfoWindow(amraBoxInfoWindow);
	}

	private void createMarkersWithInfoWindows(GoogleMap googleMap, Wagon wagon, LatLon location)
	{
		GoogleMapMarker locationMarker = GoogleMapUtilFactory.buildGoogleMapMarker(location,
				wagon.getAlias());
		GoogleMapInfoWindow fullInfoWindow = GoogleMapUtilFactory
				.buildGoogleMapFullInfoWindow(wagon, location, locationMarker);
		fullGoogleMapInfoWindows.add(fullInfoWindow);
		OpenInfoWindowOnMarkerClickListener infoWindowOpener = new OpenInfoWindowOnMarkerClickListener(
				googleMap, locationMarker, fullInfoWindow);
		googleMap.addMarkerClickListener(infoWindowOpener);
	}

	@Subscribe
	public void maximizePanel(MaximizeDashboardPanelEvent event)
	{
		for (Iterator<Component> it = dashboardPanels.iterator(); it.hasNext();)
		{
			Component c = it.next();
			c.removeStyleName("max");
			c.setVisible(false);
		}
		event.getPanel().addStyleName("max");
		event.getPanel().setVisible(true);

		for (Iterator<Component> it = root.iterator(); it.hasNext();)
		{
			it.next().setVisible(false);
		}
		dashboardPanels.setVisible(true);
	}

	@Subscribe
	public void minimizePanel(MinimizeDashboardPanelEvent event)
	{
		for (Iterator<Component> it = dashboardPanels.iterator(); it.hasNext();)
		{
			Component c = it.next();
			c.removeStyleName("max");
			c.setVisible(true);
		}

		for (Iterator<Component> it = root.iterator(); it.hasNext();)
		{
			it.next().setVisible(true);
		}
	}

	/**
	 * Called from {@link GeofenceView}
	 *
	 * @param event
	 *            {@link GeofenceSelectedEvent}
	 */
	@Subscribe
	public void fillDetails(GeofenceSelectedEvent event)
	{
		Geofence geofence = event.getGeofence();
		if (geofence != null)
		{
			fillLocationMap(geofence);
			fillSparkLines(geofence);
		}
		else
		{
			fillSparkLines(null);
			clearMapForCancelling();
			new UserNotification("no.data", 500, false);
		}
	}

	private void fillLocationMap(Geofence geofence)
	{
		clearMapForCancelling();
		if (geofence != null)
		{
			List<LatLon> positions = geofence.getPositions();
			List<GoogleMapMarker> geofenceMarkers = addMarkersForGeofence(positions);
			addGeofenceToMap(positions);
			LatLon[] array = new LatLon[positions.size()];
			positions.toArray(array);
			googleMap.setCenter(PolygonCalculator.polygonCenterOfMass(array));
			listener = new GeofenceMapListener(googleMap, positions, geofenceMarkers);
		}
		else
		{
			new UserNotification("view.geofence.map.nolocation", 100, false);
		}
	}

	private List<GoogleMapMarker> addMarkersForGeofence(List<LatLon> positions)
	{
		List<GoogleMapMarker> markers = new ArrayList<GoogleMapMarker>();
		if (positions != null && positions.size() > 0)
		{
			for (LatLon position : positions)
			{
				GoogleMapMarker geofenceMarker = new GoogleMapMarker(
						DashboardUI.getMessageSource().getMessage("view.details.map.marker.title"),
						position, false, "VAADIN/themes/dashboard/img/thumb-tack.png");
				geofenceMarker.setAnimationEnabled(false);
				googleMap.addMarker(geofenceMarker);
				markers.add(geofenceMarker);
			}
		}
		return markers;
	}

	private void addGeofenceToMap(List<LatLon> positions)
	{
		if (positions != null && positions.size() > 0)
		{
			geofence = new GoogleMapPolygon(positions, "#FE2E2E", 0.8, "#0000FF", 0.5, 3);
			googleMap.addPolygonOverlay(geofence);
			List<LatLon> positionsCopy = new ArrayList<LatLon>(positions);
			GoogleMapUtilFactory.autoZoomMap(positionsCopy, googleMap);
		}
	}

	private void fillSparkLines(Geofence geofence)
	{
		clearSparklines();

		name.setGeofenceDetail(geofence.getName());
		description.setGeofenceDetail(geofence.getDescription());
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				DashboardUI.getMessageSource().getMessage("date.format"));
		String date = dateFormat.format(geofence.getTimestamp());
		timestamp.setGeofenceDetail(date);
	}

	private void clearMapForCreation()
	{
		if (googleMap.getMarkers().size() > 0)
		{
			googleMap.clearMarkers();
		}
		if (geofence != null)
		{
			googleMap.removePolygonOverlay(geofence);
		}
		googleMapInfoWindows.forEach(infoWindow -> googleMap.closeInfoWindow(infoWindow));
	}

	private void clearMapForCancelling()
	{
		List<GoogleMapMarker> mapMarkers = new ArrayList<>(googleMap.getMarkers());
		List<GoogleMapMarker> collectedMarkers = fullGoogleMapInfoWindows.stream()
				.map(infoWindow -> infoWindow.getAnchorMarker()).collect(Collectors.toList());
		mapMarkers.removeAll(collectedMarkers);
		new ArrayList<>(mapMarkers).forEach(marker -> googleMap.removeMarker(marker));
		if (geofence != null)
		{
			googleMap.removePolygonOverlay(geofence);
		}
	}

	private void clearSparklines()
	{
		name.clearGeofenceDetail();
		description.clearGeofenceDetail();
		timestamp.clearGeofenceDetail();
	}

	@Subscribe
	public void clearValues(ClearValueEvent event)
	{
		switchToReadOnlyMode();
		disableButtons();
		new UserNotification("view.geofence.success", 1000, true);
	}

	private void disableButtons()
	{
		unselectGeofence();
		removeMapListener();
		clearSparklines();
		clearMapForCancelling();
		locationTextField.reset();
		editGeofence.setEnabled(false);
		copyGeofence.setEnabled(false);
		deleteGeofence.setEnabled(false);
	}

	@Subscribe
	public void geofenceDeleted(GeofenceDeletedEvent event)
	{
		if (event.isDeleted())
		{
			new UserNotification("view.geofence.remove.success", 1000, true);
			disableButtons();
			locationTextField.reset();
			List<Geofence> geofenceNames = DashboardUI.getGeofenceDataProvider()
					.getGeofencesForDisplaying(user.getTenant());
			Container container = new BeanItemContainer<>(Geofence.class, geofenceNames);
			geofenceSelect.setContainerDataSource(container);
		}
		else
		{
			buildNotSuccessfulGeoefenceRemoveWindow();
		}

	}

	private void buildNotSuccessfulGeoefenceRemoveWindow()
	{
		UserNotification userNotification = new UserNotification("view.geofence.remove.fail.window",
				1000, false);
		userNotification.setDescription(
				DashboardUI.getMessageSource().getMessage("view.geofence.remove.fail.label"));
		userNotification.setHtmlContentAllowed(true);
	}

	@Subscribe
	public void failedGeofenceSaving(NotSuccessfulEvent event)
	{
		String code = event.getCode();
		new UserNotification(code, 500, false);
	}

	@Override
	public void enter(ViewChangeEvent event)
	{
		Page.getCurrent().getStyles().add(".gm-style-iw + div {display: none;}");
	}

	public void addGeofenceContentWrapperListener(GeofenceContentWrapperListener listener)
	{
		listeners.add(listener);
	}

	public void removeGeofenceContentWrapperListener(GeofenceContentWrapperListener listener)
	{
		listeners.remove(listener);
	}

	public interface GeofenceContentWrapperListener
	{
		public void geofenceEditListener();
	}
}
