
package com.bosch.si.amra.view.rule.listener;

import com.bosch.si.amra.view.rule.RuleView;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;

public class RuleCopyButtonListener implements ClickListener
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= -9204356263736124609L;

	private final RuleView		view;

	public RuleCopyButtonListener(RuleView view)
	{
		this.view = view;
	}

	@Override
	public void buttonClick(ClickEvent event)
	{
		view.copyRule();
	}
}
