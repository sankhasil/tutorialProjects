
package com.bosch.si.amra.view.formatter;

import com.bosch.si.amra.entity.rule.Rule;
import com.vaadin.data.Property;
import com.vaadin.server.FontAwesome;

public class RuleNameFormatter extends PropertyFormatter
{
	@Override
	public String format(Object rowId, Property<?> property, String result)
	{
		Rule rule = (Rule) rowId;
		return (rule.getWagons() != null && !rule.getWagons().isEmpty())
				? new String(Character.toChars(FontAwesome.CHAIN.getCodepoint())) + " " + result
				: result;
	}
}
