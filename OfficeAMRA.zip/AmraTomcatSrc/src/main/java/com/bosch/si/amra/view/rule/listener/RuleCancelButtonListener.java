
package com.bosch.si.amra.view.rule.listener;

import com.bosch.si.amra.view.rule.RuleView;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;

public class RuleCancelButtonListener implements ClickListener
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= 4103461253218690721L;

	private final RuleView		view;

	public RuleCancelButtonListener(RuleView view)
	{
		this.view = view;
	}

	@Override
	public void buttonClick(ClickEvent event)
	{
		view.showRulesTable();
	}
}
