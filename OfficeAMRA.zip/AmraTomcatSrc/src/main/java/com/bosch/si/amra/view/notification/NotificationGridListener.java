
package com.bosch.si.amra.view.notification;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.notification.Notification;
import com.bosch.si.amra.event.DashboardEvent.NotificationAcknowledgeEvent;
import com.bosch.si.amra.event.DashboardEvent.NotificationsCountUpdatedEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.view.UserNotification;
import com.vaadin.event.ItemClickEvent;
import com.vaadin.event.ItemClickEvent.ItemClickListener;
import com.vaadin.event.SelectionEvent;
import com.vaadin.event.SelectionEvent.SelectionListener;
import com.vaadin.server.VaadinSession;
import com.vaadin.ui.Button;
import com.vaadin.ui.Grid;

public class NotificationGridListener implements ItemClickListener, SelectionListener
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= 8019455269211831209L;

	private final Button		approveNotifications;

	private final Grid			grid;

	public NotificationGridListener(Grid grid, Button approveNotifications)
	{
		this.approveNotifications = approveNotifications;
		this.grid = grid;
	}

	@Override
	public void select(SelectionEvent event)
	{
		List<Notification> val = grid.getSelectedRows().stream()
				.map(notificationMapper -> (Notification) notificationMapper)
				.collect(Collectors.toList());
		boolean enable = false;
		for (Notification notification : val)
		{
			if (notification != null && !notification.isAcknowledged())
			{
				enable = true;
			}
		}
		approveNotifications.setEnabled(enable);
	}

	@Override
	public void itemClick(ItemClickEvent event)
	{
		if (event.isDoubleClick())
		{
			Notification notification = (Notification) event.getItemId();
			if (notification != null)
			{
				if (notification.isAcknowledged())
				{
					new UserNotification("view.notification.read", 500, false);
				}
				else
				{
					approveSelectedNotifications(notification);
				}
			}
		}
	}

	private void approveSelectedNotifications(Notification notification)
	{
		User user = (User) VaadinSession.getCurrent().getAttribute(User.class.getName());
		DashboardEventBus.post(new NotificationAcknowledgeEvent(Arrays.asList(notification), user));
		DashboardEventBus.post(new NotificationsCountUpdatedEvent());
	}
}
