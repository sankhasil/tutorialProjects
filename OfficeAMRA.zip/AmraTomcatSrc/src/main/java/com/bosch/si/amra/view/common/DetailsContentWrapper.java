
package com.bosch.si.amra.view.common;

import com.vaadin.ui.CssLayout;
import com.vaadin.ui.themes.ValoTheme;

public class DetailsContentWrapper extends ContentWrapper
{

	@Override
	public CssLayout createSlot()
	{
		final CssLayout slot = new CssLayout();
		slot.setWidth("100%");
		slot.setHeight("100%");
		slot.addStyleName("dashboard-panel-slot");
		return slot;
	}

	@Override
	public CssLayout createCard()
	{
		CssLayout card = new CssLayout();
		card.setWidth("100%");
		card.setHeight("100%");
		card.addStyleName(ValoTheme.LAYOUT_CARD);
		return card;
	}

}
