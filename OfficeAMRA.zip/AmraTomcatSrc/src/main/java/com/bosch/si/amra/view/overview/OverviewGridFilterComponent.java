/**
 *
 */

package com.bosch.si.amra.view.overview;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.component.grid.OverviewGrid;
import com.bosch.si.amra.constants.overview.OverviewConstants;
import com.bosch.si.amra.entity.Tag;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.event.DashboardEvent.MapFilterEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.vaadin.data.Container.Filter;
import com.vaadin.data.Item;
import com.vaadin.data.Property;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.data.util.filter.SimpleStringFilter;
import com.vaadin.server.FontAwesome;
import com.vaadin.ui.AbstractComponent;
import com.vaadin.ui.TextField;
import com.vaadin.ui.themes.ValoTheme;

/**
 * @author ils5kor
 *
 */
public class OverviewGridFilterComponent
{

	public static class OverviewFilter extends TextField
	{
		/**
		 * Serial version uid
		 */
		private static final long serialVersionUID = 2925003614554210480L;

		public OverviewFilter(Object pid, OverviewGrid wagonGrid)
		{
			setWidth("100%");
			setHeight("75%");
			setNullRepresentation("");
			setNullSettingAllowed(true);
			addTextChangeListener(change -> {
				BeanItemContainer<Wagon> wagonGridCurrentContainer = (BeanItemContainer<Wagon>) wagonGrid
						.getContainerDataSource();
				wagonGridCurrentContainer.removeContainerFilters(pid);
				if (!change.getText().isEmpty())
				{
					wagonGridCurrentContainer.addContainerFilter(
							new SimpleStringFilter(pid, change.getText(), true, false));
				}
				DashboardEventBus.post(new MapFilterEvent());
			});
			addValueChangeListener(event -> {
				BeanItemContainer<Wagon> wagonGridCurrentContainer = (BeanItemContainer<Wagon>) wagonGrid
						.getContainerDataSource();
				wagonGridCurrentContainer.removeContainerFilters(pid);
				if (event.getProperty().getValue() != null)
				{
					wagonGridCurrentContainer.addContainerFilter(new SimpleStringFilter(pid,
							event.getProperty().getValue().toString(), true, false));
				}
			});
		}
	}

	public static class OverviewTagFilter extends TextField
	{
		/**
		 * Serial version uid
		 */
		private static final long serialVersionUID = 4141423206726066915L;

		public OverviewTagFilter(Object pid, OverviewGrid wagonGrid)
		{
			setWidth("100%");
			setHeight("75%");
			setNullRepresentation("");
			setNullSettingAllowed(true);
			setDescription(DashboardUI.getMessageSource()
					.getMessage("view.overview.columnheader.tags.filter.inputprompt"));
			addTextChangeListener(change -> {
				BeanItemContainer<Wagon> wagonGridCurrentContainer = (BeanItemContainer<Wagon>) wagonGrid
						.getContainerDataSource();
				wagonGridCurrentContainer.removeContainerFilters(pid);
				if (!change.getText().isEmpty())
				{
					wagonGridCurrentContainer
							.addContainerFilter(new TagListFilter(pid, change.getText()));
				}
				DashboardEventBus.post(new MapFilterEvent());
			});
			addValueChangeListener(event -> {
				BeanItemContainer<Wagon> wagonGridCurrentContainer = (BeanItemContainer<Wagon>) wagonGrid
						.getContainerDataSource();
				wagonGridCurrentContainer.removeContainerFilters(pid);
				if (event.getProperty().getValue() != null)
				{
					wagonGridCurrentContainer.addContainerFilter(
							new TagListFilter(pid, event.getProperty().getValue().toString()));
				}
			});

		}
	}

	public static class SearchFilter extends TextField
	{
		/**
		 * Serial version uid
		 */
		private static final long serialVersionUID = 2925008614554210480L;

		@SuppressWarnings ("unchecked")
		public SearchFilter(OverviewGrid wagonGrid,
				Map<AbstractComponent, Object> componentToPidMap)
		{
			this.setInputPrompt(
					DashboardUI.getMessageSource().getMessage("view.overview.input.filter"));
			this.setIcon(FontAwesome.SEARCH);
			this.addStyleName(ValoTheme.TEXTFIELD_INLINE_ICON);
			setNullRepresentation("");
			setNullSettingAllowed(true);
			addValueChangeListener(change -> {
				BeanItemContainer<Wagon> wagonGridCurrentContainer = (BeanItemContainer<Wagon>) wagonGrid
						.getContainerDataSource();
				wagonGridCurrentContainer.removeContainerFilters(OverviewConstants.ALIAS);
				if (change.getProperty().getValue() != null)
					wagonGridCurrentContainer
							.addContainerFilter(new SimpleStringFilter(OverviewConstants.ALIAS,
									(String) change.getProperty().getValue(), true, false));

			});
			componentToPidMap.put(this, OverviewConstants.ALIAS);
		}
	}

	private static final class TagListFilter implements Filter
	{

		/**
		 * Serial version uid
		 */
		private static final long	serialVersionUID	= -1565372187097825385L;

		final Object				propertyId;

		final List<String>			filterStringCommaSeparated;

		public TagListFilter(Object propertyId, String filterStringCommaSeparated)
		{
			this.propertyId = propertyId;
			this.filterStringCommaSeparated = (List<String>) Arrays
					.asList(filterStringCommaSeparated.toLowerCase().split(","));
		}

		@Override
		public boolean passesFilter(Object itemId, Item item) throws UnsupportedOperationException
		{
			final Property<?> p = item.getItemProperty(propertyId);
			if (p == null)
			{
				return false;
			}
			Object propertyValue = p.getValue();
			if (propertyValue == null
					|| !p.getType().equals((Class<List<Tag>>) (Class<?>) List.class))
			{
				return false;
			}
			final List<String> valueList = ((ArrayList<Tag>) propertyValue).stream()
					.map(tagMapper -> tagMapper.getTagName().toLowerCase())
					.collect(Collectors.toList());

			return valueList.containsAll(filterStringCommaSeparated);
		}

		@Override
		public boolean appliesToProperty(Object propertyId)
		{
			return propertyId != null && this.propertyId.equals(propertyId);
		}

	}
}
