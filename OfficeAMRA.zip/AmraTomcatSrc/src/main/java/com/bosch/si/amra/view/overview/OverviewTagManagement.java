/**
 *
 */

package com.bosch.si.amra.view.overview;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.overview.OverviewConstants;
import com.bosch.si.amra.entity.Tag;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.event.DashboardEvent.TagCreateOrUpdateEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.vaadin.addon.contextmenu.ContextMenu;
import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.vaadin.data.fieldgroup.FieldGroup;
import com.vaadin.data.fieldgroup.FieldGroup.CommitEvent;
import com.vaadin.data.fieldgroup.FieldGroup.CommitException;
import com.vaadin.data.fieldgroup.FieldGroup.CommitHandler;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.event.ItemClickEvent;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Resource;
import com.vaadin.server.Responsive;
import com.vaadin.server.Sizeable.Unit;
import com.vaadin.shared.ui.grid.HeightMode;
import com.vaadin.shared.ui.label.ContentMode;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickListener;
import com.vaadin.ui.Component;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.Grid;
import com.vaadin.ui.Grid.SelectionMode;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Notification.Type;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

/**
 * @author ils5kor
 *
 */
public class OverviewTagManagement
{

	private static final int										TEXT_LENGTH			= 26;

	private Grid													tagGrid, wagonGrid;

	private List<Tag>												tagListForGrid;

	private Button													assignTags, unassignTags,
			deleteTags, editTag, tagManagementNavigator;

	private User													user;

	private final String											TAG_COLUMN_ID		= "tagName";

	private static final int										TAG_COLUMN_WIDTH	= 215;

	private static final String										TAG_BUTTON_ROTATION	= "tag-button-rotation";

	private OverviewTagGridContextMenuOpenListnerWithButtonEvents	overviewTagGridContextMenuOpenListnerWithButtonEvents;

	private Logger													log					= Logger
			.getLogger(this.getClass());

	public OverviewTagManagement(Grid wagonGrid, List<Tag> tagListForGrid, User user)
	{
		this.wagonGrid = wagonGrid;
		this.tagListForGrid = tagListForGrid;
		this.user = user;

	}

	public Grid getTagGrid()
	{
		return tagGrid;
	}

	public List<Button> getTagToolbarButtons()
	{
		List<Button> toolbarButtonList = new ArrayList<Button>();
		toolbarButtonList.add(assignTags);
		toolbarButtonList.add(unassignTags);
		toolbarButtonList.add(deleteTags);
		toolbarButtonList.add(editTag);
		toolbarButtonList.add(tagManagementNavigator);
		return toolbarButtonList;
	}

	public Component buildTagManagementLayout()
	{

		CssLayout tagView = new CssLayout();
		Responsive.makeResponsive(tagView);
		tagView.setWidth("100%");
		VerticalLayout tagListView = new VerticalLayout();
		Responsive.makeResponsive(tagListView);
		buildTagGrid();
		TextField tagAddingTextField = new TextField();
		tagAddingTextField.setInputPrompt("Add Tag");
		tagAddingTextField.setWidth(94, Unit.PERCENTAGE);
		tagAddingTextField.setDescription(
				DashboardUI.getMessageSource().getMessage("view.overview.tag.add.tooltip"));
		tagAddingTextField.setStyleName("tag-add-textfield-align");
		// Put Validation code here
		tagAddingTextField.addValueChangeListener(listener -> {
			String tagAdded = (String) listener.getProperty().getValue();
			if (StringUtils.isNotEmpty(tagAdded) && !tagAdded.matches("\\s+"))
			{
				Tag newTag = new Tag();
				newTag.setTagName(tagAdded);
				newTag.setTenantId(user.getTenant());
				newTag.setCreatedBy(user.getFirstName() + " " + user.getLastName());
				newTag.setCreatedServerTimestamp(System.currentTimeMillis());
				newTag.setAssigned(false);
				DashboardEventBus.post(new TagCreateOrUpdateEvent(user.getTenant(), newTag));
				tagAddingTextField.setValue("");
			}
			else if (tagAdded.matches("\\s+"))
			{
				Notification.show(DashboardUI.getMessageSource()
						.getMessage("view.overview.tag.add.empty.error"), Type.WARNING_MESSAGE);
			}
		});
		tagListView.addComponent(tagAddingTextField);
		tagListView.addComponent(buildTagButtonToolbar());

		tagListView.addComponent(tagGrid);
		tagListView.setSpacing(true);
		tagView.addComponent(tagListView);
		tagView.setStyleName("tag-layout-align");
		return tagView;

	}

	private void buildTagGrid()
	{

		final BeanItemContainer<Tag> tagListDataSource = new BeanItemContainer<Tag>(Tag.class,
				tagListForGrid);
		tagGrid = new Grid()
		{
			private static final long serialVersionUID = 1149296085007000496L;

			@Override
			protected void doCancelEditor()
			{
				editTag.setEnabled(tagGrid.getSelectedRows().size() > 0);
				deleteTags.setEnabled(tagGrid.getSelectedRows().size() > 0);
				super.doCancelEditor();
			}
		};
		tagGrid.setContainerDataSource(tagListDataSource);
		tagGrid.setColumns(TAG_COLUMN_ID);
		tagGrid.getColumn(TAG_COLUMN_ID).setWidth(TAG_COLUMN_WIDTH);
		tagGrid.setSizeFull();
		tagGrid.setId("tagGrid");
		Responsive.makeResponsive(tagGrid);

		tagGrid.setHeightMode(HeightMode.ROW);
		tagGrid.setSelectionMode(SelectionMode.MULTI);
		tagGrid.sort(TAG_COLUMN_ID);
		tagGrid.getColumn(TAG_COLUMN_ID).setHidable(false).setHeaderCaption(
				DashboardUI.getMessageSource().getMessage("view.overview.tagcolumnheader.tags"));
		tagGrid.setEditorFieldGroup(getTagFieldGroup());
		tagGrid.setEditorEnabled(true);
		tagGrid.setEditorSaveCaption(
				DashboardUI.getMessageSource().getMessage("view.overview.tag.grid.button.save"));
		tagGrid.setEditorCancelCaption(
				DashboardUI.getMessageSource().getMessage("view.overview.tag.grid.button.cancel"));

		tagGrid.setHeightByRows(22);
		buildTagsDetailsGenerator();
		tagGrid.addItemClickListener(event -> tagGridItemClickListner(event));
		tagGrid.addSelectionListener(listener -> tagGridSelectListner());
		tagGrid.setEditorErrorHandler(
				editorErrorHandler -> log.error(editorErrorHandler.getUserErrorMessage()
						+ " - causing error: " + editorErrorHandler.getCause().getMessage()));

		ContextMenu tagContextMenu = new ContextMenu(tagGrid, true);
		overviewTagGridContextMenuOpenListnerWithButtonEvents = new OverviewTagGridContextMenuOpenListnerWithButtonEvents(
				tagGrid, wagonGrid, tagContextMenu, tagListForGrid);
		tagContextMenu
				.addContextMenuOpenListener(overviewTagGridContextMenuOpenListnerWithButtonEvents);

	}

	private void tagGridItemClickListner(ItemClickEvent event)
	{

		if (!event.isCtrlKey() && !event.isAltKey() && !event.isDoubleClick() && !event.isMetaKey()
				&& !event.isShiftKey())
		{
			tagGrid.setEditorEnabled(false);
			tagGrid.setDetailsVisible(event.getItemId(),
					!tagGrid.isDetailsVisible(event.getItemId()));
		}

	}

	private void tagGridSelectListner()
	{
		boolean buttonHideShowFlag = wagonGrid.getSelectedRows().size() > 0
				&& tagGrid.getSelectedRows().size() > 0;
		assignTags.setEnabled(buttonHideShowFlag);
		unassignTags.setEnabled(buttonHideShowFlag);
		deleteTags.setEnabled(
				tagGrid.getSelectedRows().size() > 0 && wagonGrid.getSelectedRows().size() == 0);
		editTag.setEnabled(
				tagGrid.getSelectedRows().size() == 1 && wagonGrid.getSelectedRows().size() == 0);

	}

	private Component buildTagButtonToolbar()
	{
		HorizontalLayout tagButtonToolBar = new HorizontalLayout();
		tagManagementNavigator = buildButton("Tags",
				DashboardUI.getMessageSource()
						.getMessage("view.overview.tag.toolbar.button.tooltip.manage"),
				FontAwesome.BOOKMARK, null);
		assignTags = buildButton("Assign",
				DashboardUI.getMessageSource().getMessage(
						"view.overview.tag.toolbar.button.tooltip.assign"),
				FontAwesome.BOOKMARK,
				listner -> overviewTagGridContextMenuOpenListnerWithButtonEvents
						.assignTagsToWagons(new ArrayList<Tag>()));
		unassignTags = buildButton("Unassign",
				DashboardUI.getMessageSource()
						.getMessage("view.overview.tag.toolbar.button.tooltip.unassign"),
				FontAwesome.BOOKMARK_O,
				listner -> overviewTagGridContextMenuOpenListnerWithButtonEvents
						.unassignTagsFromWagons(new ArrayList<Tag>()));
		deleteTags = buildButton("Delete",
				DashboardUI.getMessageSource().getMessage(
						"view.overview.tag.toolbar.button.tooltip.delete"),
				FontAwesome.TRASH_O,
				listner -> overviewTagGridContextMenuOpenListnerWithButtonEvents
						.deleteTags(new ArrayList<Tag>(), deleteTags, editTag));
		editTag = buildButton("Edit",
				DashboardUI.getMessageSource()
						.getMessage("view.overview.tag.toolbar.button.tooltip.edit"),
				FontAwesome.EDIT, listner -> {
					tagGrid.setEditorEnabled(true);
					tagGrid.editItem(((List<Object>) tagGrid.getSelectedRows()).get(0));
					deleteTags.setEnabled(false);
					editTag.setEnabled(false);
				});

		tagButtonToolBar.addComponent(assignTags);
		tagButtonToolBar.addComponent(unassignTags);
		tagButtonToolBar.addComponent(deleteTags);
		tagButtonToolBar.addComponent(editTag);
		tagButtonToolBar.setSpacing(true);

		tagButtonToolBar.setStyleName("toolbar");
		tagButtonToolBar.addStyleName("tag-button-toolbar-align");

		return tagButtonToolBar;
	}

	private Button buildButton(String buttonFor, String tooltip, Resource icon,
			ClickListener clickListner)
	{
		Button generatedButton = new Button();
		generatedButton.addStyleName(ValoTheme.BUTTON_ICON_ONLY);
		generatedButton.setEnabled(false);
		generatedButton.setId(buttonFor.toLowerCase());
		generatedButton.setIcon(icon);
		generatedButton.setDescription(tooltip);
		if (buttonFor.equalsIgnoreCase("tags"))
		{
			generatedButton.addStyleName(ValoTheme.BUTTON_BORDERLESS);
			generatedButton.addStyleName(ValoTheme.BUTTON_HUGE);
			generatedButton.addStyleName("tag-navigator-button");
			generatedButton.addStyleName(TAG_BUTTON_ROTATION);
			generatedButton.setEnabled(true);
		}
		else
		{
			generatedButton.addClickListener(clickListner);
		}
		return generatedButton;

	}

	private void buildTagsDetailsGenerator()
	{
		tagGrid.setDetailsGenerator(rowReference -> {
			SimpleDateFormat format = new SimpleDateFormat(
					DashboardUI.getMessageSource().getMessage("date.format"));

			final Tag beanTag = (Tag) rowReference.getItemId();

			String assignTagIconHtml = beanTag.isAssigned() ? FontAwesome.BOOKMARK.getHtml() : "";

			Label tagServerTime = new Label("<b> "
					+ DashboardUI.getMessageSource()
							.getMessage("view.overview.tag.grid.details.createdtime")
					+ " : " + "</b><br/>" + format.format(beanTag.getCreatedDate()),
					ContentMode.HTML);
			Label tagName = new Label(
					"<b> " + DashboardUI.getMessageSource()
							.getMessage("view.overview.tag.grid.details.name") + " : " + "</b><br/>"
					+ getWrappedHtmlText(beanTag.getTagName()) + "   " + assignTagIconHtml,
					ContentMode.HTML);
			Label tagCreatedBy = new Label("<b> "
					+ DashboardUI.getMessageSource()
							.getMessage("view.overview.tag.grid.details.createdby")
					+ " : " + "</b><br/>" + getWrappedHtmlText(beanTag.getCreatedBy()),
					ContentMode.HTML);

			FormLayout formLayout = new FormLayout(tagServerTime, tagName, tagCreatedBy);

			HorizontalLayout layout = new HorizontalLayout(formLayout);
			layout.setSpacing(true);
			layout.setMargin(true);
			return layout;
		});
	}

	private FieldGroup getTagFieldGroup()
	{
		BeanFieldGroup<Tag> beanFieldGroup = new BeanFieldGroup<Tag>(Tag.class);
		beanFieldGroup.addCommitHandler(new CommitHandler()
		{

			private static final long serialVersionUID = 6062316515368687380L;

			@Override
			public void preCommit(CommitEvent commitEvent) throws CommitException
			{

			}

			@Override
			public void postCommit(CommitEvent commitEvent) throws CommitException
			{

				Tag editingTag = beanFieldGroup.getItemDataSource().getBean();
				if (StringUtils.isNotEmpty(editingTag.getTagName())
						&& !editingTag.getTagName().matches("\\s+"))
				{
					if (DashboardUI.getDataProvider().getTags(user).stream()
							.noneMatch(tagMatch -> tagMatch.getTagName().toLowerCase()
									.equals(editingTag.getTagName().toLowerCase())))
					{
						DashboardEventBus
								.post(new TagCreateOrUpdateEvent(user.getTenant(), editingTag));
						wagonGrid.setContainerDataSource(createContainer(
								DashboardUI.getDataProvider().getWagonsWithCurrentValues(user)));
						Notification.show(DashboardUI.getMessageSource()
								.getMessage("view.overview.tag.grid.save.success"));
					}
					else
					{
						Notification.show(
								editingTag.getTagName() + " : "
										+ DashboardUI.getMessageSource().getMessage(
												"view.overview.tag.notification.duplicate"),
								Type.WARNING_MESSAGE);
						throw new CommitException(
								editingTag.getTagName() + " : " + DashboardUI.getMessageSource()
										.getMessage("view.overview.tag.notification.duplicate"));
					}
				}
				else
				{
					Notification.show(DashboardUI.getMessageSource()
							.getMessage("view.overview.tag.add.empty.error"), Type.WARNING_MESSAGE);
					throw new CommitException(DashboardUI.getMessageSource()
							.getMessage("view.overview.tag.add.empty.error"));

				}
				editTag.setEnabled(false);
				deleteTags.setEnabled(false);
			}
		});

		return beanFieldGroup;
	}

	private OverviewContainer createContainer(List<Wagon> wagons)
	{
		OverviewContainer overviewContainer = new OverviewContainer(wagons);
		overviewContainer.addNestedContainerProperty(OverviewConstants.WAGON_TYPE_NAME);
		overviewContainer.addNestedContainerProperty(OverviewConstants.STREET_CITY);
		overviewContainer.addNestedContainerProperty(OverviewConstants.COUNTRY);
		overviewContainer.addNestedContainerProperty(OverviewConstants.TAGS);
		return overviewContainer;
	}

	private String getWrappedHtmlText(String text)
	{
		return text.trim().length() > TEXT_LENGTH ? text.substring(0, TEXT_LENGTH) + "<br/>"
				+ getWrappedHtmlText(text.substring(TEXT_LENGTH)) : text;
	}
}
