
package com.bosch.si.amra.im.login;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * This annotation is used to distinguish which view is allowed to be rendered.
 * The annotation is placed on the view class with the corresponding role. The hierarchy is as
 * follows:
 * The ENDCUSTOMER is allowed to see only Disponent and Notification view.
 * The USER is allowed to see only pages with detail information and no administration view is
 * shown. The FLEETADMIN can see everything what the USER can see and the administration view. The
 * SYSTEMADMIN can see everything. The minimum accepted role is set in the annotation. It is
 * possible to set more than one role but this does not effect the rendering so far.
 * 
 * @author toa1wa3
 * 
 */
@Retention (RetentionPolicy.RUNTIME)
@Target ({ ElementType.TYPE, ElementType.METHOD })
public @interface Role
{
	public enum Roles
	{
		ENDCUSTOMER, USER, FLEETADMIN, SYSTEMADMIN
	}

	Roles[] value() default Roles.USER;
}
