
package com.bosch.si.amra.component.map;

import java.util.ArrayList;
import java.util.List;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.common.GoogleMapUtilFactory;
import com.bosch.si.amra.component.OpenInfoWindowOnMarkerClickListener;
import com.bosch.si.amra.entity.LatLong;
import com.bosch.si.amra.entity.Wagon;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Page;
import com.vaadin.server.Page.Styles;
import com.vaadin.tapio.googlemaps.GoogleMap;
import com.vaadin.tapio.googlemaps.client.LatLon;
import com.vaadin.tapio.googlemaps.client.overlays.GoogleMapMarker;
import com.vaadin.ui.MenuBar;
import com.vaadin.ui.MenuBar.Command;
import com.vaadin.ui.MenuBar.MenuItem;

public class Map extends GoogleMap
{
	/**
	 * Serial version uid
	 */
	private static final long					serialVersionUID			= 4488041627011545642L;

	private List<CustomizedGoogleMapInfoWindow>	googleMapInfoWindows		= new ArrayList<>();

	private List<CustomizedGoogleMapInfoWindow>	fullGoogleMapInfoWindows	= new ArrayList<>();

	private List<String>						aliasList					= new ArrayList<String>();

	private MenuItem							markerToggle;

	private boolean								isMarkerToggleDefault		= true;

	private CustomizedGoogleMapInfoWindow		infoWindow;

	private CustomizedGoogleMapInfoWindow		fullInfoWindow;

	public Map(List<Wagon> wagons)
	{
		super(DashboardUI.getGoogleAPIKey(), "", "");
		setId("map");
		setCaption(DashboardUI.getMessageSource().getMessage("view.dashboard.map"));
		setSizeFull();
		setMinZoom(1);
		setMaxZoom(25);
		clearMarkers();
		setHeight(98, Unit.PERCENTAGE);

		fillLocationMap(wagons);
		GoogleMapUtilFactory.buildJavaScriptFunction();
	}

	private void fillLocationMap(List<Wagon> wagons)
	{
		List<LatLon> positions = new ArrayList<LatLon>();
		for (Wagon wagon : wagons)
		{
			if (wagon.getLatLong() != null)
			{
				LatLon location = GoogleMapUtilFactory.buildLocation(wagon.getLatLong());
				positions.add(location);

				displaySmallInfoWindows(this, wagon, location);
				createMarkersWithInfoWindows(this, wagon, location);
			}
		}
		GoogleMapUtilFactory.autoZoomMap(positions, this);
	}

	private void displaySmallInfoWindows(GoogleMap googleMap, Wagon wagon, LatLon location)
	{
		CustomizedGoogleMapInfoWindow amraBoxInfoWindow = GoogleMapUtilFactory
				.buildGoogleMapSmallInfoWindow(wagon.getAlias(), wagon.getTimestamp(), location);
		amraBoxInfoWindow.setAutoPanDisabled(true);
		googleMapInfoWindows.add(amraBoxInfoWindow);
		googleMap.openInfoWindow(amraBoxInfoWindow);
	}

	private void createMarkersWithInfoWindows(GoogleMap googleMap, Wagon wagon, LatLon location)
	{
		GoogleMapMarker locationMarker = GoogleMapUtilFactory.buildGoogleMapMarker(location,
				wagon.getAlias());
		CustomizedGoogleMapInfoWindow fullInfoWindow = GoogleMapUtilFactory
				.buildGoogleMapFullInfoWindow(wagon, location, locationMarker);
		fullInfoWindow.setAlias(wagon.getAlias());
		fullGoogleMapInfoWindows.add(fullInfoWindow);
		OpenInfoWindowOnMarkerClickListener infoWindowOpener = new OpenInfoWindowOnMarkerClickListener(
				googleMap, locationMarker, fullInfoWindow);
		googleMap.addMarkerClickListener(infoWindowOpener);
	}

	@SuppressWarnings ("serial")
	public void buildMarkerToggle(MenuBar tools, MenuItem max)
	{
		markerToggle = tools.addItemBefore("", FontAwesome.MAP_MARKER, new Command()
		{
			@Override
			public void menuSelected(MenuItem selectedItem)
			{
				Styles styles = Page.getCurrent().getStyles();
				clearMarkers();
				isMarkerToggleDefault = false;
				if (selectedItem.isChecked())
				{
					selectedItem.setChecked(false);
					styles.add(".gm-style-iw + div {display: none;}");
					fullGoogleMapInfoWindows.forEach(infoWindow -> closeInfoWindow(infoWindow));
					if (fullInfoWindow != null)
						closeInfoWindow(fullInfoWindow);

					if (getInfowindow() != null)
						openInfoWindow(getInfowindow());
					else
						googleMapInfoWindows.forEach(googleMapInfoWindow -> {
							if (getAliasList().contains(googleMapInfoWindow.getAlias()))
								openInfoWindow(googleMapInfoWindow);
						});
				}
				else
				{
					selectedItem.setChecked(true);
					googleMapInfoWindows.forEach(infoWindow -> closeInfoWindow(infoWindow));
					styles.add(".gm-style-iw + div {display: block;}");
					if (getInfowindow() != null)
					{
						Wagon wagon = createWagon();
						GoogleMapMarker locationMarker = GoogleMapUtilFactory.buildGoogleMapMarker(
								getInfowindow().getPosition(), getInfowindow().getAlias());
						fullInfoWindow = GoogleMapUtilFactory.buildGoogleMapFullInfoWindow(wagon,
								getInfowindow().getPosition(), locationMarker);
						googleMapInfoWindows.forEach(infoWindow -> closeInfoWindow(infoWindow));
						closeInfoWindow(getInfowindow());
						addMarker(fullInfoWindow.getAnchorMarker());
						OpenInfoWindowOnMarkerClickListener infoWindowOpener = new OpenInfoWindowOnMarkerClickListener(
								Map.this, locationMarker, fullInfoWindow);
						addMarkerClickListener(infoWindowOpener);

					}
					else
						fullGoogleMapInfoWindows.forEach(googleMapInfoWindow -> {
							if (getAliasList().contains(googleMapInfoWindow.getAlias()))
							{
								closeInfoWindow(googleMapInfoWindow);
								addMarker(googleMapInfoWindow.getAnchorMarker());
							}
						});
				}
			}

		}, max);
		markerToggle.setStyleName("icon-only");
	}

	public List<CustomizedGoogleMapInfoWindow> getGoogleMapInfoWindows()
	{
		return googleMapInfoWindows;
	}

	public List<CustomizedGoogleMapInfoWindow> getFullGoogleMapInfoWindows()
	{
		return fullGoogleMapInfoWindows;
	}

	public CustomizedGoogleMapInfoWindow getSelectedInfoWindow(LatLong position)
	{
		if (position != null)
		{
			LatLon infoWindowPosition = new LatLon(position.getLat(), position.getLng());
			for (CustomizedGoogleMapInfoWindow infoWindow : googleMapInfoWindows)
			{
				if (infoWindow.getPosition().equals(infoWindowPosition))
					return infoWindow;
			}
		}
		return null;
	}

	public CustomizedGoogleMapInfoWindow getFullInfoWindow()
	{
		return fullInfoWindow;
	}

	public void setFullInfoWindow(CustomizedGoogleMapInfoWindow fullInfoWindow)
	{
		this.fullInfoWindow = fullInfoWindow;
	}

	public CustomizedGoogleMapInfoWindow getInfowindow()
	{
		return infoWindow;
	}

	public void setInfowindow(CustomizedGoogleMapInfoWindow infowindow)
	{
		this.infoWindow = infowindow;
	}

	public MenuItem getMarkerToggle()
	{
		return markerToggle;
	}

	public boolean isMarkerToggleDefault()
	{
		return isMarkerToggleDefault;
	}

	public void setMarkerToggle(MenuItem markerToggle)
	{
		this.markerToggle = markerToggle;
	}

	public List<String> getAliasList()
	{
		return aliasList;
	}

	public void setAliasList(List<String> aliasList)
	{
		this.aliasList = aliasList;
	}

	private Wagon createWagon()
	{
		Wagon wagon = new Wagon();
		wagon.setAlias(getInfowindow().getAlias());
		wagon.setTimestamp(getInfowindow().getTimestamp());
		wagon.setAddress(getInfowindow().getAddress());
		return wagon;
	}
}
