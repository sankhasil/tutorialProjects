
package com.bosch.si.amra.metrics;

import com.bosch.si.amra.DashboardUI;
import com.codahale.metrics.Counter;
import com.codahale.metrics.MetricRegistry;

public class MetricsFactory
{
	public static Counter createCounter(final String prefix, final String metricName)
	{
		Counter counter = DashboardUI.getMetrics().getCounters().get(prefix + "." + metricName);
		return counter != null ? counter
				: DashboardUI.getMetrics().counter(MetricRegistry.name(prefix, metricName));
	}
}
