
package com.bosch.si.amra.view.formatter;

import com.vaadin.data.Property;

public class DefaultFormatter extends PropertyFormatter
{
	@Override
	public String format(Object rowId, Property<?> property, String result)
	{
		return result;
	}
}
