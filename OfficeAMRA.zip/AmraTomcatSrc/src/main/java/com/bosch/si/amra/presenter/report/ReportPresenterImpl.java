
package com.bosch.si.amra.presenter.report;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.entity.report.MileageValue;
import com.bosch.si.amra.entity.report.SensorValue;
import com.bosch.si.amra.event.DashboardEvent.ReportEvent;
import com.bosch.si.amra.event.DashboardEvent.ReportMileageUpdateEvent;
import com.bosch.si.amra.event.DashboardEvent.ReportSensorUpdateEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.provider.AggregationDataProvider;
import com.bosch.si.amra.view.report.ReportView;

/**
 * Presenter for {@link ReportView}
 * 
 * @author toa1wa3
 * 
 */
@Component
public class ReportPresenterImpl implements Serializable, ReportPresenter
{

	/**
	 * Serial version uid
	 */
	private static final long serialVersionUID = -8401566172533393432L;

	@Override
	public Map<String, List<MileageValue>> getMileageReport(ReportEvent event)
	{
		Calendar instance = Calendar.getInstance();
		instance.add(Calendar.YEAR, -1);
		instance.set(Calendar.HOUR_OF_DAY, 0);
		instance.set(Calendar.MINUTE, 0);
		instance.set(Calendar.SECOND, 1);
		List<String> wagonIds = getWagonIds(event.getWagons());
		Map<String, Integer> offsetValues = new HashMap<String, Integer>();
		for (Wagon wagon : event.getWagons())
		{
			offsetValues.put(wagon.getAlias(), wagon.getMileageOffset());
		}
		Map<String, List<MileageValue>> mileage = DashboardUI.getAggregationDataProvider()
				.getMileage(event.getTenantId(), wagonIds, instance.getTime());

		DashboardEventBus.post(new ReportMileageUpdateEvent(mileage, offsetValues));
		return mileage;
	}

	@Override
	public Map<String, List<SensorValue>> getSensorReport(ReportEvent event)
	{
		Calendar instance = Calendar.getInstance();
		instance.add(Calendar.MONTH, -1);
		instance.set(Calendar.HOUR_OF_DAY, 0);
		instance.set(Calendar.MINUTE, 0);
		instance.set(Calendar.SECOND, 1);
		List<Wagon> wagons = event.getWagons();
		List<String> wagonIds = getWagonIds(wagons);

		AggregationDataProvider aDP = DashboardUI.getAggregationDataProvider();
		String tenantId = event.getTenantId();
		Date instanceTime = instance.getTime();

		Map<String, List<SensorValue>> sensorValues = aDP.getSensorValues(tenantId, wagonIds,
				instanceTime);

		DashboardEventBus.post(new ReportSensorUpdateEvent(sensorValues));
		return sensorValues;
	}

	private List<String> getWagonIds(List<Wagon> wagons)
	{
		List<String> wagonIds = new ArrayList<>();
		for (Wagon wagon : wagons)
		{
			wagonIds.add(wagon.getId());
		}
		return wagonIds;
	}
}
