
package com.bosch.si.amra.view.formatter;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.constants.rule.RuleConstants;
import com.bosch.si.amra.entity.rule.Rule;
import com.vaadin.data.Property;

public class RuleUnitFormatter extends PropertyFormatter
{
	@Override
	public String format(Object rowId, Property<?> property, String result)
	{
		Rule rule = (Rule) rowId;
		switch (rule.getRuleType())
		{
			case MongoConstants.HUMIDITY:
				return new String(
						DashboardUI.getMessageSource().getMessage("view.alarm.unit.percent"));
			case MongoConstants.HUMIDITY_TEMPERATURE:
			case MongoConstants.DEVICE_TEMPERATURE:
			case RuleConstants.HUMIDITY_TEMPERATURE_RANGE:
				return new String(
						DashboardUI.getMessageSource().getMessage("view.alarm.unit.celsius"));
			case MongoConstants.MILEAGE:
				return new String(DashboardUI.getMessageSource().getMessage("view.alarm.unit.km"));
		}
		return result;
	}
}
