
package com.bosch.si.amra.view.report;

import com.bosch.si.amra.entity.report.SensorValue;

/**
 * Concret humidity temperature container implementation of sensor container
 * 
 * @author toa1wa3
 *
 */
public class HumidityTemperatureContainer extends SensorContainer
{
	@Override
	public boolean isNull(SensorValue value)
	{
		return value.getHumidityTemperature() != null;
	}
}
