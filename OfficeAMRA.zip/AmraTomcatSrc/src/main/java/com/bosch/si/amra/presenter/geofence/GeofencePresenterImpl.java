
package com.bosch.si.amra.presenter.geofence;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.constants.UIConstants;
import com.bosch.si.amra.entity.geofence.Geofence;
import com.bosch.si.amra.event.DashboardEvent.ClearValueEvent;
import com.bosch.si.amra.event.DashboardEvent.GeofenceDeleteEvent;
import com.bosch.si.amra.event.DashboardEvent.GeofenceDeletedEvent;
import com.bosch.si.amra.event.DashboardEvent.GeofenceSaveEvent;
import com.bosch.si.amra.event.DashboardEvent.GeofenceSelectEvent;
import com.bosch.si.amra.event.DashboardEvent.GeofenceSelectedEvent;
import com.bosch.si.amra.event.DashboardEvent.NotSuccessfulEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.provider.DataProviderInitializer;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.DuplicateKeyException;
import com.mongodb.MongoClient;
import com.mongodb.WriteConcernException;
import com.mongodb.WriteResult;

/**
 * Implementation of {@link GeofencePresenter}
 * 
 * @author toa1wa3
 *
 */
@Component
public class GeofencePresenterImpl implements GeofencePresenter
{
	private static final Logger	logger	= LoggerFactory.getLogger(GeofencePresenterImpl.class);

	@Override
	public WriteResult saveGeofence(GeofenceSaveEvent event)
	{
		Geofence geofence = event.getGeofence();
		String tenantId = event.getTenantId();
		if (geofence == null)
		{
			throw new IllegalArgumentException("Geofencing must not be null");
		}
		if (tenantId == null || tenantId.isEmpty())
		{
			throw new IllegalArgumentException(UIConstants.TENANT_ID_MUST_NOT_BE_NULL);
		}
		if (geofence.getName() == null || geofence.getName().isEmpty()
				|| geofence.getName().matches("-"))
		{
			logger.error("Geofence name must not be null for tenant{}", tenantId);
			DashboardEventBus.post(new NotSuccessfulEvent("view.geofence.noname"));
			throw new IllegalArgumentException("Geofence name must not be null");
		}

		DBObject geofencingToSave = Geofence.geofence2DBObject(geofence);

		DBCollection geofenceCollection = getGeofenceCollection();
		try
		{
			WriteResult save = geofenceCollection.save(geofencingToSave);
			DashboardEventBus.post(new ClearValueEvent());
			logger.debug("Geofence saved");
			return save;
		}
		catch (DuplicateKeyException e)
		{
			DashboardEventBus.post(new NotSuccessfulEvent("view.geofence.duplicate"));
			logger.debug("Geofence {} already exists for the tenant {}", geofence.getName(),
					tenantId);
			logger.error(e.getMessage());
			return null;
		}
		catch (WriteConcernException e)
		{
			DashboardEventBus.post(new NotSuccessfulEvent("view.geofence.malformed"));
			logger.debug("Geofence {} is malformed and not stored properly ", geofence.getName());
			logger.error(e.getMessage());
			return null;
		}
	}

	@Override
	public Geofence showGeofence(GeofenceSelectEvent event)
	{
		String geofenceId = event.getGeofenceId();
		if (geofenceId == null || geofenceId.isEmpty())
		{
			throw new IllegalArgumentException("GeofencingId must not be null");
		}

		DBCollection geofenceCollection = getGeofenceCollection();

		DBObject match = new BasicDBObject(MongoConstants.ID, geofenceId);
		DBObject geofencingObject = geofenceCollection.findOne(match);

		Geofence geofence = Geofence.dbObject2Geofence(geofencingObject);
		DashboardEventBus.post(new GeofenceSelectedEvent(geofence));
		return geofence;
	}

	@Override
	public void deleteGeofence(GeofenceDeleteEvent event)
	{
		Geofence geofence = event.getGeofence();
		if (geofence == null || geofence.getId() == null)
		{
			throw new IllegalArgumentException(UIConstants.GEOFENCE_ID_MUST_NOT_BE_NULL);
		}

		boolean removed = false;
		if (checkUsageOfGeofenceinRule(geofence.getId()) < 1)
		{
			DBCollection geofenceCollection = getGeofenceCollection();
			DBObject deleteObject = new BasicDBObject();
			deleteObject.put(MongoConstants.ID, geofence.getId());
			geofenceCollection.remove(deleteObject);
			removed = true;
		}

		DashboardEventBus.post(new GeofenceDeletedEvent(removed));

	}

	private long checkUsageOfGeofenceinRule(String geofenceID)
	{
		DBCollection ruleCollection = getRuleCollection();
		DBObject countObject = new BasicDBObject(MongoConstants.GEOFENCE_ID, geofenceID);
		return ruleCollection.count(countObject);
	}

	private DBCollection getGeofenceCollection()
	{
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		return db.getCollection(DashboardUI.getGeofenceCollection());
	}

	private DBCollection getRuleCollection()
	{
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		return db.getCollection(DashboardUI.getRuleCollection());
	}
}
