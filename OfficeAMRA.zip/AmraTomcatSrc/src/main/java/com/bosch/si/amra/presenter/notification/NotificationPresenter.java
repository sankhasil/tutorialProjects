
package com.bosch.si.amra.presenter.notification;

import com.bosch.si.amra.event.DashboardEvent.NotificationAcknowledgeEvent;
import com.bosch.si.amra.event.DashboardEvent.NotificationsSaveAliasEvent;
import com.google.common.eventbus.Subscribe;
import com.mongodb.WriteResult;

public interface NotificationPresenter
{
	/**
	 * Acknowledging notifications
	 *
	 * @param event
	 *            {@link NotificationAcknowledgeEvent}
	 */
	@Subscribe
	public void acknowledgeNotifications(NotificationAcknowledgeEvent event);

	/**
	 * Stores the alias changes in the notifications
	 *
	 * @param event
	 *            {@link NotificationsSaveAliasEvent}
	 * @return Stores the alias changes in the notifications and returns the result
	 */
	@Subscribe
	public WriteResult saveAliasInNotifications(NotificationsSaveAliasEvent event);
}
