
package com.bosch.si.amra.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * Entity class for representing and geo location with latitude, longitude and its timestamp
 * 
 * @author toa1wa3
 * 
 */
public class LatLong implements Serializable
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= -8173112349234379254L;

	double						lat;

	double						lng;

	Date						timestamp;

	public LatLong(double lat, double lng)
	{
		this.lat = lat;
		this.lng = lng;
	}

	public LatLong(double lat, double lng, Date timestamp)
	{
		this.lat = lat;
		this.lng = lng;
		this.timestamp = timestamp;
	}

	public double getLat()
	{
		return lat;
	}

	public void setLat(double lat)
	{
		this.lat = lat;
	}

	public double getLng()
	{
		return lng;
	}

	public void setLng(double lng)
	{
		this.lng = lng;
	}

	public Date getTimestamp()
	{
		return timestamp;
	}

	public void setTimestamp(Date timestamp)
	{
		this.timestamp = timestamp;
	}

	@Override
	public String toString()
	{
		return "LatLong [lat=" + lat + ", lng=" + lng + ", timestamp=" + timestamp + "]";
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(lat);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(lng);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((timestamp == null) ? 0 : timestamp.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LatLong other = (LatLong) obj;
		if (Double.doubleToLongBits(lat) != Double.doubleToLongBits(other.lat))
			return false;
		if (Double.doubleToLongBits(lng) != Double.doubleToLongBits(other.lng))
			return false;
		if (timestamp == null)
		{
			if (other.timestamp != null)
				return false;
		}
		else if (!timestamp.equals(other.timestamp))
			return false;
		return true;
	}
}
