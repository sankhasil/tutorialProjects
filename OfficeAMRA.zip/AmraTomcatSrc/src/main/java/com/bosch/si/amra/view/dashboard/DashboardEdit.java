
package com.bosch.si.amra.view.dashboard;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.event.DashboardEvent.DashboardEditEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;
import com.vaadin.ui.Component;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.Window;
import com.vaadin.ui.themes.ValoTheme;

@SuppressWarnings ("serial")
public class DashboardEdit extends Window
{

	private final TextField	nameField	= new TextField(DashboardUI.getMessageSource().getMessage(
												"view.dashboard.name"));

	public DashboardEdit(String currentName)
	{
		setCaption(DashboardUI.getMessageSource().getMessage("view.dashboard.edit"));
		setModal(true);
		setClosable(false);
		setResizable(false);
		setWidth(300.0f, Unit.PIXELS);

		addStyleName("edit-dashboard");

		setContent(buildContent(currentName));
	}

	private Component buildContent(String currentName)
	{
		VerticalLayout result = new VerticalLayout();
		result.setMargin(true);
		result.setSpacing(true);

		nameField.setValue(currentName);
		nameField.addStyleName("caption-on-left");
		nameField.focus();

		result.addComponent(nameField);
		result.addComponent(buildFooter());

		return result;
	}

	private Component buildFooter()
	{
		HorizontalLayout footer = new HorizontalLayout();
		footer.setSpacing(true);
		footer.addStyleName(ValoTheme.WINDOW_BOTTOM_TOOLBAR);
		footer.setWidth(100.0f, Unit.PERCENTAGE);

		Button cancel = new Button(DashboardUI.getMessageSource().getMessage(
				"view.dashboard.cancel"));
		cancel.addClickListener(new ClickListener()
		{
			@Override
			public void buttonClick(ClickEvent event)
			{
				close();
			}
		});
		cancel.setClickShortcut(KeyCode.ESCAPE, null);

		Button save = new Button(DashboardUI.getMessageSource().getMessage("view.dashboard.ok"));
		save.addStyleName(ValoTheme.BUTTON_PRIMARY);
		save.addClickListener(new ClickListener()
		{
			@Override
			public void buttonClick(ClickEvent event)
			{
				DashboardEventBus.post(new DashboardEditEvent(nameField.getValue()));
				close();
			}
		});
		save.setClickShortcut(KeyCode.ENTER, null);

		footer.addComponents(cancel, save);
		footer.setExpandRatio(cancel, 1);
		footer.setComponentAlignment(cancel, Alignment.TOP_RIGHT);
		return footer;
	}
}
