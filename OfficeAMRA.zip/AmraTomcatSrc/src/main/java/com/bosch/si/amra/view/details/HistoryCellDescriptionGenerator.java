
package com.bosch.si.amra.view.details;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.overview.OverviewConstants;
import com.vaadin.ui.Grid.CellDescriptionGenerator;
import com.vaadin.ui.Grid.CellReference;

/**
 * Creates a tooltip for property Ids in the history grid
 *
 * @author toa1wa3
 *
 */
public class HistoryCellDescriptionGenerator implements CellDescriptionGenerator
{
	/**
	 * Serial version uid
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String getDescription(CellReference cell)
	{
		if (OverviewConstants.COLLECT_CAUSE.equals(cell.getPropertyId()))
		{
			return "<div><span class=\"v-icon\" style=\"color: green; font-family: FontAwesome;\">&#xF04B;</span> = "
					+ DashboardUI.getMessageSource().getMessage(
							"view.details.telematic.history.description.tripstarted")
					+ "</div>"
					+ "<div><span class=\"v-icon\" style=\"color: red; font-family: FontAwesome;\">&#xF04D;</span> = "
					+ DashboardUI.getMessageSource().getMessage(
							"view.details.telematic.history.description.tripended")
					+ "</div>";
		}
		return "";
	}
}
