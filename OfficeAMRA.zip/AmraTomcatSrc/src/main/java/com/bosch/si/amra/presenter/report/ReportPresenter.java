
package com.bosch.si.amra.presenter.report;

import java.util.List;
import java.util.Map;

import com.bosch.si.amra.entity.report.MileageValue;
import com.bosch.si.amra.entity.report.SensorValue;
import com.bosch.si.amra.event.DashboardEvent.ReportEvent;
import com.google.common.eventbus.Subscribe;

/**
 * @author toa1wa3
 * 
 */
public interface ReportPresenter
{

	/**
	 * Aggregates the mileage according to following rule: Group by box id and date and calculation
	 * the sum of the mileage for each group. Group this group according to the box id and add a
	 * list of values containing the calculated mileage grouped by the date
	 * 
	 * @param event
	 *            A {@link ReportEvent} to call this method
	 * @return A map with alias as key and a list of date, mileage entries
	 */
	@Subscribe
	public Map<String, List<MileageValue>> getMileageReport(ReportEvent event);

	/**
	 * Aggregates the sensor values according to following rule: Group by box id and date and add
	 * the needed sensor values for each group. Group this group according to the box id and add a
	 * list of values containing the timestamp and sensor values grouped by the date
	 * 
	 * @param event
	 *            A {@link ReportEvent} to call this method
	 * @return A map with alias as key and a list of date, sensor value entries
	 */
	@Subscribe
	public Map<String, List<SensorValue>> getSensorReport(ReportEvent event);
}
