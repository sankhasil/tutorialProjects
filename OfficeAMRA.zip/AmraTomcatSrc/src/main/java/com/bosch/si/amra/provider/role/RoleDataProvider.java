
package com.bosch.si.amra.provider.role;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Component;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.constants.UIConstants;
import com.bosch.si.amra.entity.WagonUser;
import com.bosch.si.amra.entity.WagonUsers;
import com.bosch.si.amra.provider.DataProviderInitializer;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

/**
 * Provides methods for retrieving user role data
 *
 * @author toa1wa3
 */
@Component
public class RoleDataProvider
{
	/**
	 * Retrieves the assigned disponent users for a given wagon within a given tenant.
	 *
	 * @param tenantId
	 *            the tenenatId
	 * @param wagonId
	 *            the wagonId
	 * @return A list of all assigned disponent users to the given wagon
	 */
	public List<WagonUser> getAssignedDisponentsForWagon(String tenantId, String wagonId)
	{
		if (tenantId == null || tenantId.isEmpty())
			throw new IllegalArgumentException(UIConstants.TENANT_ID_MUST_NOT_BE_NULL);
		if (wagonId == null || wagonId.isEmpty())
			throw new IllegalArgumentException("Wagond ID must not be null");
		List<WagonUser> assignedUsers = new ArrayList<>();
		DBObject selectedWagon = findAssignedDisponents(tenantId, wagonId);
		if (selectedWagon != null && selectedWagon.containsField(MongoConstants.DISPONENTS))
		{
			for (Object disponentChildObject : (BasicDBList) selectedWagon
					.get(MongoConstants.DISPONENTS))
			{
				DBObject disponentChild = (DBObject) disponentChildObject;
				WagonUser childDisponent = new WagonUser(
						(String) disponentChild.get(MongoConstants.ID),
						(String) disponentChild.get(MongoConstants.ALIAS), false, null, null, null);
				assignedUsers.add(childDisponent);
			}
		}
		return assignedUsers;
	}

	/**
	 * Retrieves the assigned endcustomer users for a given wagon within a given tenant.
	 *
	 * @param tenantId
	 *            the tenenatId
	 * @param wagonId
	 *            the wagonId
	 * @return A list of all assigned endcustomer users to the given wagon
	 */
	public List<WagonUser> getAssignedEndCustomersForWagon(String tenantId, String wagonId)
	{
		if (tenantId == null || tenantId.isEmpty())
			throw new IllegalArgumentException(UIConstants.TENANT_ID_MUST_NOT_BE_NULL);
		if (wagonId == null || wagonId.isEmpty())
			throw new IllegalArgumentException("Wagond ID must not be null");
		List<WagonUser> assignedUsers = new ArrayList<>();
		DBObject selectedWagon = findAssignedDisponents(tenantId, wagonId);
		if (selectedWagon != null && selectedWagon.containsField(MongoConstants.ENDCUSTOMERS))
		{
			for (Object endCustomerChildObject : (BasicDBList) selectedWagon
					.get(MongoConstants.ENDCUSTOMERS))
			{
				DBObject endCustomerChild = (DBObject) endCustomerChildObject;
				WagonUser childDisponent = new WagonUser(
						(String) endCustomerChild.get(MongoConstants.ID),
						(String) endCustomerChild.get(MongoConstants.ALIAS), true,
						new Date((Long) endCustomerChild.get(MongoConstants.ACTIVATION_TIME)), null,
						null);
				assignedUsers.add(childDisponent);
			}
		}
		return assignedUsers;
	}

	/**
	 * Retrieves all assigned users to a wagon for the whole tenant.
	 *
	 * @param tenantId
	 *            the tenenatId
	 * @return A list of all assigned users to a wagon for the given tenant. Only visible for
	 *         the fleet or system admin
	 */
	public List<WagonUsers> getUsers2WagonAssignment(String tenantId)
	{
		if (tenantId == null || tenantId.isEmpty())
			throw new IllegalArgumentException(UIConstants.TENANT_ID_MUST_NOT_BE_NULL);
		List<WagonUsers> users = new ArrayList<>();
		DBCursor findUsers = findUsers(tenantId);

		if (findUsers != null)
		{
			while (findUsers.hasNext())
			{
				DBObject userObject = findUsers.next();
				WagonUsers user2Wagon = WagonUsers.dbObject2Disponent(userObject);
				users.add(user2Wagon);
			}
		}
		return users;
	}

	private DBObject findAssignedDisponents(String tenantId, String wagonId)
	{
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DBCollection wagonCollection = mongoClient.getDB(DashboardUI.getMongoDatabase())
				.getCollection(DashboardUI.getWagonCollection());
		DBObject find = new BasicDBObject(MongoConstants.TENANT_ID, tenantId);
		find.put(MongoConstants.ID, wagonId);
		DBObject keys = project();

		return wagonCollection.findOne(find, keys);
	}

	private DBCursor findUsers(String tenantId)
	{
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DBCollection wagonCollection = mongoClient.getDB(DashboardUI.getMongoDatabase())
				.getCollection(DashboardUI.getWagonCollection());

		DBObject find = new BasicDBObject(MongoConstants.TENANT_ID, tenantId);
		DBObject keys = project();

		return wagonCollection.find(find, keys).sort(new BasicDBObject(MongoConstants.SORT, 1));
	}

	private DBObject project()
	{
		DBObject keys = new BasicDBObject(MongoConstants.ALIAS, 1);
		keys.put(MongoConstants.WAGON_TYPE + "." + MongoConstants.WAGON_TYPE_NAME, 1);
		keys.put(MongoConstants.DISPONENTS, 1);
		keys.put(MongoConstants.ENDCUSTOMERS, 1);
		return keys;
	}
}
