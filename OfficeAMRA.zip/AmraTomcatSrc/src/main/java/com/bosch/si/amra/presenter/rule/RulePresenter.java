
package com.bosch.si.amra.presenter.rule;

import java.util.List;

import com.bosch.si.amra.entity.rule.Rule;
import com.bosch.si.amra.event.DashboardEvent.RulesDeleteEvent;
import com.bosch.si.amra.event.DashboardEvent.RuleReadEvent;
import com.bosch.si.amra.event.DashboardEvent.RuleSaveEvent;
import com.bosch.si.amra.event.DashboardEvent.RuleSortAndFilterEvent;
import com.bosch.si.amra.event.DashboardEvent.RulesSaveAliasEvent;
import com.bosch.si.amra.presenter.configuration.ConfigurationPresenterImpl;
import com.google.common.eventbus.Subscribe;
import com.mongodb.WriteResult;

/**
 * Interface for {@link ConfigurationPresenterImpl}. This is need for Spring because the actual
 * bean instance is a JDK dynamic proxy which implements this interface and calls the concrete
 * implementation
 *
 */
public interface RulePresenter
{
	/**
	 * Stores the Rule for means of transport
	 *
	 * @param event
	 *            the {@link RuleSaveEvent}
	 * @return saves Rule and WriteResult is returned
	 */
	@Subscribe
	public WriteResult saveRule(RuleSaveEvent event);

	/**
	 * Stores the alias changes for Rules
	 *
	 * @param event
	 *            {@link RulesSaveAliasEvent}
	 * @return saves Alias in Rules and the WriteResult is returned
	 */
	@Subscribe
	public WriteResult saveAliasInRules(RulesSaveAliasEvent event);

	/**
	 * Sorts the rules according to the given property and the ordering
	 *
	 * @param event
	 *            {@link RuleSortAndFilterEvent}. Contains the property, the order, the tenant ID
	 *            and optional the filter text to
	 *            sort
	 * @return Sorted list of rules
	 */
	@Subscribe
	public List<Rule> sortAndFilter(RuleSortAndFilterEvent event);

	/**
	 * Deletes the Rule for means of transport
	 *
	 * @param event
	 *            {@link RulesDeleteEvent}
	 */
	@Subscribe
	public void deleteRules(RulesDeleteEvent event);

	/**
	 * Get the Rule for id
	 *
	 * @param event
	 *            {@link RuleReadEvent}
	 * @return a Rule
	 */
	@Subscribe
	public Rule getRule(RuleReadEvent event);

}
