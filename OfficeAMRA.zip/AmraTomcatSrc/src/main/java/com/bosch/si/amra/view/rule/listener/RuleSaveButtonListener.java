
package com.bosch.si.amra.view.rule.listener;

import com.bosch.si.amra.view.rule.RuleView;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;

public class RuleSaveButtonListener implements ClickListener
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= -7302713199876466877L;

	private final RuleView		view;

	public RuleSaveButtonListener(RuleView view)
	{
		this.view = view;
	}

	@Override
	public void buttonClick(ClickEvent event)
	{
		view.saveRule();
	}
}
