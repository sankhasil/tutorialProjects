
package com.bosch.si.amra.constants.notification;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.vaadin.data.Container.Filter;
import com.vaadin.data.util.filter.Compare;
import com.vaadin.data.util.filter.Or;
import com.vaadin.data.util.filter.SimpleStringFilter;

public class NotificationConstants
{
	public static final String				ALIAS						= "alias";

	public static final String				SORT						= "sort";

	public static final String				WAGON_ID					= "wagonId";

	public static final String				REASON						= "reason";

	public static final String				SHOCK_VALUE					= "shockValue";

	public static final String				REASON_NAME					= "reasonName";

	public static final String				RULE						= "rule";

	public static final String				RULETYPE					= "ruleType";

	public static final String				ID							= "_id";

	public static final String				PRIORITY					= "priority";

	public static final String				LATITUDE					= "latitude";

	public static final String				LONGITUDE					= "longitude";

	public static final String				ACKNOWLEDGED				= "acknowledged";

	public static final String				TIMESTAMP					= "timestamp";

	public static final String				ADDRESS						= "address";

	public static final String				COUNTRY						= "address.country";

	public static final String				STREET_CITY					= "address.streetAndCity";

	public static final Object[]			PROPERTY_IDS				= { PRIORITY, TIMESTAMP,
			ALIAS, REASON, STREET_CITY, COUNTRY, LATITUDE, LONGITUDE };

	private static final Filter				shockFilter					= new SimpleStringFilter(
			NotificationConstants.RULE + "." + NotificationConstants.RULETYPE,
			"SHUNTING_SHOCK_DETECTED", true, false);

	private static final Filter				humidityFilter				= new Compare.Equal(
			NotificationConstants.RULE + "." + NotificationConstants.RULETYPE, "HM");

	private static final Filter				humidityTemperatureFilter	= new Compare.Equal(
			NotificationConstants.RULE + "." + NotificationConstants.RULETYPE, "HT");

	private static final Filter				deviceTemperatureFilter		= new Compare.Equal(
			NotificationConstants.RULE + "." + NotificationConstants.RULETYPE, "DT");

	private static final Filter				mileageFilter				= new Compare.Equal(
			NotificationConstants.RULE + "." + NotificationConstants.RULETYPE, "KM");

	private static final Filter				geofenceFilter				= new Compare.Equal(
			NotificationConstants.RULE + "." + NotificationConstants.RULETYPE, "GEOFENCE");

	private static final Filter				generalFilter				= new Compare.Equal(
			NotificationConstants.RULE + "." + NotificationConstants.RULETYPE,
			"GENERAL_NOTIFICATION");

	private static final Filter				doorOpenedStatusFilter		= new Compare.Equal(
			NotificationConstants.RULE + "." + NotificationConstants.RULETYPE,
			"DOOR_OPENED_DETECTED");

	private static final Filter				doorClosedStatusFilter		= new Compare.Equal(
			NotificationConstants.RULE + "." + NotificationConstants.RULETYPE,
			"DOOR_CLOSED_DETECTED");
	
	private static final Filter				temperatureMinMaxRangeFilter		= new Compare.Equal(
			NotificationConstants.RULE + "." + NotificationConstants.RULETYPE,
			"HTR");

	public static Filter					orFilter					= new Or(shockFilter,
			humidityFilter, humidityTemperatureFilter, deviceTemperatureFilter, mileageFilter,
			geofenceFilter, generalFilter, doorOpenedStatusFilter, doorClosedStatusFilter, temperatureMinMaxRangeFilter);

	public static final Map<String, String>	MAP_RULETYPE_TO_ICON;

	static
	{
		Map<String, String> map = new HashMap<String, String>();
		map.put("SHUNTING_SHOCK_DETECTED_RZ", "SHUNTING_SHOCK_DETECTED");
		map.put("SHUNTING_SHOCK_DETECTED_RX", "SHUNTING_SHOCK_DETECTED");
		map.put("SHUNTING_SHOCK_DETECTED_RY", "SHUNTING_SHOCK_DETECTED");
		map.put("HM", "HM");
		map.put("HT", "HT");
		map.put("DT", "DT");
		map.put("KM", "KM");
		map.put("GEOFENCE", "GEOFENCE");
		map.put("DOOR_OPENED_DETECTED", "DOOR_OPENED_DETECTED");
		map.put("DOOR_CLOSED_DETECTED", "DOOR_CLOSED_DETECTED");
		map.put("HTR", "HTR");
		MAP_RULETYPE_TO_ICON = Collections.unmodifiableMap(map);
	}

	public static final Map<String, Filter> RULTE_TYPE_FILTER;

	static
	{
		Map<String, Filter> map = new HashMap<>();
		map.put("SHUNTING_SHOCK_DETECTED", shockFilter);
		map.put("HM", humidityFilter);
		map.put("HT", humidityTemperatureFilter);
		map.put("DT", deviceTemperatureFilter);
		map.put("KM", mileageFilter);
		map.put("GEOFENCE", geofenceFilter);
		map.put("GENERAL_NOTIFICATION", generalFilter);
		map.put("DOOR_OPENED", doorOpenedStatusFilter);
		map.put("DOOR_CLOSED", doorClosedStatusFilter);
		map.put("HTR", temperatureMinMaxRangeFilter);
		RULTE_TYPE_FILTER = Collections.unmodifiableMap(map);
	}
}
