
package com.bosch.si.amra.component.grid;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.component.converter.TimestampConverter;
import com.bosch.si.amra.component.filter.TimestampFilter;
import com.bosch.si.amra.constants.overview.OverviewConstants;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.view.overview.OverviewGridCellStyleGenerator;
import com.bosch.si.amra.view.overview.OverviewGridFilterComponent.OverviewFilter;
import com.bosch.si.amra.view.overview.OverviewGridFilterComponent.OverviewTagFilter;
import com.bosch.si.amra.view.overview.TagListToTagNameConverter;
import com.vaadin.data.Container.Indexed;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.VaadinSession;
import com.vaadin.shared.data.sort.SortDirection;
import com.vaadin.ui.AbstractComponent;
import com.vaadin.ui.renderers.HtmlRenderer;
import com.vaadin.ui.themes.ValoTheme;

import elemental.json.JsonValue;

/**
 * @author ils5kor
 *
 */
public class OverviewGrid extends GridComponent
{
	/**
	 * Serial version uid
	 */
	private static final long				serialVersionUID	= 5563074828562373656L;

	private final User						user				= (User) VaadinSession.getCurrent()
			.getAttribute(User.class.getName());

	private Map<AbstractComponent, Object>	componentToPidMap	= new HashMap<>();

	public OverviewGrid(Indexed container, List<Wagon> wagons)
	{
		super(container);
		setSizeFull();
		addStyleName(ValoTheme.TABLE_BORDERLESS);
		addStyleName(ValoTheme.TABLE_NO_HORIZONTAL_LINES);
		addStyleName(ValoTheme.TABLE_COMPACT);
		setColumnReorderingAllowed(true);
		setImmediate(true);
		setContainerDataSource(container);
		Object[] columnIds = getColumnIds(user);
		setColumns(columnIds);
		setColumnOrder(columnIds);
		setEditorEnabled(false);
		setFrozenColumnCount(1);
		HeaderRow filterRow = appendHeaderRow();
		addFilterRow(filterRow);
		sort(OverviewConstants.ALIAS, SortDirection.ASCENDING);
		configureColumns();
		List<String> filteredWagonCoupledAliasList = wagons.stream()
				.filter(wagonFilter -> wagonFilter.getBoxId() != null)
				.map(wagonMapper -> wagonMapper.getAlias()).collect(Collectors.toList());
		getColumn(OverviewConstants.ALIAS)
				.setRenderer(new CoupledWagonRenderer(filteredWagonCoupledAliasList));
		if (getColumn(OverviewConstants.BATTERY_LEVEL) != null)
		{
			getColumn(OverviewConstants.BATTERY_LEVEL).setRenderer(new BatteryLevelRenderer());
		}

		getColumn(OverviewConstants.TIMESTAMP).setConverter(new TimestampConverter());
		getColumn(OverviewConstants.TIMESTAMP_CONTACT).setConverter(new TimestampConverter());
		if (getColumn(OverviewConstants.TAGS) != null)
		{
			getColumn(OverviewConstants.TAGS).setSortable(false);
			getColumn(OverviewConstants.TAGS).setConverter(new TagListToTagNameConverter());
		}
		setResponsive(true);
		setCellStyleGenerator(new OverviewGridCellStyleGenerator());
		setId("overviewGrid");
	}

	@Override
	public Map<AbstractComponent, Object> getComponentToPidMap()
	{
		return componentToPidMap;
	}

	private void addFilterRow(HeaderRow filterRow)
	{
		getColumns().forEach(column -> {
			String columnId = (String) column.getPropertyId();
			HeaderCell cell = filterRow.getCell(columnId);

			AbstractComponent filterField = null;
			switch (columnId)
			{
				case OverviewConstants.TIMESTAMP:
				case OverviewConstants.TIMESTAMP_CONTACT:
					filterField = new TimestampFilter<Wagon>(columnId, this);
					break;
				case OverviewConstants.TAGS:
					filterField = new OverviewTagFilter(columnId, this);
					break;

				case OverviewConstants.BATTERY_LEVEL:
					break;

				default:
					filterField = new OverviewFilter(columnId, this);
			}

			if (filterField != null)
			{
				componentToPidMap.put(filterField, columnId);
				cell.setComponent(filterField);
			}
		});

	}

	private void configureColumns()
	{
		getColumns().forEach(column -> {
			String columnId = (String) column.getPropertyId();

			getDefaultHeaderRow().getCell(columnId).setStyleName("grid-header");
			getDefaultHeaderRow().getCell(columnId).setHtml(DashboardUI.getMessageSource()
					.getMessage("view.overview.columnheader." + columnId.toString().toLowerCase()));
			switch (columnId)
			{
				case OverviewConstants.ALIAS:
					getColumn(columnId).setWidth(
							user.isEndcustomer() ? OverviewConstants.END_CUSTOMER_ALIAS_COLUMN_WIDTH
									: OverviewConstants.MEANS_OF_TRANSPORT_COLUMN_WIDTH);
					break;
				case OverviewConstants.WAGON_TYPE_NAME:
					getColumn(columnId).setWidth(OverviewConstants.TRANSPORT_TYPE_COLUMN_WIDTH);

					getColumn(columnId).setHidable(true)
							.setHidingToggleCaption(DashboardUI.getMessageSource()
									.getMessage(OverviewConstants.HIDE_AND_SHOW_HEADERS
											+ columnId.toString().toLowerCase()));
					break;
				case OverviewConstants.STREET_CITY:
					getColumn(columnId).setWidth(
							user.isEndcustomer() ? OverviewConstants.END_CUSTOMER_ALIAS_COLUMN_WIDTH
									: OverviewConstants.ADDRESS_COLUMN_WIDTH);
					getColumn(columnId).setHidable(true)
							.setHidingToggleCaption(DashboardUI.getMessageSource()
									.getMessage(OverviewConstants.HIDE_AND_SHOW_HEADERS
											+ columnId.toString().toLowerCase()));
					break;
				case OverviewConstants.COUNTRY:
					getColumn(columnId).setWidth(user.isEndcustomer()
							? OverviewConstants.END_CUSTOMER_COUNTRY_COLUMN_WIDTH
							: OverviewConstants.SMALL_COLUMN_WIDTH);
					getColumn(columnId).setHidable(true)
							.setHidingToggleCaption(DashboardUI.getMessageSource()
									.getMessage(OverviewConstants.HIDE_AND_SHOW_HEADERS
											+ columnId.toString().toLowerCase()));
					break;
				case OverviewConstants.TAGS:
				case OverviewConstants.MILEAGE:
				case OverviewConstants.HUMIDITY:
				case OverviewConstants.DEVICE_TEMPERATURE:
				case OverviewConstants.HUMIDITY_TEMPERATURE:
				case OverviewConstants.BATTERY_LEVEL:
					getColumn(columnId).setWidth(OverviewConstants.SMALL_COLUMN_WIDTH);
					getColumn(columnId).setHidable(true)
							.setHidingToggleCaption(DashboardUI.getMessageSource()
									.getMessage(OverviewConstants.HIDE_AND_SHOW_HEADERS
											+ columnId.toString().toLowerCase()));
					break;
				case OverviewConstants.TIMESTAMP:
					getColumn(columnId).setWidth(OverviewConstants.TIMESTAMP_COLUMN_WIDTH);
					getColumn(columnId).setHidable(true)
							.setHidingToggleCaption(DashboardUI.getMessageSource()
									.getMessage(OverviewConstants.HIDE_AND_SHOW_HEADERS
											+ columnId.toString().toLowerCase()));
					break;

				case OverviewConstants.TIMESTAMP_CONTACT:
					getColumn(columnId).setWidth(OverviewConstants.TIMESTAMP_COLUMN_WIDTH);
					getColumn(columnId).setHidable(true)
							.setHidingToggleCaption(DashboardUI.getMessageSource()
									.getMessage(OverviewConstants.HIDE_AND_SHOW_HEADERS
											+ columnId.toString().toLowerCase()));
					break;
				default:
					break;
			}
		});
	}

	private class CoupledWagonRenderer extends HtmlRenderer
	{
		/**
		 * Serial version uid
		 */
		private static final long	serialVersionUID	= -1774641449898445271L;

		private final List<String>	filteredWagonCoupledAliasList;

		public CoupledWagonRenderer(List<String> filteredWagonCoupledAliasList)
		{
			this.filteredWagonCoupledAliasList = filteredWagonCoupledAliasList;
		}

		@Override
		public JsonValue encode(String value)
		{
			if (filteredWagonCoupledAliasList.contains(value))
				value = FontAwesome.LINK.getHtml() + " " + value;
			return super.encode(value);
		}
	}

	private class BatteryLevelRenderer extends HtmlRenderer
	{
		private static final long serialVersionUID = 5985037793361793094L;

		@Override
		public JsonValue encode(String value)
		{
			value = FontAwesome.BATTERY_FULL.getHtml();
			return super.encode(value);
		}
	}

	public static final Object[] getColumnIds(User user)
	{
		if (user.isEndcustomer() && !user.isDisponent() && !user.isSuperAdmin() && !user.isAdmin())
		{
			return OverviewConstants.ENDCUSTOMER_PROPERTY_IDS.clone();
		}
		else
		{
			return OverviewConstants.DEFAULT_PROPERTY_IDS.clone();
		}
	}
}
