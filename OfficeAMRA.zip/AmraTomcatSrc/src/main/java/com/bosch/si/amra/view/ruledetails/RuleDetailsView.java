
package com.bosch.si.amra.view.ruledetails;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.constants.UIConstants;
import com.bosch.si.amra.constants.overview.OverviewConstants;
import com.bosch.si.amra.constants.rule.RuleConstants;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.entity.geofence.Geofence;
import com.bosch.si.amra.entity.rule.Rule;
import com.bosch.si.amra.entity.rule.Rule.Severity;
import com.bosch.si.amra.event.DashboardEvent.BrowserResizeEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.im.login.Role;
import com.bosch.si.amra.im.login.Role.Roles;
import com.google.common.eventbus.Subscribe;
import com.vaadin.data.Container;
import com.vaadin.data.Property.ValueChangeEvent;
import com.vaadin.data.Property.ValueChangeListener;
import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.data.util.IndexedContainer;
import com.vaadin.data.validator.StringLengthValidator;
import com.vaadin.event.FieldEvents.TextChangeEvent;
import com.vaadin.event.FieldEvents.TextChangeListener;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Responsive;
import com.vaadin.server.VaadinSession;
import com.vaadin.shared.ui.slider.SliderOrientation;
import com.vaadin.ui.AbstractTextField.TextChangeEventMode;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;
import com.vaadin.ui.CheckBox;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.Component;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.MenuBar;
import com.vaadin.ui.MenuBar.Command;
import com.vaadin.ui.MenuBar.MenuItem;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Notification.Type;
import com.vaadin.ui.Panel;
import com.vaadin.ui.Slider;
import com.vaadin.ui.Table;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

@Role ({ Roles.SYSTEMADMIN })
@SuppressWarnings ("serial")
public class RuleDetailsView extends Panel
{

	private ComboBox				wagonSelect, type, condition, severity, geofenceSelect;

	private Button					clear;

	private Table					table;

	private static final String		ALIAS	= OverviewConstants.ALIAS;

	private final VerticalLayout	root;

	private CssLayout				dashboardPanels;

	private FormLayout				layout;

	private Label					limitLabel, maxRangeLabel, minRangeLabel;

	private String					unit;

	private Slider					limit, maxRange, minRange;

	private CheckBox				active;

	private BeanFieldGroup<Rule>	fieldGroup;

	private final Button			saveRule;

	private TextField				alarmName, email, limitField;

	private VerticalLayout			limitLayout, maxRangeLayout, minRangeLayout, activeLayout;

	private List<String>			conditionEntryGeofence, conditionEntrySensor,
			conditionEntryRange;

	private List<Wagon>				primaryAssignedWagonsToRule;

	private final User				user	= (User) VaadinSession.getCurrent()
			.getAttribute(User.class.getName());

	@Override
	public void detach()
	{
		super.detach();
		DashboardEventBus.unregister(this);
	}

	public RuleDetailsView(Rule rule, Button saveRule)
	{
		Rule ruleCopy = rule;
		primaryAssignedWagonsToRule = rule == null ? null : rule.getWagons();
		this.saveRule = saveRule;
		setSizeFull();
		addStyleName(ValoTheme.PANEL_BORDERLESS);
		DashboardEventBus.register(this);
		root = new VerticalLayout();
		root.setSizeFull();
		root.setMargin(true);
		root.addStyleName("dashboard-view");
		setContent(root);
		Responsive.makeResponsive(root);

		if (ruleCopy == null)
		{
			ruleCopy = new Rule();
			ruleCopy.setLimit(0);
			ruleCopy.setMinRange(0);
			ruleCopy.setMaxRange(0);
			ruleCopy.setEmail("");
		}

		if (ruleCopy.getLimit() == null)
		{
			ruleCopy.setLimit(0);
		}
		if (ruleCopy.getMinRange() == null)
		{
			ruleCopy.setMinRange(0);
		}
		if (ruleCopy.getMaxRange() == null)
		{
			ruleCopy.setMaxRange(0);
		}

		Component content = buildContent(ruleCopy);
		root.addComponent(content);
		root.setExpandRatio(content, 1);
		fieldGroup.setItemDataSource(ruleCopy);

	}

	private Component buildContent(Rule rule)
	{
		dashboardPanels = new CssLayout();

		dashboardPanels.addStyleName("dashboard-panels");
		dashboardPanels.setSizeFull();
		Responsive.makeResponsive(dashboardPanels);
		FormLayout wagonEditLayout = buildWagonEditLayout(rule);
		HorizontalLayout layout = new HorizontalLayout();
		layout.setSizeFull();
		layout.setSpacing(true);
		layout.addComponents(buildAlarmManagementForm(rule), wagonEditLayout);
		dashboardPanels.addComponent(createContentWrapper(layout, "view.alarm.help"));
		return dashboardPanels;
	}

	private Component buildAlarmManagementForm(Rule rule)
	{
		fieldGroup = new BeanFieldGroup<Rule>(Rule.class);
		fieldGroup.setBuffered(false);
		fieldGroup.setReadOnly(false);
		layout = new FormLayout();
		layout.addStyleName(ValoTheme.LAYOUT_CARD);
		layout.setSizeFull();
		layout.setSpacing(true);
		activeLayout = buildActive();
		limitField = new TextField();
		limitField.setCaption(
				DashboardUI.getMessageSource().getMessage("view.alarm.columnheader.limit"));
		limitField.setWidth("100%");
		alarmName = buildAlarmName();
		geofenceSelect = buildGeofenceSelect();
		type = buildType();
		limitLayout = buildLimit();
		maxRangeLayout = buildMaxRange();
		minRangeLayout = buildMinRange();
		conditionEntryGeofence = Arrays.asList(MongoConstants.IN, MongoConstants.OUT);
		conditionEntrySensor = Arrays.asList(MongoConstants.LESSER_THAN, MongoConstants.EQUAL,
				MongoConstants.NOT_EQUAL, MongoConstants.GREATER_THAN);
		conditionEntryRange = Arrays.asList(RuleConstants.OUT_RANGE);

		severity = buildSeverity();
		email = new TextField(
				DashboardUI.getMessageSource().getMessage("view.alarm.columnheader.email"));
		email.setWidth("100%");
		email.addValidator(new CustomizedEmailValidator(
				DashboardUI.getMessageSource().getMessage("view.rule.email.error")));
		email.setRequired(false);
		email.addValueChangeListener(new ValueChangeListener()
		{
			@Override
			public void valueChange(ValueChangeEvent event)
			{
				if (alarmName.isValid() && type.isValid() && condition.isValid()
						&& email.getValue() != null && email.isValid())
				{
					saveRule.setEnabled(true);
				}
				else
				{
					saveRule.setEnabled(false);
				}
			}
		});
		if (MongoConstants.GEOFENCE_TYPE.equals(rule.getRuleType()))
		{
			condition = buildCondition(conditionEntryGeofence);
			layout.addComponents(activeLayout, alarmName, type, limitLayout, condition, severity,
					email);
		}
		else if (RuleConstants.HUMIDITY_TEMPERATURE_RANGE.equals(rule.getRuleType()))
		{
			condition = buildCondition(conditionEntryRange);
			layout.addComponents(activeLayout, alarmName, type, minRangeLayout, maxRangeLayout,
					condition, severity, email);
		}
		else
		{
			condition = buildCondition(conditionEntrySensor);
			layout.addComponents(activeLayout, alarmName, type, limitLayout, condition, severity,
					email);
		}

		fieldGroup.bind(alarmName, "name");
		fieldGroup.bind(active, "active");
		if (MongoConstants.MILEAGE.equals(rule.getRuleType()))

		{
			fieldGroup.bind(limitField, "limit");
		}
		else if (RuleConstants.HUMIDITY_TEMPERATURE_RANGE.equals(rule.getRuleType()))
		{
			fieldGroup.bind(maxRange, "maxRange");
			fieldGroup.bind(minRange, "minRange");
		}
		else
		{
			fieldGroup.bind(limit, "limit");
		}
		fieldGroup.bind(type, "ruleType");
		fieldGroup.bind(condition, "condition");
		fieldGroup.bind(severity, "severity");
		fieldGroup.bind(geofenceSelect, "geofence");
		fieldGroup.bind(email, "email");

		return layout;

	}

	private void placeComponentsGeofence()
	{
		layout.removeAllComponents();
		layout.addComponents(activeLayout, alarmName, type, geofenceSelect, condition, severity,
				email);
		if (maxRange == fieldGroup.getField("maxRange"))
		{
			fieldGroup.unbind(maxRange);
		}
		if (minRange == fieldGroup.getField("minRange"))
		{
			fieldGroup.unbind(minRange);
		}
	}

	private void placeComponentsSensor()
	{
		layout.removeAllComponents();
		layout.addComponents(activeLayout, alarmName, type, limitLayout, condition, severity,
				email);

		if (limitField == fieldGroup.getField("limit"))
		{
			fieldGroup.unbind(limitField);
		}
		if (maxRange == fieldGroup.getField("maxRange"))
		{
			fieldGroup.unbind(maxRange);
		}
		if (minRange == fieldGroup.getField("minRange"))
		{
			fieldGroup.unbind(minRange);
		}
		fieldGroup.bind(limit, "limit");
	}

	private void placeComponentsMileage()
	{

		layout.removeAllComponents();
		layout.addComponents(activeLayout, alarmName, type, limitField, condition, severity, email);

		if (limit == fieldGroup.getField("limit"))
		{
			fieldGroup.unbind(limit);
		}
		if (maxRange == fieldGroup.getField("maxRange"))
		{
			fieldGroup.unbind(maxRange);
		}
		if (minRange == fieldGroup.getField("minRange"))
		{
			fieldGroup.unbind(minRange);
		}
		fieldGroup.bind(limitField, "limit");

	}

	private void placeComponentsRange()
	{
		layout.removeAllComponents();
		layout.addComponents(activeLayout, alarmName, type, minRangeLayout, maxRangeLayout,
				condition, severity, email);

		if (limitField == fieldGroup.getField("limit"))
		{
			fieldGroup.unbind(limitField);
		}
		if (limit == fieldGroup.getField("limit"))
		{
			fieldGroup.unbind(limit);
		}
		fieldGroup.bind(maxRange, "maxRange");
		fieldGroup.bind(minRange, "minRange");
	}

	private FormLayout buildWagonEditLayout(Rule rule)
	{
		FormLayout wagonEditLayout = new FormLayout();
		wagonEditLayout.addStyleName("edit");
		List<Wagon> rulewagons = primaryAssignedWagonsToRule;
		Table wagonTable = buildTable(rulewagons);
		wagonEditLayout.addComponents(buildWagonEditbar(), wagonTable);
		return wagonEditLayout;
	}

	private Table buildTable(List<Wagon> rulewagons)
	{
		table = new Table();
		BeanItemContainer<Wagon> wagonsContainer = new BeanItemContainer<Wagon>(Wagon.class);
		table.setContainerDataSource(wagonsContainer);
		table.addStyleName(ValoTheme.TABLE_BORDERLESS);
		table.addStyleName(ValoTheme.TABLE_NO_HORIZONTAL_LINES);
		table.addStyleName(ValoTheme.TABLE_COMPACT);
		table.setSortAscending(false);
		table.setSortAscending(true);
		table.setVisibleColumns(ALIAS);
		table.setSelectable(true);
		table.setMultiSelect(true);
		table.setWidth("99%");
		table.setColumnHeaders(
				DashboardUI.getMessageSource().getMessage("view.alarm.columnheader.alias"));

		table.addValueChangeListener(new ValueChangeListener()
		{
			@Override
			public void valueChange(ValueChangeEvent event)
			{
				@SuppressWarnings ("unchecked")
				Set<Wagon> wagons = (Set<Wagon>) table.getValue();
				if (wagons.size() > 0)
				{
					clear.setEnabled(true);
				}
			}
		});
		if (rulewagons != null)
		{
			table.addItems(rulewagons);
		}
		return table;
	}

	private Component buildWagonEditbar()
	{
		HorizontalLayout toolbar = new HorizontalLayout();
		toolbar.addStyleName("toolbar");
		toolbar.setSpacing(true);
		clear = new Button(DashboardUI.getMessageSource().getMessage("view.report.clear"));
		clear.setWidth("60px");
		clear.addStyleName(ValoTheme.BUTTON_ICON_ONLY);
		clear.setIcon(FontAwesome.MINUS);
		clear.setEnabled(false);
		clear.addClickListener(new ClickListener()
		{
			@Override
			public void buttonClick(ClickEvent event)
			{
				@SuppressWarnings ("unchecked")
				Set<Wagon> wagons = (Set<Wagon>) table.getValue();

				for (Wagon wagon : wagons)
				{
					table.removeItem(wagon);
					wagonSelect.addItem(wagon);
				}
				table.setCellStyleGenerator((tableToStyle, cellItem, cellProperty) -> {
					return "";
				});

				clear.setEnabled(false);
			}
		});
		final Button add = new Button(DashboardUI.getMessageSource().getMessage("view.report.add"));
		add.setEnabled(false);
		add.addStyleName(ValoTheme.BUTTON_PRIMARY);
		add.addStyleName(ValoTheme.BUTTON_ICON_ONLY);
		add.setIcon(FontAwesome.PLUS);
		add.addClickListener(new ClickListener()
		{
			@Override
			public void buttonClick(ClickEvent event)
			{
				addWagon();
			}
		});
		wagonSelect = new ComboBox();
		wagonSelect.setItemCaptionPropertyId("alias");
		initWagonSelect();
		wagonSelect.addValueChangeListener(new ValueChangeListener()
		{
			@Override
			public void valueChange(ValueChangeEvent event)
			{
				add.setEnabled(event.getProperty().getValue() != null);
			}
		});
		wagonSelect.setWidth("100%");
		toolbar.addComponents(wagonSelect, add, clear);
		toolbar.setExpandRatio(wagonSelect, 1.0f);
		toolbar.setWidth("99%");
		return toolbar;
	}

	private void initWagonSelect()
	{
		Collection<Wagon> wagons = DashboardUI.getDataProvider().getWagonsShort(user);
		wagons.forEach(wagon -> wagon.setInitial(true));
		if (primaryAssignedWagonsToRule != null)
			wagons.removeAll(primaryAssignedWagonsToRule);
		Container wagonContainer = new BeanItemContainer<>(Wagon.class, wagons);
		wagonSelect.setContainerDataSource(wagonContainer);
	}

	private TextField buildAlarmName()
	{
		alarmName = new TextField(
				DashboardUI.getMessageSource().getMessage("view.alarm.columnheader.name"));
		alarmName.setImmediate(true);
		alarmName.setNullRepresentation("");
		alarmName.setRequired(true);
		alarmName.setRequiredError(
				DashboardUI.getMessageSource().getMessage("view.alarm.required.error"));
		alarmName.addValidator(new StringLengthValidator(
				DashboardUI.getMessageSource().getMessage("view.details.panel.validator.error"), 0,
				400, true));
		alarmName.setTextChangeEventMode(TextChangeEventMode.EAGER);
		alarmName.addTextChangeListener(new TextChangeListener()
		{
			@Override
			public void textChange(final TextChangeEvent event)
			{
				if (event.getText() == null || event.getText().isEmpty())
				{
					saveRule.setEnabled(false);
				}
				else
				{
					if (!email.getValue().isEmpty())
						if (type.isValid() && condition.isValid() && severity.isValid()
								&& email.getValue() != null && !email.getValue().isEmpty()
								&& email.isValid())
							saveRule.setEnabled(true);
						else if (alarmName.isValid() && type.isValid() && condition.isValid()
								&& severity.isValid())
						{
							saveRule.setEnabled(true);
						}

				}
			}
		});
		alarmName.setWidth("100%");
		return alarmName;
	}

	private VerticalLayout buildActive()
	{
		VerticalLayout activeLayout = new VerticalLayout();
		active = new CheckBox();
		activeLayout.addComponents(active);
		activeLayout.setCaption(
				DashboardUI.getMessageSource().getMessage("view.alarm.columnheader.active"));
		return activeLayout;
	}

	private ComboBox buildType()
	{
		List<String> typeEntry = Arrays.asList(MongoConstants.HUMIDITY,
				MongoConstants.HUMIDITY_TEMPERATURE, MongoConstants.DEVICE_TEMPERATURE,
				MongoConstants.MILEAGE, MongoConstants.GEOFENCE_TYPE,
				RuleConstants.HUMIDITY_TEMPERATURE_RANGE);
		IndexedContainer containerType = new IndexedContainer();
		containerType.addContainerProperty("name", String.class, "");
		for (String value : typeEntry)
		{
			containerType.addItem(value);
		}
		type = new ComboBox(
				DashboardUI.getMessageSource().getMessage("view.alarm.columnheader.ruletype"));
		type.setRequired(true);
		type.setImmediate(true);
		type.setNullSelectionAllowed(false);
		type.setContainerDataSource(containerType);
		for (String typeModel : typeEntry)
		{
			type.setItemCaption(typeModel, (DashboardUI.getMessageSource()
					.getMessage("view.alarm.selecttype." + typeModel.toLowerCase())));
		}
		type.setWidth("100%");

		type.addValueChangeListener(event -> {
			if (event.getProperty().getValue().toString() != null)
			{
				unit = "";
				switch (event.getProperty().getValue().toString())
				{
					case MongoConstants.HUMIDITY:
						changeConditionForSensors(
								DashboardUI.getMessageSource()
										.getMessage("view.alarm.unit.percent"),
								UIConstants.LOWERLIMIT_HUMIDITY, UIConstants.UPPERLIMIT_HUMIDITY);
						break;
					case MongoConstants.HUMIDITY_TEMPERATURE:
						changeConditionForSensors(
								DashboardUI.getMessageSource()
										.getMessage("view.alarm.unit.celsius"),
								UIConstants.LOWERLIMIT_HUMIDITYTEMPERATURE,
								UIConstants.UPPERLIMIT_HUMIDITYTEMPERATURE);
						break;
					case MongoConstants.DEVICE_TEMPERATURE:
						changeConditionForSensors(DashboardUI.getMessageSource()
								.getMessage("view.alarm.unit.celsius"), 0, 100);
						break;
					case MongoConstants.MILEAGE:
						unit = DashboardUI.getMessageSource().getMessage("view.alarm.unit.km");
						reloadCondition(conditionEntrySensor);
						setLimitMinForMileage();
						placeComponentsMileage();
						break;
					case MongoConstants.GEOFENCE_TYPE:
						reloadCondition(conditionEntryGeofence);
						placeComponentsGeofence();
						break;
					case RuleConstants.HUMIDITY_TEMPERATURE_RANGE:
						changeConditionForRangeSensors(
								DashboardUI.getMessageSource()
										.getMessage("view.alarm.unit.celsius"),
								UIConstants.LOWERLIMIT_HUMIDITYTEMPERATURE,
								UIConstants.UPPERLIMIT_HUMIDITYTEMPERATURE);
						break;

					default:
						changeConditionForSensors(DashboardUI.getMessageSource()
								.getMessage("view.alarm.unit.celsius"), 0, 100);
						break;
				}
				if (unit != null & limit != null & limitLabel != null & limit.getValue() != null)
				{
					setLimitBetweenBounds();
					limitLabel.setValue(limit.getValue().intValue() + " " + unit);
				}
				if (unit != null & maxRangeLabel != null & minRangeLabel != null
						& maxRange.getValue() != null && minRange.getValue() != null)
				{
					setRangeBetweenBounds();
					maxRangeLabel.setValue(maxRange.getValue().intValue() + " " + unit);
					minRangeLabel.setValue(minRange.getValue().intValue() + " " + unit);
				}
				if (email.getValue().isEmpty())
				{
					if (alarmName.isValid() && type.isValid() && condition.isValid()
							&& severity.isValid())
						saveRule.setEnabled(true);
				}
				else if (alarmName.isValid() && condition.isValid() && severity.isValid()
						&& email.getValue() != null && !email.getValue().isEmpty()
						&& email.isValid())
				{
					saveRule.setEnabled(true);
				}
				else
				{
					saveRule.setEnabled(false);
				}
			}
		});
		return type;

	}

	private void changeConditionForRangeSensors(String unitText, int lowerLimit, int upperLimit)
	{
		unit = unitText;
		maxRange.setMax(upperLimit);
		maxRange.setMin(lowerLimit);
		minRange.setMax(upperLimit);
		minRange.setMin(lowerLimit);
		reloadCondition(conditionEntryRange);
		condition.select(RuleConstants.OUT_RANGE);
		setRangeBetweenBounds();
		placeComponentsRange();
	}

	private void changeConditionForSensors(String unitText, int lowerLimit, int upperLimit)
	{
		unit = unitText;
		limit.setMin(lowerLimit);
		limit.setMax(upperLimit);
		reloadCondition(conditionEntrySensor);
		setLimitBetweenBounds();
		placeComponentsSensor();
	}

	private VerticalLayout buildLimit()
	{
		VerticalLayout limitLayout = new VerticalLayout();
		limitLayout.setSizeFull();
		limitLayout.setCaption(
				DashboardUI.getMessageSource().getMessage("view.alarm.columnheader.limit"));
		limitLayout.setSpacing(true);
		limit = new Slider();
		limit.setWidth("99%");
		limit.setOrientation(SliderOrientation.HORIZONTAL);
		limit.setConverter(new DoubleToIntegerConverter());
		limit.addValueChangeListener(new ValueChangeListener()
		{
			@Override
			public void valueChange(ValueChangeEvent event)
			{

				if (unit != null)
				{
					limitLabel.setValue(
							((Double) event.getProperty().getValue()).intValue() + " " + unit);
				}

			}
		});
		HorizontalLayout labelLayout = new HorizontalLayout();
		labelLayout.setSpacing(true);
		labelLayout.setMargin(false);
		labelLayout.setWidth("100%");
		limitLabel = new Label();
		labelLayout.addComponents(limitLabel);
		limitLayout.addComponents(limit, labelLayout);
		return limitLayout;
	}

	private VerticalLayout buildMaxRange()
	{
		VerticalLayout rangeLayout = new VerticalLayout();
		rangeLayout.setSizeFull();
		rangeLayout.setCaption(
				DashboardUI.getMessageSource().getMessage("view.alarm.columnheader.maxrange"));
		rangeLayout.setSpacing(true);
		maxRange = new Slider();
		maxRange.setWidth("99%");
		maxRange.setOrientation(SliderOrientation.HORIZONTAL);
		maxRange.setConverter(new DoubleToIntegerConverter());
		maxRange.addValueChangeListener(event -> {

			if (unit != null && event.getProperty().getValue() != null)
			{
				maxRangeLabel.setValue(
						((Double) event.getProperty().getValue()).intValue() + " " + unit);
			}

		});

		HorizontalLayout maxLabelLayout = new HorizontalLayout();
		maxLabelLayout.setSpacing(true);
		maxLabelLayout.setMargin(false);
		maxLabelLayout.setWidth("100%");
		maxRangeLabel = new Label();
		maxLabelLayout.addComponents(maxRangeLabel);
		rangeLayout.addComponents(maxRange, maxLabelLayout);
		return rangeLayout;

	}

	private VerticalLayout buildMinRange()
	{
		VerticalLayout rangeLayout = new VerticalLayout();
		rangeLayout.setSizeFull();
		rangeLayout.setCaption(
				DashboardUI.getMessageSource().getMessage("view.alarm.columnheader.minrange"));
		rangeLayout.setSpacing(true);
		minRange = new Slider();
		minRange.setWidth("99%");
		minRange.setOrientation(SliderOrientation.HORIZONTAL);
		minRange.setConverter(new DoubleToIntegerConverter());
		minRange.addValueChangeListener(event -> {

			if (unit != null && event.getProperty().getValue() != null)
			{
				minRangeLabel.setValue(
						((Double) event.getProperty().getValue()).intValue() + " " + unit);
			}

		});
		minRangeLabel = new Label();

		HorizontalLayout minLabelLayout = new HorizontalLayout();
		minLabelLayout.setSpacing(true);
		minLabelLayout.setMargin(false);
		minLabelLayout.setWidth("100%");
		minLabelLayout.addComponents(minRangeLabel);
		rangeLayout.addComponents(minRange, minLabelLayout);
		return rangeLayout;

	}

	private ComboBox buildGeofenceSelect()
	{
		geofenceSelect = new ComboBox();

		geofenceSelect = new ComboBox(
				DashboardUI.getMessageSource().getMessage("view.geofence.combobox.caption"));
		geofenceSelect.setItemCaptionPropertyId("name");
		geofenceSelect.setNullSelectionAllowed(false);
		geofenceSelect.setRequired(true);
		geofenceSelect.setRequiredError(DashboardUI.getMessageSource()
				.getMessage("view.alarm.selecttype.geofence.required.error"));
		List<Geofence> geofenceNames = DashboardUI.getGeofenceDataProvider()
				.getGeofencesForDisplaying(user.getTenant());
		Container container = new BeanItemContainer<>(Geofence.class, geofenceNames);
		geofenceSelect.setContainerDataSource(container);
		geofenceSelect.setImmediate(true);
		geofenceSelect.setWidth("100%");

		return geofenceSelect;
	}

	private ComboBox buildCondition(List<String> entry)
	{

		IndexedContainer containerCondition = new IndexedContainer(entry);
		containerCondition.addContainerProperty("name", String.class, "");

		ComboBox conditionBox = new ComboBox(
				DashboardUI.getMessageSource().getMessage("view.alarm.columnheader.condition"));
		conditionBox.setRequired(true);
		conditionBox.setImmediate(true);
		conditionBox.setNullSelectionAllowed(false);
		conditionBox.setContainerDataSource(containerCondition);
		for (String conditionModel : entry)
		{
			conditionBox.setItemCaption(conditionModel, (DashboardUI.getMessageSource()
					.getMessage("view.alarm.selectcondition." + conditionModel)));
		}
		conditionBox.setWidth("100%");
		conditionBox.addValueChangeListener(new ValueChangeListener()
		{
			@Override
			public void valueChange(ValueChangeEvent event)
			{
				if (event.getProperty().toString() != null)
				{
					if (email.getValue().isEmpty())
					{
						if (alarmName.isValid() && type.isValid() && condition.isValid()
								&& severity.isValid())
							saveRule.setEnabled(true);
					}
					else if (alarmName.isValid() && type.isValid() && severity.isValid()
							&& email.getValue() != null && !email.getValue().isEmpty()
							&& email.isValid())
					{
						saveRule.setEnabled(true);
					}
					else
					{
						saveRule.setEnabled(false);
					}
				}
			}
		});
		return conditionBox;
	}

	private void reloadCondition(List<String> entry)
	{

		IndexedContainer containerCondition = new IndexedContainer(entry);
		containerCondition.addContainerProperty("name", String.class, "");

		condition.setContainerDataSource(containerCondition);
		for (String conditionModel : entry)
		{
			condition.setItemCaption(conditionModel, (DashboardUI.getMessageSource()
					.getMessage("view.alarm.selectcondition." + conditionModel)));
		}

	}

	@SuppressWarnings ("rawtypes")
	private ComboBox buildSeverity()
	{
		List<Enum> severityEntry = new ArrayList<Enum>();
		severityEntry.add(Severity.RED);
		severityEntry.add(Severity.YELLOW);
		severityEntry.add(Severity.GREEN);
		IndexedContainer containerSeverity = new IndexedContainer();
		containerSeverity.addContainerProperty("name", Enum.class, "");
		for (Enum value : severityEntry)
		{
			containerSeverity.addItem(value);
		}

		severity = new ComboBox(
				DashboardUI.getMessageSource().getMessage("view.alarm.columnheader.severity"));
		severity.setRequired(true);
		severity.setImmediate(true);
		severity.setNullSelectionAllowed(false);
		severity.setContainerDataSource(containerSeverity);
		for (Enum severityModel : severityEntry)
		{
			severity.setItemCaption(severityModel, (DashboardUI.getMessageSource().getMessage(
					"view.alarm.selectseverity." + severityModel.toString().toLowerCase())));
		}
		severity.setWidth("100%");

		severity.addValueChangeListener(new ValueChangeListener()
		{
			@Override
			public void valueChange(ValueChangeEvent event)
			{
				if (event.getProperty().toString() != null)
				{
					if (email.getValue().isEmpty())
					{
						if (alarmName.isValid() && type.isValid() && condition.isValid()
								&& severity.isValid())
							saveRule.setEnabled(true);
					}
					else if (alarmName.isValid() && type.isValid() && condition.isValid()
							&& email.getValue() != null && !email.getValue().isEmpty()
							&& email.isValid())
					{
						saveRule.setEnabled(true);
					}
					else
					{
						saveRule.setEnabled(false);
					}
				}
			}
		});
		return severity;
	}

	private Component createContentWrapper(Component content, final String code)
	{
		final CssLayout slot = new CssLayout();
		slot.setWidth("100%");
		slot.setHeight("100%");

		CssLayout card = new CssLayout();
		card.setWidth("100%");
		card.setHeight("100%");
		card.addStyleName(ValoTheme.LAYOUT_CARD);

		HorizontalLayout toolbar = new HorizontalLayout();
		toolbar.addStyleName("dashboard-panel-toolbar");
		toolbar.setWidth("100%");

		Label caption = new Label(content.getCaption());
		caption.addStyleName(ValoTheme.LABEL_H4);
		caption.addStyleName(ValoTheme.LABEL_COLORED);
		caption.addStyleName(ValoTheme.LABEL_NO_MARGIN);
		content.setCaption(null);

		MenuBar tools = new MenuBar();
		tools.addStyleName(ValoTheme.MENUBAR_BORDERLESS);
		MenuItem help = tools.addItem("", FontAwesome.QUESTION_CIRCLE, new Command()
		{
			@Override
			public void menuSelected(MenuItem selectedItem)
			{
				Notification.show(DashboardUI.getMessageSource().getMessage("slot.help"),
						DashboardUI.getMessageSource().getMessage(code), Type.HUMANIZED_MESSAGE);
			}
		});
		help.setStyleName("icon-only");

		toolbar.addComponents(caption, tools);
		toolbar.setExpandRatio(caption, 1);
		toolbar.setComponentAlignment(caption, Alignment.MIDDLE_LEFT);

		card.addComponents(toolbar, content);
		slot.addComponent(card);
		return slot;
	}

	@Subscribe
	public void browserResized(BrowserResizeEvent event)
	{
	}

	private void addWagon()
	{
		if (wagonSelect.getValue() != null)
		{
			table.addItem(wagonSelect.getValue());
			wagonSelect.removeItem(wagonSelect.getValue());
		}
	}

	public Rule getRule()
	{
		Rule rule = fieldGroup.getItemDataSource().getBean();
		@SuppressWarnings ("unchecked")
		BeanItemContainer<Wagon> wagonContainer = (BeanItemContainer<Wagon>) table
				.getContainerDataSource();
		List<Wagon> wagons = wagonContainer.getItemIds();
		rule.setWagons(wagons);
		if (rule.getRuleType() == MongoConstants.GEOFENCE_TYPE)
		{
			rule.setGeofence((Geofence) geofenceSelect.getValue());
		}

		return rule;
	}

	public List<Wagon> getPrimaryAssignedWagonsToRule()
	{
		return primaryAssignedWagonsToRule;
	}

	public Table getWagonTable()
	{
		return table;
	}

	private void setRangeBetweenBounds()
	{
		if (maxRange.getMax() < maxRange.getValue())
		{
			maxRange.setValue(maxRange.getMax());
		}
		if (maxRange.getMin() > maxRange.getValue())
		{
			maxRange.setValue(maxRange.getMin());
		}
		if (minRange.getMax() < minRange.getValue())
		{
			minRange.setValue(minRange.getMax());
		}
		if (minRange.getMin() > minRange.getValue())
		{
			minRange.setValue(minRange.getMin());
		}
	}

	private void setLimitBetweenBounds()
	{
		if (limit.getMax() < limit.getValue())
		{
			limit.setValue(limit.getMax());

		}
		if (limit.getMin() > limit.getValue())
		{
			limit.setValue(limit.getMin());

		}
	}

	private void setLimitMinForMileage()
	{

		if (0 > limit.getValue())
		{
			limit.setValue(0.0);
		}

	}

	public Slider getMaxRange()
	{
		return maxRange;
	}

	public Slider getMinRange()
	{
		return minRange;
	}

}
