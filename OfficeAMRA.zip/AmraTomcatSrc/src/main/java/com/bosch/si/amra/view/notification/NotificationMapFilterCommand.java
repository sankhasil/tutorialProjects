
package com.bosch.si.amra.view.notification;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.bosch.si.amra.constants.notification.NotificationConstants;
import com.vaadin.data.Container.Filter;
import com.vaadin.data.Container.Filterable;
import com.vaadin.data.util.filter.Or;
import com.vaadin.ui.Grid;
import com.vaadin.ui.MenuBar.Command;
import com.vaadin.ui.MenuBar.MenuItem;

public class NotificationMapFilterCommand implements Command
{
	/**
	 * Serial version uid
	 */
	private static final long			serialVersionUID	= -6767173859577731543L;

	private final Map<MenuItem, String>	menuItems;

	private final Grid					notificationGrid;

	private final NotificationView		view;

	public NotificationMapFilterCommand(Map<MenuItem, String> menuItems, Grid notificationsGrid,
			NotificationView view)
	{
		this.menuItems = menuItems;
		this.notificationGrid = notificationsGrid;
		this.view = view;
	}

	@Override
	public void menuSelected(MenuItem selectedItem)
	{
		List<Filter> filters = new ArrayList<>();
		Filter[] filterArray = new Filter[] {};
		Filterable data = (Filterable) notificationGrid.getContainerDataSource();
		data.removeContainerFilter(NotificationConstants.orFilter);
		for (MenuItem menuItem : menuItems.keySet())
		{
			if (menuItem.isChecked())
			{
				String key = menuItems.get(menuItem);
				filters.add(NotificationConstants.RULTE_TYPE_FILTER.get(key));
			}
		}
		Filter[] array = filters.toArray(filterArray);
		NotificationConstants.orFilter = new Or(array);
		data.addContainerFilter(NotificationConstants.orFilter);

		view.fillMap();
	}
}