
package com.bosch.si.amra.presenter.administration;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.constants.configuration.ConfigurationDefaultValueConstants;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.entity.WagonType;
import com.bosch.si.amra.entity.configuration.Configuration;
import com.bosch.si.amra.event.DashboardEvent.ClearValueEvent;
import com.bosch.si.amra.event.DashboardEvent.ConfigurationsSaveAliasEvent;
import com.bosch.si.amra.event.DashboardEvent.ConfigurationsSaveEvent;
import com.bosch.si.amra.event.DashboardEvent.CouplingEvent;
import com.bosch.si.amra.event.DashboardEvent.DecouplingEvent;
import com.bosch.si.amra.event.DashboardEvent.NotSuccessfulEvent;
import com.bosch.si.amra.event.DashboardEvent.NotificationsSaveAliasEvent;
import com.bosch.si.amra.event.DashboardEvent.RulesSaveAliasEvent;
import com.bosch.si.amra.event.DashboardEvent.UpdateMeansOfTransportEvent;
import com.bosch.si.amra.event.DashboardEvent.WagonTypeDeleteEvent;
import com.bosch.si.amra.event.DashboardEvent.WagonTypeEvent;
import com.bosch.si.amra.event.DashboardEvent.WagonTypeStatusEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.provider.DataProviderInitializer;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.DuplicateKeyException;
import com.mongodb.MongoClient;

/**
 * Presenter responsible for the administration view
 *
 * @author toa1wa3
 *
 */
@Component
public class AdministrationPresenterImpl implements AdministrationPresenter, Serializable
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= 6196424387271176510L;

	private static final Logger	logger				= LoggerFactory
			.getLogger(AdministrationPresenterImpl.class);

	@Override
	public void saveWagon(UpdateMeansOfTransportEvent event)
	{
		String tenantId = event.getTenantId();
		Wagon wagon = event.getWagon();
		if (wagon == null)
			throw new IllegalArgumentException("Wagon must not be null");
		if (tenantId == null || tenantId.isEmpty())
			throw new IllegalArgumentException("Tenant must not be null");

		DBObject wagonObject = Wagon.wagon2DBObject(wagon);
		String wagonId = (String) wagonObject.get(MongoConstants.ID);

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		try
		{
			if (wagon.getId() != null)
			{
				updateAliasInWagon(wagonId, wagon.getAlias());
				updateWagonTypeInWagon(wagonId, wagon.getWagonType().getTypeName());
				updateWagonOfsset(wagonId, wagon.getMileageOffset(),
						getCollection(DashboardUI.getWagonCollection()));
				updateWagonOfsset(wagonId, wagon.getMileageOffset(),
						getCollection(DashboardUI.getMongoCurrentCollection()));
				/*
				 * This is an exceptional case for creating the notification ,as per our current
				 * implementation the notification is created if the rule is not Alive and the rule
				 * is broken.But in here the user need to create the notification as soon as he
				 * added new offset value and the mileage rule is broken.Hence for this to happen
				 * its require to set the nested key Alive of rule key to false.
				 */
				if (wagon.getMileageOffset() != null
						&& wagon.getMileageOffset() != wagon.getOldMileageOffset())
					UpdateNotificationCollectionActiveKey(tenantId, wagonId);

			}
			else
			{
				wagonCollection.save(wagonObject);

				createCurrentObject(wagonObject, wagon.getId());

			}
			saveDefaultConfigurationForWagon(tenantId, wagonId, wagon.getAlias());
			updateNotificationForWagon(wagonId, wagon.getAlias());
			updateAliasInCurrent(wagonId, wagon.getAlias());
			updateAliasInCorrelated(wagonId, wagon.getAlias());
			updateAliasInRoutingInformation(wagonId, wagon.getAlias());
			updateAliasInTelematic(wagonId, wagon.getAlias());
			updateWagonTypeInCurrent(wagonId, wagon.getWagonType().getTypeName());
			updateWagonTypeInTelematic(wagonId, wagon.getWagonType().getTypeName());
			updateAliasInRule(wagonId, wagon.getAlias());
			updateAliasInMileage(wagonId, wagon.getAlias());
			DashboardEventBus.post(new ClearValueEvent());
			logger.debug("Wagon saved");
		}
		catch (DuplicateKeyException e)
		{
			DashboardEventBus.post(new NotSuccessfulEvent("view.administration.not.unique"));
			logger.debug("Wagon {} already exists for the tenant {}", wagon.getAlias(), tenantId);
			logger.error(e.getMessage());
		}

	}

	/**
	 * If the wagon id is null then create a new current document. The null check must be performed
	 * on the Java Wagon object, because this object is passed from the view and if it is newly
	 * created it does not contain an id. The mongo object contains already an id at this moment so
	 * checking the mongo object for null is useless
	 *
	 * @param wagonObject
	 * @param wagon
	 */
	private void createCurrentObject(DBObject wagonObject, String wagonId)
	{
		if (wagonId == null)
		{
			DBCollection currentCollection = getCollection(DashboardUI.getMongoCurrentCollection());

			DBObject currentObject = new BasicDBObject();
			currentObject.put(MongoConstants.ID, wagonObject.get(MongoConstants.ID));
			currentObject.put(MongoConstants.TENANT_ID, wagonObject.get(MongoConstants.TENANT_ID));
			currentObject.put(MongoConstants.DATA_ELEMENT, new BasicDBObject());
			currentObject.put(MongoConstants.ALIAS, wagonObject.get(MongoConstants.ALIAS));
			currentObject.put(MongoConstants.SORT,
					((String) wagonObject.get(MongoConstants.SORT)).toLowerCase());
			currentObject.put(MongoConstants.ADDRESS, new BasicDBObject());
			DBObject wagonTypeObject = (DBObject) wagonObject.get(MongoConstants.WAGON_TYPE);
			wagonTypeObject.removeField(MongoConstants.ID);
			currentObject.put(MongoConstants.WAGON_TYPE, wagonTypeObject);
			currentObject.put(MongoConstants.OFFSET, wagonObject.get(MongoConstants.OFFSET));

			currentCollection.insert(currentObject);
		}
	}

	private void saveDefaultConfigurationForWagon(String tenantId, String wagonId, String alias)
	{
		String configurationId = getConfigurationId(wagonId);
		if (configurationId != null)
		{
			DashboardEventBus.post(new ConfigurationsSaveAliasEvent(alias, configurationId));
		}
		else
		{
			String uuid = UUID.randomUUID().toString();
			Configuration config = new Configuration(uuid, alias,
					ConfigurationDefaultValueConstants.FLASH_DATA_DEFAULT_VALUE,
					ConfigurationDefaultValueConstants.STATUS_DEFAULT_VALUE,
					ConfigurationDefaultValueConstants.HUMIDITY_DEFAULT_VALUE,
					ConfigurationDefaultValueConstants.HUMIDITY_TEMPERATURE_DEFAULT_VALUE,
					ConfigurationDefaultValueConstants.TEMPERATURE_DEFAULT_VALUE,
					ConfigurationDefaultValueConstants.DEVICE_TEMPERATURE_DEFAULT_VALUE,
					ConfigurationDefaultValueConstants.SHOCK_X_DEFAULT_VALUE,
					ConfigurationDefaultValueConstants.SHOCK_Y_DEFAULT_VALUE,
					ConfigurationDefaultValueConstants.SHOCK_Z_DEFAULT_VALUE,
					ConfigurationDefaultValueConstants.ROUTING_DEFAULT_VALUE,
					ConfigurationDefaultValueConstants.GPS_MOVING_DEFAULT_VALUE,
					ConfigurationDefaultValueConstants.GPS_TIME_BASED_DEFAULT_VALUE,
					ConfigurationDefaultValueConstants.GSM_MOVING_DEFAULT_VALUE,
					ConfigurationDefaultValueConstants.GSM_TIME_BASED_DEFAULT_VALUE,
					ConfigurationDefaultValueConstants.BUMP_DETECTION_DEFAULT_VALUE,
					ConfigurationDefaultValueConstants.AQUITION_FREQUENCY_DEFAULT_VALUE, wagonId,
					tenantId, null);

			List<Configuration> configurations = new ArrayList<Configuration>();
			configurations.add(config);
			DashboardEventBus.post(new ConfigurationsSaveEvent(configurations, tenantId));
		}
	}

	private void updateNotificationForWagon(String wagonId, String alias)
	{
		DashboardEventBus.post(new NotificationsSaveAliasEvent(alias, wagonId));
	}

	private String getConfigurationId(String wagonId)
	{
		DBCollection collection = getCollection(DashboardUI.getConfigurationCollection());
		DBObject findOneConfiguration = collection.findOne(
				new BasicDBObject(MongoConstants.WAGON_ID, wagonId),
				new BasicDBObject(MongoConstants.ID, 1));
		return findOneConfiguration != null ? (String) findOneConfiguration.get(MongoConstants.ID)
				: null;
	}

	private void updateAliasInCurrent(String wagonId, String alias)
	{
		DBCollection currentCollection = getCollection(DashboardUI.getMongoCurrentCollection());

		updateAliasInCollection(currentCollection, wagonId, alias, MongoConstants.ID, false);
	}

	private void updateAliasInWagon(String wagonId, String alias)
	{
		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());

		updateAliasInCollection(wagonCollection, wagonId, alias, MongoConstants.ID, false);
	}

	private void updateAliasInCorrelated(String wagonId, String alias)
	{
		DBCollection correlatedCollection = getCollection(DashboardUI.getMongoCollection());

		updateAliasInCollection(correlatedCollection, wagonId, alias, MongoConstants.WAGON_ID,
				true);
	}

	private void updateAliasInRoutingInformation(String wagonId, String alias)
	{
		DBCollection routingInformationCollection = getCollection(
				DashboardUI.getMongoRoutingCollection());

		updateAliasInCollection(routingInformationCollection, wagonId, alias,
				MongoConstants.WAGON_ID, true);
	}

	private void updateAliasInTelematic(String wagonId, String alias)
	{
		DBCollection telematicCollection = getCollection(DashboardUI.getEventCollection());

		updateAliasInCollection(telematicCollection, wagonId, alias, MongoConstants.WAGON_ID, true);
	}

	private void updateAliasInRule(String wagonId, String alias)
	{
		DashboardEventBus.post(new RulesSaveAliasEvent(alias, wagonId));
	}

	private void updateAliasInMileage(String wagonId, String alias)
	{
		DBCollection mileage = getCollection(DashboardUI.getMongoMileageCollection());

		updateAliasInCollection(mileage, wagonId, alias, MongoConstants.WAGON_ID, true);
	}

	private void updateAliasInCollection(DBCollection collection, String wagonId, String alias,
			String mongoId, boolean multi)
	{
		DBObject update = new BasicDBObject(MongoConstants.ALIAS, alias);
		update.put(MongoConstants.SORT, alias.toLowerCase());
		DBObject set = new BasicDBObject("$set", update);

		DBObject match = new BasicDBObject(mongoId, wagonId);
		collection.update(match, set, false, multi);
	}

	private void updateWagonTypeInCurrent(String wagonId, String typeName)
	{
		DBCollection currentCollection = getCollection(DashboardUI.getMongoCurrentCollection());

		updateWagonTypeInCollection(currentCollection, wagonId, typeName, MongoConstants.ID, false);
	}

	private void updateWagonTypeInWagon(String wagonId, String typeName)
	{
		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());

		updateWagonTypeInCollection(wagonCollection, wagonId, typeName, MongoConstants.ID, false);
	}

	private void updateWagonTypeInTelematic(String wagonId, String typeName)
	{
		DBCollection telematicCollection = getCollection(DashboardUI.getEventCollection());

		updateWagonTypeInCollection(telematicCollection, wagonId, typeName, MongoConstants.WAGON_ID,
				true);
	}

	private void updateWagonTypeInCollection(DBCollection collection, String wagonId,
			String typeName, String mongoId, boolean multi)
	{
		DBObject update = new BasicDBObject(
				MongoConstants.WAGON_TYPE + "." + MongoConstants.WAGON_TYPE_NAME, typeName);
		update.put(MongoConstants.WAGON_TYPE + "." + MongoConstants.SORT, typeName.toLowerCase());
		DBObject set = new BasicDBObject("$set", update);

		DBObject match = new BasicDBObject(mongoId, wagonId);
		collection.update(match, set, false, multi);
	}

	private void updateWagonOfsset(String wagonId, Integer offset, DBCollection collection)
	{
		DBObject update = new BasicDBObject(MongoConstants.OFFSET, offset);
		DBObject set = new BasicDBObject("$set", update);
		DBObject match = new BasicDBObject(MongoConstants.ID, wagonId);
		collection.update(match, set, false, false);

	}

	private void UpdateNotificationCollectionActiveKey(String tenantId, String wagonId)
	{
		DBCollection collection = getCollection(DashboardUI.getNotificationCollection());
		DBObject match = new BasicDBObject(MongoConstants.TENANT_ID, tenantId);
		match.put(MongoConstants.WAGON_ID, wagonId);
		match.put(MongoConstants.RULE + "." + MongoConstants.ALARM_RULE_TYPE,
				MongoConstants.MILEAGE);
		match.put(MongoConstants.RULE + "." + MongoConstants.ALARM_ALIVE, true);
		DBObject update = new BasicDBObject(MongoConstants.RULE + "." + MongoConstants.ALARM_ALIVE,
				false);
		DBObject set = new BasicDBObject("$set", update);
		collection.update(match, set, false, true);

	}

	@Override
	public void coupleWagonWithBox(CouplingEvent event)
	{
		Wagon wagon = event.getWagon();
		if (wagon == null)
			throw new IllegalArgumentException("Wagon must not be null");

		String wagonId = wagon.getId();
		String configurationId = getConfigurationId(wagonId);

		try
		{
			updateWagon(wagon, wagonId);
			updateCurrent(wagon, wagonId);
			updateConfiguration(wagon, configurationId);
			DashboardEventBus.post(new ClearValueEvent());
			logger.debug("Wagon coupled");
		}
		catch (DuplicateKeyException e)
		{
			DashboardEventBus.post(new NotSuccessfulEvent("view.administration.coupling.error"));
			logger.debug("Wagon {} is already coupled with boxId {}", wagon.getAlias(),
					wagon.getBoxId());
			logger.error(e.getMessage());
		}
	}

	private void updateWagon(Wagon wagon, String wagonId)
	{
		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject update = new BasicDBObject(MongoConstants.BOX_ID, wagon.getBoxId());
		DBObject set = new BasicDBObject("$set", update);

		DBObject match = new BasicDBObject(MongoConstants.ID, wagonId);
		wagonCollection.update(match, set, false, false);
	}

	private void updateCurrent(Wagon wagon, String wagonId)
	{
		DBCollection wagonCollection = getCollection(DashboardUI.getMongoCurrentCollection());
		DBObject update = new BasicDBObject();
		if (wagon.getBoxId() != null)
		{
			update.put("$set", new BasicDBObject(MongoConstants.BOX_ID, wagon.getBoxId()));
		}
		else
		{
			update.put("$unset", new BasicDBObject(MongoConstants.BOX_ID, 1));
		}
		DBObject match = new BasicDBObject(MongoConstants.ID, wagonId);
		wagonCollection.update(match, update, false, false);
	}

	private void updateConfiguration(Wagon wagon, String configurationId)
	{
		DBCollection configurationCollection = getCollection(
				DashboardUI.getConfigurationCollection());
		if (configurationId != null)
		{
			DBObject update = new BasicDBObject();
			if (wagon.getBoxId() != null)
			{
				update.put("$set", new BasicDBObject(MongoConstants.BOX_ID, wagon.getBoxId()));
			}
			else
			{
				update.put("$unset", new BasicDBObject(MongoConstants.BOX_ID, 1));
			}
			DBObject match = new BasicDBObject(MongoConstants.ID, configurationId);

			configurationCollection.update(match, update, false, false);
		}
	}

	@Override
	public void decoupleWagonWithBox(DecouplingEvent event)
	{
		Wagon wagon = event.getWagon();
		if (wagon == null)
			throw new IllegalArgumentException("Wagon must not be null");

		String wagonId = wagon.getId();
		if (wagonId == null || wagonId.isEmpty())
			throw new IllegalArgumentException("Wagon id must not be null or empty");
		String configurationId = getConfigurationId(wagonId);

		wagon.setBoxId(null);

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		wagonCollection.save(Wagon.wagon2DBObject(wagon));

		updateCurrent(wagon, wagonId);
		updateConfiguration(wagon, configurationId);

		DashboardEventBus.post(new ClearValueEvent());
		logger.debug("Wagon decoupled");
	}

	@Override
	public void saveWagonType(WagonTypeEvent event)
	{
		WagonType wagonType = event.getWagonType();
		String tenantId = event.getTenantId();
		if (wagonType == null)
			throw new IllegalArgumentException("Wagon type must not be null");
		if (tenantId == null || tenantId.isEmpty())
			throw new IllegalArgumentException("Tenant must not be null");

		DBCollection wagonTypeCollection = getCollection(DashboardUI.getWagonTypeCollection());
		DBObject wagonTypeObject = WagonType.wagonType2DBObject(wagonType);
		try
		{
			wagonTypeCollection.save(wagonTypeObject);
			DashboardEventBus.post(
					new WagonTypeStatusEvent(wagonType, WagonTypeStatusEvent.Status.OK_ADDED));
			logger.debug("Wagon Type '{}' saved", wagonType.getTypeName());
		}
		catch (DuplicateKeyException e)
		{
			DashboardEventBus.post(new WagonTypeStatusEvent(wagonType,
					WagonTypeStatusEvent.Status.ERROR_EXISTING_TRANSPORT_TYPE));
			logger.debug("WagonType '{}' already exists for the tenant '{}'",
					wagonType.getTypeName(), tenantId);
			logger.error(e.getMessage());
		}
	}

	@Override
	public void deleteWagonType(WagonTypeDeleteEvent event)
	{
		WagonType wagonType = event.getWagonType();
		String tenantId = event.getTenantId();
		if (wagonType == null)
			throw new IllegalArgumentException("Wagon type must not be null");
		if (tenantId == null || tenantId.isEmpty())
			throw new IllegalArgumentException("Tenant must not be null");

		// check if the wagon type is used by any wagon with the same tenant
		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject queryUsedWagonType = new BasicDBObject(
				MongoConstants.WAGON_TYPE + "." + MongoConstants.WAGON_TYPE_NAME,
				wagonType.getTypeName());
		queryUsedWagonType.put(MongoConstants.TENANT_ID, wagonType.getTenantId());
		if (wagonCollection.count(queryUsedWagonType) > 0)
		{
			DashboardEventBus.post(new WagonTypeStatusEvent(wagonType,
					WagonTypeStatusEvent.Status.ERROR_USED_TRANSPORT_TYPE));
			logger.debug("Wagon Type '{}' is used by a wagon", wagonType.getTypeName());
		}
		else
		{
			// do the the removal
			DBCollection wagonTypeCollection = getCollection(DashboardUI.getWagonTypeCollection());
			DBObject wagonTypeObject = WagonType.wagonType2DBObject(wagonType);

			wagonTypeCollection.remove(wagonTypeObject);

			DashboardEventBus.post(
					new WagonTypeStatusEvent(wagonType, WagonTypeStatusEvent.Status.OK_REMOVED));
			logger.debug("Wagon Type '{}' removed", wagonType.getTypeName());
		}
	}

	private DBCollection getCollection(String collectionName)
	{
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection collection = db.getCollection(collectionName);
		return collection;
	}
}
