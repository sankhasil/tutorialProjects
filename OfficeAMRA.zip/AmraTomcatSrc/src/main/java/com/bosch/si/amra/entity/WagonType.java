
package com.bosch.si.amra.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

import com.bosch.si.amra.constants.MongoConstants;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

/**
 * Entity for WagonType table
 * 
 * @author toa1wa3
 * 
 */
public class WagonType implements Serializable
{

	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= -6119205544347075608L;

	private String				id;

	private String				typeName;

	private Date				createdTs			= new Date();

	private String				tenantId;

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public Date getCreatedTs()
	{
		return createdTs;
	}

	public void setCreatedTs(Date createdTs)
	{
		this.createdTs = createdTs;
	}

	public String getTypeName()
	{
		return typeName;
	}

	public void setTypeName(String typeName)
	{
		this.typeName = typeName;
	}

	public String getTenantId()
	{
		return tenantId;
	}

	public void setTenantId(String tenantId)
	{
		this.tenantId = tenantId;
	}

	public static DBObject wagonType2DBObject(WagonType wagonType)
	{
		DBObject wagonTypeObject = null;
		if (wagonType != null)
		{
			wagonTypeObject = new BasicDBObject();
			String id = wagonType.getId();
			if (id == null)
			{
				id = UUID.randomUUID().toString();
			}
			wagonTypeObject.put(MongoConstants.ID, id);
			wagonTypeObject.put(MongoConstants.WAGON_TYPE_NAME, wagonType.getTypeName());
			wagonTypeObject.put(MongoConstants.SORT, wagonType.getTypeName().toLowerCase());
			wagonTypeObject.put(MongoConstants.TIMESTAMP, wagonType.getCreatedTs());
			wagonTypeObject.put(MongoConstants.TENANT_ID, wagonType.getTenantId());
		}
		return wagonTypeObject;
	}

	public static WagonType dbObject2WagonType(DBObject dbObject)
	{
		WagonType wagonType = null;
		if (dbObject != null)
		{
			wagonType = new WagonType();
			wagonType.setId((String) dbObject.get(MongoConstants.ID));
			wagonType.setTypeName((String) dbObject.get(MongoConstants.WAGON_TYPE_NAME));
			wagonType.setCreatedTs((Date) dbObject.get(MongoConstants.TIMESTAMP));
			wagonType.setTenantId((String) dbObject.get(MongoConstants.TENANT_ID));
		}
		return wagonType;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((typeName == null) ? 0 : typeName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		WagonType other = (WagonType) obj;
		if (typeName == null)
		{
			if (other.typeName != null)
				return false;
		}
		else if (!typeName.equals(other.typeName))
			return false;
		return true;
	}
}
