
package com.bosch.si.amra.entity.geofence;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import com.bosch.si.amra.constants.MongoConstants;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.vaadin.tapio.googlemaps.client.LatLon;

public class Geofence implements Serializable
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= -5081130135883895695L;

	private String				id;

	private String				name;

	private String				description;

	private Date				timestamp;

	private List<LatLon>		positions;

	private String				tenantId;

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getDescription()
	{
		return description;
	}

	public void setDescription(String description)
	{
		this.description = description;
	}

	public Date getTimestamp()
	{
		return timestamp;
	}

	public void setTimestamp(Date timestamp)
	{
		this.timestamp = timestamp;
	}

	public List<LatLon> getPositions()
	{
		return positions;
	}

	public void setPositions(List<LatLon> positions)
	{
		this.positions = positions;
	}

	public String getTenantId()
	{
		return tenantId;
	}

	public void setTenantId(String tenantId)
	{
		this.tenantId = tenantId;
	}

	public static DBObject geofence2DBObject(Geofence geofencing)
	{
		DBObject geofencingObject = null;
		if (geofencing != null)
		{
			geofencingObject = new BasicDBObject();
			String id = geofencing.getId();
			if (id == null)
			{
				id = UUID.randomUUID().toString();
			}
			geofencingObject.put(MongoConstants.ID, id);
			geofencingObject.put(MongoConstants.GEOFENCE_NAME, geofencing.getName());
			geofencingObject.put(MongoConstants.SORT, geofencing.getName().toLowerCase());
			geofencingObject.put(MongoConstants.GEOFENCE_DESCRIPTION, geofencing.getDescription());
			geofencingObject.put(MongoConstants.TIMESTAMP, geofencing.getTimestamp());
			DBObject geoJson = new BasicDBObject(MongoConstants.GEOJSON_TYPE,
					MongoConstants.POLYGON);
			BasicDBList buildGeoJsonPolygon = buildGeoJsonPolygon(geofencing.getPositions());
			geoJson.put(MongoConstants.GEOJSON_COORDINATES, buildGeoJsonPolygon);
			geofencingObject.put(MongoConstants.LOCATION, geoJson);
			geofencingObject.put(MongoConstants.TENANT_ID, geofencing.getTenantId());
		}
		return geofencingObject;
	}

	public static Geofence dbObject2Geofence(DBObject dbObject)
	{
		Geofence geofence = null;
		if (dbObject != null)
		{
			geofence = new Geofence();
			geofence.setId((String) dbObject.get(MongoConstants.ID));
			geofence.setName((String) dbObject.get(MongoConstants.GEOFENCE_NAME));
			geofence.setDescription((String) dbObject.get(MongoConstants.GEOFENCE_DESCRIPTION));
			geofence.setTimestamp((Date) dbObject.get(MongoConstants.TIMESTAMP));
			List<LatLon> extractedPositions = extractPositions((DBObject) dbObject
					.get(MongoConstants.LOCATION));
			geofence.setPositions(extractedPositions);
			geofence.setTenantId((String) dbObject.get(MongoConstants.TENANT_ID));
		}
		return geofence;
	}

	private static BasicDBList buildGeoJsonPolygon(List<LatLon> coordinates)
	{
		List<BasicDBList> coordinatesList = new ArrayList<BasicDBList>();
		if (coordinates != null && coordinates.size() > 0)
		{
			for (LatLon coordinate : coordinates)
			{
				BasicDBList list = new BasicDBList();
				list.add(coordinate.getLon());
				list.add(coordinate.getLat());
				coordinatesList.add(list);
			}
			// Need to store the first element as last element to be GeoJson conform
			BasicDBList lastElement = new BasicDBList();
			lastElement.add(coordinates.get(0).getLon());
			lastElement.add(coordinates.get(0).getLat());
			coordinatesList.add(lastElement);
		}

		BasicDBList list = new BasicDBList();
		list.add(coordinatesList);
		return list;
	}

	private static List<LatLon> extractPositions(DBObject locObject)
	{
		List<LatLon> positions = new ArrayList<LatLon>();
		if (locObject != null)
		{
			BasicDBList coordinates = (BasicDBList) locObject
					.get(MongoConstants.GEOJSON_COORDINATES);
			BasicDBList coordinatesList = (BasicDBList) coordinates.get(0);
			for (Object coordinate : coordinatesList.subList(0, coordinatesList.size() - 1))
			{
				BasicDBList coordinateList = (BasicDBList) coordinate;
				double lat = ((Double) coordinateList.get(1)).doubleValue();
				double lon = ((Double) coordinateList.get(0)).doubleValue();
				positions.add(new LatLon(lat, lon));
			}
		}
		return positions;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Geofence other = (Geofence) obj;
		if (id == null)
		{
			if (other.id != null)
				return false;
		}
		else if (!id.equals(other.id))
			return false;
		if (name == null)
		{
			if (other.name != null)
				return false;
		}
		else if (!name.equals(other.name))
			return false;
		return true;
	}
}
