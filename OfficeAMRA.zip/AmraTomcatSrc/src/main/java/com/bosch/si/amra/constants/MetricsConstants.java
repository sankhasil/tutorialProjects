
package com.bosch.si.amra.constants;

public class MetricsConstants
{
	public static final String	UI_DOMAIN			= "amra.ui";

	public static final String	UI_LOGIN_PREFIX		= "ui.login";

	public static final String	UI_LOGOUT_PREFIX	= "ui.logout";

	public static final String	VIEW_VISIT_PREFIX	= "view.visit";
}
