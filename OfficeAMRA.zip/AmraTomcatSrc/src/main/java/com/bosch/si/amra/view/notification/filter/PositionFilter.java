
package com.bosch.si.amra.view.notification.filter;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;

import com.vaadin.data.Container.Filter;
import com.vaadin.data.Item;
import com.vaadin.data.Property;
import com.vaadin.server.Page;

public class PositionFilter implements Filter
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= 2703520181971869553L;

	private static final String	DECIMAL_PATTERN		= "0.000";

	private final Object		propertyId;

	private final String		filterString;

	public PositionFilter(Object propertyId, String filterString)
	{
		this.propertyId = propertyId;
		this.filterString = filterString;
	}

	@Override
	public boolean passesFilter(Object itemId, Item item) throws UnsupportedOperationException
	{
		final Property<?> p = item.getItemProperty(propertyId);
		if (p == null)
		{
			return false;
		}
		Object propertyValue = p.getValue();
		if (propertyValue == null || !p.getType().equals(Double.class))
		{
			return false;
		}

		String positionValue = getNumberFormat().format((Double) propertyValue).toString();
		if (positionValue.contains(filterString))
			return true;
		return false;
	}

	@Override
	public boolean appliesToProperty(Object propertyId)
	{
		return propertyId != null && propertyId.equals(this.propertyId);
	}

	private NumberFormat getNumberFormat()
	{
		return new DecimalFormat(DECIMAL_PATTERN,
				new DecimalFormatSymbols(Page.getCurrent().getWebBrowser().getLocale()));
	}

}
