
package com.bosch.si.amra.entity.rule;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.constants.rule.RuleConstants;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.entity.geofence.Geofence;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

public class Rule implements Serializable
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= -8511458505919585532L;

	private String				id;

	/**
	 * name of rule
	 */
	private String				name;

	/**
	 * indicator whether the rule is active or inactive
	 */
	private Boolean				active;

	/**
	 * one of: relative humidity, total mileage, ambient temperature, load temperature, Geofence
	 */
	private String				ruleType;

	/**
	 * the upper/lower values or the area of the geofence
	 */
	private Integer				limit;

	/**
	 * the lower value of temperature.
	 */
	private Integer				minRange;

	/**
	 * the upper value of temperature.
	 */
	private Integer				maxRange;

	/**
	 * depends on type of rule: °C, km/h
	 */
	private String				unit;

	/**
	 * one of: below threshold, above threshold, arriving, leaving
	 * depending on type of rule
	 */
	private String				condition;

	/**
	 * one of: low, medium, high
	 */
	private Severity			severity;

	private String				tenantId;

	private List<Wagon>			wagons;

	private Date				timestamp;

	private Geofence			geofence;

	private String				email;

	public enum Severity
	{
		RED, YELLOW, GREEN;
	}

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public Boolean getActive()
	{
		return active;
	}

	public void setActive(Boolean active)
	{
		this.active = active;
	}

	public String getRuleType()
	{
		return ruleType;
	}

	public void setRuleType(String ruleType)
	{
		this.ruleType = ruleType;
	}

	public Integer getLimit()
	{
		return limit;
	}

	public void setLimit(Integer limit)
	{
		this.limit = limit;
	}

	public Integer getMinRange()
	{
		return minRange;
	}

	public void setMinRange(Integer minRange)
	{
		this.minRange = minRange;
	}

	public Integer getMaxRange()
	{
		return maxRange;
	}

	public void setMaxRange(Integer maxRange)
	{
		this.maxRange = maxRange;
	}

	public String getUnit()
	{
		return unit;
	}

	public void setUnit(String unit)
	{
		this.unit = unit;
	}

	public String getCondition()
	{
		return condition;
	}

	public void setCondition(String condition)
	{
		this.condition = condition;
	}

	public Severity getSeverity()
	{
		return severity;
	}

	public void setSeverity(Severity severity)
	{
		this.severity = severity;
	}

	public String getTenantId()
	{
		return tenantId;
	}

	public void setTenantId(String tenantId)
	{
		this.tenantId = tenantId;
	}

	public Date getTimestamp()
	{
		return timestamp;
	}

	public void setTimestamp(Date timestamp)
	{
		this.timestamp = timestamp;
	}

	public Geofence getGeofence()
	{
		return geofence;
	}

	public void setGeofence(Geofence geofence)
	{
		this.geofence = geofence;
	}

	public String getEmail()
	{
		return email;
	}

	public void setEmail(String email)
	{
		this.email = email;
	}

	public List<Wagon> getWagons()
	{
		return wagons;
	}

	public void setWagons(List<Wagon> wagons)
	{
		this.wagons = wagons;
	}

	public boolean isValid()
	{
		return name != null && !name.isEmpty() && condition != null
				&& (limit != null || (maxRange != null && minRange != null)) && ruleType != null
				&& severity != null;
	}

	public static DBObject rule2DBObject(Rule rule, String tenantId)
	{
		DBObject ruleObject = null;
		if (rule != null)
		{

			ruleObject = new BasicDBObject();
			String id = rule.getId();
			if (id == null)
			{
				id = UUID.randomUUID().toString();
			}
			ruleObject.put(MongoConstants.ID, id);
			ruleObject.put(MongoConstants.ALARM_NAME, rule.getName());
			ruleObject.put(MongoConstants.SORT, rule.getName().toLowerCase());
			ruleObject.put(MongoConstants.ALARM_ACTIVE,
					rule.getActive() != null ? rule.getActive() : false);
			ruleObject.put(MongoConstants.ALARM_RULE_TYPE, rule.getRuleType());
			ruleObject.put(MongoConstants.ALARM_SEVERITY, rule.getSeverity().name());
			if (rule.getTenantId() != null)
			{
				ruleObject.put(MongoConstants.TENANT_ID, rule.getTenantId());
			}
			else
			{
				ruleObject.put(MongoConstants.TENANT_ID, tenantId);
			}
			if (rule.getTimestamp() != null)
			{
				ruleObject.put(MongoConstants.TIMESTAMP, rule.getTimestamp());
			}
			else
			{
				ruleObject.put(MongoConstants.TIMESTAMP, new Date());
			}

			if (rule.getRuleType().equals(MongoConstants.GEOFENCE_TYPE))
			{
				if (rule.getGeofence() != null)
				{
					ruleObject.put(MongoConstants.GEOFENCE,
							buildGeofenceObject(rule.getGeofence(), rule));
				}
			}
			else if (rule.getRuleType().equals(RuleConstants.HUMIDITY_TEMPERATURE_RANGE)
					&& rule.getMaxRange() != null && rule.getMinRange() != null)
			{
				DBObject sensorObject = new BasicDBObject();
				sensorObject.put(MongoConstants.ALARM_MAX_RANGE, rule.getMaxRange());
				sensorObject.put(MongoConstants.ALARM_MIN_RANGE, rule.getMinRange());
				sensorObject.put(MongoConstants.ALARM_CONDITION, rule.getCondition());
				ruleObject.put(MongoConstants.SENSORVALUES_ELEMENT, sensorObject);
			}
			else
			{
				DBObject sensorObject = new BasicDBObject();
				sensorObject.put(MongoConstants.ALARM_LIMIT, rule.getLimit());
				sensorObject.put(MongoConstants.ALARM_CONDITION, rule.getCondition());
				ruleObject.put(MongoConstants.SENSORVALUES_ELEMENT, sensorObject);
			}
			BasicDBList wagons = buildWagonsList(rule.getWagons());
			ruleObject.put(MongoConstants.RULE_WAGONS, wagons);
			BasicDBList emailList = buildEmailList(rule.getEmail());
			ruleObject.put(MongoConstants.EMAIL, emailList);
		}
		return ruleObject;
	}

	private static BasicDBList buildWagonsList(List<Wagon> wagons)
	{
		BasicDBList list = new BasicDBList();
		if (wagons != null && !wagons.isEmpty())
		{
			for (Wagon wagon : wagons)
			{
				DBObject object = new BasicDBObject();
				object.put(MongoConstants.WAGON_ID, wagon.getId());
				object.put(MongoConstants.ALIAS, wagon.getAlias());
				object.put(MongoConstants.ALIAS_TO_LOWERCASE, wagon.getAlias().toLowerCase());
				object.put(MongoConstants.ALARM_INITIAL, wagon.getInitial());
				list.add(object);
			}
		}
		return list;
	}

	private static BasicDBList buildEmailList(String value)
	{
		BasicDBList emailList = new BasicDBList();
		if (!value.isEmpty())
		{
			String emails[] = value.toString().trim().split(",");
			for (String email : emails)
			{
				emailList.add(email.trim());
			}

		}
		return emailList;
	}

	public static Rule dbObject2Rule(DBObject dbObject)
	{
		Rule rule = null;
		if (dbObject != null)
		{
			rule = new Rule();
			rule.setId((String) dbObject.get(MongoConstants.ID));
			rule.setName((String) dbObject.get(MongoConstants.ALARM_NAME));
			rule.setActive(dbObject.get(MongoConstants.ALARM_ACTIVE) != null
					? (Boolean) dbObject.get(MongoConstants.ALARM_ACTIVE) : false);
			rule.setRuleType((String) dbObject.get(MongoConstants.ALARM_RULE_TYPE));
			DBObject sensorObject = (DBObject) dbObject.get(MongoConstants.SENSORVALUES_ELEMENT);
			if (sensorObject != null)
			{
				if (rule.getRuleType().equals(RuleConstants.HUMIDITY_TEMPERATURE_RANGE))
				{
					rule.setMinRange((Integer) sensorObject.get(MongoConstants.ALARM_MIN_RANGE));
					rule.setMaxRange((Integer) sensorObject.get(MongoConstants.ALARM_MAX_RANGE));
				}
				else
				{
					rule.setLimit((Integer) sensorObject.get(MongoConstants.ALARM_LIMIT));
				}
				rule.setCondition((String) sensorObject.get(MongoConstants.ALARM_CONDITION));
			}
			rule.setSeverity(getSeverity(dbObject));
			rule.setTenantId((String) dbObject.get(MongoConstants.TENANT_ID));
			rule.setTimestamp((Date) dbObject.get(MongoConstants.TIMESTAMP));

			List<Wagon> extractedwagons = extractWagons(
					(BasicDBList) dbObject.get(MongoConstants.RULE_WAGONS));
			rule.setWagons(extractedwagons);
			DBObject geofenceObject = (DBObject) dbObject.get(MongoConstants.GEOFENCE);
			if (geofenceObject != null)
			{
				rule.setGeofence(extractGeofence(geofenceObject));
				rule.setCondition((String) geofenceObject.get(MongoConstants.ALARM_CONDITION));
			}
			String email = list2String((BasicDBList) dbObject.get(MongoConstants.EMAIL));
			rule.setEmail(email);
		}
		return rule;
	}

	private static Severity getSeverity(DBObject dbObject)
	{
		String severity = (String) dbObject.get(MongoConstants.ALARM_SEVERITY);
		return Severity.valueOf(severity);
	}

	static String list2String(BasicDBList emailList)
	{
		StringBuffer emails = new StringBuffer();
		if (emailList != null && emailList.size() > 0)
		{
			for (int i = 0; i < emailList.size(); i++)
			{
				String email = (String) emailList.get(i);
				emails.append(email);
				if (i != (emailList.size() - 1))
					emails.append(",");
			}
		}
		return emails.toString();
	}

	private static List<Wagon> extractWagons(BasicDBList wagonsList)
	{
		List<Wagon> wagons = new ArrayList<Wagon>();
		if (wagonsList != null && !wagonsList.isEmpty())
		{
			for (Object wagon : wagonsList)
			{
				DBObject object = (DBObject) wagon;
				String wagonId = String.valueOf(object.get(MongoConstants.WAGON_ID));
				String alias = String.valueOf(object.get(MongoConstants.ALIAS));
				Boolean initial = (Boolean) object.get(MongoConstants.ALARM_INITIAL);
				Wagon wagonObject = new Wagon();
				wagonObject.setId(wagonId);
				wagonObject.setAlias(alias);
				wagonObject.setInitial(initial);
				wagons.add(wagonObject);
			}
		}
		return wagons;
	}

	private static Geofence extractGeofence(DBObject geofence)
	{
		Geofence extractedGeofence = new Geofence();
		if (geofence != null)
		{
			DBObject object = (DBObject) geofence;
			String geofenceId = String.valueOf(object.get(MongoConstants.ID));
			String geofenceName = String.valueOf(object.get(MongoConstants.GEOFENCE_NAME));
			extractedGeofence.setId(geofenceId);
			extractedGeofence.setName(geofenceName);
		}
		return extractedGeofence;
	}

	private static DBObject buildGeofenceObject(Geofence geofence, Rule rule)
	{
		DBObject object = new BasicDBObject();
		if (geofence != null)
		{
			object.put(MongoConstants.ID, geofence.getId());
			object.put(MongoConstants.GEOFENCE_NAME, geofence.getName());
			object.put(MongoConstants.SORT, geofence.getName().toLowerCase());
			object.put(MongoConstants.ALARM_CONDITION, rule.getCondition());
		}
		return object;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((active == null) ? 0 : active.hashCode());
		result = prime * result + ((condition == null) ? 0 : condition.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((geofence == null) ? 0 : geofence.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((limit == null) ? 0 : limit.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((ruleType == null) ? 0 : ruleType.hashCode());
		result = prime * result + ((severity == null) ? 0 : severity.hashCode());
		result = prime * result + ((tenantId == null) ? 0 : tenantId.hashCode());
		result = prime * result + ((timestamp == null) ? 0 : timestamp.hashCode());
		result = prime * result + ((unit == null) ? 0 : unit.hashCode());
		result = prime * result + ((wagons == null) ? 0 : wagons.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Rule other = (Rule) obj;
		if (active == null)
		{
			if (other.active != null)
				return false;
		}
		else if (!active.equals(other.active))
			return false;
		if (condition == null)
		{
			if (other.condition != null)
				return false;
		}
		else if (!condition.equals(other.condition))
			return false;
		if (email == null)
		{
			if (other.email != null)
				return false;
		}
		else if (!email.equals(other.email))
			return false;
		if (geofence == null)
		{
			if (other.geofence != null)
				return false;
		}
		else if (!geofence.equals(other.geofence))
			return false;
		if (id == null)
		{
			if (other.id != null)
				return false;
		}
		else if (!id.equals(other.id))
			return false;
		if (limit == null)
		{
			if (other.limit != null)
				return false;
		}
		else if (!limit.equals(other.limit))
			return false;
		if (name == null)
		{
			if (other.name != null)
				return false;
		}
		else if (!name.equals(other.name))
			return false;
		if (ruleType == null)
		{
			if (other.ruleType != null)
				return false;
		}
		else if (!ruleType.equals(other.ruleType))
			return false;
		if (severity != other.severity)
			return false;
		if (tenantId == null)
		{
			if (other.tenantId != null)
				return false;
		}
		else if (!tenantId.equals(other.tenantId))
			return false;
		if (timestamp == null)
		{
			if (other.timestamp != null)
				return false;
		}
		else if (!timestamp.equals(other.timestamp))
			return false;
		if (unit == null)
		{
			if (other.unit != null)
				return false;
		}
		else if (!unit.equals(other.unit))
			return false;
		if (wagons == null)
		{
			if (other.wagons != null)
				return false;
		}
		else if (!wagons.equals(other.wagons))
			return false;
		return true;
	}

}
