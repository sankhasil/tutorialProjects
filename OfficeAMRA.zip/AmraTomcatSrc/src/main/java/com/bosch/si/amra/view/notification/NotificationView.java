
package com.bosch.si.amra.view.notification;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.common.GoogleMapUtilFactory;
import com.bosch.si.amra.component.OpenInfoWindowOnMarkerClickListener;
import com.bosch.si.amra.constants.notification.NotificationConstants;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.notification.Notification;
import com.bosch.si.amra.event.DashboardEvent.NotificationAcknowledgeEvent;
import com.bosch.si.amra.event.DashboardEvent.NotificationSetEvent;
import com.bosch.si.amra.event.DashboardEvent.NotificationsCountUpdatedEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.im.login.Role;
import com.bosch.si.amra.im.login.Role.Roles;
import com.bosch.si.amra.view.notification.converter.ReasonPropertyValueGenerator;
import com.bosch.si.amra.view.notification.grid.NotificationContainer;
import com.bosch.si.amra.view.notification.grid.NotificationGrid;
import com.bosch.si.amra.view.notification.listener.NotificationApproveButtonListener;
import com.bosch.si.amra.view.notification.listener.NotificationShowInMapButtonListener;
import com.bosch.si.amra.view.notification.listener.NotificationShowInTableButtonListener;
import com.google.common.eventbus.Subscribe;
import com.vaadin.data.Container.Filter;
import com.vaadin.data.Container.Filterable;
import com.vaadin.data.Property.ValueChangeEvent;
import com.vaadin.data.Property.ValueChangeListener;
import com.vaadin.data.util.GeneratedPropertyContainer;
import com.vaadin.data.util.filter.Compare;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.event.ShortcutListener;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Page;
import com.vaadin.server.Responsive;
import com.vaadin.server.ThemeResource;
import com.vaadin.server.VaadinSession;
import com.vaadin.shared.data.sort.SortDirection;
import com.vaadin.tapio.googlemaps.GoogleMap;
import com.vaadin.tapio.googlemaps.client.LatLon;
import com.vaadin.tapio.googlemaps.client.overlays.GoogleMapInfoWindow;
import com.vaadin.tapio.googlemaps.client.overlays.GoogleMapMarker;
import com.vaadin.ui.AbstractField;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.CheckBox;
import com.vaadin.ui.Component;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.MenuBar;
import com.vaadin.ui.MenuBar.MenuItem;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

@Role ({ Roles.ENDCUSTOMER, Roles.USER, Roles.FLEETADMIN, Roles.SYSTEMADMIN, })
@SuppressWarnings ("serial")
public class NotificationView extends VerticalLayout implements View
{
	private NotificationGrid				grid;

	private HorizontalLayout				tools;

	private VerticalLayout					map;

	private Button							approveNotifications;

	private Button							showNotificationsInMap;

	private Button							showNotificationsInTable;

	private CheckBox						checkBox;

	private final GoogleMap					googleMap;

	private List<Notification>				notifications;

	private Map<MenuItem, String>			menuItems;

	private final List<GoogleMapInfoWindow>	mapInfoWindows	= new ArrayList<GoogleMapInfoWindow>();

	private final User						user			= (User) VaadinSession.getCurrent()
			.getAttribute(User.class.getName());

	private final Filter					acknowledgedFilter;

	public NotificationView()
	{
		notifications = DashboardUI.getNotificationDataProvider().getNotifications(user, false,
				true);
		acknowledgedFilter = new Compare.Equal(NotificationConstants.ACKNOWLEDGED, false);

		setSizeFull();
		addStyleName("notification");
		DashboardEventBus.register(this);

		addComponent(buildToolbar());

		googleMap = new GoogleMap(DashboardUI.getGoogleAPIKey(), "", "");
		grid = buildGrid();
		buildMap();
		addComponents(grid);
		setExpandRatio(grid, 1);

		addShortcutListener(new ShortcutListener("Clear", KeyCode.ESCAPE, null)
		{
			@SuppressWarnings ("unchecked")
			@Override
			public void handleAction(Object sender, Object target)
			{
				GeneratedPropertyContainer container = (GeneratedPropertyContainer) grid
						.getContainerDataSource();
				if (target instanceof AbstractField)
					((AbstractField<String>) target).setValue(null);
				Object pid = grid.getComponentToPidMap().get(target);
				if (pid != null)
				{
					List<Filter> removedFilter = container.getContainerFilters().stream()
							.filter(filter -> filter.appliesToProperty(pid))
							.collect(Collectors.toList());
					removedFilter.stream().forEach(filterToBeRemoved -> container
							.removeContainerFilter(filterToBeRemoved));
				}
			}
		});
	}

	@Override
	public void detach()
	{
		super.detach();
		DashboardEventBus.unregister(this);
	}

	private Component buildToolbar()
	{
		HorizontalLayout header = new HorizontalLayout();
		header.addStyleName("viewheader");
		header.setSpacing(true);
		Responsive.makeResponsive(header);

		Label title = new Label(
				DashboardUI.getMessageSource().getMessage("view.notification.caption"));
		title.setSizeUndefined();
		title.addStyleName(ValoTheme.LABEL_H1);
		title.addStyleName(ValoTheme.LABEL_NO_MARGIN);
		header.addComponent(title);

		approveNotifications = buildApproveNotification();
		showNotificationsInMap = buildShowNotificationsInMap();
		showNotificationsInTable = buildShowNotificationsInTable();
		checkBox = buildShowAllNotAcknowledgedNotifications();
		tools = new HorizontalLayout(showNotificationsInMap, approveNotifications, checkBox);
		tools.setSpacing(true);
		tools.addStyleName("toolbar");
		header.addComponent(tools);

		return header;
	}

	private Button buildApproveNotification()
	{
		final Button approveNotificationButton = buildButton(null,
				"view.notification.button.approve.tooltip");
		approveNotificationButton.setIcon(new ThemeResource("img/notification/done2.png"));
		approveNotificationButton.addClickListener(new NotificationApproveButtonListener(this));
		approveNotificationButton.setEnabled(false);
		return approveNotificationButton;
	}

	private Button buildShowNotificationsInMap()
	{
		final Button showNotificationsInMap = buildButton(FontAwesome.GLOBE,
				"view.notification.button.map.tooltip");
		showNotificationsInMap.addClickListener(new NotificationShowInMapButtonListener(this));
		return showNotificationsInMap;
	}

	private Button buildShowNotificationsInTable()
	{
		final Button showNotificationsInTable = buildButton(FontAwesome.TABLE,
				"view.notification.button.table.tooltip");
		showNotificationsInTable.addClickListener(new NotificationShowInTableButtonListener(this));
		return showNotificationsInTable;
	}

	private Button buildButton(FontAwesome icon, String description)
	{
		final Button button = new Button(icon);
		button.setDescription(DashboardUI.getMessageSource().getMessage(description));
		button.addStyleName(ValoTheme.BUTTON_ICON_ONLY);
		return button;
	}

	private CheckBox buildShowAllNotAcknowledgedNotifications()
	{
		final CheckBox checkBox = new CheckBox();
		checkBox.setValue(false);
		checkBox.addStyleName(ValoTheme.BUTTON_ICON_ONLY);
		checkBox.setImmediate(true);
		checkBox.setDescription(DashboardUI.getMessageSource()
				.getMessage("view.notification.checkbox.tooltip.notack"));
		checkBox.addStyleName("checkBox");
		checkBox.setValue(true);
		checkBox.addValueChangeListener(new ValueChangeListener()
		{
			@Override
			public void valueChange(ValueChangeEvent event)
			{
				Filterable data = (Filterable) grid.getContainerDataSource();
				if ((boolean) event.getProperty().getValue())
					data.addContainerFilter(acknowledgedFilter);
				else
					data.removeContainerFilter(acknowledgedFilter);
				fillMap();
			}
		});

		return checkBox;
	}

	private NotificationGrid buildGrid()
	{
		GeneratedPropertyContainer generatedPropertyContainer = new GeneratedPropertyContainer(
				new NotificationContainer(Notification.class, notifications))
		{
			@Override
			public Collection<?> getSortableContainerPropertyIds()
			{
				return Arrays.asList(NotificationConstants.PROPERTY_IDS);
			}
		};
		generatedPropertyContainer.addGeneratedProperty(NotificationConstants.REASON,
				new ReasonPropertyValueGenerator());
		grid = new NotificationGrid(generatedPropertyContainer);

		NotificationGridListener listener = new NotificationGridListener(grid,
				approveNotifications);
		grid.addItemClickListener(listener);
		grid.addSelectionListener(listener);

		Filterable data = (Filterable) grid.getContainerDataSource();
		data.addContainerFilter(acknowledgedFilter);

		return grid;
	}

	private Component buildMap()
	{
		map = new VerticalLayout();
		map.setSizeFull();
		map.setMargin(true);
		map.addStyleName("notification-map");

		googleMap.setSizeFull();
		googleMap.setMinZoom(1);
		googleMap.setMaxZoom(21);

		map.addComponents(buildMapToolbar(), googleMap);
		map.setExpandRatio(googleMap, 1);

		return map;
	}

	private Component buildMapToolbar()
	{
		HorizontalLayout toolbar = new HorizontalLayout();
		toolbar.setWidth("100%");

		NotificationViewMap notificationViewMap = new NotificationViewMap();

		Label caption = notificationViewMap.buildCaptionLabel();

		MenuBar menuBar = new MenuBar();
		menuItems = notificationViewMap.buildToolbar(menuBar);

		for (MenuItem menuItem : menuItems.keySet())
		{
			menuItem.setCommand(new NotificationMapFilterCommand(menuItems, grid, this));
		}

		toolbar.addComponents(caption, menuBar);
		toolbar.setExpandRatio(caption, 1);
		toolbar.setComponentAlignment(caption, Alignment.MIDDLE_LEFT);

		return toolbar;
	}

	public void approveSelectedNotifications()
	{
		List<Notification> selectedNotifications = grid.getSelectedRows().stream()
				.map(notificationMapper -> (Notification) notificationMapper)
				.collect(Collectors.toList());
		DashboardEventBus.post(new NotificationAcknowledgeEvent(selectedNotifications, user));
		DashboardEventBus.post(new NotificationsCountUpdatedEvent());
	}

	public void showNotificationsInMap()
	{
		this.replaceComponent(grid, map);
		tools.replaceComponent(showNotificationsInMap, showNotificationsInTable);
	}

	public void showNotificationsInTable()
	{
		for (MenuItem key : menuItems.keySet())
		{
			key.setChecked(true);
		}
		Filterable data = (Filterable) grid.getContainerDataSource();
		data.removeContainerFilter(NotificationConstants.orFilter);
		NotificationConstants.orFilter = null;

		clearMap();
		this.replaceComponent(map, grid);
		tools.replaceComponent(showNotificationsInTable, showNotificationsInMap);
	}

	@SuppressWarnings ("unchecked")
	public void fillMap()
	{
		if (googleMap != null)
		{
			clearMap();
			List<LatLon> positions = new ArrayList<>();
			List<Notification> itemIds = (List<Notification>) grid.getContainerDataSource()
					.getItemIds();
			for (Notification notification : itemIds)
			{
				NotificationViewMap notificationViewMap = new NotificationViewMap();
				GoogleMapMarker notificationMarker = notificationViewMap
						.buildNotificationMarker(notification);
				GoogleMapInfoWindow notificationMarkerWindow = notificationViewMap
						.buildNotificationMarkerWindow(notificationMarker, notification);
				mapInfoWindows.add(notificationMarkerWindow);
				if (notification.isGpsFixed())
				{
					googleMap.addMarker(notificationMarker);
					googleMap.addMarkerClickListener(new OpenInfoWindowOnMarkerClickListener(
							googleMap, notificationMarker, notificationMarkerWindow));
					positions.add(getPosition(notification));
				}
			}
			GoogleMapUtilFactory.autoZoomMap(positions, googleMap);
		}
	}

	private void clearMap()
	{
		if (googleMap != null)
		{
			googleMap.clearMarkers();
			for (GoogleMapInfoWindow mapInfoWindow : mapInfoWindows)
			{
				googleMap.closeInfoWindow(mapInfoWindow);
			}
		}
	}

	private LatLon getPosition(Notification notification)
	{
		if (notification.getLatitude() != null && notification.getLongitude() != null)
			return new LatLon(notification.getLatitude(), notification.getLongitude());
		else
			return null;
	}

	@Override
	public void enter(ViewChangeEvent event)
	{
		Page.getCurrent().getStyles().add(".gm-style-iw + div {display: block;}");
	}

	@Subscribe
	public void setNotificationList(NotificationSetEvent event)
	{
		notifications = event.getNotifications();
		GeneratedPropertyContainer container = (GeneratedPropertyContainer) grid
				.getContainerDataSource();
		NotificationContainer wrappedContainer = (NotificationContainer) container
				.getWrappedContainer();
		wrappedContainer.removeAllItems();
		wrappedContainer.addAll(notifications);
		grid.sort(NotificationConstants.TIMESTAMP, SortDirection.DESCENDING);
		fillMap();

	}

}