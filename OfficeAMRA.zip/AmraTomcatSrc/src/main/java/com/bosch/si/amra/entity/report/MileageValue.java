
package com.bosch.si.amra.entity.report;

import java.io.Serializable;
import java.util.Date;

public class MileageValue implements Serializable
{

	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= -6349426828799382554L;

	private Date				date;

	private Integer				mileage;

	public MileageValue()
	{

	}

	public MileageValue(Date date, Integer mileage)
	{
		this.date = date;
		this.mileage = mileage;
	}

	public Date getDate()
	{
		return date;
	}

	public void setDate(Date date)
	{
		this.date = date;
	}

	public Integer getMileage()
	{
		return mileage;
	}

	public void setMileage(Integer mileage)
	{
		this.mileage = mileage;
	}
}
