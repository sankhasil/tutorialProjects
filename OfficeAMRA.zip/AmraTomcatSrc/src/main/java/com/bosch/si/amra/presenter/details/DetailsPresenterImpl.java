
package com.bosch.si.amra.presenter.details;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.entity.LatLong;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.event.DashboardEvent;
import com.bosch.si.amra.event.DashboardEvent.CalculateMileageEvent;
import com.bosch.si.amra.event.DashboardEvent.RouteUpdateEvent;
import com.bosch.si.amra.event.DashboardEvent.ShowDetailsForWagonEvent;
import com.bosch.si.amra.event.DashboardEvent.ShowRouteEvent;
import com.bosch.si.amra.event.DashboardEvent.UpdateEvent;
import com.bosch.si.amra.event.DashboardEvent.WagonSelectedEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.provider.DataProviderInitializer;
import com.mongodb.AggregationOutput;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.vaadin.server.VaadinSession;
import com.vaadin.tapio.googlemaps.client.LatLon;

/**
 * Presenter for saving and updating a wagon
 *
 * @author toa1wa3
 */
@Component
public class DetailsPresenterImpl implements Serializable, DetailsPresenter
{
	private static final String	MILEAGE				= "mileage";

	private static final String	DATE_NULL			= "The date must not be null or empty";

	private static final String	WAGON_ID_NULL		= "Wagon Id must not be null or empty";

	private static final String	ROUTING				= "RO";

	private static final String	BOX_DATE_PATTERN	= "yy-MM-dd";

	private static final String	LESS_EQUAL_THAN		= "$lte";

	private static final String	GREATER_EQUAL_THAN	= "$gte";

	private static final long	serialVersionUID	= 1L;

	private static final Logger	logger				= LoggerFactory
			.getLogger(DetailsPresenterImpl.class);

	@Override
	public Wagon showDetailsForWagon(ShowDetailsForWagonEvent event)
	{
		if (event.getWagon() == null)
			throw new IllegalArgumentException("Wagon must not be null");
		if (event.getTenantId() == null || event.getTenantId().isEmpty())
			throw new IllegalArgumentException("Tenant Id must not be null");

		Wagon wagon = DataProviderInitializer.getCurrentValuesForWagon(event.getWagon().getId(),
				event.getTenantId());
		List<Wagon> telematicDataForWagons = null;

		if (VaadinSession.getCurrent() != null)
		{
			User user = (User) VaadinSession.getCurrent().getAttribute(User.class.getName());
			if (user.isEndcustomer() && !user.isDisponent() && !user.isAdmin()
					&& !user.isSuperAdmin())
			{
				Date activationTime = DataProviderInitializer
						.getWagonActivationTime(event.getWagon().getId(), user.getId());
				telematicDataForWagons = DashboardUI.getDetailsDataProvider()
						.getTelematicDataForWagon(event.getWagon().getId()).stream()
						.filter(telematicWagon -> telematicWagon.getTimestamp()
								.after(activationTime))
						.collect(Collectors.toList());
			}
			else
			{
				telematicDataForWagons = DashboardUI.getDetailsDataProvider()
						.getTelematicDataForWagon(event.getWagon().getId());
			}
		}

		DashboardEventBus.post(new WagonSelectedEvent(wagon));
		DashboardEventBus.post(new DashboardEvent.WagonSetEvent(telematicDataForWagons));
		return wagon;
	}

	@Override
	public Integer calculateMileageForPeriod(CalculateMileageEvent event)
	{
		if (event.getWagonId() == null)
			throw new IllegalArgumentException(WAGON_ID_NULL);
		if (event.getStartDate() == null || event.getEndDate() == null)
			throw new IllegalArgumentException(DATE_NULL);

		AggregationOutput aggregate = aggregateMileage(event);
		Integer mileage = 0;
		if (aggregate != null && aggregate.results() != null
				&& aggregate.results().iterator().hasNext())
		{
			DBObject next = aggregate.results().iterator().next();
			mileage = (Integer) next.get(MILEAGE);
		}
		DashboardEventBus.post(new UpdateEvent(mileage));
		return mileage;
	}

	private AggregationOutput aggregateMileage(CalculateMileageEvent event)
	{
		SimpleDateFormat format = new SimpleDateFormat(BOX_DATE_PATTERN);
		Date startDate = event.getStartDate();
		Date endDate = event.getEndDate();
		String wagonId = event.getWagonId();

		DBCollection collection = getCollection(DashboardUI.getMongoMileageCollection());

		DBObject toMatch = new BasicDBObject(MongoConstants.WAGON_ID, wagonId);
		DBObject dateMatch = new BasicDBObject(GREATER_EQUAL_THAN, format.format(startDate));
		dateMatch.put(LESS_EQUAL_THAN, format.format(endDate));
		toMatch.put(MongoConstants.DATE, dateMatch);
		DBObject match = new BasicDBObject("$match", toMatch);

		DBObject groupData = new BasicDBObject("_id", "$WI");
		groupData.put(MILEAGE, new BasicDBObject("$sum", "$KM"));
		DBObject group = new BasicDBObject("$group", groupData);

		AggregationOutput aggregate = null;
		if (collection != null)
		{
			aggregate = collection.aggregate(Arrays.asList(match, group));
		}
		return aggregate;
	}

	@Override
	public Route calculateRoute(ShowRouteEvent event)
	{
		if (event.getWagonId() == null)
			throw new IllegalArgumentException(WAGON_ID_NULL);
		if (event.getStartDate() == null || event.getEndDate() == null)
			throw new IllegalArgumentException(DATE_NULL);

		Route route = new Route();
		route.setRoute(getRoutePositions(event));
		route.setPositions(getPositions(event));

		DashboardEventBus.post(new RouteUpdateEvent(route));
		return route;
	}

	private List<LatLon> getRoutePositions(ShowRouteEvent event)
	{
		DBCursor routingCursor = getRoutingInformationFromDB(event);
		List<LatLon> routePositions = new ArrayList<>();
		if (routingCursor != null)
		{
			while (routingCursor.hasNext())
			{
				DBObject next = routingCursor.next();
				BasicDBList list = (BasicDBList) next.get(ROUTING);
				for (Object object : list)
				{
					DBObject routingObject = (DBObject) object;
					LatLon latLon = new LatLon((Double) routingObject.get(MongoConstants.LATITUDE),
							(Double) routingObject.get(MongoConstants.LONGITUDE));
					routePositions.add(latLon);
				}
			}
		}
		return routePositions;
	}

	private DBCursor getRoutingInformationFromDB(ShowRouteEvent event)
	{
		SimpleDateFormat format = new SimpleDateFormat(BOX_DATE_PATTERN);
		String wagonId = event.getWagonId();
		Date start = event.getStartDate();
		Date end = event.getEndDate();

		DBCollection collection = getCollection(DashboardUI.getMongoRoutingCollection());

		DBObject findDbObject = new BasicDBObject(MongoConstants.WAGON_ID, wagonId);
		DBObject dateRangeObject = new BasicDBObject(GREATER_EQUAL_THAN, format.format(start));
		dateRangeObject.put(LESS_EQUAL_THAN, format.format(end));
		findDbObject.put(MongoConstants.DATE, dateRangeObject);

		DBObject sortObject = new BasicDBObject(MongoConstants.DATE, 1);
		sortObject.put(MongoConstants.TIME, 1);
		DBCursor sortCursor = null;
		if (collection != null)
		{
			sortCursor = collection.find(findDbObject).sort(sortObject);
		}
		return sortCursor;
	}

	@Override
	public List<LatLong> getPositions(ShowRouteEvent event)
	{
		if (event.getWagonId() == null)
			throw new IllegalArgumentException(WAGON_ID_NULL);
		if (event.getStartDate() == null || event.getEndDate() == null)
			throw new IllegalArgumentException(DATE_NULL);

		SimpleDateFormat format = new SimpleDateFormat("yy-MM-dd hh:mm:ss");
		format.setTimeZone(TimeZone.getTimeZone("UTC"));
		AggregationOutput routingCursor = findBoxPositions(event);
		List<LatLong> positions = new ArrayList<>();
		if (routingCursor != null && routingCursor.results() != null)
		{
			for (Iterator<DBObject> iterator = routingCursor.results().iterator(); iterator
					.hasNext();)
			{
				DBObject next = iterator.next();
				BasicDBObject object = (BasicDBObject) next.get(MongoConstants.DATA_ELEMENT);
				Number unixTime = (Number) object.get(MongoConstants.UNIX_TIME);
				LatLong latLon = new LatLong((Double) object.get(MongoConstants.LATITUDE),
						(Double) object.get(MongoConstants.LONGITUDE),
						new Date(unixTime.longValue() * 1000L));
				positions.add(latLon);
			}
		}
		return positions;
	}

	private AggregationOutput findBoxPositions(ShowRouteEvent event)
	{
		SimpleDateFormat format = new SimpleDateFormat(BOX_DATE_PATTERN);
		String wagonId = event.getWagonId();
		Date start = event.getStartDate();
		Date end = event.getEndDate();

		DBCollection collection = getCollection(DashboardUI.getEventCollection());

		DBObject findDbObject = new BasicDBObject(MongoConstants.WAGON_ID, wagonId);
		DBObject dateRangeObject = new BasicDBObject(GREATER_EQUAL_THAN, format.format(start));
		dateRangeObject.put(LESS_EQUAL_THAN, format.format(end));
		findDbObject.put(MongoConstants.DATA_DATE, dateRangeObject);
		DBObject match = new BasicDBObject("$match", findDbObject);
		BasicDBObject basicDBObject = new BasicDBObject(MongoConstants.DATA_DATE, 1);
		basicDBObject.put(MongoConstants.DATA_TIME, 1);

		DBObject sort = new BasicDBObject("$sort", basicDBObject);

		AggregationOutput aggregate = null;
		if (collection != null)
		{
			aggregate = collection.aggregate(Arrays.asList(match, sort));
		}
		return aggregate;
	}

	@Override
	public List<LatLon> calculateBounds(ShowRouteEvent event)
	{
		if (event.getWagonId() == null)
			throw new IllegalArgumentException(WAGON_ID_NULL);
		if (event.getStartDate() == null || event.getEndDate() == null)
			throw new IllegalArgumentException(DATE_NULL);

		MaxMin maxMinLatitude = getMaxMin(event, MongoConstants.LATITUDE);
		MaxMin maxMinLongitude = getMaxMin(event, MongoConstants.LONGITUDE);

		List<LatLon> list = new ArrayList<>();
		if (maxMinLatitude != null && maxMinLongitude != null)
		{
			LatLon northEasternBound = new LatLon(maxMinLatitude.getMax(),
					maxMinLongitude.getMax());
			LatLon southWesternBound = new LatLon(maxMinLatitude.getMin(),
					maxMinLongitude.getMin());
			list = Arrays.asList(northEasternBound, southWesternBound);
		}
		return list;
	}

	private MaxMin getMaxMin(ShowRouteEvent event, String attribute)
	{
		MaxMin maxMin = null;
		AggregationOutput aggregateLatitude = aggregateBounds(event, attribute);
		if (aggregateLatitude != null && aggregateLatitude.results() != null
				&& aggregateLatitude.results().iterator().hasNext())
		{
			DBObject next = aggregateLatitude.results().iterator().next();

			maxMin = new MaxMin((Double) next.get("max"), (Double) next.get("min"));
		}
		return maxMin;
	}

	private AggregationOutput aggregateBounds(ShowRouteEvent event, String attribute)
	{
		SimpleDateFormat format = new SimpleDateFormat(BOX_DATE_PATTERN);
		Date startDate = event.getStartDate();
		Date endDate = event.getEndDate();
		String wagonId = event.getWagonId();

		DBCollection collection = getCollection(DashboardUI.getMongoRoutingCollection());

		DBObject toMatch = new BasicDBObject(MongoConstants.WAGON_ID, wagonId);
		DBObject dateMatch = new BasicDBObject(GREATER_EQUAL_THAN, format.format(startDate));
		dateMatch.put(LESS_EQUAL_THAN, format.format(endDate));
		toMatch.put(MongoConstants.DATE, dateMatch);
		DBObject match = new BasicDBObject("$match", toMatch);

		DBObject unwind = new BasicDBObject("$unwind", "$RO");

		DBObject sort = new BasicDBObject("$sort", new BasicDBObject("RO." + attribute, -1));

		DBObject groupData = new BasicDBObject("_id", "$WI");
		groupData.put("max", new BasicDBObject("$first", "$RO." + attribute));
		groupData.put("min", new BasicDBObject("$last", "$RO." + attribute));
		DBObject group = new BasicDBObject("$group", groupData);

		AggregationOutput aggregate = null;
		if (collection != null)
		{
			aggregate = collection.aggregate(Arrays.asList(match, unwind, sort, group));
		}
		return aggregate;
	}

	private DBCollection getCollection(String collectionName)
	{
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection collection = db.getCollection(collectionName);
		return collection;
	}

	private static class MaxMin
	{
		Double	max;

		Double	min;

		public MaxMin(Double max, Double min)
		{
			this.max = max;
			this.min = min;
		}

		public Double getMax()
		{
			return max;
		}

		public Double getMin()
		{
			return min;
		}
	}
}
