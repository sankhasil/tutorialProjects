
package com.bosch.si.amra.component;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.event.DashboardEventBus;
import com.vaadin.server.FontAwesome;
import com.vaadin.shared.ui.label.ContentMode;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Label;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

public class Sparkline extends VerticalLayout
{
	private static final String	boxIdFormat			= "<b>%s</b>";

	private static final String	currentValueFormat	= "%s %s";

	private static final long	serialVersionUID	= -8775096885448756786L;

	private Label				boxId;

	private Label				current;

	private String				noContent			= DashboardUI.getMessageSource().getMessage(
															"view.details.noinformation");

	public Sparkline(String name, String unit, String id, Object currentValue, String stylename)
	{
		DashboardEventBus.register(this);

		setSizeUndefined();
		addStyleName("spark");
		setDefaultComponentAlignment(Alignment.TOP_CENTER);

		addComponent(buildCurrent(unit, currentValue, stylename));

		addComponent(buildTitle(name, unit));

		addComponent(buildBoxId(id));
	}

	private Label buildCurrent(String unit, Object currentValue, String stylename)
	{
		current = new Label(noContent);
		setCurrentValue(unit, currentValue, stylename);
		current.setContentMode(ContentMode.HTML);
		current.setSizeUndefined();
		current.addStyleName(ValoTheme.LABEL_HUGE);
		current.setImmediate(true);

		return current;
	}

	private Label buildTitle(String name, String unit)
	{
		Label title = new Label(DashboardUI.getMessageSource().getMessage(name) + " in " + unit);
		title.setSizeUndefined();
		title.addStyleName(ValoTheme.LABEL_SMALL);
		title.addStyleName(ValoTheme.LABEL_LIGHT);

		return title;
	}

	private Label buildBoxId(String id)
	{
		boxId = new Label(noContent);
		if (id != null)
		{
			boxId = new Label(String.format(boxIdFormat, id));
		}
		boxId.setContentMode(ContentMode.HTML);
		boxId.addStyleName(ValoTheme.LABEL_TINY);
		boxId.addStyleName(ValoTheme.LABEL_LIGHT);
		boxId.setSizeUndefined();
		boxId.setImmediate(true);

		return boxId;
	}

	public void setValues(String id, Object value, String unit, String stylename)
	{
		boxId.setValue(String.format(boxIdFormat, id));

		current.setValue(noContent);
		setCurrentValue(unit, value, stylename);
	}

	private void setCurrentValue(String unit, Object currentValue, String stylename)
	{
		if (currentValue != null)
			current.setValue(String.format(currentValueFormat, currentValue, unit));

		if (stylename != null && !stylename.isEmpty())
		{
			current.setValue(String.format(currentValueFormat, currentValue, unit) + " "
					+ FontAwesome.EXCLAMATION_TRIANGLE.getHtml());
			current.addStyleName(stylename);
		}
	}

	public void clearValues()
	{
		boxId.setValue("");
		current.setValue("");
	}
}
