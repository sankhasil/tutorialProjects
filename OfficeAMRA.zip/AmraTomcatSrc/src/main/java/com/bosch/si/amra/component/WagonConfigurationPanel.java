
package com.bosch.si.amra.component;

import java.util.List;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.entity.WagonType;
import com.bosch.si.amra.event.DashboardEvent.ClearValueEvent;
import com.bosch.si.amra.event.DashboardEvent.NotSuccessfulEvent;
import com.bosch.si.amra.event.DashboardEvent.UpdateMeansOfTransportEvent;
import com.bosch.si.amra.event.DashboardEvent.WagonSelectedEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.presenter.details.DetailsPresenterImpl;
import com.bosch.si.amra.view.administration.AdministrationView;
import com.bosch.si.amra.view.details.DetailsView;
import com.bosch.si.amra.view.overview.OverviewView;
import com.google.common.eventbus.Subscribe;
import com.vaadin.data.Property.ValueChangeEvent;
import com.vaadin.data.Property.ValueChangeListener;
import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.vaadin.data.fieldgroup.PropertyId;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.data.validator.IntegerRangeValidator;
import com.vaadin.data.validator.StringLengthValidator;
import com.vaadin.event.FieldEvents.TextChangeEvent;
import com.vaadin.event.FieldEvents.TextChangeListener;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Page;
import com.vaadin.server.VaadinSession;
import com.vaadin.shared.ui.MarginInfo;
import com.vaadin.shared.ui.combobox.FilteringMode;
import com.vaadin.ui.AbstractTextField.TextChangeEventMode;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.Component;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Notification.Type;
import com.vaadin.ui.Panel;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

@SuppressWarnings ("serial")
public class WagonConfigurationPanel extends Panel
{
	private static final long			serialVersionUID	= 4363097405470687223L;

	public static final String			ALIAS				= "alias";

	public static final String			BOX_ID				= "boxId";

	public static final String			WAGON_TYPE_NAME		= "wagonType.typeName";

	private final BeanFieldGroup<Wagon>	administrationFieldGroup;

	@PropertyId ("alias")
	private TextField					alias;

	@PropertyId ("wagonType")
	private ComboBox					wagonType;

	private Button						saveButton;

	private final List<WagonType>		wagonTypes;

	private TextField					mileageOffset;

	private Integer						offsetOldValue;

	public WagonConfigurationPanel(boolean isAdministrator, List<WagonType> wagonTypes)
	{
		DashboardEventBus.register(this);

		this.wagonTypes = wagonTypes;

		VerticalLayout verticalLayout = new VerticalLayout();
		verticalLayout.setWidth("100%");
		verticalLayout.setMargin(new MarginInfo(true, false, false, false));
		verticalLayout.setSpacing(true);
		addStyleName(ValoTheme.PANEL_BORDERLESS);

		setContent(verticalLayout);

		verticalLayout.addComponent(buildAlias());
		verticalLayout.addComponent(buildWagonType());
		verticalLayout.addComponent(buildWagonOffset());
		if (isAdministrator)
		{
			configureComponentsForAdministrator();
			verticalLayout.addComponent(buildSaveButton());
		}
		administrationFieldGroup = new BeanFieldGroup<Wagon>(Wagon.class);
		administrationFieldGroup.bindMemberFields(this);
		administrationFieldGroup.setBuffered(false);
	}

	private Component buildAlias()
	{
		alias = new TextField(
				DashboardUI.getMessageSource().getMessage("view.details.panel.alias"));
		alias.setWidth(100, Unit.PERCENTAGE);
		alias.setNullRepresentation("");
		alias.setImmediate(true);
		return alias;
	}

	private Component buildWagonType()
	{
		wagonType = new ComboBox(
				DashboardUI.getMessageSource().getMessage("view.details.panel.transportType"));
		wagonType.setImmediate(true);
		wagonType.setWidth(100, Unit.PERCENTAGE);
		wagonType.setContainerDataSource(new BeanItemContainer<>(WagonType.class, wagonTypes));
		wagonType.setItemCaptionPropertyId("typeName");
		return wagonType;
	}

	private Component buildWagonOffset()
	{
		mileageOffset = new TextField(
				DashboardUI.getMessageSource().getMessage("view.details.panel.mileageOffset"));
		mileageOffset.addValidator(new IntegerRangeValidator(
				DashboardUI.getMessageSource().getMessage("view.details.offset.error"),
				Integer.MIN_VALUE, Integer.MAX_VALUE));
		mileageOffset.setConversionError(
				DashboardUI.getMessageSource().getMessage("view.details.offset.error"));

		mileageOffset.setImmediate(true);
		mileageOffset.setNullSettingAllowed(true);
		mileageOffset.setNullRepresentation("");

		return mileageOffset;
	}

	private void configureComponentsForAdministrator()
	{
		configureAlias();
		configureWagonType();
	}

	private void configureAlias()
	{
		alias.setRequired(true);
		alias.setRequiredError(
				DashboardUI.getMessageSource().getMessage("view.administration.required.error"));
		alias.addValidator(new StringLengthValidator(
				DashboardUI.getMessageSource().getMessage("view.details.panel.validator.error"), 0,
				40, true));
		alias.setInputPrompt(
				DashboardUI.getMessageSource().getMessage("view.details.panel.alias.input"));
		alias.setTextChangeEventMode(TextChangeEventMode.LAZY);
		alias.addTextChangeListener(new TextChangeListener()
		{
			@Override
			public void textChange(TextChangeEvent event)
			{
				if (isTextValid(event.getText().trim()))
				{
					alias.setValidationVisible(false);
					if (wagonType.isValid())
						saveButton.setEnabled(true);
				}
				else
				{
					alias.setValidationVisible(true);
					saveButton.setEnabled(false);
				}
			}

			private boolean isTextValid(String text)
			{
				return !text.isEmpty() && text.length() <= 40;
			}
		});
	}

	private void configureWagonType()
	{
		wagonType.setTextInputAllowed(true);
		wagonType.setFilteringMode(FilteringMode.CONTAINS);
		wagonType.setRequired(true);
		wagonType.addValueChangeListener(new ValueChangeListener()
		{

			@Override
			public void valueChange(ValueChangeEvent event)
			{
				if (event.getProperty().getValue() != null)
				{
					if (alias.isValid())
						saveButton.setEnabled(true);
				}
				else
				{
					saveButton.setEnabled(false);
				}
			}
		});
	}

	private Component buildSaveButton()
	{
		saveButton = new Button(DashboardUI.getMessageSource().getMessage("view.details.save"));
		saveButton.setIcon(FontAwesome.SAVE);
		saveButton.addClickListener(new Button.ClickListener()
		{
			@Override
			public void buttonClick(ClickEvent event)
			{
				if (mileageOffset.isEmpty()
						|| (!mileageOffset.isEmpty() && mileageOffset.isValid()))
				{
					Wagon wagon = administrationFieldGroup.getItemDataSource().getBean();
					wagon.setOldMileageOffset(offsetOldValue);
					wagon.getAlias().trim();
					User user = (User) VaadinSession.getCurrent()
							.getAttribute(User.class.getName());
					DashboardEventBus
							.post(new UpdateMeansOfTransportEvent(wagon, user.getTenant()));
				}
				else
					Notification.show(DashboardUI.getMessageSource()
							.getMessage("view.details.offset.notification"));
			}
		});
		saveButton.setEnabled(false);
		return saveButton;
	}

	/**
	 * Called from {@link DetailsView} {@code buildToolbar()}, {@link OverviewView}
	 * {@code showDetailsForSelection()}, {@link OverviewView} {@code editSelectedWagon()} and
	 * {@link AdministrationView} {@code buildCreateWagon()}
	 *
	 * @param event
	 *            {@link WagonSelectedEvent}
	 */
	@Subscribe
	public void fillDetails(WagonSelectedEvent event)
	{
		Wagon wagon = event.getWagon();
		offsetOldValue = wagon.getMileageOffset();
		administrationFieldGroup.setItemDataSource(wagon);
		if (saveButton != null && wagon.getAlias() != null)
		{
			saveButton.setEnabled(true);
		}
	}

	/**
	 * Called from {@link DetailsPresenterImpl}
	 * {@code updateMetaDataForBox(ConfigurationSaveEvent event)} and {@link AdministrationView}
	 * {@code buildClearAllFields()}
	 *
	 * @param event
	 *            {@link ClearValueEvent}
	 */
	@Subscribe
	public void clearValues(ClearValueEvent event)
	{
		alias.setValue("");
		wagonType.setValue(null);
		if (saveButton != null)
			saveButton.setEnabled(false);
		alias.setValidationVisible(true);
		mileageOffset.setValue(null);
	}

	/**
	 * Called from {@link DetailsPresenterImpl} {@code updateMetaDataForBox()}
	 *
	 * @param event
	 *            {@link NotSuccessfulEvent}
	 */
	@Subscribe
	public void showUserFriendlyError(NotSuccessfulEvent event)
	{
		String code = event.getCode();
		Notification notification = new Notification(
				DashboardUI.getMessageSource().getMessage(code), Type.WARNING_MESSAGE);
		notification.setDelayMsec(1000);
		notification.show(Page.getCurrent());
	}

	@Override
	public void detach()
	{
		super.detach();

		DashboardEventBus.unregister(this);
	}
}
