
package com.bosch.si.amra.entity;

import java.io.Serializable;
import java.util.Date;

public class SensorData implements Serializable
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= -4990129745560375918L;

	private Integer				mileage;

	private Integer				batteryLevel;

	private BatterySeverity		batterySeverity;

	private LatLong				latLong;

	private Date				timestamp;

	private Integer				humidity;

	private Integer				temperature;

	private Integer				humidityTemperature;

	public enum BatterySeverity
	{
		NONE, WARN, ALARM;
	}

	public Integer getMileage()
	{
		return mileage;
	}

	public void setMileage(Integer mileage)
	{
		this.mileage = mileage;
	}

	public Integer getBatteryLevel()
	{
		return batteryLevel;
	}

	public void setBatteryLevel(Integer batteryLevel)
	{
		this.batteryLevel = batteryLevel;
	}

	public BatterySeverity getBatterySeverity()
	{
		return batterySeverity;
	}

	public void setBatterySeverity(BatterySeverity batterySeverity)
	{
		this.batterySeverity = batterySeverity;
	}

	public LatLong getLatLong()
	{
		return latLong;
	}

	public void setLatLong(LatLong latLong)
	{
		this.latLong = latLong;
	}

	public Date getTimestamp()
	{
		return timestamp;
	}

	public void setTimestamp(Date timestamp)
	{
		this.timestamp = timestamp;
	}

	public Integer getHumidity()
	{
		return humidity;
	}

	public void setHumidity(Integer humidity)
	{
		this.humidity = humidity;
	}

	public Integer getTemperature()
	{
		return temperature;
	}

	public void setTemperature(Integer temperature)
	{
		this.temperature = temperature;
	}

	public Integer getHumidityTemperature()
	{
		return humidityTemperature;
	}

	public void setHumidityTemperature(Integer humidityTemperature)
	{
		this.humidityTemperature = humidityTemperature;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((batteryLevel == null) ? 0 : batteryLevel.hashCode());
		result = prime * result + ((batterySeverity == null) ? 0 : batterySeverity.hashCode());
		result = prime * result + ((humidity == null) ? 0 : humidity.hashCode());
		result = prime * result + ((latLong == null) ? 0 : latLong.hashCode());
		result = prime * result + ((mileage == null) ? 0 : mileage.hashCode());
		result = prime * result + ((temperature == null) ? 0 : temperature.hashCode());
		result = prime * result + ((timestamp == null) ? 0 : timestamp.hashCode());
		result = prime * result
				+ ((humidityTemperature == null) ? 0 : humidityTemperature.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SensorData other = (SensorData) obj;
		if (batteryLevel == null)
		{
			if (other.batteryLevel != null)
				return false;
		}
		else if (!batteryLevel.equals(other.batteryLevel))
			return false;
		if (batterySeverity != other.batterySeverity)
			return false;
		if (humidity == null)
		{
			if (other.humidity != null)
				return false;
		}
		else if (!humidity.equals(other.humidity))
			return false;
		if (latLong == null)
		{
			if (other.latLong != null)
				return false;
		}
		else if (!latLong.equals(other.latLong))
			return false;
		if (mileage == null)
		{
			if (other.mileage != null)
				return false;
		}
		else if (!mileage.equals(other.mileage))
			return false;
		if (temperature == null)
		{
			if (other.temperature != null)
				return false;
		}
		else if (!temperature.equals(other.temperature))
			return false;
		if (timestamp == null)
		{
			if (other.timestamp != null)
				return false;
		}
		else if (!humidityTemperature.equals(other.humidityTemperature))
			return false;
		if (humidityTemperature == null)
		{
			if (other.humidityTemperature != null)
				return false;
		}
		else if (!timestamp.equals(other.timestamp))
			return false;
		return true;
	}
}
