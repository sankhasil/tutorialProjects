
package com.bosch.si.amra.presenter.configuration;

import java.io.Serializable;
import java.util.List;

import org.springframework.stereotype.Component;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.constants.UIConstants;
import com.bosch.si.amra.constants.configuration.ConfigurationConstants;
import com.bosch.si.amra.entity.configuration.Configuration;
import com.bosch.si.amra.event.DashboardEvent;
import com.bosch.si.amra.event.DashboardEvent.ConfigurationSortAndFilterEvent;
import com.bosch.si.amra.event.DashboardEvent.ConfigurationsEvent;
import com.bosch.si.amra.event.DashboardEvent.ConfigurationsSaveAliasEvent;
import com.bosch.si.amra.event.DashboardEvent.ConfigurationsSaveEvent;
import com.bosch.si.amra.event.DashboardEvent.ConfigurationsSavedEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.provider.DataProviderInitializer;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.WriteResult;

/**
 * Implementation of configuration presenter
 *
 * @author toa1wa3
 *
 */
@Component
public class ConfigurationPresenterImpl implements Serializable, ConfigurationPresenter
{
	/**
	 * Serial version uid
	 */
	private static final long serialVersionUID = -7518329456726015816L;

	@Override
	public List<Configuration> getConfigurations(ConfigurationsEvent event)
	{
		String tenantId = event.getTenantId();
		isTenantNull(tenantId);

		List<Configuration> configurations = DashboardUI.getConfigurationDataProvider()
				.getConfigurations(tenantId);
		DashboardEventBus.post(new DashboardEvent.ConfigurationSetEvent(configurations));
		return configurations;
	}

	@Override
	public List<Configuration> sortAndFilter(ConfigurationSortAndFilterEvent event)
	{
		String tenantId = event.getTenantId();
		isTenantNull(tenantId);
		String propertyToSort = event.getPropertyToSort();
		boolean ascending = event.isAscending();
		String filterText = event.getFilterText();

		DBObject find = new BasicDBObject(MongoConstants.TENANT_ID, tenantId);
		buildFilterCriteria(filterText, find);
		DBObject sort = buildSortCriteria(propertyToSort, ascending);

		DBCollection configurationCollection = getConfigurationCollection();
		DBCursor configurationsCursor = configurationCollection.find(find).sort(sort);

		List<Configuration> configurationsList = DashboardUI.getConfigurationDataProvider()
				.createConfigurationsList(configurationsCursor);
		DashboardEventBus.post(new DashboardEvent.ConfigurationSetEvent(configurationsList));
		return configurationsList;
	}

	@Override
	public void saveConfigurations(ConfigurationsSaveEvent event)
	{
		String tenantId = event.getTenantId();
		isTenantNull(tenantId);
		List<Configuration> configurations = event.getConfigurations();
		if (configurations == null || configurations.isEmpty())
		{
			throw new IllegalArgumentException(UIConstants.LIST_MUST_NOT_BE_NULL);
		}

		DBCollection configurationCollection = getConfigurationCollection();
		for (Configuration configuration : configurations)
		{
			saveConfigurationsInMongo(configurationCollection, configuration);
			if (!configuration.isRouting())
				disableRoutingForBox(getTelematicCollection(), configuration);
		}
		DashboardEventBus.post(new ConfigurationsSavedEvent(configurations));
	}

	private void isTenantNull(String tenantId)
	{
		if (tenantId == null || tenantId.isEmpty())
		{
			throw new IllegalArgumentException(UIConstants.TENANT_ID_MUST_NOT_BE_NULL);
		}
	}

	private void buildFilterCriteria(String filterText, DBObject find)
	{
		if (filterText != null && !filterText.isEmpty())
		{
			find.put(MongoConstants.SORT,
					new BasicDBObject("$regex", filterText).append("$options", "i"));
		}
	}

	/**
	 * Creates the sort criteria if the propertyToSort is available and an ordering is given. If not
	 * take the default ascending order for the alias
	 *
	 * @param propertyToSort
	 *            property to be sorted
	 * @param ascending
	 *            ascending order
	 * @return the sorted result
	 */
	private DBObject buildSortCriteria(String propertyToSort, boolean ascending)
	{
		DBObject sort = new BasicDBObject();
		if (propertyToSort != null && !propertyToSort.isEmpty())
		{
			sort.put(ConfigurationConstants.MAPPING.get(propertyToSort),
					ConfigurationConstants.ASCENDING.get(ascending));
		}
		else
		{
			sort.put(MongoConstants.SORT, ConfigurationConstants.ASCENDING.get(ascending));
		}
		return sort;
	}

	private DBCollection getConfigurationCollection()
	{
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		return db.getCollection(DashboardUI.getConfigurationCollection());
	}

	private DBCollection getTelematicCollection()
	{
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		return db.getCollection(DashboardUI.getEventCollection());
	}

	private void saveConfigurationsInMongo(DBCollection configurationCollection,
			Configuration configuration)
	{
		DBObject configurationObject = Configuration.configuration2dbObject(configuration);
		DBObject updateObject = new BasicDBObject("$set", configurationObject);
		DBObject criteria = new BasicDBObject(MongoConstants.ID, configuration.getId());
		configurationCollection.update(criteria, updateObject, true, false);
	}

	private void disableRoutingForBox(DBCollection telematicCollection, Configuration configuration)
	{
		DBObject criteria = new BasicDBObject(MongoConstants.WAGON_ID, configuration.getWagonId());
		criteria.put(MongoConstants.PROCESSED, false);
		DBObject updateObject = new BasicDBObject("$set",
				new BasicDBObject(MongoConstants.PROCESSED, true));
		telematicCollection.update(criteria, updateObject, false, false);
	}

	@Override
	public WriteResult saveAliasInConfigurations(ConfigurationsSaveAliasEvent event)
	{
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DBCollection configurationCollection = mongoClient.getDB(DashboardUI.getMongoDatabase())
				.getCollection(DashboardUI.getConfigurationCollection());

		String configurationId = event.getConfigurationId();
		String alias = event.getAlias();

		if (configurationId != null)
		{

			DBObject criteria = new BasicDBObject(MongoConstants.ID, configurationId);
			DBObject aliasAndSortUpdate = new BasicDBObject(MongoConstants.ALIAS, alias);
			aliasAndSortUpdate.put(MongoConstants.SORT, alias.trim().toLowerCase());
			DBObject update = new BasicDBObject("$set", aliasAndSortUpdate);

			return configurationCollection.update(criteria, update, false, false);
		}
		return null;
	}
}
