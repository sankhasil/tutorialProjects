
package com.bosch.si.amra;

import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import javax.servlet.annotation.WebListener;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.web.context.ContextLoaderListener;

import com.bosch.si.amra.constants.MetricsConstants;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.constants.UIConstants;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.event.DashboardEvent.BrowserResizeEvent;
import com.bosch.si.amra.event.DashboardEvent.ClearValueEvent;
import com.bosch.si.amra.event.DashboardEvent.CloseOpenWindowsEvent;
import com.bosch.si.amra.event.DashboardEvent.CommunicationProblemEvent;
import com.bosch.si.amra.event.DashboardEvent.LoginFailedEvent;
import com.bosch.si.amra.event.DashboardEvent.SaveUserSettingsEvent;
import com.bosch.si.amra.event.DashboardEvent.UserLoggedInEvent;
import com.bosch.si.amra.event.DashboardEvent.UserLoggedOutEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.im.login.IdentityManagementUtil;
import com.bosch.si.amra.metrics.MetricsFactory;
import com.bosch.si.amra.metrics.MetricsLoggerFactory;
import com.bosch.si.amra.presenter.administration.AdministrationPresenter;
import com.bosch.si.amra.presenter.configuration.ConfigurationPresenter;
import com.bosch.si.amra.presenter.details.DetailsPresenter;
import com.bosch.si.amra.presenter.export.ExportPresenter;
import com.bosch.si.amra.presenter.fleetbalancing.FleetBalancingPresenter;
import com.bosch.si.amra.presenter.geofence.GeofencePresenter;
import com.bosch.si.amra.presenter.notification.NotificationPresenter;
import com.bosch.si.amra.presenter.overview.OverviewPresenter;
import com.bosch.si.amra.presenter.report.ReportPresenter;
import com.bosch.si.amra.presenter.role.RolePresenter;
import com.bosch.si.amra.presenter.rule.RulePresenter;
import com.bosch.si.amra.provider.AggregationDataProvider;
import com.bosch.si.amra.provider.NewDataProvider;
import com.bosch.si.amra.provider.UserSessionDataProvider;
import com.bosch.si.amra.provider.configuration.ConfigurationDataProvider;
import com.bosch.si.amra.provider.details.DetailsDataProvider;
import com.bosch.si.amra.provider.geofence.GeofenceDataProvider;
import com.bosch.si.amra.provider.notification.NotificationDataProvider;
import com.bosch.si.amra.provider.role.RoleDataProvider;
import com.bosch.si.amra.provider.rule.RuleDataProvider;
import com.bosch.si.amra.view.AmraView;
import com.bosch.si.amra.view.LoginView;
import com.bosch.si.amra.view.MainView;
import com.bosch.si.amra.view.UserNotification;
import com.bosch.si.fleet.common.error.GeneralErrorHandler;
import com.bosch.si.fleet.common.internationalization.I18n;
import com.codahale.metrics.JmxReporter;
import com.codahale.metrics.MetricRegistry;
import com.google.common.eventbus.Subscribe;
import com.mongodb.DBObject;
import com.vaadin.annotations.PreserveOnRefresh;
import com.vaadin.annotations.Theme;
import com.vaadin.annotations.Title;
import com.vaadin.annotations.Widgetset;
import com.vaadin.server.Page;
import com.vaadin.server.Page.BrowserWindowResizeEvent;
import com.vaadin.server.Page.BrowserWindowResizeListener;
import com.vaadin.server.Responsive;
import com.vaadin.server.VaadinRequest;
import com.vaadin.server.VaadinService;
import com.vaadin.server.VaadinSession;
import com.vaadin.spring.annotation.SpringUI;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Notification.Type;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;
import com.vaadin.ui.themes.ValoTheme;

@SpringUI
@Scope ("prototype")
@Theme ("dashboard")
@Widgetset ("com.bosch.si.amra.AmraWidgetSet")
@Title ("AMRA")
@SuppressWarnings ("serial")
@PreserveOnRefresh
public class DashboardUI extends UI
{

	@WebListener
	public static class AmraContextLoaderListener extends ContextLoaderListener
	{

	}

	private static transient final MetricRegistry	metrics				= new MetricRegistry();

	private static transient final JmxReporter		reporter			= JmxReporter
			.forRegistry(metrics).convertDurationsTo(TimeUnit.MILLISECONDS)
			.convertRatesTo(TimeUnit.MILLISECONDS).inDomain(MetricsConstants.UI_DOMAIN).build();

	public transient DashboardEventBus				dashboardEventbus	= new DashboardEventBus();

	@Autowired
	private transient NewDataProvider				dataProvider;

	@Autowired
	private transient AggregationDataProvider		aggregationDataProvider;

	@Autowired
	private transient ConfigurationDataProvider		configurationDataProvider;

	@Autowired
	private transient NotificationDataProvider		notificationDataProvider;

	@Autowired
	private transient GeofenceDataProvider			geofenceDataProvider;

	@Autowired
	private transient RuleDataProvider				ruleDataProvider;

	@Autowired
	private transient RoleDataProvider				disponentsRolesDataProvider;

	@Autowired
	private transient DetailsDataProvider			detailsDataProvider;

	@Autowired
	private transient UserSessionDataProvider		userSessionDataProvider;

	@Autowired
	private I18n									i18n;

	@Autowired
	private transient IdentityManagementUtil		util;

	@Autowired
	private OverviewPresenter						overviewPresenter;

	@Autowired
	private DetailsPresenter						wagonConfigurationPresenter;

	@Autowired
	private AdministrationPresenter					administrationPresenter;

	@Autowired
	private ReportPresenter							reportPresenter;

	@Autowired
	private FleetBalancingPresenter					fleetBalancingPresenter;

	@Autowired
	private NotificationPresenter					notificationPresenter;

	@Autowired
	private ConfigurationPresenter					configurationPresenter;

	@Autowired
	private GeofencePresenter						geofencePresenter;

	@Autowired
	private ExportPresenter							exportPresenter;

	@Autowired
	private RulePresenter							rulePresenter;

	@Autowired
	private RolePresenter							disponentsPresenter;

	@Autowired
	private GeneralErrorHandler						errorHandler;

	@Value ("${GOOGLE_API_KEY_OR_CLIENT_ID}")
	public String									GOOGLE_API_KEY_OR_CLIENT_ID;

	@Value ("${USE_PROXY}")
	public String									PROXY;

	@Value ("${USE_OPENCAGE_DATA}")
	public String									USE_OPENCAGE_DATA;

	@Value ("${HOST}")
	public String									HOST;

	@Value ("${PORT}")
	public Integer									PORT;

	@Value ("${OPENCAGE_URL}")
	public String									OPENCAGE_URL;

	@Value ("${OPENCAGE_API_KEY}")
	public String									OPENCAGE_API_KEY;

	@Value ("${MONGO_HOST}")
	public String									MONGO_HOST;

	@Value ("${MONGO_PORT}")
	public Integer									MONGO_PORT;

	@Value ("${MONGO_DATABASE}")
	public String									MONGO_DATABASE;

	@Value ("${MONGO_USERNAME}")
	public String									MONGO_USERNAME;

	@Value ("${MONGO_PASSWORD}")
	public String									MONGO_PASSWORD;

	@Value ("${MONGO_COLLECTION}")
	public String									MONGO_COLLECTION;

	@Value ("${EVENT_COLLECTION}")
	public String									EVENT_COLLECTION;

	@Value ("${TELEMATIC_UNWIND_COLLECTION}")
	public String									TELEMATIC_UNWIND_COLLECTION;

	@Value ("${MILEAGE_COLLECTION}")
	public String									MILEAGE_COLLECTION;

	@Value ("${ROUTING_COLLECTION}")
	public String									ROUTING_COLLECTION;

	@Value ("${CURRENT_COLLECTION}")
	public String									CURRENT_COLLECTION;

	@Value ("${WAGON_TYPE_COLLECTION}")
	private String									WAGON_TYPE_COLLECTION;

	@Value ("${WAGON_COLLECTION}")
	private String									WAGON_COLLECTION;

	@Value ("${NOTIFICATION_COLLECTION}")
	private String									NOTIFICATION_COLLECTION;

	@Value ("${CONFIGURATION_COLLECTION}")
	private String									CONFIGURATION_COLLECTION;

	@Value ("${GEOFENCE_COLLECTION}")
	private String									GEOFENCE_COLLECTION;

	@Value ("${RULE_COLLECTION}")
	private String									RULE_COLLECTION;

	@Value ("${TAG_COLLECTION}")
	private String									TAG_COLLECTION;

	@Value ("${USERSESSION_COLLECTION}")
	private String									USERSESSION_COLLECTION;

	@Value ("${SHOCK_MAX}")
	private Double									SHOCK_MAX;

	@Value ("${SHOCK_MIN}")
	private Double									SHOCK_MIN;

	@Value ("${DETAILS_MAP_MARKER_BUTTON_FLAG}")
	private Boolean									DETAILS_MAP_MARKER_BUTTON_FLAG;

	@Override
	protected void init(VaadinRequest request)
	{
		reporter.start();
		setWebAppSettings(request);
		registerEventBusListener();

		Responsive.makeResponsive(this);
		addStyleName(ValoTheme.UI_WITH_MENU);

		updateContent();

		addWindowResizeListener();

	}

	private void setWebAppSettings(VaadinRequest request)
	{
		DashboardSessionInitListener dashboardSessionInitListener = new DashboardSessionInitListener();
		VaadinService.getCurrent().addSessionInitListener(dashboardSessionInitListener);
		VaadinService.getCurrent().addSessionDestroyListener(dashboardSessionInitListener);

		VaadinSession.getCurrent().setErrorHandler(errorHandler);
		VaadinSession.getCurrent().setLocale(request.getLocale());
	}

	private void registerEventBusListener()
	{
		DashboardEventBus.register(this);
		DashboardEventBus.register(util);
		DashboardEventBus.register(overviewPresenter);
		DashboardEventBus.register(wagonConfigurationPresenter);
		DashboardEventBus.register(administrationPresenter);
		DashboardEventBus.register(reportPresenter);
		DashboardEventBus.register(fleetBalancingPresenter);
		DashboardEventBus.register(notificationPresenter);
		DashboardEventBus.register(configurationPresenter);
		DashboardEventBus.register(geofencePresenter);
		DashboardEventBus.register(exportPresenter);
		DashboardEventBus.register(rulePresenter);
		DashboardEventBus.register(disponentsPresenter);
	}

	private void unregisterEventBusListener()
	{
		DashboardEventBus.unregister(this);
		DashboardEventBus.unregister(util);
		DashboardEventBus.unregister(overviewPresenter);
		DashboardEventBus.unregister(wagonConfigurationPresenter);
		DashboardEventBus.unregister(administrationPresenter);
		DashboardEventBus.unregister(reportPresenter);
		DashboardEventBus.unregister(fleetBalancingPresenter);
		DashboardEventBus.unregister(notificationPresenter);
		DashboardEventBus.unregister(configurationPresenter);
		DashboardEventBus.unregister(geofencePresenter);
		DashboardEventBus.unregister(exportPresenter);
		DashboardEventBus.unregister(rulePresenter);
		DashboardEventBus.unregister(disponentsPresenter);
	}

	private void updateContent()
	{
		User user = (User) VaadinSession.getCurrent().getAttribute(User.class.getName());
		if (user != null)
		{
			MetricsFactory.createCounter(MetricsConstants.UI_LOGIN_PREFIX,
					user.getTenantName() + "." + user.getTechnialName()).inc();
			MetricsLoggerFactory.log(MetricsConstants.UI_LOGIN_PREFIX,
					user.getTenantName() + "." + user.getTechnialName());
			// Authenticated user
			setContent(new MainView());
			removeStyleName("loginview");
			List<Wagon> wagons = getDataProvider().getWagonsShort(user);
			String viewState = "";
			if (wagons.size() <= 0)
			{
				if (user.isAdmin() || user.isSuperAdmin())
				{
					viewState = AmraView.ADMINISTRATION.getViewName();
					Notification.show(getMessageSource().getMessage("noentries"),
							Type.HUMANIZED_MESSAGE);
				}
				else
				{
					viewState = AmraView.DASHBOARD.getViewName();
					Notification.show(getMessageSource().getMessage("noentries.disponent"),
							Type.HUMANIZED_MESSAGE);
				}
			}
			else
			{
				viewState = getNavigator().getState();
			}
			getNavigator().navigateTo(viewState);
		}
		else
		{
			setContent(new LoginView());
			addStyleName("loginview");
		}
	}

	private void addWindowResizeListener()
	{
		Page.getCurrent().addBrowserWindowResizeListener(new BrowserWindowResizeListener()
		{
			@Override
			public void browserWindowResized(BrowserWindowResizeEvent event)
			{
				DashboardEventBus.post(new BrowserResizeEvent());
			}
		});
	}

	@Subscribe
	public void userLoggedIn(UserLoggedInEvent event)
	{
		VaadinSession.getCurrent().setAttribute(User.class.getName(), event.getUser());
		fetchSessionData(event.getUser());
		updateContent();
	}

	@Subscribe
	public void userLoggedOut(UserLoggedOutEvent event)
	{
		User user = (User) VaadinSession.getCurrent().getAttribute(User.class.getName());
		MetricsFactory.createCounter(MetricsConstants.UI_LOGOUT_PREFIX,
				user.getTenantName() + "." + user.getTechnialName()).inc();
		MetricsLoggerFactory.log(MetricsConstants.UI_LOGOUT_PREFIX,
				user.getTenantName() + "." + user.getTechnialName());
		saveSessionData();
		unregisterEventBusListener();
		VaadinSession.getCurrent().close();
		Page.getCurrent().reload();
	}

	private void fetchSessionData(User user)
	{
		DBObject userSettings = DashboardUI.getUserSessionDataProvider().getUserSettings(user);
		VaadinSession.getCurrent().setAttribute(UIConstants.OVERVIEW_VIEW_SESSION_OBJECT,
				DashboardUI.getUserSessionDataProvider().fetchCurrentUserSettings(userSettings,
						MongoConstants.OVERVIEW_PAGE));
		VaadinSession.getCurrent().setAttribute(UIConstants.DISPONENT_VIEW_SESSION_OBJECT,
				DashboardUI.getUserSessionDataProvider().fetchCurrentUserSettings(userSettings,
						MongoConstants.DISPONENT_PAGE));
		VaadinSession.getCurrent().setAttribute(UIConstants.DISPONENT_HISTORY_SESSION_OBJECT,
				DashboardUI.getUserSessionDataProvider().fetchCurrentUserSettings(userSettings,
						MongoConstants.DISPONENT_HISTORY_PAGE));
		VaadinSession.getCurrent().setAttribute(UIConstants.FLEET_BALANCING_VIEW_SESSION_OBJECT,
				DashboardUI.getUserSessionDataProvider().fetchCurrentUserSettings(userSettings,
						MongoConstants.FLEET_BALANCING_PAGE));
	}

	private void saveSessionData()
	{
		if (getNavigator().getState().equals(AmraView.OVERVIEW)
				|| getNavigator().getState().equals(AmraView.DISPONENT))
			DashboardEventBus.post(new SaveUserSettingsEvent());
	}

	@Subscribe
	public void loginFailed(LoginFailedEvent event)
	{
		updateContent();
		Notification.show(DashboardUI.getMessageSource().getMessage("login.failed"),
				Type.HUMANIZED_MESSAGE);
	}

	@Subscribe
	public void communicationProblems(CommunicationProblemEvent event)
	{
		new UserNotification(event.getMessageCode(), 1000, false);
	}

	@Subscribe
	public void closeOpenWindows(CloseOpenWindowsEvent event)
	{
		for (Window window : getWindows())
		{
			window.close();
		}
	}

	@Subscribe
	public void updateValues(ClearValueEvent event)
	{
		// TODO: Remove when all administration panels are separated
		DashboardUI.getCurrent().getNavigator()
				.navigateTo(DashboardUI.getCurrent().getNavigator().getState());
	}

	public static TimeZone getUserTimeZone()
	{
		int rawOffset = Page.getCurrent().getWebBrowser().getRawTimezoneOffset();
		int dstSavings = Page.getCurrent().getWebBrowser().getDSTSavings();

		String[] availableIDs = TimeZone.getAvailableIDs(rawOffset);
		for (String id : availableIDs)
		{
			TimeZone timeZone = TimeZone.getTimeZone(id);
			if (dstSavings == timeZone.getDSTSavings())
			{
				return timeZone;
			}
		}
		return TimeZone.getDefault();
	}

	public static MetricRegistry getMetrics()
	{
		return DashboardUI.metrics;
	}

	public static NewDataProvider getDataProvider()
	{
		return ((DashboardUI) getCurrent()).dataProvider;
	}

	public static AggregationDataProvider getAggregationDataProvider()
	{
		return ((DashboardUI) getCurrent()).aggregationDataProvider;
	}

	public static ConfigurationDataProvider getConfigurationDataProvider()
	{
		return ((DashboardUI) getCurrent()).configurationDataProvider;
	}

	public static NotificationDataProvider getNotificationDataProvider()
	{
		return ((DashboardUI) getCurrent()).notificationDataProvider;
	}

	public static GeofenceDataProvider getGeofenceDataProvider()
	{
		return ((DashboardUI) getCurrent()).geofenceDataProvider;
	}

	public static RuleDataProvider getRuleDataProvider()
	{
		return ((DashboardUI) getCurrent()).ruleDataProvider;
	}

	public static RoleDataProvider getDisponentsRolesDataProvider()
	{
		return ((DashboardUI) getCurrent()).disponentsRolesDataProvider;
	}

	public static DetailsDataProvider getDetailsDataProvider()
	{
		return ((DashboardUI) getCurrent()).detailsDataProvider;
	}

	public static UserSessionDataProvider getUserSessionDataProvider()
	{
		return ((DashboardUI) getCurrent()).userSessionDataProvider;
	}

	public static I18n getMessageSource()
	{
		return ((DashboardUI) getCurrent()).i18n;
	}

	public static String getGoogleAPIKey()
	{
		return ((DashboardUI) getCurrent()).GOOGLE_API_KEY_OR_CLIENT_ID;
	}

	public static String getMongoHost()
	{
		return ((DashboardUI) getCurrent()).MONGO_HOST;
	}

	public static Integer getMongoPort()
	{
		return ((DashboardUI) getCurrent()).MONGO_PORT;
	}

	public static String getMongoDatabase()
	{
		return ((DashboardUI) getCurrent()).MONGO_DATABASE;
	}

	public static String getMongoUsername()
	{
		return ((DashboardUI) getCurrent()).MONGO_USERNAME;
	}

	public static String getMongoPassword()
	{
		return ((DashboardUI) getCurrent()).MONGO_PASSWORD;
	}

	public static String getMongoCollection()
	{
		return ((DashboardUI) getCurrent()).MONGO_COLLECTION;
	}

	public static String getEventCollection()
	{
		return ((DashboardUI) getCurrent()).EVENT_COLLECTION;
	}

	public static String getTelematicUnwind()
	{
		return ((DashboardUI) getCurrent()).TELEMATIC_UNWIND_COLLECTION;
	}

	public static String getMongoMileageCollection()
	{
		return ((DashboardUI) getCurrent()).MILEAGE_COLLECTION;
	}

	public static String getMongoRoutingCollection()
	{
		return ((DashboardUI) getCurrent()).ROUTING_COLLECTION;
	}

	public static String getMongoCurrentCollection()
	{
		return ((DashboardUI) getCurrent()).CURRENT_COLLECTION;
	}

	public static String getMongoTagCollection()
	{
		return ((DashboardUI) getCurrent()).TAG_COLLECTION;
	}

	public static String getMongoUserSessionCollection()
	{
		return ((DashboardUI) getCurrent()).USERSESSION_COLLECTION;
	}

	public static String isProxyUsed()
	{
		return ((DashboardUI) getCurrent()).PROXY;
	}

	public static String isOpenCageDataUsed()
	{
		return ((DashboardUI) getCurrent()).USE_OPENCAGE_DATA;
	}

	public static String getHost()
	{
		return ((DashboardUI) getCurrent()).HOST;
	}

	public static Integer getPort()
	{
		return ((DashboardUI) getCurrent()).PORT;
	}

	public static String getOpencageUrl()
	{
		return ((DashboardUI) getCurrent()).OPENCAGE_URL;
	}

	public static String getOpencageApiKey()
	{
		return ((DashboardUI) getCurrent()).OPENCAGE_API_KEY;
	}

	public static String getWagonTypeCollection()
	{
		return ((DashboardUI) getCurrent()).WAGON_TYPE_COLLECTION;
	}

	public static String getWagonCollection()
	{
		return ((DashboardUI) getCurrent()).WAGON_COLLECTION;
	}

	public static String getNotificationCollection()
	{
		return ((DashboardUI) getCurrent()).NOTIFICATION_COLLECTION;
	}

	public static String getConfigurationCollection()
	{
		return ((DashboardUI) getCurrent()).CONFIGURATION_COLLECTION;
	}

	public static String getGeofenceCollection()
	{
		return ((DashboardUI) getCurrent()).GEOFENCE_COLLECTION;
	}

	public static String getRuleCollection()
	{
		return ((DashboardUI) getCurrent()).RULE_COLLECTION;
	}

	public static Double getShockMax()
	{
		return ((DashboardUI) getCurrent()).SHOCK_MAX;
	}

	public static Double getShockMin()
	{
		return ((DashboardUI) getCurrent()).SHOCK_MIN;
	}

	public static Boolean getDETAILS_MAP_MARKER_BUTTON_FLAG()
	{
		return ((DashboardUI) getCurrent()).DETAILS_MAP_MARKER_BUTTON_FLAG;
	}

}
