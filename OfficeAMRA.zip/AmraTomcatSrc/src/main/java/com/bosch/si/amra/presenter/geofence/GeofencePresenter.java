
package com.bosch.si.amra.presenter.geofence;

import com.bosch.si.amra.entity.geofence.Geofence;
import com.bosch.si.amra.event.DashboardEvent.GeofenceDeleteEvent;
import com.bosch.si.amra.event.DashboardEvent.GeofenceSaveEvent;
import com.bosch.si.amra.event.DashboardEvent.GeofenceSelectEvent;
import com.google.common.eventbus.Subscribe;
import com.mongodb.WriteResult;

/**
 * Interface for {@link GeofencePresenterImpl}. This is needed for Spring because the actual
 * bean instance is a JDK dynamic proxy which implements this interface and calls the concrete
 * implementation
 *
 * @author toa1wa3
 *
 */
public interface GeofencePresenter
{
	/**
	 * Saves the given geofence
	 *
	 * @param event
	 *            {@link GeofenceSaveEvent}. The event contains the geofence to be saved and the
	 *            tenantId the geofence belongs to
	 * @return WriteResult of the save
	 */
	@Subscribe
	public WriteResult saveGeofence(GeofenceSaveEvent event);

	/**
	 * Displays the geofence for the given id
	 *
	 * @param event
	 *            {@link GeofenceSelectEvent} The event contains the selected geofence Id
	 * @return The selected {@link Geofence} to be displayed for the given tenant
	 */
	@Subscribe
	public Geofence showGeofence(GeofenceSelectEvent event);

	/**
	 * Delete the geofence
	 *
	 * @param event
	 *            {@link GeofenceDeleteEvent}. The event contains the geofence Id to delete the
	 *            corresponding Geofence
	 */
	@Subscribe
	public void deleteGeofence(GeofenceDeleteEvent event);

}
