
package com.bosch.si.amra.view.formatter;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.rule.Rule;
import com.vaadin.data.Property;

public class RuleConditionFormatter extends PropertyFormatter
{
	@Override
	public String format(Object rowId, Property<?> property, String result)
	{
		Rule rule = (Rule) rowId;
		return rule.getCondition() != null ? new String(DashboardUI.getMessageSource()
				.getMessage("view.alarm.selectcondition." + rule.getCondition().toLowerCase()))
				: "";
	}
}
