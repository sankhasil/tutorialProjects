
package com.bosch.si.amra.view.notification;

import com.bosch.si.amra.constants.notification.NotificationConstants;
import com.bosch.si.amra.entity.notification.Notification;
import com.vaadin.ui.Grid.CellReference;
import com.vaadin.ui.Grid.CellStyleGenerator;

public class NotificationTableCellStyleGenerator implements CellStyleGenerator
{
	/**
	 * Serial version uid
	 */
	private static final long serialVersionUID = -2015789282955474134L;

	@Override
	public String getStyle(CellReference cell)
	{
		Notification notification = (Notification) cell.getItemId();
		if (NotificationConstants.PRIORITY.equals(cell.getPropertyId()))
		{
			if (notification != null)
			{
				switch (notification.getPriority())
				{
					case RED:
						return "red";
					case YELLOW:
						return "yellow";
					case GREEN:
						return "green";
					default:
						break;
				}
			}
		}
		if (!notification.isAcknowledged())
		{
			return "acknowledged";
		}
		else
		{
			return null;
		}
	}
}
