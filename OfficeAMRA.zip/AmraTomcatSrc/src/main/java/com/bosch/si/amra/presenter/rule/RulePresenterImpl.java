
package com.bosch.si.amra.presenter.rule;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.constants.UIConstants;
import com.bosch.si.amra.constants.monitoring.AlarmConstants;
import com.bosch.si.amra.constants.rule.RuleConstants;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.entity.rule.Rule;
import com.bosch.si.amra.event.DashboardEvent;
import com.bosch.si.amra.event.DashboardEvent.NotSuccessfulEvent;
import com.bosch.si.amra.event.DashboardEvent.RuleReadEvent;
import com.bosch.si.amra.event.DashboardEvent.RuleSaveEvent;
import com.bosch.si.amra.event.DashboardEvent.RuleSortAndFilterEvent;
import com.bosch.si.amra.event.DashboardEvent.RulesDeleteEvent;
import com.bosch.si.amra.event.DashboardEvent.RulesSaveAliasEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.provider.DataProviderInitializer;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.DuplicateKeyException;
import com.mongodb.MongoClient;
import com.mongodb.WriteResult;

@Component
public class RulePresenterImpl implements RulePresenter
{
	private static final Logger logger = LoggerFactory.getLogger(RulePresenterImpl.class);

	@Override
	public WriteResult saveRule(RuleSaveEvent event)
	{
		WriteResult result = null;
		String tenantId = event.getTenantId();
		if (tenantId == null || tenantId.isEmpty())
		{
			throw new IllegalArgumentException(UIConstants.TENANT_ID_MUST_NOT_BE_NULL);
		}

		Rule rule = event.getRule();
		if (rule == null)
		{
			logger.error("Rule must not be null for tenant{}", tenantId);
			DashboardEventBus.post(new NotSuccessfulEvent("view.alarm.noname"));
			throw new IllegalArgumentException("Rule must not be null.");
		}
		else
		{
			if (!rule.isValid())
			{
				logger.error("Rule must not be valid for tenant{}", tenantId);
				DashboardEventBus.post(new NotSuccessfulEvent("view.alarm.noname"));
				throw new IllegalArgumentException("Rule must not be valid");
			}
		}
		if (rule.getRuleType().equals(RuleConstants.HUMIDITY_TEMPERATURE_RANGE))
		{
			List<Rule> rulesWithAssignedWagons = DashboardUI.getRuleDataProvider()
					.getRulesWithSameRuleTypeAndAssignedWagons(tenantId, rule);
			Set<Wagon> alreadyAssignedWagons = DashboardUI.getRuleDataProvider()
					.getAlreadyAssignedWagonsToRules(tenantId, rule);
			String[] wagonAliases = alreadyAssignedWagons.stream()
					.map(wagon -> new String(wagon.getAlias())).toArray(size -> new String[size]);
			String[] ruleNames = rulesWithAssignedWagons.stream()
					.map(assignedRule -> new String(assignedRule.getName()))
					.toArray(size -> new String[size]);
			if (wagonAliases != null && wagonAliases.length > 0)
			{
				logger.error("{} already assigned to Rule(s) : {}", wagonAliases, ruleNames);
				DashboardEventBus.post(new DashboardEvent.TemperatureRangeRuleFailedSavedEvent(rule,
						wagonAliases, ruleNames));
				return null;
			}
		}

		try
		{

			DBCollection ruleCollection = DataProviderInitializer
					.getCollection(DashboardUI.getRuleCollection());
			DBObject ruleToSave = Rule.rule2DBObject(rule, tenantId);
			result = ruleCollection.save(ruleToSave);

			if (rule.getRuleType().equals(RuleConstants.HUMIDITY_TEMPERATURE_RANGE)
					&& rule.getActive() != null)
			{
				if (rule.getActive().equals(Boolean.FALSE))
				{
					updateTemperatureRangeInConfigurationCollection(rule.getWagons(), 0, 0);
				}
				else
				{
					updateTemperatureRangeInConfigurationCollection(rule.getWagons(),
							rule.getMinRange(), rule.getMaxRange());
				}
				List<Wagon> deassignedWagons = findDeassignedWagonsToRule(rule,
						event.getPrimaryAssignedWagonsToRule());
				updateTemperatureRangeInConfigurationCollection(deassignedWagons, 0, 0);
			}
			logger.debug("Rule saved");
			List<Rule> rules = getRules(tenantId);
			DashboardEventBus.post(new DashboardEvent.RuleSentAllEvent(rules));
			DashboardEventBus.post(new DashboardEvent.RuleSavedEvent());
		}
		catch (DuplicateKeyException e)
		{
			DashboardEventBus.post(new NotSuccessfulEvent("view.alarm.duplicate"));
			logger.debug("Rule {} already exists for the tenant {}", rule.getName(), tenantId);
			logger.error(e.getMessage());
		}

		return result;
	}

	@Override
	public WriteResult saveAliasInRules(RulesSaveAliasEvent event)
	{
		String wagonId = event.getWagonId();
		String alias = event.getAlias();
		WriteResult result = null;

		if (wagonId != null && alias != null)
		{
			DBCollection ruleCollection = DataProviderInitializer
					.getCollection(DashboardUI.getRuleCollection());
			DBObject updateObject = new BasicDBObject();
			updateObject.put(MongoConstants.RULE_WAGONS + ".$." + MongoConstants.ALIAS, alias);
			updateObject.put(MongoConstants.RULE_WAGONS + ".$." + MongoConstants.ALIAS_TO_LOWERCASE,
					alias.trim().toLowerCase());
			DBObject setObject = new BasicDBObject();
			setObject.put("$set", updateObject);
			DBObject criteria = new BasicDBObject(
					MongoConstants.RULE_WAGONS + "." + MongoConstants.WAGON_ID, wagonId);
			result = ruleCollection.update(criteria, setObject, false, true);
			logger.debug("Rule alias updated to {}.", alias);
		}
		return result;
	}

	@Override
	public List<Rule> sortAndFilter(RuleSortAndFilterEvent event)
	{
		String tenantId = event.getTenantId();
		if (tenantId == null || tenantId.isEmpty())
		{
			throw new IllegalArgumentException(UIConstants.TENANT_ID_MUST_NOT_BE_NULL);
		}
		String propertyToSort = event.getPropertyToSort();
		boolean ascending = event.isAscending();
		String filterText = event.getFilterText();

		DBObject find = new BasicDBObject(MongoConstants.TENANT_ID, tenantId);
		buildFilterCriteria(filterText, find);
		DBObject sort = buildSortCriteria(propertyToSort, ascending);

		DBCollection ruleCollection = DataProviderInitializer
				.getCollection(DashboardUI.getRuleCollection());
		DBCursor ruleCursor = ruleCollection.find(find).sort(sort);

		List<Rule> rules = DashboardUI.getRuleDataProvider().transformDBobject2Rule(ruleCursor);

		DashboardEventBus.post(new DashboardEvent.RuleSentAllEvent(rules));
		return rules;
	}

	@Override
	public void deleteRules(RulesDeleteEvent event)
	{
		String tenantId = event.getTenantId();
		if (tenantId == null || tenantId.isEmpty())
		{
			throw new IllegalArgumentException(UIConstants.TENANT_ID_MUST_NOT_BE_NULL);
		}

		List<Rule> selectedRules = event.getRules();
		if (selectedRules == null || selectedRules.isEmpty())
		{
			throw new IllegalArgumentException(UIConstants.LIST_MUST_NOT_BE_NULL);
		}

		for (Rule rule : selectedRules)
		{
			if (rule.getRuleType() != null
					&& rule.getRuleType().equals(RuleConstants.HUMIDITY_TEMPERATURE_RANGE))
			{
				updateTemperatureRangeInConfigurationCollection(rule.getWagons(), 0, 0);
			}
			deleteRule(rule.getId());
			logger.debug("Rule deleted");
			List<Rule> rules = getRules(tenantId);
			DashboardEventBus.post(new DashboardEvent.RuleSentAllEvent(rules));
		}
	}

	@Override
	public Rule getRule(RuleReadEvent event)
	{
		String Id = event.getId();
		if (Id == null || Id.isEmpty())
		{
			throw new IllegalArgumentException(UIConstants.ID_MUST_NOT_BE_NULL);
		}
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection ruleCollection = db.getCollection(DashboardUI.getRuleCollection());
		DBObject match = new BasicDBObject(MongoConstants.ID, Id);
		DBObject dbObject = ruleCollection.findOne(match);

		Rule rule = Rule.dbObject2Rule(dbObject);
		DashboardEventBus.post(new DashboardEvent.RuleSentEvent(rule));
		return rule;
	}

	private List<Rule> getRules(String tenantId)
	{
		if (tenantId == null || tenantId.isEmpty())
		{
			throw new IllegalArgumentException(UIConstants.TENANT_ID_MUST_NOT_BE_NULL);
		}
		List<Rule> rules = DashboardUI.getRuleDataProvider().getRules(tenantId);
		return rules;
	}

	private void updateTemperatureRangeInConfigurationCollection(List<Wagon> wagons,
			Integer minRange, Integer maxRange)
	{
		if (wagons == null)
		{
			return;
		}

		for (Wagon wagon : wagons)
		{
			Map<String, Integer> configurationObject = new HashMap<>();
			configurationObject.put(MongoConstants.TEMPERATURE_RANGE_MIN, minRange);
			configurationObject.put(MongoConstants.TEMPERATURE_RANGE_MAX, maxRange);
			DBObject updateObject = new BasicDBObject("$set", configurationObject);
			DBObject criteria = new BasicDBObject(MongoConstants.WAGON_ID, wagon.getId());
			DBCollection configurationCollection = DataProviderInitializer
					.getCollection(DashboardUI.getConfigurationCollection());
			configurationCollection.update(criteria, updateObject, true, false);
			logger.error("Configuration is updated for: {} id: {}", wagon.getAlias(),
					wagon.getId());
		}
	}

	private List<Wagon> findDeassignedWagonsToRule(Rule rule,
			List<Wagon> primaryAssignedWagonsToRule)
	{
		if (primaryAssignedWagonsToRule == null)
		{
			return null;
		}
		if (rule.getWagons() == null || rule.getWagons().isEmpty())
		{
			return primaryAssignedWagonsToRule;
		}
		return primaryAssignedWagonsToRule.stream()
				.filter(primaryAssignedWagon -> !rule.getWagons().contains(primaryAssignedWagon))
				.collect(Collectors.toList());
	}

	private void deleteRule(String ruleId)
	{
		DBCollection ruleCollection = DataProviderInitializer
				.getCollection(DashboardUI.getRuleCollection());
		DBObject deleteObject = new BasicDBObject();
		deleteObject.put(MongoConstants.ID, ruleId);
		ruleCollection.remove(deleteObject);
	}

	/**
	 * Creates the sort criteria if the propertyToSort is available and an ordering is given. If not
	 * take the default ascending order for the alias
	 * 
	 * @param propertyToSort
	 * @param ascending
	 * @return
	 */
	private DBObject buildSortCriteria(String propertyToSort, boolean ascending)
	{
		DBObject sort = new BasicDBObject();
		if (propertyToSort != null && !propertyToSort.isEmpty())
		{
			if (propertyToSort.equals(RuleConstants.RULE_LIMIT))
			{
				sort.put(MongoConstants.SENSORVALUES_ELEMENT + "." + RuleConstants.RULE_LIMIT,
						RuleConstants.ASCENDING.get(ascending));
			}
			else if (propertyToSort.equals(RuleConstants.RULE_CONDITION))
			{
				sort.put(MongoConstants.SENSORVALUES_ELEMENT + "." + RuleConstants.RULE_CONDITION,
						RuleConstants.ASCENDING.get(ascending));
			}
			else
			{
				sort.put(RuleConstants.MAPPING.get(propertyToSort),
						RuleConstants.ASCENDING.get(ascending));
			}
		}
		else
		{
			sort.put(MongoConstants.SORT, AlarmConstants.ASCENDING.get(ascending));
		}
		return sort;
	}

	private void buildFilterCriteria(String filterText, DBObject find)
	{
		if (filterText != null && !filterText.isEmpty())
		{
			find.put(MongoConstants.SORT,
					new BasicDBObject("$regex", filterText).append("$options", "i"));
		}
	}
}
