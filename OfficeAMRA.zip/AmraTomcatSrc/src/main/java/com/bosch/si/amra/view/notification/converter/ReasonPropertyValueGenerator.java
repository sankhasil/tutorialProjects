
package com.bosch.si.amra.view.notification.converter;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;

import org.springframework.context.NoSuchMessageException;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.notification.Notification;
import com.vaadin.data.Container.Filter;
import com.vaadin.data.Item;
import com.vaadin.data.sort.SortOrder;
import com.vaadin.data.util.PropertyValueGenerator;
import com.vaadin.data.util.filter.UnsupportedFilterException;
import com.vaadin.server.Page;

public class ReasonPropertyValueGenerator extends PropertyValueGenerator<String>
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= 6537255822716086732L;

	private static final String	DECIMAL_PATTERN		= "0.0";

	@Override
	public String getValue(Item item, Object itemId, Object propertyId)
	{
		if (itemId != null)
		{
			Notification notification = (Notification) itemId;
			try
			{
				String result = DashboardUI.getMessageSource()
						.getMessage("view.notification.reason."
								+ String.valueOf(notification.getReason()).toLowerCase());
				if (notification.getShockValue() != null)
					result += " ("
							+ getNumberFormat().format(notification.getShockValue()).toString()
							+ "G)";
				return result;
			}
			catch (NoSuchMessageException e)
			{
				return String.valueOf(notification.getReason());
			}
		}
		return null;
	}

	@Override
	public Class<String> getType()
	{
		return String.class;
	}

	@Override
	public Filter modifyFilter(Filter filter) throws UnsupportedFilterException
	{
		return filter;
	}

	@Override
	public SortOrder[] getSortProperties(SortOrder order)
	{
		return new SortOrder[] { new SortOrder(order.getPropertyId(), order.getDirection()) };
	}

	private NumberFormat getNumberFormat()
	{
		return new DecimalFormat(DECIMAL_PATTERN,
				new DecimalFormatSymbols(Page.getCurrent().getWebBrowser().getLocale()));
	}
}
