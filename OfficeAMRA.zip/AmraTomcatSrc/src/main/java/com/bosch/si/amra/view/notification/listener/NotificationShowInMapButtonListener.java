
package com.bosch.si.amra.view.notification.listener;

import com.bosch.si.amra.view.notification.NotificationView;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;

public class NotificationShowInMapButtonListener implements ClickListener
{
	/**
	 * Serial version uid
	 */
	private static final long		serialVersionUID	= 4811612719836350451L;

	private final NotificationView	view;

	public NotificationShowInMapButtonListener(NotificationView view)
	{
		this.view = view;
	}

	@Override
	public void buttonClick(ClickEvent event)
	{
		view.fillMap();
		view.showNotificationsInMap();
	}
}
