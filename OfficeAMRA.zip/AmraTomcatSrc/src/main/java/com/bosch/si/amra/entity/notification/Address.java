
package com.bosch.si.amra.entity.notification;

import java.io.Serializable;

/**
 * Represents an address for notifications consisting of street, city and country
 *
 * @author toa1wa3
 *
 */
public class Address implements Serializable
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= -8391344173858061251L;

	private String				formattedAddress;

	private String				street				= "";

	private String				city				= "";

	private String				country				= "";

	private String				streetAndCity		= "";

	public String getFormattedAddress()
	{
		return formattedAddress;
	}

	public void setFormattedAddress(String formattedAddress)
	{
		this.formattedAddress = formattedAddress;
	}

	public String getStreet()
	{
		return street;
	}

	public void setStreet(String street)
	{
		this.street = street;
	}

	public String getCity()
	{
		return city;
	}

	public void setCity(String city)
	{
		this.city = city;
	}

	public String getCountry()
	{
		return country;
	}

	public void setCountry(String country)
	{
		this.country = country;
	}

	public String getStreetAndCity()
	{
		return streetAndCity;
	}

	public void setStreetAndCity(String streetAndCity)
	{
		this.streetAndCity = streetAndCity;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((city == null) ? 0 : city.hashCode());
		result = prime * result + ((country == null) ? 0 : country.hashCode());
		result = prime * result + ((formattedAddress == null) ? 0 : formattedAddress.hashCode());
		result = prime * result + ((street == null) ? 0 : street.hashCode());
		result = prime * result + ((streetAndCity == null) ? 0 : streetAndCity.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Address other = (Address) obj;
		if (city == null)
		{
			if (other.city != null)
				return false;
		}
		else if (!city.equals(other.city))
			return false;
		if (country == null)
		{
			if (other.country != null)
				return false;
		}
		else if (!country.equals(other.country))
			return false;
		if (formattedAddress == null)
		{
			if (other.formattedAddress != null)
				return false;
		}
		else if (!formattedAddress.equals(other.formattedAddress))
			return false;
		if (street == null)
		{
			if (other.street != null)
				return false;
		}
		else if (!street.equals(other.street))
			return false;
		if (streetAndCity == null)
		{
			if (other.streetAndCity != null)
				return false;
		}
		else if (!streetAndCity.equals(other.streetAndCity))
			return false;
		return true;
	}
}
