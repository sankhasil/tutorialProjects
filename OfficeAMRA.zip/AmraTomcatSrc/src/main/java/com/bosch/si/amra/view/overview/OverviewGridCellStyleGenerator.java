
package com.bosch.si.amra.view.overview;

import com.bosch.si.amra.constants.overview.OverviewConstants;
import com.vaadin.ui.Grid.CellReference;
import com.vaadin.ui.Grid.CellStyleGenerator;

public class OverviewGridCellStyleGenerator implements CellStyleGenerator
{
	/**
	 * Serial version uid
	 */
	private static final long serialVersionUID = 7290076311751662781L;

	@Override
	public String getStyle(CellReference cellReference)
	{
		switch (cellReference.getPropertyId().toString())
		{
			case OverviewConstants.MILEAGE:
			case OverviewConstants.HUMIDITY:
			case OverviewConstants.HUMIDITY_TEMPERATURE:
			case OverviewConstants.DEVICE_TEMPERATURE:
				return "rightalign";
			case OverviewConstants.BATTERY_LEVEL:
				return "batteryicon";
			default:
				return null;
		}
	}
}
