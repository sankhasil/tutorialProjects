
package com.bosch.si.amra.view.configuration.converter;

import java.util.Locale;

import com.bosch.si.amra.constants.configuration.ConfigurationConstants;
import com.vaadin.data.util.converter.Converter;

public class IntervalConverter implements Converter<String, Integer>
{

	/**
	 * Serial version uid
	 */
	private static final long serialVersionUID = 2829250613993451275L;

	@Override
	public Integer convertToModel(String value, Class<? extends Integer> targetType, Locale locale)
			throws com.vaadin.data.util.converter.Converter.ConversionException
	{
		if (value == null || value.length() == 0)
		{
			return null;
		}

		if (value.matches("[0-9]*:?[0-9]*"))
		{
			String[] split = value.split(":");
			if (split.length > 0)
			{
				Integer hour = Integer.valueOf(!split[0].isEmpty() ? split[0] : "0") * 3600;
				Integer minutes = Integer.valueOf(split.length > 1 ? split[1] : "0") * 60;
				Integer intervalInseconds = hour + minutes;
				if (intervalInseconds >= ConfigurationConstants.MINIMUM_INTERVAL
						&& intervalInseconds <= ConfigurationConstants.MAXIMUM_INTERVAL)
				{
					return hour + minutes;
				}
			}
		}

		throw new ConversionException("Could not convert '" + value + "' to "
				+ Integer.class.getName() + ": value out of range");
	}

	@Override
	public String convertToPresentation(Integer value, Class<? extends String> targetType,
			Locale locale) throws com.vaadin.data.util.converter.Converter.ConversionException
	{

		if (value != null)
		{
			int hour = value / 3600;
			int minutes = (value % 3600) / 60;
			return String.format("%02d:%02d", hour, minutes);
		}
		return "";
	}

	@Override
	public Class<Integer> getModelType()
	{
		return Integer.class;
	}

	@Override
	public Class<String> getPresentationType()
	{
		return String.class;
	}
}
