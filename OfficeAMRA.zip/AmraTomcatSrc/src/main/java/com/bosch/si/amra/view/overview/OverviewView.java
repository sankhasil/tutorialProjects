
package com.bosch.si.amra.view.overview;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.common.UserSettingsStorer;
import com.bosch.si.amra.component.button.OverviewButton;
import com.bosch.si.amra.component.filter.TimestampFilter;
import com.bosch.si.amra.component.grid.OverviewGrid;
import com.bosch.si.amra.constants.UIConstants;
import com.bosch.si.amra.constants.overview.OverviewConstants;
import com.bosch.si.amra.entity.Tag;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.event.DashboardEvent;
import com.bosch.si.amra.event.DashboardEvent.ReportEvent;
import com.bosch.si.amra.event.DashboardEvent.SaveUserSettingsEvent;
import com.bosch.si.amra.event.DashboardEvent.TagSaveStatusEvent;
import com.bosch.si.amra.event.DashboardEvent.WagonDetailsEvent;
import com.bosch.si.amra.event.DashboardEvent.WagonSetEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.im.login.Role;
import com.bosch.si.amra.im.login.Role.Roles;
import com.bosch.si.amra.view.AmraView;
import com.bosch.si.amra.view.overview.OverviewGridFilterComponent.OverviewFilter;
import com.bosch.si.amra.view.overview.OverviewGridFilterComponent.OverviewTagFilter;
import com.bosch.si.amra.view.overview.OverviewGridFilterComponent.SearchFilter;
import com.google.common.eventbus.Subscribe;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.event.ShortcutListener;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Responsive;
import com.vaadin.server.VaadinSession;
import com.vaadin.shared.MouseEventDetails.MouseButton;
import com.vaadin.ui.Button;
import com.vaadin.ui.Component;
import com.vaadin.ui.DateField;
import com.vaadin.ui.Grid;
import com.vaadin.ui.Grid.SelectionMode;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.HorizontalSplitPanel;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Notification.Type;
import com.vaadin.ui.UI;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

@Role ({ Roles.USER, Roles.FLEETADMIN, Roles.SYSTEMADMIN })
@SuppressWarnings ("serial")

public class OverviewView extends VerticalLayout implements View
{

	private OverviewGrid			grid;

	private Grid					tagGrid;

	private Button					showDetails;

	private Button					assignTags, unassignTags, deleteTags, editTag,
			tagManagementNavigator;

	private Button					showReport;

	private Button					removeWagon;

	private Button					editWagon;

	private final User				user	= (User) VaadinSession.getCurrent()
			.getAttribute(User.class.getName());

	private final List<Wagon>		wagons;

	private List<Tag>				tagListForGrid;

	private HorizontalSplitPanel	overviewHorizontalSplitPanel;

	private OverviewContainer		overviewContainer;

	public OverviewView()
	{
		wagons = DashboardUI.getDataProvider().getWagonsWithCurrentValues(user);
		tagListForGrid = DashboardUI.getDataProvider().getTags(user);
		overviewContainer = createContainer(wagons);
		setSizeFull();
		addStyleName("overview");
		DashboardEventBus.register(this);
		overviewHorizontalSplitPanel = new HorizontalSplitPanel();
		overviewHorizontalSplitPanel.setSizeFull();
		overviewHorizontalSplitPanel.setId("overviewHorizontalSplitPanel");
		grid = buildGrid();
		OverviewTagManagement tagManagement = new OverviewTagManagement(grid, tagListForGrid, user);

		overviewHorizontalSplitPanel.setFirstComponent(tagManagement.buildTagManagementLayout());
		overviewHorizontalSplitPanel.setSecondComponent(grid);
		overviewHorizontalSplitPanel.addSplitterClickListener(splitClickListner -> {
			if (splitClickListner.getButton().equals(MouseButton.LEFT))
			{
				HorizontalSplitPanel leftSplitPanel = (HorizontalSplitPanel) splitClickListner
						.getSource();

				if (leftSplitPanel.getSplitPosition() < new Float(1.0))
					leftSplitPanel.setSplitPosition(277, Unit.PIXELS);
				else
					leftSplitPanel.setSplitPosition(0, Unit.PIXELS);
			}
		});
		overviewHorizontalSplitPanel.setSplitPosition(0, Unit.PIXELS);
		overviewHorizontalSplitPanel.setMaxSplitPosition(277, Unit.PIXELS);
		overviewHorizontalSplitPanel.setResponsive(true);
		tagGrid = tagManagement.getTagGrid();
		Responsive.makeResponsive(tagGrid);
		tagManagement.getTagToolbarButtons().forEach(toolbarButton -> {
			switch (toolbarButton.getId())
			{
				case "assign":
					assignTags = toolbarButton;
					break;
				case "unassign":
					unassignTags = toolbarButton;
					break;
				case "delete":
					deleteTags = toolbarButton;
					break;
				case "edit":
					editTag = toolbarButton;
					break;
				case "tags":
					tagManagementNavigator = toolbarButton;
					tagManagementNavigator.addClickListener(closeListner -> {

						if (overviewHorizontalSplitPanel.getSplitPosition() < new Float(1.0))
							overviewHorizontalSplitPanel.setSplitPosition(277, Unit.PIXELS);
						else
							overviewHorizontalSplitPanel.setSplitPosition(0, Unit.PIXELS);
					});
					break;
				default:
					break;
			}
		});
		addComponent(buildToolbar());
		addComponent(overviewHorizontalSplitPanel);
		setExpandRatio(overviewHorizontalSplitPanel, 1);
		addShortcutListener(new ShortcutListener("Clear", KeyCode.ESCAPE, null)
		{
			@SuppressWarnings ("unchecked")
			@Override
			public void handleAction(Object sender, Object target)
			{
				BeanItemContainer<Wagon> container = (BeanItemContainer<Wagon>) grid
						.getContainerDataSource();
				if (target != null && target instanceof OverviewFilter)
					((OverviewFilter) target).setValue(null);
				else if (target != null && target instanceof TimestampFilter)
					((DateField) target).setValue(null);
				else if (target != null && target instanceof OverviewTagFilter)
					((OverviewTagFilter) target).setValue(null);
				else if (target != null && target instanceof SearchFilter)
					((SearchFilter) target).setValue("");
				Object pid = grid.getComponentToPidMap().get(target);
				if (pid != null)
					container.removeContainerFilters(pid);
			}
		});
	}

	@Override
	public void detach()
	{
		super.detach();
		DashboardEventBus.unregister(this);
		UserSettingsStorer.saveSessionUserSettings(grid, UIConstants.OVERVIEW_VIEW_SESSION_OBJECT);
	}

	@Override
	public void attach()
	{
		super.attach();
		UserSettingsStorer.fetchSessionUserSettings(grid, UIConstants.OVERVIEW_VIEW_SESSION_OBJECT,
				OverviewGrid.getColumnIds(user));
	}

	private Component buildToolbar()
	{
		HorizontalLayout header = new HorizontalLayout();
		header.addStyleName("viewheader");
		header.setSpacing(true);
		Responsive.makeResponsive(header);

		Label title = new Label(DashboardUI.getMessageSource().getMessage("view.overview.caption"));
		title.setSizeUndefined();
		title.addStyleName(ValoTheme.LABEL_H1);
		title.addStyleName(ValoTheme.LABEL_NO_MARGIN);
		header.addComponent(title);
		showDetails = new OverviewButton(
				DashboardUI.getMessageSource().getMessage("view.overview.button.details.caption"),
				DashboardUI.getMessageSource().getMessage("view.overview.button.details.tooltip"),
				FontAwesome.INFO_CIRCLE,
				listner -> showDetailsForSelection(new ArrayList<Wagon>()));
		showReport = new OverviewButton(
				DashboardUI.getMessageSource().getMessage("view.overview.button.report.caption"),
				DashboardUI.getMessageSource().getMessage("view.overview.button.report.tooltip"),
				FontAwesome.BAR_CHART_O, listner -> showReportForSelection());
		HorizontalLayout tools = new HorizontalLayout(showDetails, showReport);
		if (user.isAdmin() || user.isSuperAdmin())
		{
			removeWagon = new OverviewButton(
					DashboardUI.getMessageSource()
							.getMessage("view.overview.button.remove.caption"),
					DashboardUI.getMessageSource()
							.getMessage("view.overview.button.remove.tooltip"),
					FontAwesome.TRASH_O,
					listner -> Notification.show("Not implemented yet", Type.TRAY_NOTIFICATION));
			editWagon = new OverviewButton(
					DashboardUI.getMessageSource().getMessage("view.overview.button.edit.caption"),
					DashboardUI.getMessageSource().getMessage("view.overview.button.edit.tooltip"),
					FontAwesome.COGS, listner -> editSelectedWagon());
			tools.addComponents(removeWagon, editWagon);
		}
		tools.setSpacing(true);
		tools.addStyleName("toolbar");
		header.addComponent(tagManagementNavigator);
		header.addComponent(tools);
		return header;
	}

	private OverviewGrid buildGrid()
	{
		grid = new OverviewGrid(overviewContainer, wagons);
		grid.setSelectionMode(SelectionMode.MULTI);
		grid.addSelectionListener(listener -> valueChange());
		grid.addItemClickListener(listener -> {
			if (listener.isDoubleClick())
			{
				List<Wagon> selectedWagons = new ArrayList<Wagon>();
				selectedWagons.add((Wagon) listener.getItemId());
				showDetailsForSelection(selectedWagons);
			}
		});

		return grid;
	}

	public void showDetailsForSelection(List<Wagon> selectedWagon)
	{
		if (selectedWagon.isEmpty())
		{
			selectedWagon = grid.getSelectedRows().stream().map(wagonMapper -> (Wagon) wagonMapper)
					.collect(Collectors.toList());
		}
		UI.getCurrent().getNavigator().navigateTo(AmraView.DETAILS.getViewName());

		DashboardEventBus.post(new WagonDetailsEvent(selectedWagon));
	}

	public void showReportForSelection()
	{
		UI.getCurrent().getNavigator().navigateTo(AmraView.REPORT.getViewName());
		List<Object> selectedRows = (List<Object>) grid.getSelectedRows();
		List<Wagon> selectedWagon = new ArrayList<Wagon>();
		selectedRows.forEach(rowObject -> selectedWagon.add((Wagon) rowObject));
		DashboardEventBus.post(new ReportEvent(user.getTenant(), selectedWagon));
	}

	public void editSelectedWagon()
	{
		UI.getCurrent().getNavigator().navigateTo(AmraView.ADMINISTRATION.getViewName());
		List<Object> selectedRows = (List<Object>) grid.getSelectedRows();
		List<Wagon> selectedWagon = new ArrayList<Wagon>();
		selectedRows.forEach(rowObject -> selectedWagon.add((Wagon) rowObject));
		DashboardEventBus
				.post(new DashboardEvent.WagonSelectedEvent(selectedWagon.iterator().next()));
	}

	@Subscribe
	public void saveTagStatus(TagSaveStatusEvent event)
	{
		Tag newTag = event.getTag();
		if (event.isSuccess())
		{

			if (!tagListForGrid.contains(newTag))
			{
				Notification.show(DashboardUI.getMessageSource().getMessage(
						"view.overview.tag.notification.created"), Type.HUMANIZED_MESSAGE);
				tagGrid.getContainerDataSource().addItem(newTag);
				tagListForGrid.add(newTag);
			}
		}
		else
		{
			Notification.show(
					event.getTag().getTagName() + " : "
							+ DashboardUI.getMessageSource()
									.getMessage("view.overview.tag.notification.duplicate"),
					Type.WARNING_MESSAGE);
		}
	}

	@Subscribe
	public void saveSessionData(SaveUserSettingsEvent event)
	{
		UserSettingsStorer.saveSessionUserSettings(grid, UIConstants.OVERVIEW_VIEW_SESSION_OBJECT);
	}

	@Subscribe
	public void setWagonsList(WagonSetEvent event)
	{
		List<Wagon> wagons = event.getWagons();
		grid.getContainerDataSource().removeAllItems();
		if (wagons.size() > 0)
		{
			OverviewContainer overviewContainer = createContainer(wagons);
			grid.setContainerDataSource(overviewContainer);
		}
	}

	public void valueChange()
	{
		Collection<Object> val = grid.getSelectedRows();
		if (val.size() >= 1)
		{
			showDetails.setEnabled(true);
			showReport.setEnabled(true);
		}
		else
		{
			showDetails.setEnabled(false);
			showReport.setEnabled(false);
		}
		boolean buttonHideShowFlag = val.size() > 0 && tagGrid.getSelectedRows().size() > 0;
		assignTags.setEnabled(buttonHideShowFlag);
		unassignTags.setEnabled(buttonHideShowFlag);
		deleteTags.setEnabled(val.size() == 0 && tagGrid.getSelectedRows().size() > 0);
		editTag.setEnabled(tagGrid.getSelectedRows().size() == 1 && val.size() == 0);
		if (user.isAdmin() || user.isSuperAdmin())
		{
			if (removeWagon != null)
				removeWagon.setEnabled(val.size() == 1);
			if (editWagon != null)
				editWagon.setEnabled(val.size() == 1);
		}
	}

	private OverviewContainer createContainer(List<Wagon> wagons)
	{
		OverviewContainer overviewContainer = new OverviewContainer(wagons);
		overviewContainer.addNestedContainerProperty(OverviewConstants.WAGON_TYPE_NAME);
		overviewContainer.addNestedContainerProperty(OverviewConstants.STREET_CITY);
		overviewContainer.addNestedContainerProperty(OverviewConstants.COUNTRY);
		overviewContainer.addNestedContainerProperty(OverviewConstants.TAGS);
		return overviewContainer;
	}

	@Override
	public void enter(ViewChangeEvent event)
	{
	}
}
