
package com.bosch.si.amra.view.dashboard;

import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.context.NoSuchMessageException;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.component.Sparkline;
import com.bosch.si.amra.component.TopMileageChart;
import com.bosch.si.amra.component.map.Map;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.event.DashboardEvent.DashboardEditEvent;
import com.bosch.si.amra.event.DashboardEvent.MaximizeDashboardPanelEvent;
import com.bosch.si.amra.event.DashboardEvent.MinimizeDashboardPanelEvent;
import com.bosch.si.amra.event.DashboardEvent.NotificationsCountUpdatedEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.im.login.Role;
import com.bosch.si.amra.im.login.Role.Roles;
import com.bosch.si.amra.view.AmraView;
import com.google.common.eventbus.Subscribe;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Page;
import com.vaadin.server.Responsive;
import com.vaadin.server.VaadinSession;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;
import com.vaadin.ui.Component;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Panel;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.Window;
import com.vaadin.ui.themes.ValoTheme;

@Role ({ Roles.USER, Roles.FLEETADMIN, Roles.SYSTEMADMIN })
@SuppressWarnings ("serial")
public class DashboardView extends Panel implements View
{

	public static final String		EDIT_ID		= "dashboard-edit";

	public static final String		TITLE_ID	= "dashboard-title";

	private Label					titleLabel;

	private NotificationsButton		notificationsButton;

	private CssLayout				dashboardPanels;

	private final VerticalLayout	root;

	private Window					notificationsWindow;

	private final List<Wagon>		topFiveMileageWagons;

	private final User				user		= (User) VaadinSession.getCurrent()
			.getAttribute(User.class.getName());

	public DashboardView()
	{
		topFiveMileageWagons = DashboardUI.getAggregationDataProvider().getTopFiveMileage(user);

		addStyleName(ValoTheme.PANEL_BORDERLESS);
		setSizeFull();
		DashboardEventBus.register(this);

		root = new VerticalLayout();
		root.setSizeFull();
		root.setMargin(true);
		root.addStyleName("dashboard-view");
		setContent(root);
		Responsive.makeResponsive(root);

		root.addComponent(buildHeader());

		root.addComponent(buildSparklines());

		Component content = buildContent();
		root.addComponent(content);
		root.setExpandRatio(content, 1);
	}

	@Override
	public void detach()
	{
		super.detach();
		DashboardEventBus.unregister(this);
	};

	Component buildSparklines()
	{
		CssLayout sparks = new CssLayout();
		sparks.setId("sparks");
		sparks.addStyleName("sparks");
		sparks.setWidth("100%");
		Responsive.makeResponsive(sparks);

		sparks.addComponent(buildMileageSparkline());
		sparks.addComponent(buildTemperatureSparkline());
		sparks.addComponent(buildHumiditySparkline());
		sparks.addComponent(buildHumididtyTemperatureSparkline());

		return sparks;
	}

	private Sparkline buildMileageSparkline()
	{
		String alias = DashboardUI.getMessageSource().getMessage("view.details.noinformation");
		String mileage = null;

		if (topFiveMileageWagons != null && !topFiveMileageWagons.isEmpty())
		{
			Wagon wagon = topFiveMileageWagons.get(0);
			if (wagon != null)
			{
				alias = wagon.getAlias();
				mileage = String.valueOf(wagon.getMileage());
			}
		}
		Sparkline s = new Sparkline("view.dashboard.mileage", "KM", alias, mileage, null);
		return s;
	}

	private Sparkline buildTemperatureSparkline()
	{
		Wagon wagon = DashboardUI.getAggregationDataProvider().getMaximumAmbientTemperature(user);

		String alias = DashboardUI.getMessageSource().getMessage("view.details.noinformation");
		String temperature = null;
		if (wagon != null)
		{
			alias = wagon.getAlias();
			temperature = String.valueOf(wagon.getTemperature());
		}
		Sparkline s = new Sparkline("view.dashboard.temperature", "°C", alias, temperature, null);
		return s;
	}

	private Sparkline buildHumiditySparkline()
	{
		Wagon wagon = DashboardUI.getAggregationDataProvider().getMaximumHumidity(user);

		String alias = DashboardUI.getMessageSource().getMessage("view.details.noinformation");
		String humidity = null;
		if (wagon != null)
		{
			alias = wagon.getAlias();
			humidity = String.valueOf(wagon.getHumidity());
		}

		Sparkline s = new Sparkline("view.dashboard.humidity", "%", alias, humidity, null);
		return s;
	}

	private Sparkline buildHumididtyTemperatureSparkline()
	{
		Wagon wagon = DashboardUI.getAggregationDataProvider().getMaximumPayloadTemperature(user);

		String alias = DashboardUI.getMessageSource().getMessage("view.details.noinformation");
		String humidityTemperature = null;
		if (wagon != null)
		{
			alias = wagon.getAlias();
			humidityTemperature = String.valueOf(wagon.getHumidityTemperature());
		}
		Sparkline s = new Sparkline("view.dashboard.humidity_temperature", "°C", alias,
				humidityTemperature, null);
		return s;
	}

	private Component buildHeader()
	{
		HorizontalLayout header = new HorizontalLayout();
		header.addStyleName("viewheader");
		header.setSpacing(true);

		titleLabel = new Label(DashboardUI.getMessageSource().getMessage("view.dashboard.title"));
		titleLabel.setId(TITLE_ID);
		titleLabel.setSizeUndefined();
		titleLabel.addStyleName(ValoTheme.LABEL_H1);
		titleLabel.addStyleName(ValoTheme.LABEL_NO_MARGIN);
		header.addComponent(titleLabel);

		notificationsButton = buildNotificationsButton();
		Component edit = buildEdit();
		edit.setId(EDIT_ID);
		HorizontalLayout tools = new HorizontalLayout(notificationsButton, edit);
		tools.setSpacing(true);
		tools.addStyleName("toolbar");
		header.addComponent(tools);

		return header;
	}

	private NotificationsButton buildNotificationsButton()
	{
		NotificationsButton notificationsButton = new NotificationsButton();
		notificationsButton.addClickListener(new ClickListener()
		{
			@Override
			public void buttonClick(ClickEvent event)
			{
				openNotificationsPopup(event);
			}
		});
		return notificationsButton;
	}

	private void openNotificationsPopup(ClickEvent event)
	{
		VerticalLayout notificationsLayout = new VerticalLayout();
		notificationsLayout.setMargin(true);
		notificationsLayout.setSpacing(true);

		Label title = new Label(
				DashboardUI.getMessageSource().getMessage("view.notification.caption"));
		title.addStyleName(ValoTheme.LABEL_H3);
		title.addStyleName(ValoTheme.LABEL_NO_MARGIN);
		notificationsLayout.addComponent(title);

		Collection<com.bosch.si.amra.entity.notification.Notification> notifications = DashboardUI
				.getNotificationDataProvider().getNotifications(user, true, false);
		DashboardEventBus.post(new NotificationsCountUpdatedEvent());
		for (com.bosch.si.amra.entity.notification.Notification notification : notifications)
		{
			VerticalLayout notificationLayout = new VerticalLayout();
			notificationLayout.addStyleName("notification-item");

			Label titleLabel = new Label(notification.getAlias());
			titleLabel.addStyleName("notification-title");

			SimpleDateFormat dateFormat = new SimpleDateFormat(
					DashboardUI.getMessageSource().getMessage("date.format"));
			dateFormat.setTimeZone(DashboardUI.getUserTimeZone());
			Label timeLabel = new Label(dateFormat.format(notification.getTimestamp()));
			timeLabel.addStyleName("notification-time");

			Label contentLabel;
			try
			{
				contentLabel = new Label(DashboardUI.getMessageSource().getMessage(
						"view.notification.reason." + notification.getReason().toLowerCase()));
			}
			catch (NoSuchMessageException e)
			{
				contentLabel = new Label(notification.getReason());
			}
			contentLabel.addStyleName("notification-content");

			notificationLayout.addComponents(titleLabel, timeLabel, contentLabel);
			notificationsLayout.addComponent(notificationLayout);
		}

		HorizontalLayout footer = new HorizontalLayout();
		footer.addStyleName(ValoTheme.WINDOW_BOTTOM_TOOLBAR);
		footer.setWidth("100%");
		Button showAll = new Button(
				DashboardUI.getMessageSource().getMessage("view.notification.button.showall"));
		showAll.addStyleName(ValoTheme.BUTTON_BORDERLESS_COLORED);
		showAll.addStyleName(ValoTheme.BUTTON_SMALL);
		footer.addComponent(showAll);
		footer.setComponentAlignment(showAll, Alignment.TOP_CENTER);
		notificationsLayout.addComponent(footer);

		if (notificationsWindow == null)
		{
			notificationsWindow = new Window();
			notificationsWindow.setWidth(300.0f, Unit.PIXELS);
			notificationsWindow.addStyleName("notifications");
			notificationsWindow.setClosable(false);
			notificationsWindow.setResizable(false);
			notificationsWindow.setDraggable(false);
			notificationsWindow.addCloseShortcut(KeyCode.ESCAPE, null);
			notificationsWindow.setContent(notificationsLayout);
		}

		if (!notificationsWindow.isAttached())
		{
			notificationsWindow.setPositionY(event.getClientY() - event.getRelativeY() + 40);
			getUI().addWindow(notificationsWindow);
			notificationsWindow.focus();
		}
		else
		{
			notificationsWindow.close();
		}

		showAll.addClickListener(new ClickListener()
		{
			@Override
			public void buttonClick(ClickEvent event)
			{
				notificationsWindow.close();
				DashboardUI.getCurrent().getNavigator()
						.navigateTo(AmraView.NOTIFICATION.getViewName());
			}
		});
	}

	private Component buildEdit()
	{
		Button edit = new Button();
		edit.setIcon(FontAwesome.EDIT);
		edit.addStyleName("icon-edit");
		edit.addStyleName(ValoTheme.BUTTON_ICON_ONLY);
		edit.setDescription(DashboardUI.getMessageSource().getMessage("view.dashboard.edit"));
		edit.addClickListener(new ClickListener()
		{
			@Override
			public void buttonClick(ClickEvent event)
			{
				getUI().addWindow(new DashboardEdit(titleLabel.getValue()));
			}
		});
		return edit;
	}

	private Component buildContent()
	{
		dashboardPanels = new CssLayout();
		dashboardPanels.addStyleName("dashboard-panels");
		Responsive.makeResponsive(dashboardPanels);

		dashboardPanels.addComponent(buildTopMileage());
		dashboardPanels.addComponent(buildMap());

		return dashboardPanels;
	}

	private Component buildTopMileage()
	{
		TopMileageChart topMileageChart = new TopMileageChart(topFiveMileageWagons);
		topMileageChart.setId("mileage");
		topMileageChart.setSizeFull();
		return new DashboardContentWrapper().createContentWrapper(topMileageChart,
				"view.dashboard.mileage.help");
	}

	private Component buildMap()
	{
		Map map = new Map(DashboardUI.getDataProvider().getWagonsWithCurrentValues(user));
		map.setAliasList(DashboardUI.getDataProvider().getWagonsWithCurrentValues(user).stream()
				.map(wagon -> wagon.getAlias()).collect(Collectors.toList()));

		DashboardContentWrapper wrapper = new DashboardContentWrapper();
		Component contentWrapper = wrapper.createContentWrapper(map, "view.dashboard.map.help");
		map.buildMarkerToggle(wrapper.getTools(), wrapper.getMax());

		return contentWrapper;
	}

	@Override
	public void enter(ViewChangeEvent event)
	{
		notificationsButton.updateNotificationsCount(null);
		Page.getCurrent().getStyles().add(".gm-style-iw + div {display: none;}");
	}

	@Subscribe
	public void dashboardEdited(DashboardEditEvent event)
	{
		titleLabel.setValue(event.getName());
	}

	public static class NotificationsButton extends Button
	{
		private static final String	STYLE_UNREAD	= "unread";

		public static final String	ID				= "dashboard-notifications";

		private final User			user			= (User) VaadinSession.getCurrent()
				.getAttribute(User.class.getName());

		public NotificationsButton()
		{
			setIcon(FontAwesome.BELL);
			setId(ID);
			addStyleName("notifications");
			addStyleName(ValoTheme.BUTTON_ICON_ONLY);
		}

		@Override
		public void attach()
		{
			super.attach();
			DashboardEventBus.register(this);
		}

		@Override
		public void detach()
		{
			super.detach();
			DashboardEventBus.unregister(this);
		}

		@Subscribe
		public void updateNotificationsCount(NotificationsCountUpdatedEvent event)
		{
			setUnreadCount(
					DashboardUI.getNotificationDataProvider().getUnreadNotificationsCount(user));
		}

		public void setUnreadCount(int count)
		{
			setCaption(String.valueOf(count));

			String description = DashboardUI.getMessageSource()
					.getMessage("view.notification.caption");

			if (count > 0)
			{
				addStyleName(STYLE_UNREAD);
				description += " (" + count + " "
						+ DashboardUI.getMessageSource().getMessage("view.notification.unread")
						+ ")";
			}
			else
			{
				removeStyleName(STYLE_UNREAD);
			}
			setDescription(description);
		}
	}

	@Subscribe
	public void maximizePanel(MaximizeDashboardPanelEvent event)
	{
		for (Iterator<Component> it = dashboardPanels.iterator(); it.hasNext();)
		{
			Component c = it.next();
			c.removeStyleName("max");
			c.setVisible(false);
		}
		event.getPanel().addStyleName("max");
		event.getPanel().setVisible(true);

		for (Iterator<Component> it = root.iterator(); it.hasNext();)
		{
			it.next().setVisible(false);
		}
		dashboardPanels.setVisible(true);
	}

	@Subscribe
	public void minimizePanel(MinimizeDashboardPanelEvent event)
	{
		for (Iterator<Component> it = dashboardPanels.iterator(); it.hasNext();)
		{
			Component c = it.next();
			c.removeStyleName("max");
			c.setVisible(true);
		}

		for (Iterator<Component> it = root.iterator(); it.hasNext();)
		{
			it.next().setVisible(true);
		}
	}
}
