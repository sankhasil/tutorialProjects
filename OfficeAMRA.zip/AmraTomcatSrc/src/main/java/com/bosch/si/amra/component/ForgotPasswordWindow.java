
package com.bosch.si.amra.component;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.event.DashboardEvent.ResetPasswordEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.view.UserNotification;
import com.vaadin.data.Item;
import com.vaadin.data.fieldgroup.FieldGroup;
import com.vaadin.data.fieldgroup.FieldGroup.CommitException;
import com.vaadin.data.fieldgroup.PropertyId;
import com.vaadin.data.util.ObjectProperty;
import com.vaadin.data.util.PropertysetItem;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Responsive;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;
import com.vaadin.ui.Component;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

public class ForgotPasswordWindow extends CustomComponent
{
	/**
	 * Serial version uid
	 */
	private static final long		serialVersionUID	= -3486173311031390915L;

	private final PropertysetItem	passwordItem;

	private FieldGroup				resetPasswordFieldGroup;

	@PropertyId ("username")
	private TextField				username;

	@PropertyId ("tenantName")
	private TextField				tenantName;

	private Button					cancel;

	public ForgotPasswordWindow()
	{
		this.passwordItem = new PropertysetItem();
		passwordItem.addItemProperty("username", new ObjectProperty<String>(""));
		passwordItem.addItemProperty("tenantName", new ObjectProperty<String>(""));

		VerticalLayout content = new VerticalLayout();
		content.setSizeFull();
		setCompositionRoot(content);
		addStyleName("reset-password");

		Responsive.makeResponsive(this);

		content.addComponent(buildForgotPassword());
		content.addComponent(buildFooter());
	}

	private Component buildForgotPassword()
	{
		HorizontalLayout root = new HorizontalLayout();
		root.setCaption(DashboardUI.getMessageSource().getMessage("view.reset.password"));
		root.setIcon(FontAwesome.LOCK);
		root.setSpacing(true);
		root.setMargin(true);
		root.addStyleName("reset-form");

		FormLayout passwordChange = new FormLayout();
		passwordChange.addStyleName(ValoTheme.FORMLAYOUT_LIGHT);
		root.addComponent(passwordChange);
		root.setExpandRatio(passwordChange, 1);

		tenantName = new TextField(
				DashboardUI.getMessageSource().getMessage("view.reset.password.tenant.name"));
		tenantName.setImmediate(true);
		tenantName.setRequired(true);
		tenantName.setRequiredError(
				DashboardUI.getMessageSource().getMessage("view.reset.password.empty.tenant.name"));
		passwordChange.addComponent(tenantName);

		username = new TextField(
				DashboardUI.getMessageSource().getMessage("view.reset.password.username"));
		username.setImmediate(true);
		username.setRequired(true);
		username.setRequiredError(
				DashboardUI.getMessageSource().getMessage("view.reset.password.empty.username"));
		passwordChange.addComponent(username);

		resetPasswordFieldGroup = new FieldGroup(passwordItem);
		resetPasswordFieldGroup.bindMemberFields(this);

		return root;
	}

	private Component buildFooter()
	{
		HorizontalLayout footer = new HorizontalLayout();
		footer.addStyleName(ValoTheme.WINDOW_BOTTOM_TOOLBAR);
		footer.setSizeFull();

		Button ok = new Button(DashboardUI.getMessageSource().getMessage("view.profile.ok"));
		ok.addStyleName(ValoTheme.BUTTON_PRIMARY);
		ok.addClickListener(new OkButtonListener());
		ok.focus();

		cancel = new Button(DashboardUI.getMessageSource().getMessage("view.dashboard.cancel"));

		footer.addComponents(ok, cancel);
		footer.setComponentAlignment(ok, Alignment.TOP_LEFT);
		footer.setComponentAlignment(cancel, Alignment.TOP_RIGHT);
		return footer;
	}

	private class OkButtonListener implements ClickListener
	{
		/**
		 * Serial version uid
		 */
		private static final long serialVersionUID = 797040551184208200L;

		public OkButtonListener()
		{
		}

		@Override
		public void buttonClick(ClickEvent event)
		{
			try
			{
				resetPasswordFieldGroup.commit();
				Item passwordItem = resetPasswordFieldGroup.getItemDataSource();
				String username = (String) passwordItem.getItemProperty("username").getValue();
				String tenantName = (String) passwordItem.getItemProperty("tenantName").getValue();
				User user = new User();
				user.setTechnialName(username);
				user.setTenantName(tenantName);
				DashboardEventBus.post(new ResetPasswordEvent(user));
			}
			catch (CommitException e)
			{
				new UserNotification("view.profile.wrong.password.group", 1000, false);
			}
		}
	}

	public void discardChanges()
	{
		tenantName.setValue("");
		username.setValue("");
	}

	public Button getCancel()
	{
		return cancel;
	}
}
