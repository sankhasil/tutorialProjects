
package com.bosch.si.amra.view.rule;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.component.button.RuleButton;
import com.bosch.si.amra.component.table.AmraTable;
import com.bosch.si.amra.constants.rule.RuleConstants;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.entity.rule.Rule;
import com.bosch.si.amra.event.DashboardEvent.BrowserResizeEvent;
import com.bosch.si.amra.event.DashboardEvent.NotSuccessfulEvent;
import com.bosch.si.amra.event.DashboardEvent.RuleSaveEvent;
import com.bosch.si.amra.event.DashboardEvent.RuleSavedEvent;
import com.bosch.si.amra.event.DashboardEvent.RuleSentAllEvent;
import com.bosch.si.amra.event.DashboardEvent.RuleSortAndFilterEvent;
import com.bosch.si.amra.event.DashboardEvent.RulesDeleteEvent;
import com.bosch.si.amra.event.DashboardEvent.TemperatureRangeRuleFailedSavedEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.im.login.Role;
import com.bosch.si.amra.im.login.Role.Roles;
import com.bosch.si.amra.view.UserNotification;
import com.bosch.si.amra.view.rule.listener.RuleCancelButtonListener;
import com.bosch.si.amra.view.rule.listener.RuleCopyButtonListener;
import com.bosch.si.amra.view.rule.listener.RuleCreateButtonListener;
import com.bosch.si.amra.view.rule.listener.RuleEditButtonListener;
import com.bosch.si.amra.view.rule.listener.RuleRemoveButtonListener;
import com.bosch.si.amra.view.rule.listener.RuleSaveButtonListener;
import com.bosch.si.amra.view.ruledetails.RuleDetailsView;
import com.google.common.eventbus.Subscribe;
import com.vaadin.data.Container.Filterable;
import com.vaadin.data.Property.ValueChangeEvent;
import com.vaadin.data.Property.ValueChangeListener;
import com.vaadin.event.FieldEvents.TextChangeEvent;
import com.vaadin.event.FieldEvents.TextChangeListener;
import com.vaadin.event.ItemClickEvent;
import com.vaadin.event.ItemClickEvent.ItemClickListener;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.event.ShortcutListener;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Page;
import com.vaadin.server.Responsive;
import com.vaadin.server.VaadinSession;
import com.vaadin.ui.Button;
import com.vaadin.ui.Component;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Notification.Type;
import com.vaadin.ui.Table;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

@Role ({ Roles.USER, Roles.FLEETADMIN, Roles.SYSTEMADMIN })
@SuppressWarnings ("serial")
public class RuleView extends VerticalLayout implements View
{
	private HorizontalLayout	tools;

	private TextField			filter;

	private Button				createRule;

	private Button				editRule;

	private Button				copyRule;

	private Button				removeRule;

	private Button				saveRule;

	private Button				cancel;

	private Table				table;

	private final User			user	= (User) VaadinSession.getCurrent()
			.getAttribute(User.class.getName());

	private List<Rule>			rules;

	private RuleDetailsView		ruleDetailsView;

	public RuleView()
	{
		rules = DashboardUI.getRuleDataProvider().getRules(user.getTenant());

		setSizeFull();
		addStyleName("rule");
		DashboardEventBus.register(this);

		addComponent(buildToolbar());

		table = buildTable();
		addComponent(table);
		setExpandRatio(table, 1);
	}

	@Override
	public void detach()
	{
		super.detach();
		// This view gets re-instantiated every time it's navigated to so we'll
		// need to clean up references to it on detach.
		DashboardEventBus.unregister(this);
	}

	private Component buildToolbar()
	{
		HorizontalLayout header = new HorizontalLayout();
		header.addStyleName("viewheader");
		header.setSpacing(true);
		Responsive.makeResponsive(header);

		Label title = new Label(
				DashboardUI.getMessageSource().getMessage(RuleConstants.TITLE_CAPTION));
		title.setSizeUndefined();
		title.addStyleName(ValoTheme.LABEL_H1);
		title.addStyleName(ValoTheme.LABEL_NO_MARGIN);
		header.addComponent(title);

		createRule = new RuleButton(RuleConstants.CREATE_TOOLTIP, FontAwesome.PLUS, true,
				new RuleCreateButtonListener(this));
		editRule = new RuleButton(RuleConstants.EDIT_TOOLTIP, FontAwesome.EDIT, false,
				new RuleEditButtonListener(this));
		copyRule = new RuleButton(RuleConstants.COPY_TOOLTIP, FontAwesome.COPY, false,
				new RuleCopyButtonListener(this));
		removeRule = new RuleButton(RuleConstants.DELETE_TOOLTIP, FontAwesome.TRASH_O, false,
				new RuleRemoveButtonListener(this));
		saveRule = new RuleButton(RuleConstants.SAVE_TOOLTIP, FontAwesome.SAVE, false,
				new RuleSaveButtonListener(this));
		cancel = new RuleButton(RuleConstants.CANCEL_TOOLTIP, FontAwesome.TIMES, false,
				new RuleCancelButtonListener(this));

		filter = buildFilter();

		tools = new HorizontalLayout(filter, createRule, editRule, copyRule, removeRule);
		tools.setSpacing(true);
		tools.addStyleName("toolbar");
		header.addComponent(tools);

		return header;
	}

	private Table buildTable()
	{
		table = new AmraTable();
		if (rules != null && rules.size() > 0)
		{
			configureTable();
		}

		RuleTableListener listener = new RuleTableListener();
		table.addValueChangeListener(listener);
		table.addItemClickListener(listener);
		table.setCellStyleGenerator(new RuleTableCellStyleGenerator());

		return table;
	}

	private void configureTable()
	{
		RuleContainer tempNotificationsContainer = new RuleContainer(rules, filter);
		table.setContainerDataSource(tempNotificationsContainer,
				Arrays.asList(RuleConstants.PROPERTY_IDS));
		table.setColumnCollapsible(RuleConstants.RULE_NAME, false);
		table.setColumnCollapsible(RuleConstants.RULE_ACTIVE, false);
		table.setColumnCollapsible(RuleConstants.RULE_TYPE, false);
		table.setVisibleColumns(RuleConstants.VISIBLE_PROPERTY_IDS);
		for (Object propertyId : RuleConstants.VISIBLE_PROPERTY_IDS)
		{
			table.setColumnHeader(propertyId, DashboardUI.getMessageSource()
					.getMessage(RuleConstants.COLUMN_HEADER + ((String) propertyId).toLowerCase()));
		}
	}

	@SuppressWarnings ("unchecked")
	public void editRuleDetails()
	{
		showRuleDetails(((Collection<Rule>) table.getValue()).iterator().next(), true);
	}

	public void showRuleDetails(Rule rule, boolean saveRuleButtonEnabled)
	{
		ruleDetailsView = new RuleDetailsView(rule, saveRule);

		this.replaceComponent(table, ruleDetailsView);

		tools.removeAllComponents();
		tools.addComponents(saveRule, cancel);

		saveRule.setEnabled(saveRuleButtonEnabled);
		cancel.setEnabled(true);
	}

	@SuppressWarnings ("unchecked")
	public void copyRule()
	{
		Rule rule = ((Collection<Rule>) table.getValue()).iterator().next();
		rule.setId(null);
		rule.setName(rule.getName() + "_"
				+ DashboardUI.getMessageSource().getMessage(RuleConstants.COPY_POST_FIX));
		rule.getWagons().forEach(wagon -> wagon.setInitial(true));
		showRuleDetails(rule, true);
	}

	@SuppressWarnings ("unchecked")
	public void removeRule()
	{
		Set<Rule> rules = (Set<Rule>) table.getValue();
		List<Rule> rulesList = new ArrayList<Rule>();
		rulesList.addAll(rules);

		DashboardEventBus.post(new RulesDeleteEvent(rulesList, user.getTenant()));
	}

	public void saveRule()
	{
		if (ruleDetailsView != null)
		{
			if (ruleDetailsView.getRule().getRuleType()
					.equals(RuleConstants.HUMIDITY_TEMPERATURE_RANGE)
					&& ruleDetailsView.getMinRange().getValue() >= ruleDetailsView.getMaxRange()
							.getValue())
				Notification
						.show(DashboardUI.getMessageSource().getMessage("view.rule.range.invalid"));
			else
				DashboardEventBus.post(new RuleSaveEvent(ruleDetailsView.getRule(),
						user.getTenant(), ruleDetailsView.getPrimaryAssignedWagonsToRule()));
		}
		else
		{
			DashboardEventBus.post(new RuleSaveEvent(null, user.getTenant(), null));
		}
	}

	public void showRulesTable()
	{
		boolean ascending = table.isSortAscending();
		String propertyToSort = (String) table.getSortContainerPropertyId();
		DashboardEventBus.post(new RuleSortAndFilterEvent(user.getTenant(), propertyToSort,
				!ascending, filter.getValue()));

		this.replaceComponent(ruleDetailsView, table);

		tools.removeAllComponents();
		tools.addComponents(filter, createRule, editRule, copyRule, removeRule);

		createRule.setEnabled(true);
		editRule.setEnabled(false);
		copyRule.setEnabled(false);
		removeRule.setEnabled(false);
	}

	@Subscribe
	public void setRuleList(RuleSentAllEvent event)
	{
		rules = event.getRules();
		table.getContainerDataSource().removeAllItems();
		if (rules.size() > 0)
		{
			configureTable();
		}
	}

	private TextField buildFilter()
	{
		filter = new TextField();
		filter.addTextChangeListener(new TextChangeListener()
		{
			@Override
			public void textChange(final TextChangeEvent event)
			{
				filter(event.getText());
			}
		});

		filter.setInputPrompt(
				DashboardUI.getMessageSource().getMessage(RuleConstants.FILTER_INPUT));
		filter.setIcon(FontAwesome.SEARCH);
		filter.addStyleName(ValoTheme.TEXTFIELD_INLINE_ICON);
		filter.addShortcutListener(new ShortcutListener("Clear", KeyCode.ESCAPE, null)
		{
			@Override
			public void handleAction(Object sender, Object target)
			{
				filter.setValue("");
				((Filterable) table.getContainerDataSource()).removeAllContainerFilters();
				filter(filter.getValue());
			}
		});
		return filter;
	}

	private void filter(String value)
	{
		String propertyToSort = (String) table.getSortContainerPropertyId();
		boolean ascending = table.isSortAscending();

		DashboardEventBus.post(
				new RuleSortAndFilterEvent(user.getTenant(), propertyToSort, !ascending, value));
	}

	private boolean defaultColumnsVisible()
	{
		boolean result = true;
		for (String propertyId : RuleConstants.DEFAULT_COLLAPSIBLE)
		{
			if (table.isColumnCollapsed(
					propertyId) == Page.getCurrent().getBrowserWindowWidth() < 800)
			{
				result = false;
			}
		}
		return result;
	}

	@Subscribe
	public void browserResized(BrowserResizeEvent event)
	{
		if (defaultColumnsVisible())
		{
			for (String propertyId : RuleConstants.DEFAULT_COLLAPSIBLE)
			{
				table.setColumnCollapsed(propertyId,
						Page.getCurrent().getBrowserWindowWidth() < 800);
			}
		}
	}

	@Subscribe
	public void successfulRuleSaving(RuleSavedEvent event)
	{
		showRulesTable();
		new UserNotification("view.alarm.success", 1000, true);
	}

	@Subscribe
	public void failedRuleSaving(NotSuccessfulEvent event)
	{
		String code = event.getCode();
		new UserNotification(code, 1000, false);
	}

	@Subscribe
	public void failedRuleSaving(TemperatureRangeRuleFailedSavedEvent event)
	{
		String wagonAliases = buildHtmlList(event.getWagonAliases());
		String ruleNames = buildHtmlList(event.getRuleNames());
		String errorMessageFormatted = String.format(
				DashboardUI.getMessageSource().getMessage("view.alarm.duplicate.wagons"),
				wagonAliases, ruleNames);
		Notification errorNotification = new Notification(errorMessageFormatted,
				Type.ERROR_MESSAGE);
		errorNotification.setHtmlContentAllowed(true);
		errorNotification.show(Page.getCurrent());

		Table wagonAssignedTable = ruleDetailsView.getWagonTable();
		wagonAssignedTable.setCellStyleGenerator((tableToStyle, cellItem, cellProperty) -> {

			Wagon wagon = (Wagon) cellItem;
			return Arrays.asList(event.getWagonAliases()).contains(wagon.getAlias())
					? "highlight-row" : "";
		});
	}

	private String buildHtmlList(String[] contentArray)
	{
		StringBuilder wagonAliases = new StringBuilder("<ul>");
		Arrays.stream(contentArray)
				.forEach(alias -> wagonAliases.append("<li>").append(alias).append("</li>"));
		wagonAliases.append("</ul>");
		return wagonAliases.toString();
	}

	@Override
	public void enter(ViewChangeEvent event)
	{
	}

	@SuppressWarnings ("unchecked")
	private class RuleTableListener implements ValueChangeListener, ItemClickListener
	{
		@Override
		public void itemClick(ItemClickEvent event)
		{
			if (event.isDoubleClick())
			{
				showRuleDetails(((Collection<Rule>) table.getValue()).iterator().next(), true);
			}
		}

		@Override
		public void valueChange(ValueChangeEvent event)
		{
			Collection<Wagon> val = (Collection<Wagon>) table.getValue();
			editRule.setEnabled(val.size() == 1);
			copyRule.setEnabled(val.size() == 1);
			removeRule.setEnabled(val.size() >= 1);
		}
	}
}