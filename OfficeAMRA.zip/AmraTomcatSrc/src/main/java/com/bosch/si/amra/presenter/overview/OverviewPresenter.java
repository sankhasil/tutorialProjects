
package com.bosch.si.amra.presenter.overview;

import com.bosch.si.amra.event.DashboardEvent.DeleteTagEvent;
import com.bosch.si.amra.event.DashboardEvent.TagAssignChangeEvent;
import com.bosch.si.amra.event.DashboardEvent.TagCreateOrUpdateEvent;
import com.google.common.eventbus.Subscribe;

public interface OverviewPresenter
{

	@Subscribe
	public void createOrUpdateTag(TagCreateOrUpdateEvent event);

	@Subscribe
	public void changeTagAssignmentToWagon(TagAssignChangeEvent event);

	@Subscribe
	public void deleteTags(DeleteTagEvent event);
}
