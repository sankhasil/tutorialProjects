
package com.bosch.si.amra.view.export;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.event.DashboardEvent.ExportDownloadEvent;
import com.bosch.si.amra.event.DashboardEvent.ExportGenerationEvent;
import com.bosch.si.amra.event.DashboardEvent.ReportEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.im.login.Role;
import com.bosch.si.amra.im.login.Role.Roles;
import com.google.common.eventbus.Subscribe;
import com.vaadin.data.Container;
import com.vaadin.data.Property.ValueChangeEvent;
import com.vaadin.data.Property.ValueChangeListener;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.event.ItemClickEvent;
import com.vaadin.event.ItemClickEvent.ItemClickListener;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.event.ShortcutListener;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Page;
import com.vaadin.server.Responsive;
import com.vaadin.server.StreamResource;
import com.vaadin.server.VaadinSession;
import com.vaadin.shared.ui.datefield.Resolution;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;
import com.vaadin.ui.CheckBox;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.Component;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.MenuBar;
import com.vaadin.ui.MenuBar.Command;
import com.vaadin.ui.MenuBar.MenuItem;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Notification.Type;
import com.vaadin.ui.Panel;
import com.vaadin.ui.PopupDateField;
import com.vaadin.ui.Table;
import com.vaadin.ui.UI;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

@SuppressWarnings ("serial")
@Role ({ Roles.USER, Roles.FLEETADMIN, Roles.SYSTEMADMIN })
public class ExportView extends Panel implements View
{

	private static final String		CSV_FILE_NAME_DATE_FORMAT	= "yyyy.MM.dd__HH.mm.ss";

	private static final String		ALIAS						= "alias";

	private final VerticalLayout	root;

	private ComboBox				wagonSelect;

	private CssLayout				dashboardPanels;

	private Button					clear;

	private Button					export;

	private PopupDateField			toDateField;

	private PopupDateField			fromDateField;

	private Table					table;

	private CheckBox				checkBoxLONGITUDE;

	private CheckBox				checkBoxLATITUDE;

	private CheckBox				checkBoxALTITUDE;

	private CheckBox				checkBoxHUMIDITY;

	private CheckBox				checkBoxDEVICE_TEMPERATURE;

	private CheckBox				checkBoxHUMIDITY_TEMPERATURE;

	private CheckBox				checkBoxSHOCK;

	private CheckBox				checkBoxMILEAGE;

	private final User				user						= (User) VaadinSession.getCurrent()
			.getAttribute(User.class.getName());

	public ExportView()
	{
		setSizeFull();
		addStyleName("sales");
		DashboardEventBus.register(this);

		root = new VerticalLayout();
		root.setSizeFull();
		root.setMargin(true);
		root.addStyleName("dashboard-view");
		setContent(root);
		Responsive.makeResponsive(root);
		root.addComponent(buildHeader());
		initWagonSelect();

		Component content = buildContent();
		root.addComponent(content);
		root.setExpandRatio(content, 1);
	}

	private Component buildHeader()
	{
		HorizontalLayout header = new HorizontalLayout();
		header.addStyleName("viewheader");
		header.setSpacing(true);
		Responsive.makeResponsive(header);
		Label titleLabel = new Label(
				DashboardUI.getMessageSource().getMessage("view.export.caption"));
		titleLabel.setSizeUndefined();
		titleLabel.addStyleName(ValoTheme.LABEL_H1);
		titleLabel.addStyleName(ValoTheme.LABEL_NO_MARGIN);
		header.addComponents(titleLabel, buildToolbar());

		return header;
	}

	private Component buildToolbar()
	{
		HorizontalLayout toolbar = new HorizontalLayout();
		toolbar.addStyleName("toolbar");
		toolbar.setSpacing(true);

		clear = new Button();
		clear.setDescription(DashboardUI.getMessageSource().getMessage("view.export.clear"));
		clear.setIcon(FontAwesome.TRASH_O);
		clear.setEnabled(false);
		clear.addClickListener(new ClickListener()
		{
			@Override
			public void buttonClick(ClickEvent event)
			{
				table.removeAllItems();
				initWagonSelect();
				clear.setEnabled(false);
				export.setEnabled(false);
				checkBoxLONGITUDE.setValue(false);
				checkBoxLATITUDE.setValue(false);
				checkBoxALTITUDE.setValue(false);
				checkBoxHUMIDITY.setValue(false);
				checkBoxDEVICE_TEMPERATURE.setValue(false);
				checkBoxHUMIDITY_TEMPERATURE.setValue(false);
				checkBoxSHOCK.setValue(false);
				checkBoxMILEAGE.setValue(false);
				initializeDateFields();
			}
		});

		wagonSelect = new ComboBox();
		wagonSelect.setItemCaptionPropertyId("alias");
		wagonSelect.addShortcutListener(new ShortcutListener(
				DashboardUI.getMessageSource().getMessage("view.report.add"), KeyCode.ENTER, null)
		{
			@Override
			public void handleAction(Object sender, Object target)
			{
				Wagon wagon = (Wagon) wagonSelect.getValue();
				DashboardEventBus.post(new ReportEvent(user.getTenant(), Arrays.asList(wagon)));
			}
		});

		final Button add = new Button();
		add.setDescription(DashboardUI.getMessageSource().getMessage("view.export.add"));
		add.setIcon(FontAwesome.PLUS);
		add.setEnabled(false);
		add.addStyleName(ValoTheme.BUTTON_PRIMARY);
		add.addClickListener(new ClickListener()
		{
			@Override
			public void buttonClick(ClickEvent event)
			{
				addWagon();
			}
		});

		CssLayout group = new CssLayout(wagonSelect, add);
		group.addStyleName(ValoTheme.LAYOUT_COMPONENT_GROUP);
		toolbar.addComponent(group);

		wagonSelect.addValueChangeListener(new ValueChangeListener()
		{
			@Override
			public void valueChange(ValueChangeEvent event)
			{
				add.setEnabled(event.getProperty().getValue() != null);
			}
		});

		export = buildExportButton();
		toolbar.addComponent(export);
		toolbar.addComponent(clear);

		return toolbar;
	}

	private void initWagonSelect()
	{
		Collection<Wagon> wagons = DashboardUI.getDataProvider().getWagonsShort(user);
		Container wagonContainer = new BeanItemContainer<>(Wagon.class, wagons);
		wagonSelect.setContainerDataSource(wagonContainer);
	}

	private void addWagon()
	{
		if (wagonSelect.getValue() != null)
		{
			table.addItem(wagonSelect.getValue());
			wagonSelect.removeItem(wagonSelect.getValue());

		}

		clear.setEnabled(true);
		export.setEnabled(true);
	}

	private Button buildExportButton()
	{
		export = new Button();
		export.setDescription(DashboardUI.getMessageSource().getMessage("view.export.caption"));
		export.setIcon(FontAwesome.TABLE);
		export.setEnabled(false);
		export.addClickListener(new Button.ClickListener()
		{
			@SuppressWarnings ("unchecked")
			@Override
			public void buttonClick(ClickEvent event)
			{
				Map<String, Boolean> selectedCheckBoxes = new LinkedHashMap<String, Boolean>();
				selectedCheckBoxes.put(MongoConstants.DATE, true);
				selectedCheckBoxes.put(MongoConstants.TIME, true);
				selectedCheckBoxes.put(MongoConstants.LONGITUDE, checkBoxLONGITUDE.getValue());
				selectedCheckBoxes.put(MongoConstants.LATITUDE, checkBoxLATITUDE.getValue());
				selectedCheckBoxes.put(MongoConstants.ALTITUDE, checkBoxALTITUDE.getValue());
				selectedCheckBoxes.put(MongoConstants.HUMIDITY, checkBoxHUMIDITY.getValue());
				selectedCheckBoxes.put(MongoConstants.DEVICE_TEMPERATURE,
						checkBoxDEVICE_TEMPERATURE.getValue());
				selectedCheckBoxes.put(MongoConstants.HUMIDITY_TEMPERATURE,
						checkBoxHUMIDITY_TEMPERATURE.getValue());
				selectedCheckBoxes.put(MongoConstants.SHOCK, checkBoxSHOCK.getValue());
				selectedCheckBoxes.put(MongoConstants.MILEAGE, checkBoxMILEAGE.getValue());
				Calendar startDate = formatStartDate();
				Calendar endDate = formatEndDate();

				BeanItemContainer<Wagon> wagonContainer = (BeanItemContainer<Wagon>) table
						.getContainerDataSource();

				List<Wagon> selectedWagons = wagonContainer.getItemIds();

				if (selectedWagons != null)
				{
					DashboardEventBus
							.post(new ExportGenerationEvent(user.getTenant(), selectedWagons,
									selectedCheckBoxes, new Date(startDate.getTimeInMillis()),
									new Date(endDate.getTimeInMillis())));
				}
			}
		});
		return export;
	}

	private Component buildContent()
	{
		dashboardPanels = new CssLayout();
		dashboardPanels.addStyleName("dashboard-panels");
		Responsive.makeResponsive(dashboardPanels);
		dashboardPanels.addComponent(buildCSVGUI());
		return dashboardPanels;
	}

	private Component buildCSVGUI()
	{
		VerticalLayout verticalLayout = new VerticalLayout();
		verticalLayout.setSizeFull();
		Responsive.makeResponsive(verticalLayout);
		Component datePicker = buildDatePicker();
		verticalLayout.addComponent(datePicker);
		table = buildTable();
		VerticalLayout checkBoxes = generateCheckboxes();
		HorizontalLayout tools = new HorizontalLayout(table, checkBoxes);
		tools.setSpacing(true);
		tools.setWidth("100%");
		verticalLayout.addComponent(tools);
		HorizontalLayout buttonLayout = new HorizontalLayout();
		buttonLayout.setWidth("100%");
		buttonLayout.setSpacing(true);
		verticalLayout.addComponent(buttonLayout);
		verticalLayout.setExpandRatio(datePicker, 1);
		verticalLayout.setExpandRatio(tools, 4);
		verticalLayout.setExpandRatio(buttonLayout, 1);

		Component buildCSVGUI = createContentWrapper(verticalLayout, "view.export.help");

		return buildCSVGUI;
	}

	private Table buildTable()
	{
		table = new Table();

		BeanItemContainer<Wagon> wagonsContainer = new BeanItemContainer<Wagon>(Wagon.class);
		table.setContainerDataSource(wagonsContainer);
		table.addStyleName(ValoTheme.TABLE_BORDERLESS);
		table.addStyleName(ValoTheme.TABLE_NO_HORIZONTAL_LINES);
		table.addStyleName(ValoTheme.TABLE_COMPACT);
		table.setSortAscending(false);
		table.setColumnCollapsible(ALIAS, false);
		table.setSortAscending(true);
		table.setVisibleColumns(ALIAS);
		table.setColumnHeaders(
				DashboardUI.getMessageSource().getMessage("view.overview.columnheader.alias"));
		table.setSelectable(true);

		table.addItemClickListener(new ItemClickListener()
		{
			@SuppressWarnings ("unchecked")
			@Override
			public void itemClick(ItemClickEvent event)
			{
				if (event.isDoubleClick())
				{
					Wagon wagon = (Wagon) event.getItemId();
					table.removeItem(wagon);
					wagonSelect.addItem(wagon);
					BeanItemContainer<Wagon> wagonContainer = (BeanItemContainer<Wagon>) table
							.getContainerDataSource();

					if (wagonContainer.getItemIds().isEmpty())
					{
						clear.setEnabled(false);
						export.setEnabled(false);
					}
				}
			}
		});
		return table;
	}

	private Component buildDatePicker()
	{
		HorizontalLayout horizontalLayout = new HorizontalLayout();
		horizontalLayout.setSpacing(true);
		horizontalLayout.setWidth("100%");

		fromDateField = new PopupDateField(
				DashboardUI.getMessageSource().getMessage("view.mileage.popupdate.from"));
		fromDateField
				.setDateFormat(DashboardUI.getMessageSource().getMessage("date.format.picker"));
		fromDateField.setResolution(Resolution.DAY);
		fromDateField.setLocale(UI.getCurrent().getLocale());
		fromDateField.setImmediate(true);
		fromDateField.setLenient(true);
		fromDateField.addStyleName(ValoTheme.DATEFIELD_LARGE);
		fromDateField.setParseErrorMessage(
				DashboardUI.getMessageSource().getMessage("view.mileage.wrong.date"));
		fromDateField.setValidationVisible(true);
		fromDateField.setDateOutOfRangeMessage(
				DashboardUI.getMessageSource().getMessage("view.mileage.wrong.period"));
		fromDateField.setRangeEnd(new Date());

		toDateField = new PopupDateField(
				DashboardUI.getMessageSource().getMessage("view.mileage.popupdate.to"));
		toDateField.setDateFormat(DashboardUI.getMessageSource().getMessage("date.format.picker"));
		toDateField.setResolution(Resolution.DAY);
		toDateField.setLocale(UI.getCurrent().getLocale());
		toDateField.setImmediate(true);
		toDateField.setLenient(true);
		toDateField.addStyleName(ValoTheme.DATEFIELD_LARGE);
		toDateField.setParseErrorMessage(
				DashboardUI.getMessageSource().getMessage("view.mileage.wrong.date"));
		toDateField.setValidationVisible(true);
		toDateField.setDateOutOfRangeMessage(
				DashboardUI.getMessageSource().getMessage("view.mileage.wrong.period"));

		initializeDateFields();
		fromDateField.setRangeEnd(toDateField.getValue());
		toDateField.setRangeStart(fromDateField.getValue());

		fromDateField.addValueChangeListener(new ValueChangeListener()
		{
			@Override
			public void valueChange(ValueChangeEvent event)
			{
				toDateField.setRangeStart((Date) event.getProperty().getValue());
				enableButton();
			}
		});

		toDateField.addValueChangeListener(new ValueChangeListener()
		{
			@Override
			public void valueChange(ValueChangeEvent event)
			{
				fromDateField.setRangeEnd((Date) event.getProperty().getValue());
				enableButton();
			}
		});

		horizontalLayout.addComponents(fromDateField, toDateField);
		return horizontalLayout;
	}

	private void initializeDateFields()
	{
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.MONTH, calendar.get(Calendar.MONTH) - 1);

		fromDateField.setValue(new Date(calendar.getTimeInMillis()));
		toDateField.setValue(new Date());
	}

	private void enableButton()
	{

		if (fromDateField.isValid() && toDateField.isValid() && wagonSelect.getValue() != null)
		{
			fromDateField.setValidationVisible(false);
			toDateField.setValidationVisible(false);
		}
		else
		{
			fromDateField.setValidationVisible(true);
			toDateField.setValidationVisible(true);
		}
	}

	private VerticalLayout generateCheckboxes()
	{
		checkBoxLONGITUDE = new CheckBox(DashboardUI.getMessageSource()
				.getMessage("view.notification.columnheader.longitude"), false);
		checkBoxLATITUDE = new CheckBox(DashboardUI.getMessageSource()
				.getMessage("view.notification.columnheader.latitude"), false);
		checkBoxALTITUDE = new CheckBox(DashboardUI.getMessageSource()
				.getMessage("view.notification.columnheader.altitude"), false);
		checkBoxHUMIDITY = new CheckBox(
				DashboardUI.getMessageSource().getMessage("view.export.checkbox.humidity"), false);
		checkBoxDEVICE_TEMPERATURE = new CheckBox(
				DashboardUI.getMessageSource().getMessage("view.export.checkbox.devicetemperature"),
				false);
		checkBoxHUMIDITY_TEMPERATURE = new CheckBox(DashboardUI.getMessageSource()
				.getMessage("view.export.checkbox.humiditytemperature"), false);
		checkBoxSHOCK = new CheckBox(
				DashboardUI.getMessageSource().getMessage("view.export.checkbox.shockx"), false);

		checkBoxMILEAGE = new CheckBox(
				DashboardUI.getMessageSource().getMessage("view.export.checkbox.mileage"), false);

		VerticalLayout checkBoxes = new VerticalLayout(checkBoxLONGITUDE, checkBoxLATITUDE,
				checkBoxALTITUDE, checkBoxHUMIDITY, checkBoxDEVICE_TEMPERATURE,
				checkBoxHUMIDITY_TEMPERATURE, checkBoxSHOCK, checkBoxMILEAGE);

		return checkBoxes;
	}

	private Component createContentWrapper(Component content, final String code)
	{
		final CssLayout slot = new CssLayout();
		slot.setWidth("100%");
		slot.setHeight("100%");

		CssLayout card = new CssLayout();
		card.setWidth("100%");
		card.setHeight("100%");
		card.addStyleName(ValoTheme.LAYOUT_CARD);

		HorizontalLayout toolbar = new HorizontalLayout();
		toolbar.addStyleName("dashboard-panel-toolbar");
		toolbar.setWidth("100%");

		Label caption = new Label(content.getCaption());
		caption.addStyleName(ValoTheme.LABEL_H4);
		caption.addStyleName(ValoTheme.LABEL_COLORED);
		caption.addStyleName(ValoTheme.LABEL_NO_MARGIN);
		content.setCaption(null);

		MenuBar tools = new MenuBar();
		tools.addStyleName(ValoTheme.MENUBAR_BORDERLESS);
		MenuItem help = tools.addItem("", FontAwesome.QUESTION_CIRCLE, new Command()
		{
			@Override
			public void menuSelected(MenuItem selectedItem)
			{
				Notification.show(DashboardUI.getMessageSource().getMessage("slot.help"),
						DashboardUI.getMessageSource().getMessage(code), Type.HUMANIZED_MESSAGE);
			}
		});
		help.setStyleName("icon-only");

		toolbar.addComponents(caption, tools);
		toolbar.setExpandRatio(caption, 1);
		toolbar.setComponentAlignment(caption, Alignment.MIDDLE_LEFT);

		card.addComponents(toolbar, content);
		slot.addComponent(card);
		return slot;
	}

	private Calendar formatStartDate()
	{
		Calendar startDate = Calendar.getInstance();
		startDate.setTime(fromDateField.getValue());
		startDate.set(Calendar.HOUR_OF_DAY, 0);
		startDate.set(Calendar.MINUTE, 0);
		startDate.set(Calendar.SECOND, 0);
		startDate.set(Calendar.MILLISECOND, 0);
		return startDate;
	}

	private Calendar formatEndDate()
	{
		Calendar endDate = Calendar.getInstance();
		endDate.setTime(toDateField.getValue());
		endDate.set(Calendar.HOUR_OF_DAY, 23);
		endDate.set(Calendar.MINUTE, 59);
		endDate.set(Calendar.SECOND, 59);
		endDate.set(Calendar.MILLISECOND, 999);
		return endDate;
	}

	@SuppressWarnings ({ "deprecation" })
	@Subscribe
	public void provideCSVDownload(ExportDownloadEvent event) throws UnsupportedEncodingException
	{

		final StringBuffer sb = event.getStreamResource();

		String timeStamp = new SimpleDateFormat(CSV_FILE_NAME_DATE_FORMAT).format(new Date());
		String wagonData = new String(("Wagon_Data_" + timeStamp + ".csv").getBytes(), "UTF-8");

		StreamResource streamResource = new StreamResource(new StreamResource.StreamSource()
		{
			@Override
			public InputStream getStream()
			{
				try
				{
					String str = sb.toString();

					byte[] bytes = str.getBytes("ISO-8859-1");

					ByteArrayInputStream bai = new ByteArrayInputStream(bytes);

					return bai;
				}
				catch (Exception e)
				{
					e.printStackTrace();
					return null;
				}
			}
		}, wagonData);
		streamResource.setMIMEType("text/comma-separated-values");
		streamResource.getStream().setParameter("Content-Type",
				"text/comma-separated-values; charset=UTF-8");
		Page.getCurrent().open(streamResource, "Download", false);
	}

	@Override
	public void detach()
	{
		super.detach();
		DashboardEventBus.unregister(this);
	}

	@Override
	public void enter(ViewChangeEvent event)
	{
	}
}