/**
 *
 */

package com.bosch.si.amra.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;

import com.bosch.si.amra.constants.MongoConstants;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

/**
 * @author ils5kor
 *
 */
public class Tag implements Serializable
{

	private static final long	serialVersionUID	= 1L;

	private String				id;

	private String				tagName;

	private Long				createdServerTimestamp;

	private Date				createdDate			= new Date();

	private String				tenantId;

	private String				createdBy;

	private boolean				assigned;

	public Tag()
	{
		this.id = UUID.randomUUID().toString();
	}

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public String getTagName()
	{
		return tagName;
	}

	public void setTagName(String tagName)
	{
		this.tagName = tagName;
	}

	public Long getCreatedServerTimestamp()
	{
		return createdServerTimestamp;
	}

	public void setCreatedServerTimestamp(Long createdServerTimestamp)
	{
		this.createdServerTimestamp = createdServerTimestamp;
	}

	public String getTenantId()
	{
		return tenantId;
	}

	public void setTenantId(String tenantId)
	{
		this.tenantId = tenantId;
	}

	public boolean isAssigned()
	{
		return assigned;
	}

	public void setAssigned(boolean assigned)
	{
		this.assigned = assigned;
	}

	public Date getCreatedDate()
	{
		return createdDate;
	}

	public void setCreatedDate(Date createdDate)
	{
		this.createdDate = createdDate;
	}

	public String getCreatedBy()
	{
		return createdBy;
	}

	public void setCreatedBy(String createdBy)
	{
		this.createdBy = createdBy;
	}

	/**
	 * converts the tag object to DBObject for MongoDB
	 *
	 * @param tag The Tag object
	 * @return {@link DBObject}
	 */
	public static DBObject tag2DBObject(Tag tag)
	{
		DBObject tagObject = null;
		if (tag != null)
		{
			tagObject = new BasicDBObject();
			String id = tag.getId();
			tagObject.put(MongoConstants.ID, id);
			if (StringUtils.isNotEmpty(tag.getTagName()))
			{
				tagObject.put(MongoConstants.TAG_NAME, tag.getTagName());
				tagObject.put(MongoConstants.SORT, tag.getTagName().toLowerCase());
				tagObject.put(MongoConstants.SERVER_TIMESTAMP, tag.getCreatedServerTimestamp());
				tagObject.put(MongoConstants.TENANT_ID, tag.getTenantId());
				tagObject.put(MongoConstants.TAG_ASSIGNED, tag.isAssigned());
				if (StringUtils.isNotEmpty(tag.getCreatedBy()))
					tagObject.put(MongoConstants.CREATED_BY, tag.getCreatedBy());
			}
		}
		return tagObject;
	}

	/**
	 * converts DBObject of MongoDB to Tag Object
	 *
	 * @param dbObject the Tag DBObject
	 * @return {@link Tag}
	 */
	public static Tag dbObject2Tag(DBObject dbObject)
	{
		Tag tag = null;
		if (dbObject != null)
		{
			tag = new Tag();
			tag.setId((String) dbObject.get(MongoConstants.ID));
			tag.setTagName((String) dbObject.get(MongoConstants.TAG_NAME));
			tag.setCreatedServerTimestamp((Long) dbObject.get(MongoConstants.SERVER_TIMESTAMP));
			tag.setTenantId((String) dbObject.get(MongoConstants.TENANT_ID));
			tag.setCreatedDate(new Date((Long) dbObject.get(MongoConstants.SERVER_TIMESTAMP)));
			tag.setAssigned((boolean) dbObject.get(MongoConstants.TAG_ASSIGNED));
			tag.setCreatedBy((String) dbObject.get(MongoConstants.CREATED_BY));
		}
		return tag;

	}

	public static Tag dbObjectShort2Tag(DBObject dbObject)
	{
		Tag tag = null;
		if (dbObject != null)
		{
			tag = new Tag();
			tag.setId((String) dbObject.get(MongoConstants.ID));
			tag.setTagName((String) dbObject.get(MongoConstants.TAG_NAME));
		}
		return tag;

	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Tag other = (Tag) obj;
		if (id == null)
		{
			if (other.id != null)
				return false;
		}
		else if (!id.equals(other.id))
			return false;
		if (tagName == null)
		{
			if (other.tagName != null)
				return false;
		}
		else if (!tagName.equals(other.tagName))
			return false;
		return true;
	}

}
