
package com.bosch.si.amra.presenter.notification;

import java.io.Serializable;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.constants.UIConstants;
import com.bosch.si.amra.constants.notification.NotificationConstants;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.notification.Notification;
import com.bosch.si.amra.event.DashboardEvent;
import com.bosch.si.amra.event.DashboardEvent.NotificationAcknowledgeEvent;
import com.bosch.si.amra.event.DashboardEvent.NotificationsSaveAliasEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.provider.DataProviderInitializer;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.WriteResult;

@Component
public class NotificationPresenterImpl implements Serializable, NotificationPresenter
{

	private static final Logger	logger				= LoggerFactory
			.getLogger(NotificationPresenterImpl.class);

	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= -2486697363649941698L;

	@Override
	public void acknowledgeNotifications(NotificationAcknowledgeEvent event)
	{
		List<Notification> notifications = event.getNotifications();
		User user = event.getUser();
		if (user == null)
			throw new IllegalArgumentException(UIConstants.USER_MUST_NOT_BE_NULL);
		if (notifications == null)
			throw new IllegalArgumentException("Notifications must not be null");
		if (user.getTenant() == null || user.getTenant().isEmpty())
			throw new IllegalArgumentException(UIConstants.TENANT_ID_MUST_NOT_BE_NULL);

		DBCollection notificationCollection = getNotificationCollection();
		DBObject updateObject = createUpdateObject();
		for (Notification notification : notifications)
		{
			if (!notification.isAcknowledged())
			{
				notificationCollection.update(
						new BasicDBObject().append("_id", notification.getId()), updateObject,
						false, true);
			}
		}

		List<Notification> notificationsList = DashboardUI.getNotificationDataProvider()
				.getNotifications(user, false, true);
		DashboardEventBus.post(new DashboardEvent.NotificationSetEvent(notificationsList));
		logger.debug("Acknowledged notification");
	}

	private DBObject createUpdateObject()
	{
		DBObject updateObject = new BasicDBObject();
		updateObject.put(NotificationConstants.ACKNOWLEDGED, true);

		DBObject setObject = new BasicDBObject();
		setObject.put("$set", updateObject);
		return setObject;
	}

	@Override
	public WriteResult saveAliasInNotifications(NotificationsSaveAliasEvent event)
	{

		if (event.getWagonId() == null || event.getAlias() == null || event.getWagonId().isEmpty()
				|| event.getAlias().isEmpty())
		{
			throw new IllegalArgumentException("Arguments must not be null or empty");
		}
		String wagonId = event.getWagonId();
		String alias = event.getAlias();

		DBCollection notificationCollection = getNotificationCollection();

		return notificationCollection.update(
				new BasicDBObject().append(MongoConstants.WAGON_ID, wagonId),
				createAliasUpdateObject(alias), false, true);
	}

	private DBObject createAliasUpdateObject(String alias)
	{
		DBObject updateObject = new BasicDBObject();
		updateObject.put(NotificationConstants.ALIAS, alias);
		updateObject.put(NotificationConstants.SORT, alias.toLowerCase());

		DBObject setObject = new BasicDBObject();
		setObject.put("$set", updateObject);
		return setObject;
	}

	private DBCollection getNotificationCollection()
	{
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		return db.getCollection(DashboardUI.getNotificationCollection());
	}
}
