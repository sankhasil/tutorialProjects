
package com.bosch.si.amra.component;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.WagonUser;
import com.bosch.si.amra.event.DashboardEvent.AssignUserToWagonsEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.data.util.converter.Converter.ConversionException;
import com.vaadin.data.validator.NullValidator;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.server.FontAwesome;
import com.vaadin.shared.ui.window.WindowMode;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.Component;
import com.vaadin.ui.DateField;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.ListSelect;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Notification.Type;
import com.vaadin.ui.PopupDateField;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.Window;

public class WagonUserAssignmentWindow extends Window
{
	private static final long	serialVersionUID		= 3171386869696873733L;

	private static final int	LIST_SELECT_WIDTH		= 300;

	private final String		selectedWagonId;

	private ListSelect			leftSelect;

	private ListSelect			rightSelect;

	private DateField			activationDateField;

	private Button				saveButton;

	private boolean				isRightSelectionStarted	= false;

	private boolean				isLeftSelectionStarted	= false;

	public WagonUserAssignmentWindow(String selectedWagonId)
	{
		this.selectedWagonId = selectedWagonId;
		center();
		setClosable(true);
		addCloseShortcut(KeyCode.ESCAPE, null);
		setResizable(false);
		setWindowMode(WindowMode.NORMAL);
		setModal(true);

		VerticalLayout mainVerticalLayout = new VerticalLayout();
		mainVerticalLayout.setSpacing(true);
		mainVerticalLayout.setMargin(true);
		mainVerticalLayout.addComponents(buildTwinColSelect(), buildToolsButtons());
		setContent(mainVerticalLayout);
	}

	private Component buildTwinColSelect()
	{
		leftSelect = createListSelect("view.role.assign.left.caption");
		rightSelect = createListSelect("view.role.assign.right.caption");
		Button leftButton = new Button(FontAwesome.CHEVRON_LEFT);
		Button rightButton = new Button(FontAwesome.CHEVRON_RIGHT);
		configureListenersForTwinCol(leftButton, rightButton);

		VerticalLayout verticalLayout = new VerticalLayout(leftButton, rightButton);

		HorizontalLayout horizontalLayout = new HorizontalLayout();
		horizontalLayout.setSpacing(true);
		horizontalLayout.setMargin(true);
		horizontalLayout.addComponents(leftSelect, verticalLayout, rightSelect);
		horizontalLayout.setComponentAlignment(verticalLayout, Alignment.MIDDLE_CENTER);

		return horizontalLayout;
	}

	private ListSelect createListSelect(String title)
	{
		ListSelect listSelect = new ListSelect(DashboardUI.getMessageSource().getMessage(title));
		listSelect.setNullSelectionAllowed(false);
		listSelect.setWidth(LIST_SELECT_WIDTH, Unit.PIXELS);
		listSelect.setMultiSelect(true);
		listSelect.setContainerDataSource(
				new BeanItemContainer<>(WagonUser.class, new ArrayList<WagonUser>()));
		listSelect.setItemCaptionPropertyId("description");
		return listSelect;
	}

	@SuppressWarnings ("unchecked")
	private void configureListenersForTwinCol(Button leftButton, Button rightButton)
	{
		leftSelect.addValueChangeListener(event -> {
			isLeftSelectionStarted = true;
			if (isRightSelectionStarted == false && !rightSelect.isEmpty())
			{
				rightSelect.clear();
			}

			Collection<WagonUser> rows = (Collection<WagonUser>) leftSelect.getValue();
			Boolean noEndCustomersInGroup = true;
			for (WagonUser user : rows)
			{
				if (user.isEndCustomer())
				{

					noEndCustomersInGroup = false;
					break;
				}

			}
			activationDateField.setEnabled(!noEndCustomersInGroup);
			isLeftSelectionStarted = false;
		});

		rightButton.addClickListener(event -> {
			Set<WagonUser> selectedUsers = (Set<WagonUser>) leftSelect.getValue();
			for (WagonUser selectedUser : selectedUsers)
			{
				if (selectedUser.isEndCustomer())
				{
					if (activationDateField.getValue() == null)
					{
						continue;
					}
					Calendar activationDate = Calendar.getInstance(DashboardUI.getUserTimeZone());
					activationDate.setTime(activationDateField.getValue());
					activationDate.set(Calendar.HOUR_OF_DAY, 0);
					activationDate.set(Calendar.MINUTE, 0);
					activationDate.set(Calendar.SECOND, 0);
					activationDate.set(Calendar.MILLISECOND, 0);
					selectedUser.setActivationTime(activationDate.getTime());
				}
				leftSelect.removeItem(selectedUser);
				rightSelect.addItem(selectedUser);
			}
			if (rightSelect.size() > 0)
			{
				activationDateField.setEnabled(false);
			}
		});

		rightSelect.addValueChangeListener(event -> {
			isRightSelectionStarted = true;
			if (isLeftSelectionStarted == false && !leftSelect.isEmpty())
			{
				leftSelect.clear();
			}

			Boolean noEndCustomersInGroup = true;
			Collection<WagonUser> selectedusers = (Collection<WagonUser>) rightSelect.getValue();
			for (WagonUser user : selectedusers)
			{
				if (user.isEndCustomer())
					noEndCustomersInGroup = false;
			}
			activationDateField.setEnabled(!noEndCustomersInGroup);
			isRightSelectionStarted = false;
		});

		leftButton.addClickListener(event -> {
			Set<WagonUser> selectedUsers = (Set<WagonUser>) rightSelect.getValue();
			for (WagonUser selectedUser : selectedUsers)
			{
				rightSelect.removeItem(selectedUser);

				selectedUser.setActivationTime(null);
				leftSelect.addItem(selectedUser);
			}
		});
	}

	@SuppressWarnings ("unchecked")
	private Component buildToolsButtons()
	{
		HorizontalLayout horizontalLayout = new HorizontalLayout();
		horizontalLayout.setWidth("91%");
		horizontalLayout.setStyleName("role-view-horizontal-layout");

		String errorMessage = DashboardUI.getMessageSource().getMessage("view.mileage.empty.date");
		activationDateField = new PopupDateField(
				DashboardUI.getMessageSource().getMessage("view.role.assign.activation.caption"))
		{
			private static final long serialVersionUID = -8068600640264676078L;

			@Override
			protected Date handleUnparsableDateString(String dateString) throws ConversionException
			{
				throw new ConversionException(errorMessage);
			}
		};
		activationDateField.setValue(new Date());
		activationDateField
				.setDateFormat(DashboardUI.getMessageSource().getMessage("date.format.picker"));
		activationDateField.setTimeZone(DashboardUI.getUserTimeZone());

		activationDateField.addValidator(new NullValidator(errorMessage, false));
		activationDateField.setConversionError(errorMessage);
		activationDateField.setEnabled(false);
		saveButton = new Button(FontAwesome.SAVE);
		saveButton.setDescription(
				DashboardUI.getMessageSource().getMessage("view.role.assign.save.button.tooltip"));
		saveButton.addClickListener(event -> {
			Collection<WagonUser> invalidAssignedEndUsers = getInvalidAssignedEndUsers();
			if (invalidAssignedEndUsers != null && !invalidAssignedEndUsers.isEmpty())
			{
				String[] userNames = invalidAssignedEndUsers.stream()
						.map(user -> new String(user.getUserName()))
						.toArray(size -> new String[size]);
				String msg = String.format(
						DashboardUI.getMessageSource()
								.getMessage("view.role.assign.enduser.activationtime.empty"),
						String.join(", ", userNames));
				Notification.show(msg, Type.ERROR_MESSAGE);
				rightSelect.clear();
				invalidAssignedEndUsers.forEach(user -> rightSelect.select(user));
			}
			else
			{
				assignActivationTime();
				Collection<WagonUser> col = (Collection<WagonUser>) rightSelect.getItemIds();
				DashboardEventBus
						.post(new AssignUserToWagonsEvent(new ArrayList<>(col), selectedWagonId));
				close();
			}
		});
		activationDateField.addValueChangeListener(listener -> {
			assignActivationTime();
		});

		horizontalLayout.addComponent(activationDateField);
		horizontalLayout.addComponent(saveButton);

		horizontalLayout.setComponentAlignment(activationDateField, Alignment.BOTTOM_LEFT);
		horizontalLayout.setComponentAlignment(saveButton, Alignment.BOTTOM_RIGHT);
		return horizontalLayout;
	}

	private void assignActivationTime()
	{
		Collection<WagonUser> col = (Collection<WagonUser>) rightSelect.getValue();
		for (WagonUser user : col)
		{
			if (user.isEndCustomer())
			{
				user.setActivationTime(activationDateField.getValue());
				rightSelect.attach();
			}
		}
	}

	public void setContainerDataSource(List<WagonUser> availableUsers,
			List<WagonUser> assignedDisponents, List<WagonUser> assignedendCustomers)
	{
		for (WagonUser availabaleUser : availableUsers)
		{
			leftSelect.addItem(availabaleUser);
		}

		for (WagonUser assignedDisponent : assignedDisponents)
		{
			leftSelect.removeItem(assignedDisponent);
			rightSelect.addItem(assignedDisponent);
		}

		for (WagonUser assignedEndCustomer : assignedendCustomers)
		{
			leftSelect.removeItem(assignedEndCustomer);
			rightSelect.addItem(assignedEndCustomer);
		}
	}

	private Collection<WagonUser> getInvalidAssignedEndUsers()
	{
		Collection<WagonUser> wagonUsers = (Collection<WagonUser>) rightSelect.getItemIds();
		Collection<WagonUser> invalidAssignedEndUsers = wagonUsers.stream()
				.filter(user -> user.isEndCustomer() && user.getActivationTime() == null)
				.collect(Collectors.toList());
		return invalidAssignedEndUsers;
	}
}
