
package com.bosch.si.amra.view.configuration.converter;

import java.util.Locale;

import com.bosch.si.amra.constants.configuration.ConfigurationConstants;
import com.vaadin.data.util.converter.Converter;

public class OnOffConverter implements Converter<String, Boolean>
{
	private static final long serialVersionUID = 9202141089631939170L;

	@Override
	public Boolean convertToModel(String value, Class<? extends Boolean> targetType, Locale locale)
			throws ConversionException
	{
		if (value != null && value.length() == 1)
		{
			if (value.indexOf(ConfigurationConstants.ON) == 0)
			{
				return true;
			}
			else if (value.indexOf(ConfigurationConstants.OFF) == 0)
			{
				return false;
			}
		}
		throw new ConversionException("Could not convert '" + value + "' to "
				+ Boolean.class.getName() + ": value out of range");
	}

	@Override
	public String convertToPresentation(Boolean value, Class<? extends String> targetType,
			Locale locale) throws com.vaadin.data.util.converter.Converter.ConversionException
	{
		if (value != null)
		{
			return value ? ConfigurationConstants.ON : ConfigurationConstants.OFF;
		}

		throw new ConversionException(
				"Could not convert '" + value + "' to On/Off String : value out of range");
	}

	@Override
	public Class<Boolean> getModelType()
	{
		return Boolean.class;
	}

	@Override
	public Class<String> getPresentationType()
	{
		return String.class;
	}
}
