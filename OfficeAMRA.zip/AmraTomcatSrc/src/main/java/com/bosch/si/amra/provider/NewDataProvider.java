
package com.bosch.si.amra.provider;

import java.util.List;

import org.springframework.stereotype.Component;

import com.bosch.si.amra.entity.Tag;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.entity.WagonType;

/**
 * DataProvider which unifies the telematic data retrieved from the Mongo DB and the wagon data
 * retrieved from the Oracle DB
 *
 * @author toa1wa3
 *
 */
@Component
public class NewDataProvider
{
	private static final String TENANT_ID_MUST_NOT_BE_NULL = "Tenant id must not be null";

	/**
	 * A list of wagons for the corresponding tenant. Throws an IllegalArgumentException if the
	 * tenantId is null or empty
	 *
	 * @param user
	 *            the user used for getting the wagons corresponding to its tenant
	 * @return A list of wagons for the corresponding tenant
	 */
	public List<Wagon> getWagons(User user)
	{
		return DataProviderInitializer.getWagons(user);
	}

	public List<Wagon> getWagonsShort(User user)
	{
		return DataProviderInitializer.getWagonsShort(user);
	}

	/**
	 * A list of wagon types for the specific tenant
	 *
	 * @param tenantId
	 *            the tenantId
	 * @return A wagon type list
	 */
	public List<WagonType> getWagonTypes(String tenantId)
	{
		return DataProviderInitializer.getWagonTypes(tenantId);
	}

	/**
	 * Returns all current values for all wagons which belongs to the given tenant
	 * the user used for retrieving all current values for all wagons which belongs to
	 * user's tenant
	 *
	 * @param user The logged in User
	 * @return A list with all wagons for this tenants and their data
	 */
	public List<Wagon> getWagonsWithCurrentValues(User user)
	{
		if (user == null)
			throw new IllegalArgumentException("User must not be null");
		if (user.getTenant() == null)
			throw new IllegalArgumentException(TENANT_ID_MUST_NOT_BE_NULL);
		List<Wagon> wagons = DataProviderInitializer.getCurrentValuesForWagons(user);
		return wagons;
	}

	public List<Tag> getTags(User user)
	{
		if (user == null)
			throw new IllegalArgumentException("User must not be null");
		if (user.getTenant() == null)
			throw new IllegalArgumentException(TENANT_ID_MUST_NOT_BE_NULL);
		List<Tag> tags = DataProviderInitializer.getTagsForTenant(user);
		return tags;
	}
}
