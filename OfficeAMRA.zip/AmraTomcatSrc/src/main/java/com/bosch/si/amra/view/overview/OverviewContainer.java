
package com.bosch.si.amra.view.overview;

import java.util.Arrays;
import java.util.Collection;

import com.bosch.si.amra.component.grid.OverviewGrid;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.Wagon;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.server.VaadinSession;

public class OverviewContainer extends BeanItemContainer<Wagon>
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= 787992511711591145L;

	private final User			user				= (User) VaadinSession.getCurrent()
			.getAttribute(User.class.getName());

	public OverviewContainer(Collection<Wagon> collection)
	{
		super(Wagon.class, collection);
	}

	@Override
	public Collection<?> getSortableContainerPropertyIds()
	{
		return Arrays.asList(OverviewGrid.getColumnIds(user));
	}
}
