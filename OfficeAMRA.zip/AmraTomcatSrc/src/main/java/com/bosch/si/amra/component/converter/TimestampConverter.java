
package com.bosch.si.amra.component.converter;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Locale;

import com.bosch.si.amra.DashboardUI;
import com.vaadin.data.util.converter.StringToDateConverter;

/**
 * Extending the default {@link StringToDateConverter} to format the date.
 * <ul>
 * <li>German format: <b>dd.MM.yyyy HH:mm:ss</b></li>
 * <li>English format: <b>yyyy/MM/dd HH:mm:ss</b></li>
 * </ul>
 *
 * @author toa1wa3
 *
 */
public class TimestampConverter extends StringToDateConverter
{
	/**
	 * Serial version uid
	 */
	private static final long serialVersionUID = 8849227509088871685L;

	@Override
	protected DateFormat getFormat(Locale locale)
	{
		SimpleDateFormat dateFormater = new SimpleDateFormat(
				DashboardUI.getMessageSource().getMessage("date.format"));
		dateFormater.setTimeZone(DashboardUI.getUserTimeZone());
		return dateFormater;
	}
}
