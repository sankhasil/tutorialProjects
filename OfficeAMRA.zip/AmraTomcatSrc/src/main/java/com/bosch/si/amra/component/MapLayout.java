
package com.bosch.si.amra.component;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.common.GoogleMapUtilFactory;
import com.bosch.si.amra.entity.LatLong;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.event.DashboardEvent.CalculateMileageEvent;
import com.bosch.si.amra.event.DashboardEvent.RouteUpdateEvent;
import com.bosch.si.amra.event.DashboardEvent.ShowRouteEvent;
import com.bosch.si.amra.event.DashboardEvent.UpdateEvent;
import com.bosch.si.amra.event.DashboardEvent.WagonSelectedEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.presenter.details.DetailsPresenterImpl;
import com.bosch.si.amra.presenter.details.Route;
import com.bosch.si.amra.view.UserNotification;
import com.google.common.eventbus.Subscribe;
import com.vaadin.server.Responsive;
import com.vaadin.shared.ui.datefield.Resolution;
import com.vaadin.shared.ui.label.ContentMode;
import com.vaadin.tapio.googlemaps.GoogleMap;
import com.vaadin.tapio.googlemaps.client.LatLon;
import com.vaadin.tapio.googlemaps.client.overlays.GoogleMapInfoWindow;
import com.vaadin.tapio.googlemaps.client.overlays.GoogleMapMarker;
import com.vaadin.tapio.googlemaps.client.overlays.GoogleMapPolyline;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.Component;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.MenuBar.MenuItem;
import com.vaadin.ui.PopupDateField;
import com.vaadin.ui.UI;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

/**
 * Mileage panel for calculating the mileage of a given means of transport for a given date range
 *
 * @author toa1wa3
 *
 */
public class MapLayout extends VerticalLayout
{
	private static final String					TRIP_LATEST_LOCATION_PNG	= "VAADIN/themes/dashboard/img/location.png";

	private static final long					serialVersionUID			= 4363097405470687223L;

	private static final int					MAX_Z_INDEX					= 288000001;

	private GoogleMap							googleMap;

	private GoogleMapPolyline					polyline;

	private PopupDateField						toDateField;

	private PopupDateField						fromDateField;

	private Button								routeButton;

	private Button								latestPositionButton;

	private Button								calculateButton;

	private OpenInfoWindowOnMarkerClickListener	tripLastInfoWindowClickListner;

	private static MenuItem						markerToggle;

	private static MenuItem						onOffSwitch;

	private Label								mileageLabel;

	private Wagon								wagon;

	private List<GoogleMapInfoWindow>			googleMapInfoWindows		= new ArrayList<>();

	private List<GoogleMapInfoWindow>			fullGoogleMapInfoWindows	= new ArrayList<>();

	private boolean								routeingEnabled;

	public MapLayout()
	{
		DashboardEventBus.register(this);
		Responsive.makeResponsive(this);

		// setSpacing(true);
		setSizeFull();
		setCaption(DashboardUI.getMessageSource().getMessage("view.dashboard.map"));

		Responsive.makeResponsive(this);

		Component datePicker = buildDatePicker();
		Component buttonLayout = buildButtonLayout();
		addComponent(datePicker);
		addComponent(buttonLayout);

		CssLayout googleMapLayout = new CssLayout();
		googleMapLayout.setSizeFull();
		googleMap = new GoogleMap(DashboardUI.getGoogleAPIKey(), "", "");
		googleMap.setSizeFull();
		googleMap.setMinZoom(1);
		googleMap.setMaxZoom(25);
		googleMap.clearMarkers();
		googleMapLayout.addComponent(googleMap);
		googleMapLayout.setHeight(98, Unit.PERCENTAGE);
		googleMapLayout.setResponsive(true);
		addComponent(googleMapLayout);
		setExpandRatio(googleMapLayout, 1.0f);
	}

	private Component buildDatePicker()
	{
		final HorizontalLayout horizontalLayout = new HorizontalLayout();
		horizontalLayout.setSpacing(true);
		horizontalLayout.setWidth("100%");

		fromDateField = new PopupDateField(
				DashboardUI.getMessageSource().getMessage("view.mileage.popupdate.from"));
		fromDateField
				.setDateFormat(DashboardUI.getMessageSource().getMessage("date.format.picker"));
		fromDateField.setResolution(Resolution.DAY);
		fromDateField.setLocale(UI.getCurrent().getLocale());
		fromDateField.setImmediate(true);
		fromDateField.setLenient(true);
		fromDateField.addStyleName(ValoTheme.DATEFIELD_LARGE);
		fromDateField.setParseErrorMessage(
				DashboardUI.getMessageSource().getMessage("view.mileage.wrong.date"));
		fromDateField.setValidationVisible(true);
		fromDateField.setDateOutOfRangeMessage(
				DashboardUI.getMessageSource().getMessage("view.mileage.wrong.period"));
		fromDateField.setRangeEnd(new Date());

		toDateField = new PopupDateField(
				DashboardUI.getMessageSource().getMessage("view.mileage.popupdate.to"));
		toDateField.setDateFormat(DashboardUI.getMessageSource().getMessage("date.format.picker"));
		toDateField.setResolution(Resolution.DAY);
		toDateField.setLocale(UI.getCurrent().getLocale());
		toDateField.setImmediate(true);
		toDateField.setLenient(true);
		toDateField.addStyleName(ValoTheme.DATEFIELD_LARGE);
		toDateField.setParseErrorMessage(
				DashboardUI.getMessageSource().getMessage("view.mileage.wrong.date"));
		toDateField.setValidationVisible(true);
		toDateField.setDateOutOfRangeMessage(
				DashboardUI.getMessageSource().getMessage("view.mileage.wrong.period"));

		initializeDateFields();

		fromDateField.addValueChangeListener(event -> {
			toDateField.setRangeStart((Date) event.getProperty().getValue());
			fromDateField.setRangeEnd(toDateField.getValue());
			enableButton();
			toDateField.setRangeStart(null);
		});

		toDateField.addValueChangeListener(event -> {
			toDateField.setRangeStart(fromDateField.getValue());
			fromDateField.setRangeEnd((Date) event.getProperty().getValue());
			enableButton();
			fromDateField.setRangeEnd(null);
		});

		horizontalLayout.addComponents(fromDateField, toDateField);
		horizontalLayout.setComponentAlignment(toDateField, Alignment.MIDDLE_RIGHT);

		return horizontalLayout;
	}

	private void initializeDateFields()
	{
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.MONTH, calendar.get(Calendar.MONTH) - 1);

		fromDateField.setValue(new Date(calendar.getTimeInMillis()));
		toDateField.setValue(new Date());
	}

	private void enableButton()
	{
		boolean valid = fromDateField.isValid() && toDateField.isValid() && wagon != null;
		routeButton.setEnabled(valid);
		calculateButton.setEnabled(valid);
		fromDateField.setValidationVisible(!valid);
		toDateField.setValidationVisible(!valid);
	}

	private Component buildButtonLayout()
	{
		CssLayout routingLayout = new CssLayout();
		routingLayout.addStyleName("routing");
		routingLayout.setWidth("100%");

		routeButton = new Button(DashboardUI.getMessageSource().getMessage("view.details.route"));
		routeButton.setDescription(
				DashboardUI.getMessageSource().getMessage("view.details.route.tooltip"));
		routeButton.addStyleName("space");
		routeButton.setEnabled(false);
		latestPositionButton = new Button(
				DashboardUI.getMessageSource().getMessage("view.details.latest.caption"));
		latestPositionButton.setDescription(
				DashboardUI.getMessageSource().getMessage("view.details.latest.tooltip"));
		latestPositionButton.addStyleName("space");
		latestPositionButton.setEnabled(false);

		routeButton.addClickListener(event -> {
			checkDateRange();
			clearMap();
			DashboardEventBus.post(new ShowRouteEvent(wagon.getId(), formatStartDate().getTime(),
					formatEndDate().getTime()));
		});

		latestPositionButton.addClickListener(event -> {
			clearMap();
			fillLocationMap(wagon);
			routeingEnabled = false;
			markerToggle.setEnabled(false);
			onOffSwitch.setEnabled(false);
		});

		calculateButton = new Button(
				DashboardUI.getMessageSource().getMessage("view.details.calculate"));
		calculateButton.setDescription(
				DashboardUI.getMessageSource().getMessage("view.details.mileage.tooltip"));
		calculateButton.addStyleName("space");
		calculateButton.setEnabled(false);
		calculateButton.addClickListener(event -> {
			DashboardEventBus.post(new CalculateMileageEvent(wagon.getId(),
					formatStartDate().getTime(), formatEndDate().getTime()));
			routeingEnabled = false;
			markerToggle.setEnabled(false);
			onOffSwitch.setEnabled(false);
		});

		mileageLabel = new Label();
		mileageLabel.addStyleName("space route");
		mileageLabel.setSizeUndefined();
		mileageLabel.setContentMode(ContentMode.HTML);
		mileageLabel.setImmediate(true);
		routingLayout.addComponents(routeButton, latestPositionButton, calculateButton,
				mileageLabel);
		return routingLayout;
	}

	private Calendar formatStartDate()
	{
		Calendar startDate = Calendar.getInstance();
		startDate.setTime(fromDateField.getValue());
		startDate.set(Calendar.HOUR_OF_DAY, 0);
		startDate.set(Calendar.MINUTE, 0);
		startDate.set(Calendar.SECOND, 1);
		startDate.set(Calendar.MILLISECOND, 1);
		return startDate;
	}

	private Calendar formatEndDate()
	{
		Calendar endDate = Calendar.getInstance();
		endDate.setTime(toDateField.getValue());
		endDate.set(Calendar.HOUR_OF_DAY, 23);
		endDate.set(Calendar.MINUTE, 59);
		endDate.set(Calendar.SECOND, 59);
		endDate.set(Calendar.MILLISECOND, 999);
		return endDate;
	}

	private void checkDateRange()
	{
		Date toDate = toDateField.getValue();
		Date fromDate = fromDateField.getValue();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(fromDate);
		calendar.add(Calendar.MONTH, 1);
		Date expectedToDate = calendar.getTime();
		if (toDate.after(expectedToDate))
		{
			UserNotification userNotification = new UserNotification("view.details.limit.date", -1,
					false);
			userNotification.setStyleName("closable dark");
			toDateField.setValue(expectedToDate);
		}
	}

	private void clearMap()
	{
		if (googleMap.getMarkers().size() > 0)
			googleMap.clearMarkers();
		if (polyline != null)
			googleMap.removePolyline(polyline);

		googleMapInfoWindows.forEach(infoWindow -> {
			googleMap.closeInfoWindow(infoWindow);
		});
		googleMapInfoWindows.clear();
		fullGoogleMapInfoWindows.clear();
	}

	@Subscribe
	public void fillDetails(WagonSelectedEvent event)
	{
		Wagon wagon = event.getWagon();
		this.wagon = wagon;
		routeButton.setEnabled(wagon != null);
		latestPositionButton.setEnabled(wagon != null);
		calculateButton.setEnabled(wagon != null);
		initializeDateFields();
		if (wagon != null)
			fillLocationMap(wagon);
		mileageLabel.setValue("");
	}

	private void fillLocationMap(Wagon wagon)
	{
		clearMap();
		if (wagon.getLatLong() != null)
		{
			LatLon location = GoogleMapUtilFactory.buildLocation(wagon.getLatLong());
			GoogleMapMarker locationMarker = GoogleMapUtilFactory.buildGoogleMapMarker(location,
					wagon.getAlias());
			googleMap.addMarker(locationMarker);
			GoogleMapInfoWindow amraBoxInfoWindow = GoogleMapUtilFactory
					.buildGoogleMapFullInfoWindow(wagon, location, locationMarker);
			OpenInfoWindowOnMarkerClickListener infoWindowOpener = new OpenInfoWindowOnMarkerClickListener(
					googleMap, locationMarker, amraBoxInfoWindow);
			googleMap.addMarkerClickListener(infoWindowOpener);
			googleMap.setCenter(location);
		}
		else
		{
			new UserNotification("view.details.map.nolocation", 1000, false);
		}
	}

	@Subscribe
	public void showRoute(RouteUpdateEvent event)
	{
		Route route = event.getRoute();
		if (route != null)
		{
			changeVisibilityOfMapButtons(route);
			showRoute(route.getRoute());
			showPositions(route.getPositions());
			fitToBounds(route.getPositions());
		}
		else
		{
			new UserNotification("view.details.map.nolocation", 1000, false);
		}
	}

	private void changeVisibilityOfMapButtons(Route route)
	{
		if ((route.getPositions() != null && route.getPositions().size() > 0)
				|| (route.getRoute() != null && route.getRoute().size() > 0))
		{
			routeingEnabled = true;
			markerToggle.setChecked(false);
			markerToggle.setEnabled(true);
			onOffSwitch.setChecked(false);
			onOffSwitch.setEnabled(true);
		}
	}

	private void showRoute(List<LatLon> routePositions)
	{
		if (routePositions != null && routePositions.size() > 0)
		{
			polyline = new GoogleMapPolyline(routePositions, "#d31717", 0.5, 5);
			googleMap.addPolyline(polyline);
		}
	}

	public void showPositions(List<LatLong> positions)
	{
		if (positions != null && positions.size() > 0)
		{
			positions.stream().limit(positions.size() - 1)
					.forEach(position -> createMarkerWithWindow(position, null, 0));
			LatLong latestPosition = positions.get(positions.size() - 1);
			createMarkerWithWindow(latestPosition, TRIP_LATEST_LOCATION_PNG, MAX_Z_INDEX);
		}
	}

	public LatLon createMarkerWithWindow(LatLong position, String iconUrl, int zIndex)
	{
		LatLon latLong = new LatLon(position.getLat(), position.getLng());
		GoogleMapMarker marker = GoogleMapUtilFactory.buildGoogleMapMarker(latLong, null);
		marker.setIconUrl(iconUrl);
		marker.setzIndex(zIndex);
		googleMap.addMarker(marker);
		GoogleMapInfoWindow infoWindow = GoogleMapUtilFactory
				.buildGoogleMapSmallInfoWindow(wagon.getAlias(), position.getTimestamp(), latLong);
		infoWindow.setAnchorMarker(marker);
		googleMapInfoWindows.add(infoWindow);
		fullGoogleMapInfoWindows.add(infoWindow);
		OpenInfoWindowOnMarkerClickListener infoWindowOpener = new OpenInfoWindowOnMarkerClickListener(
				googleMap, marker, infoWindow);

		if (iconUrl != null && iconUrl.equalsIgnoreCase(TRIP_LATEST_LOCATION_PNG))
			tripLastInfoWindowClickListner = infoWindowOpener;

		googleMap.addMarkerClickListener(infoWindowOpener);
		return latLong;
	}

	private void fitToBounds(List<LatLong> positions)
	{
		if (positions != null && positions.size() > 0)
		{
			List<LatLon> positionBounds = positions.stream()
					.map(position -> new LatLon(position.getLat(), position.getLng()))
					.collect(Collectors.toList());
			GoogleMapUtilFactory.autoZoomMap(positionBounds, googleMap);
		}
	}

	/**
	 * Called from {@link DetailsPresenterImpl} {@code calculateMileageForPeriod()}
	 *
	 * @param event
	 *            {@link UpdateEvent}
	 */
	@Subscribe
	public void updateMileageLabel(UpdateEvent event)
	{
		if (event.getValue() instanceof Integer)
		{
			mileageLabel.setValue(String.valueOf(event.getValue()) + " KM");
		}
	}

	public void setWagon(Wagon wagon)
	{
		this.wagon = wagon;
	}

	@Override
	public void detach()
	{
		super.detach();

		DashboardEventBus.unregister(this);
	}

	public GoogleMap getGoogleMap()
	{
		return googleMap;
	}

	public List<GoogleMapInfoWindow> getGoogleMapInfoWindows()
	{
		return googleMapInfoWindows;
	}

	public List<GoogleMapInfoWindow> getFullGoogleMapInfoWindows()
	{
		return fullGoogleMapInfoWindows;
	}

	public boolean isRouteingEnabled()
	{
		return routeingEnabled;
	}

	public void setMarkerToggle(MenuItem markerToggle)
	{
		MapLayout.markerToggle = markerToggle;
	}

	public void setOnOffSwitch(MenuItem onOffSwitch)
	{
		MapLayout.onOffSwitch = onOffSwitch;
	}

	public OpenInfoWindowOnMarkerClickListener getTripLastInfoWindowClickListner()
	{
		return tripLastInfoWindowClickListner;
	}

	public GoogleMapPolyline getPolyline()
	{
		return polyline;
	}

}