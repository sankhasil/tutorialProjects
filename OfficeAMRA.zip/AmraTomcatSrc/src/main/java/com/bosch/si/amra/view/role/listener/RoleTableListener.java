
package com.bosch.si.amra.view.role.listener;

import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.WagonUser;
import com.bosch.si.amra.entity.WagonUsers;
import com.bosch.si.amra.event.DashboardEvent.GetAllUsersEvent;
import com.bosch.si.amra.view.role.RoleView;
import com.bosch.si.amra.event.DashboardEventBus;
import com.vaadin.data.Property.ValueChangeEvent;
import com.vaadin.data.Property.ValueChangeListener;
import com.vaadin.event.ItemClickEvent;
import com.vaadin.event.ItemClickEvent.ItemClickListener;
import com.vaadin.server.VaadinSession;

public class RoleTableListener implements ValueChangeListener, ItemClickListener
{
	private static final long			serialVersionUID	= 872298909906006516L;

	private final RoleView	view;

	public RoleTableListener(RoleView view)
	{
		this.view = view;
	}

	@Override
	public void itemClick(ItemClickEvent event)
	{
		if (event.isDoubleClick())
		{
			User user = (User) VaadinSession.getCurrent().getAttribute(User.class.getName());
			if (event.getItemId() instanceof WagonUsers)
			{
				DashboardEventBus.post(new GetAllUsersEvent(user,
						((WagonUsers) event.getItemId()).getId()));
			}
			else
			{
				DashboardEventBus.post(new GetAllUsersEvent(user,
						((WagonUser) event.getItemId()).getWagonId()));
			}
		}
	}

	@Override
	public void valueChange(ValueChangeEvent event)
	{
		view.valueChange();
	}
}
