
package com.bosch.si.amra.constants.fleetbalancing;

public class FleetBalancingConstants
{
	public static final String	TOTAL_MILEAGE	= "totalMileage";

	public static final String	OFFSET			= "offset";

	public static final String	MILEAGE_KEY		= "mileage";

	public static final String	AVERAGE_MILEAGE	= "averageMileage";

	public static final String	SUM_OFFSET		= "sumOffset";

	public static final String	MILEAGE_SUM		= "mileageSum";

	public static final String	DEVIATION		= "deviation";
}
