
package com.bosch.si.amra.component;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.event.DashboardEvent.ClearValueEvent;
import com.bosch.si.amra.event.DashboardEvent.CouplingEvent;
import com.bosch.si.amra.event.DashboardEvent.DecouplingEvent;
import com.bosch.si.amra.event.DashboardEvent.NotSuccessfulCoupledEvent;
import com.bosch.si.amra.event.DashboardEvent.WagonSelectedEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.presenter.details.DetailsPresenterImpl;
import com.bosch.si.amra.view.administration.AdministrationView;
import com.bosch.si.amra.view.overview.OverviewView;
import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;
import com.google.common.eventbus.Subscribe;
import com.vaadin.data.Property.ValueChangeEvent;
import com.vaadin.data.Property.ValueChangeListener;
import com.vaadin.data.fieldgroup.PropertyId;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.data.util.converter.Converter;
import com.vaadin.data.validator.StringLengthValidator;
import com.vaadin.event.FieldEvents.TextChangeEvent;
import com.vaadin.event.FieldEvents.TextChangeListener;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Page;
import com.vaadin.shared.ui.MarginInfo;
import com.vaadin.shared.ui.combobox.FilteringMode;
import com.vaadin.ui.AbstractTextField.TextChangeEventMode;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.Component;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Notification.Type;
import com.vaadin.ui.Panel;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

/**
 * Panel for coupling a created wagon with an IMEI
 *
 * @author toa1wa3
 *
 */
@SuppressWarnings ("serial")
public class CouplingPanel extends Panel
{
	@PropertyId ("boxId")
	private TextField				imei;

	private ComboBox				wagonsToCouple;

	private Button					couple;

	private Button					decouple;

	private final List<Wagon>		wagons;

	private final VerticalLayout	verticalLayout;

	public CouplingPanel(List<Wagon> wagons)
	{
		DashboardEventBus.register(this);

		this.wagons = wagons;

		verticalLayout = new VerticalLayout();
		verticalLayout.setWidth("100%");
		verticalLayout.setMargin(new MarginInfo(true, false, false, false));
		verticalLayout.setSpacing(true);
		addStyleName(ValoTheme.PANEL_BORDERLESS);

		setContent(verticalLayout);

		verticalLayout.addComponent(buildWagonsToCouple());
		verticalLayout.addComponent(buildAlias());
		verticalLayout.addComponent(buildCoupleButton());
	}

	private Component buildAlias()
	{
		imei = new TextField(
				DashboardUI.getMessageSource().getMessage("view.administration.imei.caption"));
		imei.setWidth(100, Unit.PERCENTAGE);
		imei.setNullRepresentation("0");
		imei.setConverter(new LongConverter());
		imei.setConversionError(DashboardUI.getMessageSource()
				.getMessage("view.administration.validation.imei.error"));
		imei.setImmediate(true);
		imei.setBuffered(false);
		imei.setRequired(true);
		imei.setRequiredError(
				DashboardUI.getMessageSource().getMessage("view.administration.imei.error"));
		imei.addValidator(new StringLengthValidator(DashboardUI.getMessageSource()
				.getMessage("view.administration.validation.imei.error"), 15, 15, true));
		imei.setInputPrompt(
				DashboardUI.getMessageSource().getMessage("view.administration.panel.imei.input"));
		imei.setTextChangeEventMode(TextChangeEventMode.LAZY);

		imei.addTextChangeListener(new TextChangeListener()
		{
			@Override
			public void textChange(TextChangeEvent event)
			{
				if (isTextValid(event.getText().trim()))
				{
					imei.setValidationVisible(false);
					if (wagonsToCouple.isValid())
					{
						couple.setEnabled(true);
						imei.setValue(event.getText().trim());
					}
				}
				else
				{
					imei.setValidationVisible(true);
					couple.setEnabled(false);
				}
			}

			private boolean isTextValid(String text)
			{
				return !text.isEmpty() && 15 == text.length();
			}
		});
		return imei;
	}

	private Component buildWagonsToCouple()
	{
		List<Wagon> wagons = filteredWagons();

		wagonsToCouple = new ComboBox(
				DashboardUI.getMessageSource().getMessage("view.administration.coupling.wagons"));
		wagonsToCouple.setImmediate(true);
		wagonsToCouple.setTextInputAllowed(true);
		wagonsToCouple.setFilteringMode(FilteringMode.CONTAINS);
		wagonsToCouple.setWidth(100, Unit.PERCENTAGE);
		wagonsToCouple.setContainerDataSource(new BeanItemContainer<>(Wagon.class, wagons));
		wagonsToCouple.setItemCaptionPropertyId("alias");
		wagonsToCouple.setRequired(true);
		wagonsToCouple.addValueChangeListener(new ValueChangeListener()
		{

			@Override
			public void valueChange(ValueChangeEvent event)
			{
				Wagon wagon = (Wagon) event.getProperty().getValue();
				if (wagon != null)
				{
					if (imei.isValid())
						couple.setEnabled(true);
				}
				else
				{
					couple.setEnabled(false);
				}

			}
		});
		return wagonsToCouple;
	}

	private Component buildCoupleButton()
	{
		couple = new Button(
				DashboardUI.getMessageSource().getMessage("view.administration.button.couple"));
		couple.setIcon(FontAwesome.CHAIN);
		couple.setEnabled(false);
		couple.addClickListener(new Button.ClickListener()
		{
			@Override
			public void buttonClick(ClickEvent event)
			{
				Wagon selectedWagon = (Wagon) wagonsToCouple.getValue();
				selectedWagon.setBoxId((Long) imei.getConvertedValue());
				DashboardEventBus.post(new CouplingEvent(selectedWagon));
			}
		});
		return couple;
	}

	/**
	 * Filter all wagons where the box id is null. These wagons can be coupled with a box
	 *
	 * @return list of wagons which can be coupled
	 */
	private List<Wagon> filteredWagons()
	{
		Iterable<Wagon> filteredWagons = Iterables.filter(wagons, new Predicate<Wagon>()
		{
			@Override
			public boolean apply(Wagon input)
			{
				if (input != null)
				{
					return null == input.getBoxId();
				}
				return false;
			}
		});
		List<Wagon> filteredWagonsList = new ArrayList<>();
		for (Iterator<Wagon> iterator = filteredWagons.iterator(); iterator.hasNext();)
		{
			filteredWagonsList.add(iterator.next());
		}
		return filteredWagonsList;
	}

	/**
	 * Called from {@link DetailsPresenterImpl} {@code updateMetaDataForBox()} and
	 * {@link AdministrationView} {@code buildClearAllFields()}
	 *
	 * @param event
	 *            {@link ClearValueEvent}
	 */
	@Subscribe
	public void updateWagonsToCouple(ClearValueEvent event)
	{
		wagonsToCouple
				.setContainerDataSource(new BeanItemContainer<>(Wagon.class, filteredWagons()));
		couple.setEnabled(false);
		couple.setCaption(
				DashboardUI.getMessageSource().getMessage("view.administration.button.couple"));
		couple.setIcon(FontAwesome.CHAIN);
		imei.setValue("");
		imei.setValidationVisible(true);
	}

	/**
	 * Called from {@link OverviewView} {@code editSelectedWagon()}
	 *
	 * @param event
	 *            {@link WagonSelectedEvent}
	 */
	@Subscribe
	public void fillDetails(WagonSelectedEvent event)
	{
		Wagon wagon = event.getWagon();
		List<Wagon> wagons = filteredWagons();
		wagons.add(wagon);
		wagonsToCouple.setContainerDataSource(new BeanItemContainer<>(Wagon.class, wagons));
		wagonsToCouple.select(wagon);
		imei.setValue(wagon.getBoxId() != null ? String.valueOf(wagon.getBoxId()) : "");
		imei.setValidationVisible(wagon.getBoxId() != null ? false : true);
		switchToDecoupleButton();
	}

	private void switchToDecoupleButton()
	{
		if (imei.getValue() != null && !imei.getValue().isEmpty())
		{
			decouple = new Button(DashboardUI.getMessageSource()
					.getMessage("view.administration.button.decouple"));
			decouple.setEnabled(true);
			decouple.setCaption(DashboardUI.getMessageSource()
					.getMessage("view.administration.button.decouple"));
			decouple.setIcon(FontAwesome.CHAIN_BROKEN);
			decouple.addClickListener(new Button.ClickListener()
			{
				@Override
				public void buttonClick(ClickEvent event)
				{
					Wagon selectedWagon = (Wagon) wagonsToCouple.getValue();
					DashboardEventBus.post(new DecouplingEvent(selectedWagon));
				}
			});
			verticalLayout.replaceComponent(couple, decouple);
		}

	}

	@Override
	public void detach()
	{
		super.detach();

		DashboardEventBus.unregister(this);
	}

	private static class LongConverter implements Converter<String, Long>
	{

		@Override
		public Long convertToModel(String value, Class<? extends Long> targetType, Locale locale)
				throws com.vaadin.data.util.converter.Converter.ConversionException
		{
			if (value != null && !value.isEmpty())
			{
				try
				{
					return Long.valueOf(value);
				}
				catch (NumberFormatException e)
				{
					throw new ConversionException(e);
				}
			}
			else
			{
				return null;
			}
		}

		@Override
		public String convertToPresentation(Long value, Class<? extends String> targetType,
				Locale locale) throws com.vaadin.data.util.converter.Converter.ConversionException
		{
			if (value != null)
			{
				return String.valueOf(value);
			}
			else
			{
				return "";
			}
		}

		@Override
		public Class<Long> getModelType()
		{
			return Long.class;
		}

		@Override
		public Class<String> getPresentationType()
		{
			return String.class;
		}

	}

	/**
	 * Called from {@link DetailsPresenterImpl} {@code updateMetaDataForBox()}
	 *
	 * @param event
	 *            {@link NotSuccessfulCoupledEvent}
	 */
	@Subscribe
	public void showUserFriendlyError(NotSuccessfulCoupledEvent event)
	{
		String code = event.getCode();
		Notification notification = new Notification(
				DashboardUI.getMessageSource().getMessage(code), Type.WARNING_MESSAGE);
		notification.setDelayMsec(1000);
		notification.show(Page.getCurrent());
	}

}
