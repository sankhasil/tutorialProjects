
package com.bosch.si.amra.view.geofence;

import com.vaadin.tapio.googlemaps.client.LatLon;

/**
 * Some methods for making processing polygons easier
 * 
 * @author toa1wa3
 *
 */
public class PolygonCalculator
{
	/**
	 * Calculates the area of a polygon
	 * 
	 * @param positions
	 *            coordinates of the polygon
	 * @param N
	 *            number of elements
	 * @return Area of the polygon
	 */
	public static double polygonArea(LatLon[] positions, int N)
	{

		int i, j;
		double area = 0;

		for (i = 0; i < N; i++)
		{
			j = (i + 1) % N;
			area += positions[i].getLat() * positions[j].getLon();
			area -= positions[i].getLon() * positions[j].getLat();
		}

		area /= 2.0;
		return (Math.abs(area));
	}

	/**
	 * Calculates the centroid point of a polygon. More information can be found on <a
	 * href="https://de.wikipedia.org/wiki/Geometrischer_Schwerpunkt#Polygon"> Wikipedia </a>.
	 * The returned value contains either the absolute value of the raw value. This can be negative.
	 * This depends on if a coordinate (latitude or longitude) of a position is negative
	 * 
	 * @param positions
	 *            coordinates of the polygon
	 * @return The centroid point of the polygon
	 */
	public static LatLon polygonCenterOfMass(LatLon[] positions)
	{

		if (positions == null)
			return null;

		int N = positions.length;

		double cx = 0, cy = 0;
		double A = polygonArea(positions, N);
		int i, j;
		boolean negativeLat = false;
		boolean negativeLon = false;

		double factor = 0;
		for (i = 0; i < N; i++)
		{
			if (positions[i].getLat() < 0)
				negativeLat = true;
			if (positions[i].getLon() < 0)
				negativeLon = true;
			j = (i + 1) % N;
			factor = (positions[i].getLat() * positions[j].getLon() - positions[j].getLat()
					* positions[i].getLon());
			cx += (positions[i].getLat() + positions[j].getLat()) * factor;
			cy += (positions[i].getLon() + positions[j].getLon()) * factor;
		}
		factor = 1.0 / (6.0 * A);
		cx *= factor;
		cy *= factor;
		return new LatLon(negativeLat ? cx : Math.abs(cx), negativeLon ? cy : Math.abs(cy));
	}
}
