
package com.bosch.si.amra.component.grid;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.configuration.ConfigurationConstants;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.entity.configuration.Configuration;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.event.DashboardEvent.ConfigurationsSaveEvent;
import com.bosch.si.amra.view.configuration.ConfigurationGridFilterComponent.BooleanFilterHeader;
import com.bosch.si.amra.view.configuration.ConfigurationGridFilterComponent.IntervalFilterHeader;
import com.bosch.si.amra.view.configuration.ConfigurationGridFilterComponent.TagFilterHeader;
import com.bosch.si.amra.view.configuration.ConfigurationGridFilterComponent.ConfigurationGeneralFilterHeader;
import com.bosch.si.amra.view.configuration.converter.OnOffConverter;
import com.bosch.si.amra.view.configuration.converter.IntervalConverter;
import com.bosch.si.amra.view.overview.TagListToTagNameConverter;
import com.vaadin.data.Item;
import com.vaadin.data.Property;
import com.vaadin.data.Container.Indexed;
import com.vaadin.data.fieldgroup.FieldGroup.CommitEvent;
import com.vaadin.data.fieldgroup.FieldGroup.CommitException;
import com.vaadin.data.fieldgroup.FieldGroup.CommitHandler;
import com.vaadin.data.validator.DoubleRangeValidator;
import com.vaadin.data.validator.IntegerRangeValidator;
import com.vaadin.data.validator.NullValidator;
import com.vaadin.data.validator.StringLengthValidator;
import com.vaadin.server.Page;
import com.vaadin.shared.data.sort.SortDirection;
import com.vaadin.ui.AbstractComponent;
import com.vaadin.ui.CheckBox;
import com.vaadin.ui.Grid;
import com.vaadin.ui.TextField;
import com.vaadin.ui.themes.ValoTheme;

public class ConfigurationGrid extends GridComponent
{
	private static final long				serialVersionUID	= 3267204373910327317L;

	private Map<AbstractComponent, Object>	componentToPidMap	= new HashMap<>();

	private static final Logger				logger				= LoggerFactory
			.getLogger(ConfigurationGrid.class);

	public ConfigurationGrid(Indexed container, List<Configuration> configurations,
			List<Wagon> wagons, User user)
	{
		super(container);
		setSizeFull();
		addStyleName(ValoTheme.TABLE_BORDERLESS);
		addStyleName(ValoTheme.TABLE_NO_HORIZONTAL_LINES);
		addStyleName(ValoTheme.TABLE_COMPACT);
		setImmediate(true);

		setEditorSaveCaption(
				DashboardUI.getMessageSource().getMessage("view.overview.tag.grid.button.save"));
		setEditorCancelCaption(
				DashboardUI.getMessageSource().getMessage("view.overview.tag.grid.button.cancel"));

		setEditorEnabled(true);
		setSelectionMode(SelectionMode.MULTI);

		configureColumns(user);
		configureCellStyleGenerator();
		HeaderRow filterRow = appendHeaderRow();
		addFilterRow(filterRow);
		sort(ConfigurationConstants.ALIAS, SortDirection.ASCENDING);
		configureEditLineSave(configurations, user);

		setResponsive(true);
		setId("configurationGrid");
	}

	@Override
	public Map<AbstractComponent, Object> getComponentToPidMap()
	{
		return componentToPidMap;
	}

	private void configureColumns(User user)
	{
		Object[] columnIds = Arrays.copyOfRange(ConfigurationConstants.PROPERTY_IDS, 0,
				ConfigurationConstants.PROPERTY_IDS.length - (user.isSuperAdmin() ? 0 : 2));
		setColumns(columnIds);
		setColumnReorderingAllowed(true);
		setFrozenColumnCount(1);

		getColumns().forEach(column -> {
			String columnId = (String) column.getPropertyId();

			getDefaultHeaderRow().getCell(columnId).setStyleName("grid-header");
			getDefaultHeaderRow().getCell(columnId)
					.setHtml(DashboardUI.getMessageSource()
							.getMessage("view.configuration.columnheader."
									+ columnId.toString().toLowerCase()));

			// set default width
			column.setWidth(ConfigurationConstants.DEFAULT_COLUMN_WIDTH);
			// set default hidable to true
			column.setHidable(true)
					.setHidingToggleCaption(DashboardUI.getMessageSource().getMessage(
							ConfigurationConstants.HIDE_AND_SHOW_HEADERS + columnId.toLowerCase()));
			// set default editable to true
			column.setEditable(true);

			// customize the columns
			switch (columnId)
			{
				case ConfigurationConstants.ALIAS:
					column.setWidth(ConfigurationConstants.MEANS_OF_TRANSPORT_COLUMN_WIDTH);
					column.setHidable(false);
					column.setEditable(false);
					break;

				case ConfigurationConstants.WAGON_TYPE:
					column.setWidth(ConfigurationConstants.TRANSPORT_TYPE_COLUMN_WIDTH);
					column.setEditable(false);
					column.setSortable(false);
					break;

				case ConfigurationConstants.TAGS:
					column.setWidth(ConfigurationConstants.MEANS_OF_TRANSPORT_COLUMN_WIDTH);
					column.setEditable(false);
					column.setConverter(new TagListToTagNameConverter());
					column.setSortable(false);
					break;

				case ConfigurationConstants.HUMIDITY:
				case ConfigurationConstants.HUMIDITY_TEMPERATURE:
				case ConfigurationConstants.TEMPERATURE:
				case ConfigurationConstants.DEVICE_TEMPERATURE:
				case ConfigurationConstants.ROUTING:
					column.setConverter(new OnOffConverter());
					CheckBox checkBox = new CheckBox();
					checkBox.setStyleName("grid-edit-checkbox");
					column.setEditorField(checkBox);
					break;

				case ConfigurationConstants.SHOCK_X:
				case ConfigurationConstants.SHOCK_Y:
				case ConfigurationConstants.SHOCK_Z:
					String errorEditShockMessage = String.format(
							Page.getCurrent().getWebBrowser().getLocale(),
							DashboardUI.getMessageSource()
									.getMessage("view.configuration.shock.notvalid"),
							DashboardUI.getShockMin(), DashboardUI.getShockMax());
					TextField shockTextField = new TextField();
					shockTextField.setConversionError(errorEditShockMessage);
					shockTextField.addValidator(new DoubleRangeValidator(errorEditShockMessage,
							DashboardUI.getShockMin(), DashboardUI.getShockMax()));
					shockTextField.addValidator(new NullValidator(errorEditShockMessage, false));
					shockTextField
							.setStyleName(ConfigurationConstants.STYLE_GRID_TEXT_CENTER_ALIGN);
					// the next method is used as otherwise if empty string is entered it is
					// shown 'red null' during validation instead of 'red empty string'
					shockTextField.setNullRepresentation("");
					column.setEditorField(shockTextField);
					break;

				case ConfigurationConstants.GPS_MOVING:
				case ConfigurationConstants.GPS_TIME_BASED:
				case ConfigurationConstants.GSM_MOVING:
				case ConfigurationConstants.GSM_TIME_BASED:
					IntervalConverter intervalConverter = new IntervalConverter();
					TextField intervalTextField = new TextField();
					String errorEditIntervalMessage = String.format(
							DashboardUI.getMessageSource()
									.getMessage("view.configuration.interval.notvalid"),
							intervalConverter.convertToPresentation(
									ConfigurationConstants.MINIMUM_INTERVAL, String.class,
									Page.getCurrent().getWebBrowser().getLocale()),
							intervalConverter.convertToPresentation(
									ConfigurationConstants.MAXIMUM_INTERVAL, String.class,
									Page.getCurrent().getWebBrowser().getLocale()));
					intervalTextField.setConversionError(errorEditIntervalMessage);
					intervalTextField
							.setStyleName(ConfigurationConstants.STYLE_GRID_TEXT_CENTER_ALIGN);
					intervalTextField.addValidator(new IntegerRangeValidator(
							errorEditIntervalMessage, ConfigurationConstants.MINIMUM_INTERVAL,
							ConfigurationConstants.MAXIMUM_INTERVAL));
					intervalTextField
							.addValidator(new NullValidator(errorEditIntervalMessage, false));
					intervalTextField.setConverter(intervalConverter);
					column.setEditorField(intervalTextField);
					column.setConverter(intervalConverter);
					break;

				case ConfigurationConstants.FLASH_DATA:
					String errorEditFlashDataMessage = String.format(
							DashboardUI.getMessageSource()
									.getMessage("view.configuration.firmware.notvalid"),
							ConfigurationConstants.MINIMUM_FW_VERSION,
							ConfigurationConstants.MAXIMUM_FW_VERSION);
					TextField versionTextField = new TextField();
					versionTextField.setConversionError(errorEditFlashDataMessage);
					versionTextField
							.setStyleName(ConfigurationConstants.STYLE_GRID_TEXT_CENTER_ALIGN);
					versionTextField.addValidator(new IntegerRangeValidator(
							errorEditFlashDataMessage, ConfigurationConstants.MINIMUM_FW_VERSION,
							ConfigurationConstants.MAXIMUM_FW_VERSION));
					versionTextField
							.addValidator(new NullValidator(errorEditFlashDataMessage, false));
					// the next method is used as otherwise if empty string is entered it is
					// shown 'red null' during validation instead of 'red empty string'
					versionTextField.setNullRepresentation("");
					column.setEditorField(versionTextField);
					break;

				case ConfigurationConstants.STATUS:
					String errorEditStatusMessage = String.format(
							DashboardUI.getMessageSource()
									.getMessage("view.configuration.status.notvalid"),
							ConfigurationConstants.MAXIMUM_STATUS);
					TextField statusTextField = new TextField();
					statusTextField.setConversionError(errorEditStatusMessage);
					statusTextField
							.setStyleName(ConfigurationConstants.STYLE_GRID_TEXT_CENTER_ALIGN);
					statusTextField.addValidator(new StringLengthValidator(errorEditStatusMessage,
							ConfigurationConstants.MINIMUM_STATUS,
							ConfigurationConstants.MAXIMUM_STATUS, false));
					column.setEditorField(statusTextField);
					break;

				default:
			}
		});
	}

	private void addFilterRow(HeaderRow filterRow)
	{
		getColumns().forEach(column -> {
			String columnId = (String) column.getPropertyId();
			AbstractComponent filterField;

			switch (columnId)
			{
				case ConfigurationConstants.HUMIDITY:
				case ConfigurationConstants.HUMIDITY_TEMPERATURE:
				case ConfigurationConstants.TEMPERATURE:
				case ConfigurationConstants.DEVICE_TEMPERATURE:
				case ConfigurationConstants.ROUTING:
					filterField = new BooleanFilterHeader(columnId, this);
					break;

				case ConfigurationConstants.GPS_MOVING:
				case ConfigurationConstants.GPS_TIME_BASED:
				case ConfigurationConstants.GSM_MOVING:
				case ConfigurationConstants.GSM_TIME_BASED:
					filterField = new IntervalFilterHeader(columnId, this);
					break;

				case ConfigurationConstants.TAGS:
					filterField = new TagFilterHeader(columnId, this);
					break;

				default:
					filterField = new ConfigurationGeneralFilterHeader(columnId, this);
			}

			filterField.setWidth("100%");
			filterField.setHeight("75%");
			componentToPidMap.put(filterField, columnId);
			filterRow.getCell(columnId).setComponent(filterField);
		});
	}

	private void configureEditLineSave(List<Configuration> configurations, User user)
	{
		getEditorFieldGroup().addCommitHandler(new CommitHandler()
		{
			private static final long serialVersionUID = 8776294791777773854L;

			@Override
			public void preCommit(CommitEvent commitEvent) throws CommitException
			{
				// Do nothing
			}

			@Override
			public void postCommit(CommitEvent commitEvent) throws CommitException
			{
				Item item = getContainerDataSource().getItem(getEditedItemId());
				String alias = (String) item.getItemProperty(ConfigurationConstants.ALIAS)
						.getValue();

				// normally the configuration should always be found
				Configuration editedConfiguration = configurations.stream()
						.filter(filter -> filter.getAlias().equals(alias)).findFirst().get();

				DashboardEventBus.post(new ConfigurationsSaveEvent(
						Arrays.asList(editedConfiguration), user.getTenant()));
			}
		});
	}

	private void configureCellStyleGenerator()
	{
		setCellStyleGenerator((Grid.CellReference cellReference) -> {
			switch (cellReference.getPropertyId().toString())
			{
				case ConfigurationConstants.ALIAS:
				case ConfigurationConstants.TAGS:
				case ConfigurationConstants.WAGON_TYPE:
					return "align-left";
				case ConfigurationConstants.HUMIDITY:
				case ConfigurationConstants.HUMIDITY_TEMPERATURE:
				case ConfigurationConstants.TEMPERATURE:
				case ConfigurationConstants.DEVICE_TEMPERATURE:
				case ConfigurationConstants.ROUTING:
					if (((Boolean) cellReference.getValue()).booleanValue())
					{
						return "on";
					}
					else
					{
						return "off";
					}
				default:
					return ConfigurationConstants.STYLE_GRID_TEXT_CENTER_ALIGN;
			}
		});
	}

	/**
	 * Updates existing grid data source configurations.
	 * The update should be initiated outside the view.
	 * <p>
	 * The method uses java reflection to traverse all fields instead using getters as this approach
	 * seems more general.
	 * 
	 * @param configurations
	 *            modified configurations to update.
	 */
	@SuppressWarnings ({ "unchecked", "rawtypes" })
	public void updateConfigurations(List<Configuration> configurations)
	{
		if (configurations != null)
		{
			for (Configuration configuration : configurations)
			{
				Item gridConfigurationItem = getContainerDataSource()
						.getItem(configuration.getId());
				if (gridConfigurationItem != null)
				{
					for (Field configurationJavaField : Configuration.class.getDeclaredFields())
					{
						try
						{
							configurationJavaField.setAccessible(true);
							Property configurationItemProperty = gridConfigurationItem
									.getItemProperty(configurationJavaField.getName());
							if (configurationItemProperty != null)
							{
								configurationItemProperty
										.setValue(configurationJavaField.get(configuration));
							}
						}
						catch (IllegalArgumentException | IllegalAccessException e)
						{
							logger.error(
									"Error while updating configuration field {} for configuration with id {}",
									configurationJavaField.getName(), configuration.getId(), e);
						}
					}
				}
			}
		}
	}
}
