
package com.bosch.si.amra.view.formatter;

import com.vaadin.data.Property;
import com.vaadin.server.Page;

public class FlashDataFormatter extends PropertyFormatter
{
	@Override
	public String format(Object rowId, Property<?> property, String result)
	{
		return String.format(Page.getCurrent().getWebBrowser().getLocale(), "%,d",
				property.getValue());
	}
}
