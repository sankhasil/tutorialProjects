
package com.bosch.si.amra.component.grid;

import java.util.Arrays;
import java.util.Map;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.component.converter.AddressConverter;
import com.bosch.si.amra.component.converter.TimestampConverter;
import com.bosch.si.amra.constants.disponent.DisponentViewConstants;
import com.bosch.si.amra.view.details.CollectCauseCellStyleGenerator;
import com.bosch.si.amra.view.details.HistoryCellDescriptionGenerator;
import com.bosch.si.amra.view.details.converter.CollectCauseConverter;
import com.vaadin.data.Container.Indexed;
import com.vaadin.data.sort.SortOrder;
import com.vaadin.shared.data.sort.SortDirection;
import com.vaadin.ui.AbstractComponent;
import com.vaadin.ui.Grid;
import com.vaadin.ui.renderers.HtmlRenderer;

/**
 * Represents a {@link Grid} with history telematic data
 *
 * @author toa1wa3
 *
 */
public class HistoryGrid extends GridComponent
{
	/**
	 * Serial version uid
	 */
	private static final long serialVersionUID = 405126799683228661L;

	public HistoryGrid(Indexed container)
	{
		super(container);
		setSizeFull();
		setCaption(DashboardUI.getMessageSource()
				.getMessage("view.details.telematic.history.caption"));
		setColumns(DisponentViewConstants.PROPERTY_IDS);
		setColumnReorderingAllowed(true);
		setSortOrder(Arrays
				.asList(new SortOrder(DisponentViewConstants.TIMESTAMP, SortDirection.DESCENDING)));
		setResponsive(true);
		getColumns().forEach(column -> {
			column.setHeaderCaption(DashboardUI.getMessageSource()
					.getMessage("view.details.telematic.history.columnheader."
							+ ((String) column.getPropertyId()).toLowerCase()));
			column.setWidthUndefined();
			column.setHidable(true);
		});
		getColumn(DisponentViewConstants.TIMESTAMP).setConverter(new TimestampConverter())
				.setWidth(DisponentViewConstants.TIMESTAMP_COLUMN_WIDTH);
		getColumn(DisponentViewConstants.COLLECT_CAUSE)
				.setWidth(DisponentViewConstants.COLLECT_CAUSE_COLUMN_WIDTH)
				.setMaximumWidth(DisponentViewConstants.COLLECT_CAUSE_COLUMN_WIDTH)
				.setMinimumWidth(DisponentViewConstants.COLLECT_CAUSE_COLUMN_WIDTH)
				.setResizable(false).setSortable(false)
				.setRenderer(new HtmlRenderer(), new CollectCauseConverter())
				.setHidingToggleCaption(DashboardUI.getMessageSource()
						.getMessage("view.details.telematic.history.toggle.caption"));
		getColumn(DisponentViewConstants.STREET_AND_CITY).setConverter(new AddressConverter())
				.setWidth(DisponentViewConstants.STREET_AND_CITY_COLUMN_WIDTH);
		getColumn(DisponentViewConstants.COUNTRY)
				.setWidth(DisponentViewConstants.COUNTRY_COLUMN_WIDTH);
		setCellStyleGenerator(new CollectCauseCellStyleGenerator());
		setCellDescriptionGenerator(new HistoryCellDescriptionGenerator());
	}

	@Override
	public Map<AbstractComponent, Object> getComponentToPidMap()
	{
		return null;
	}
}