
package com.bosch.si.amra.metrics;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The class encapuslates loggin metrics in the defined logger called monitoring. Given a prefix and
 * a logname leads to an entry in the monitoring log so these logs can be visualized
 * 
 * @author toa1wa3
 *
 */
public class MetricsLoggerFactory
{
	private static final String	LOGGER_NAME	= "monitoring";

	private static final Logger	logger		= LoggerFactory.getLogger(LOGGER_NAME);

	public static void log(final String prefix, final String logName)
	{
		logger.info(prefix + "." + logName);
	}
}
