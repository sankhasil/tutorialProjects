
package com.bosch.si.amra.im.login;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bosch.im.authentication.AuthenticationDeniedException;
import com.bosch.im.authentication.IAuthenticationManager;
import com.bosch.im.authentication.IdentityContextIdCredentials;
import com.bosch.im.authentication.UserCredentials;
import com.bosch.im.command.ICommandExecutor;
import com.bosch.im.command.ICommandFactory;
import com.bosch.im.command.commands.IUpdateEntityCommand;
import com.bosch.im.context.IIdentityContext;
import com.bosch.im.context.IdentityContextHolder;
import com.bosch.im.context.IdentityContextId;
import com.bosch.im.exception.IMRuntimeException;
import com.bosch.im.exception.MissingServerConnectionException;
import com.bosch.im.model.IRole;
import com.bosch.im.model.IUser;
import com.bosch.im.model.QualifiedUserName;
import com.bosch.im.model.builder.factory.IEntityBuilderFactory;
import com.bosch.im.query.predicate.IPredicate;
import com.bosch.im.query.predicate.IPredicateFactory;
import com.bosch.im.util.IPagedCollection;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.WagonUser;
import com.bosch.si.amra.event.DashboardEvent;
import com.bosch.si.amra.event.DashboardEvent.ChangePasswordEvent;
import com.bosch.si.amra.event.DashboardEvent.GetAllUsersEvent;
import com.bosch.si.amra.event.DashboardEvent.PasswordChangedEvent;
import com.bosch.si.amra.event.DashboardEvent.PasswordResetEvent;
import com.bosch.si.amra.event.DashboardEvent.ProfileUpdateEvent;
import com.bosch.si.amra.event.DashboardEvent.ProfileUpdatedEvent;
import com.bosch.si.amra.event.DashboardEvent.ReceivedAllUsersEvent;
import com.bosch.si.amra.event.DashboardEvent.ResetPasswordEvent;
import com.bosch.si.amra.event.DashboardEvent.UserLoggedInEvent;
import com.bosch.si.amra.event.DashboardEvent.UserLoginRequestedEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.google.common.eventbus.Subscribe;

@Component
public class IdentityManagementUtil implements Serializable
{
	private static final String	SYSTEMADMINISTRATOR	= "Systemadministrator";

	private static final String	FLEETADMINISTRATOR	= "Fleetadministrator";

	private static final String	DISPONENT			= "Disponent";

	private static final String	ENDCUSTOMER			= "Endcustomer";

	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= 79614471440710996L;

	private Logger				logger				= LoggerFactory
			.getLogger(IdentityManagementUtil.class);

	@Autowired
	IAuthenticationManager		authenticationManager;

	@Autowired
	IPredicateFactory			predicateFactory;

	@Autowired
	IEntityBuilderFactory		entityBuilderFactory;

	@Autowired
	ICommandFactory				commandFactory;

	@Autowired
	ICommandExecutor			commandExecutor;

	private String				password;

	private IUser				user;

	public IUser getUser()
	{
		return user;
	}

	public void setUser(IUser user)
	{
		this.user = user;
	}

	@Subscribe
	public void userLoginRequested(UserLoginRequestedEvent event)
	{
		try
		{
			password = event.getPassword();
			// authenticate with 'user', 'password', 'tenant', and set identity context
			final IIdentityContext identityContext = authenticationManager.getIdentityContext(
					new UserCredentials(event.getUserName(), password, event.getTenant()));
			IdentityContextHolder.setContext(identityContext);
			// use the command API to query all users
			IPredicate predicate = predicateFactory.name(event.getUserName());
			final IPagedCollection<IUser> users = commandExecutor
					.execute(commandFactory.queryUserBuilder().query(predicate).get());

			predicate = predicateFactory.relationToUser(predicateFactory.name(event.getUserName()),
					false);
			final IPagedCollection<IRole> roles = commandExecutor
					.execute(commandFactory.queryRoleBuilder().query(predicate).get());

			IUser imUser = users.iterator().next();
			setUser(imUser);
			User user = toUser(imUser, roles, event.getTenant());
			user.setIdentityContextId(identityContext.getContextId().getId());
			DashboardEventBus.post(new UserLoggedInEvent(user));
		}
		catch (AuthenticationDeniedException e)
		{
			// user couldn't be authenticated with the given credentials
			DashboardEventBus.post(new DashboardEvent.LoginFailedEvent());
		}
		catch (MissingServerConnectionException e)
		{
			logger.error("Communication problems from IM", e);
			DashboardEventBus.post(new DashboardEvent.CommunicationProblemEvent("login.failed"));
		}
	}

	@Subscribe
	public List<WagonUser> getAllUsers(GetAllUsersEvent event)
	{
		List<WagonUser> wagon2Users = new ArrayList<>();
		try
		{
			User user = event.getUser();
			IIdentityContext identityContext = authenticationManager
					.getIdentityContext(new IdentityContextIdCredentials(
							IdentityContextId.newInstance(user.getIdentityContextId())));
			IdentityContextHolder.setContext(identityContext);

			IPredicate predicate = predicateFactory.and(
					predicateFactory.relationToRole(predicateFactory.name(DISPONENT), true),
					predicateFactory.relationToTenant(predicateFactory.name(user.getTenantName())));

			IPagedCollection<IUser> execute = commandExecutor
					.execute(commandFactory.queryUserBuilder().query(predicate).get());
			Iterator<IUser> iterator = execute.iterator();
			while (iterator.hasNext())
			{
				IUser next = iterator.next();
				wagon2Users.add(new WagonUser(next.getId().getId(), next.getName(), false, null,
						null, null));
			}

			IPredicate predicate2 = predicateFactory.and(
					predicateFactory.relationToRole(predicateFactory.name(ENDCUSTOMER), true),
					predicateFactory.relationToTenant(predicateFactory.name(user.getTenantName())));

			IPagedCollection<IUser> execute2 = commandExecutor
					.execute(commandFactory.queryUserBuilder().query(predicate2).get());
			Iterator<IUser> iterator2 = execute2.iterator();
			while (iterator2.hasNext())
			{
				IUser next = iterator2.next();
				// Checks if the user is not having disponent role also. In such case user stays
				// with disponent role.
				boolean existingUserWithDisponentRole = false;
				for (WagonUser user2wagon : wagon2Users)
				{
					if (user2wagon.getUserId().equals(next.getId().getId()))
					{
						existingUserWithDisponentRole = true;
						break;
					}
				}
				if (!existingUserWithDisponentRole)
				{
					wagon2Users.add(new WagonUser(next.getId().getId(), next.getName(), true, null,
							null, null));
				}
			}
			DashboardEventBus
					.post(new ReceivedAllUsersEvent(wagon2Users, event.getSelectedWagonId()));
		}
		catch (AuthenticationDeniedException e)
		{
			// user couldn't be authenticated with the given credentials
			DashboardEventBus.post(new DashboardEvent.LoginFailedEvent());
		}
		catch (MissingServerConnectionException e)
		{
			logger.error("Communication problems from IM", e);
			DashboardEventBus.post(
					new DashboardEvent.CommunicationProblemEvent("vaadin.internalError.Message"));
		}
		return wagon2Users;
	}

	@Subscribe
	public void changeUserProfile(ProfileUpdateEvent event)
	{
		try
		{
			// Fetch the User Profile Info submitted from the Form
			User user = event.getUser();
			String firstName = user.getFirstName();
			String lastName = user.getLastName();
			String email = user.getEmail();

			try
			{
				IIdentityContext identityContext = authenticationManager
						.getIdentityContext(new IdentityContextIdCredentials(
								IdentityContextId.newInstance(user.getIdentityContextId())));
				IdentityContextHolder.setContext(identityContext);

				IUser userToUpate = entityBuilderFactory.user(getUser()).firstName(firstName)
						.lastName(lastName).eMail(email).get();
				IUpdateEntityCommand<IUser> updateUser = commandFactory.update(userToUpate,
						getUser().getId());
				commandExecutor.execute(updateUser);
				DashboardEventBus.post(new ProfileUpdatedEvent());
			}
			catch (AuthenticationDeniedException e)
			{
				// user couldn't be authenticated with the given credentials
				DashboardEventBus.post(new DashboardEvent.LoginFailedEvent());
			}

		}
		catch (IMRuntimeException e)
		{
			logger.error("Communication problems from IM", e);
			DashboardEventBus.post(new DashboardEvent.CommunicationProblemEvent(
					"view.profile.contact.change.unsuccessful"));
		}
	}

	@Subscribe
	public void changePassword(ChangePasswordEvent event)
	{
		try
		{
			User user = event.getUser();
			String oldPassword = event.getOldPassword();
			String newPassword = event.getNewPassword();
			commandExecutor.execute(commandFactory.changePassword(user.getTenantName(),
					user.getTechnialName(), oldPassword, newPassword));
			DashboardEventBus.post(new PasswordChangedEvent());
		}
		catch (IMRuntimeException e)
		{
			logger.error("Communication problems from IM", e);
			DashboardEventBus.post(new DashboardEvent.CommunicationProblemEvent(
					"view.profile.password.change.unsuccessful"));
		}
	}

	@Subscribe
	public void resetPassword(ResetPasswordEvent event)
	{
		try
		{
			User user = event.getUser();
			commandExecutor.execute(commandFactory.sendPasswordResetEmail(
					QualifiedUserName.newInstance(user.getTechnialName(), user.getTenantName())));
			DashboardEventBus.post(new PasswordResetEvent());
		}
		catch (IMRuntimeException e)
		{
			logger.error("Communication problems from IM", e);
			DashboardEventBus.post(
					new DashboardEvent.CommunicationProblemEvent("view.reset.password.error"));
		}
	}

	private User toUser(IUser iUser, IPagedCollection<IRole> iRoles, String tenantName)
	{
		User user = new User();
		user.setId(iUser.getId().getId());
		user.setFirstName(iUser.getFirstName());
		user.setLastName(iUser.getLastName());
		user.setTechnialName(iUser.getName());
		user.setEmail(iUser.getEMailAddress());
		user.setTenantName(tenantName);

		for (Iterator<IRole> iterator = iRoles.iterator(); iterator.hasNext();)
		{
			IRole role = iterator.next();
			if (role.getName().equals(FLEETADMINISTRATOR))
				user.setAdmin(true);
			if (role.getName().equals(SYSTEMADMINISTRATOR))
				user.setSuperAdmin(true);
			if (role.getName().equals(ENDCUSTOMER))
				user.setEndCustomer(true);
			if (role.getName().equals(DISPONENT))
				user.setDisponent(true);
		}
		user.setTenant(iUser.getTenantId().getId());
		return user;
	}
}
