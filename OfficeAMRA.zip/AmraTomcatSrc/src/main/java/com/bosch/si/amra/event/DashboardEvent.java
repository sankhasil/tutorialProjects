
package com.bosch.si.amra.event;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.bosch.si.amra.entity.Tag;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.entity.WagonType;
import com.bosch.si.amra.entity.WagonUser;
import com.bosch.si.amra.entity.configuration.Configuration;
import com.bosch.si.amra.entity.geofence.Geofence;
import com.bosch.si.amra.entity.monitoring.AlarmRule;
import com.bosch.si.amra.entity.notification.Notification;
import com.bosch.si.amra.entity.report.MileageValue;
import com.bosch.si.amra.entity.report.SensorValue;
import com.bosch.si.amra.entity.rule.Rule;
import com.bosch.si.amra.presenter.details.Route;
import com.bosch.si.amra.presenter.fleetbalancing.FleetBalancingType;
import com.bosch.si.amra.view.AmraView;
import com.vaadin.tapio.googlemaps.client.LatLon;
import com.vaadin.ui.Component;

public class DashboardEvent implements Serializable
{

	/**
	 * Serial version uid
	 */
	private static final long serialVersionUID = 965359953980722507L;

	public static class UserLoginRequestedEvent
	{
		private final String userName, password, tenant;

		public UserLoginRequestedEvent(String userName, String password, String tenant)
		{
			this.userName = userName;
			this.password = password;
			this.tenant = tenant;
		}

		public String getUserName()
		{
			return userName;
		}

		public String getPassword()
		{
			return password;
		}

		public String getTenant()
		{
			return tenant;
		}

	}

	public static class UserLoggedInEvent
	{
		private final User user;

		public UserLoggedInEvent(User user)
		{
			this.user = user;
		}

		public User getUser()
		{
			return user;
		}
	}

	public static class GetAllUsersEvent
	{
		private final User		user;

		private final String	selectedWagonId;

		public GetAllUsersEvent(User user, String selectedWagonId)
		{
			this.user = user;
			this.selectedWagonId = selectedWagonId;
		}

		public User getUser()
		{
			return user;
		}

		public String getSelectedWagonId()
		{
			return selectedWagonId;
		}
	}

	public static class ReceivedAllUsersEvent
	{
		private final List<WagonUser>	users;

		private final String			selectedWagonId;

		public ReceivedAllUsersEvent(List<WagonUser> users, String selectedWagonId)
		{
			this.users = users;
			this.selectedWagonId = selectedWagonId;
		}

		public List<WagonUser> getUsers()
		{
			return users;
		}

		public String getSelectedWagonId()
		{
			return selectedWagonId;
		}
	}

	public static class AssignUserToWagonsEvent
	{
		private final List<WagonUser>	selectedUsers;

		private final String			selectedWagonId;

		public AssignUserToWagonsEvent(List<WagonUser> selectedUsers, String selectedWagonId)
		{
			this.selectedUsers = selectedUsers;
			this.selectedWagonId = selectedWagonId;
		}

		public String getSelectedWagonId()
		{
			return selectedWagonId;
		}

		public List<WagonUser> getSelectedUsers()
		{
			return selectedUsers;
		}
	}

	public static class UserToWagonAssignedEvent
	{
		private final List<WagonUser>	assignedUsers;

		private final String			selectedWagonId;

		public UserToWagonAssignedEvent(List<WagonUser> assignedUsers, String selectedWagonId)
		{
			this.assignedUsers = assignedUsers;
			this.selectedWagonId = selectedWagonId;
		}

		public String getSelectedWagon()
		{
			return selectedWagonId;
		}

		public List<WagonUser> getAssignedUsers()
		{
			return assignedUsers;
		}
	}

	public static class WagonSelectedEvent
	{
		private final Wagon wagon;

		public WagonSelectedEvent(Wagon wagon)
		{
			this.wagon = wagon;
		}

		public Wagon getWagon()
		{
			return wagon;
		}
	}

	public static class ShowDetailsForWagonEvent
	{
		private final Wagon		wagon;

		private final String	tenantId;

		public ShowDetailsForWagonEvent(Wagon wagon, String tenantId)
		{
			this.wagon = wagon;
			this.tenantId = tenantId;
		}

		public Wagon getWagon()
		{
			return wagon;
		}

		public String getTenantId()
		{
			return tenantId;
		}
	}

	public static class UpdateMeansOfTransportEvent
	{
		private final Wagon		wagon;

		private final String	tenantId;

		public UpdateMeansOfTransportEvent(Wagon wagon, String tenantId)
		{
			this.wagon = wagon;
			this.tenantId = tenantId;
		}

		public Wagon getWagon()
		{
			return wagon;
		}

		public String getTenantId()
		{
			return tenantId;
		}

	}

	public static class CouplingEvent
	{
		private final Wagon wagon;

		public CouplingEvent(Wagon wagon)
		{
			this.wagon = wagon;
		}

		public Wagon getWagon()
		{
			return wagon;
		}

	}

	public static class DecouplingEvent
	{
		private final Wagon wagon;

		public DecouplingEvent(Wagon wagon)
		{
			this.wagon = wagon;
		}

		public Wagon getWagon()
		{
			return wagon;
		}

	}

	public static class WagonTypeEvent
	{
		private final WagonType	wagonType;

		private final String	tenantId;

		public WagonTypeEvent(WagonType typeName, String tenantId)
		{
			this.wagonType = typeName;
			this.tenantId = tenantId;
		}

		public WagonType getWagonType()
		{
			return wagonType;
		}

		public String getTenantId()
		{
			return tenantId;
		}
	}

	public static class WagonTypeDeleteEvent
	{
		private final WagonType	wagonType;

		private final String	tenantId;

		public WagonTypeDeleteEvent(WagonType typeName, String tenantId)
		{
			this.wagonType = typeName;
			this.tenantId = tenantId;
		}

		public WagonType getWagonType()
		{
			return wagonType;
		}

		public String getTenantId()
		{
			return tenantId;
		}
	}

	public static class WagonTypeStatusEvent
	{
		public enum Status
		{
			OK_ADDED, OK_REMOVED, ERROR_EXISTING_TRANSPORT_TYPE, ERROR_USED_TRANSPORT_TYPE
		}

		private final WagonType	wagonType;

		private final Status	status;

		public WagonTypeStatusEvent(WagonType wagonType, Status status)
		{
			this.wagonType = wagonType;
			this.status = status;
		}

		public WagonType getWagonType()
		{
			return wagonType;
		}

		public Status getStatus()
		{
			return status;
		}
	}

	public static class WagonDetailsEvent
	{
		private final Collection<Wagon> wagons;

		public WagonDetailsEvent(Collection<Wagon> transactions)
		{
			this.wagons = transactions;
		}

		public Collection<Wagon> getWagons()
		{
			return wagons;
		}
	}

	public static class CalculateMileageEvent
	{
		private final Date		startDate, endDate;

		private final String	wagonId;

		public CalculateMileageEvent(String wagonId, Date startDate, Date endDate)
		{
			this.wagonId = wagonId;
			this.startDate = startDate;
			this.endDate = endDate;

		}

		public Date getStartDate()
		{
			return startDate;
		}

		public Date getEndDate()
		{
			return endDate;
		}

		public String getWagonId()
		{
			return wagonId;
		}

	}

	public static class ShowRouteEvent
	{
		private final Date		startDate, endDate;

		private final String	wagonId;

		public ShowRouteEvent(String wagonId, Date startDate, Date endDate)
		{
			this.wagonId = wagonId;
			this.startDate = startDate;
			this.endDate = endDate;
		}

		public Date getStartDate()
		{
			return startDate;
		}

		public Date getEndDate()
		{
			return endDate;
		}

		public String getWagonId()
		{
			return wagonId;
		}

	}

	public static class NotSuccessfulEvent
	{
		private final String code;

		public NotSuccessfulEvent(String code)
		{
			this.code = code;
		}

		public String getCode()
		{
			return code;
		}
	}

	public static class NotSuccessfulCoupledEvent
	{
		private final String code;

		public NotSuccessfulCoupledEvent(String code)
		{
			this.code = code;
		}

		public String getCode()
		{
			return code;
		}
	}

	public static class ClearValueEvent
	{

	}

	public static class UpdateEvent
	{
		private final Object value;

		public UpdateEvent(Object value)
		{
			this.value = value;
		}

		public Object getValue()
		{
			return value;
		}
	}

	public static class RouteUpdateEvent
	{
		private final Route route;

		public RouteUpdateEvent(Route route)
		{
			this.route = route;
		}

		public Route getRoute()
		{
			return route;
		}
	}

	public static class ReportEvent
	{
		private final String		tenantId;

		private final List<Wagon>	wagons;

		public ReportEvent(String tenantId, List<Wagon> wagons)
		{
			this.tenantId = tenantId;
			this.wagons = wagons;
		}

		public String getTenantId()
		{
			return tenantId;
		}

		public List<Wagon> getWagons()
		{
			return wagons;
		}
	}

	public static class ExportGenerationEvent
	{
		private final String				tenantId;

		private final List<Wagon>			wagons;

		private final Map<String, Boolean>	selectedFields;

		private final Date					startDate, endDate;

		public ExportGenerationEvent(String tenantId, List<Wagon> wagons,
				Map<String, Boolean> selectedFields, Date startDate, Date endDate)
		{
			this.tenantId = tenantId;
			this.wagons = wagons;
			this.selectedFields = selectedFields;
			this.startDate = startDate;
			this.endDate = endDate;
		}

		public Date getStartDate()
		{
			return startDate;
		}

		public Date getEndDate()
		{
			return endDate;
		}

		public String getTenantId()
		{
			return tenantId;
		}

		public List<Wagon> getWagons()
		{
			return wagons;
		}

		public Map<String, Boolean> getSelectedFields()
		{
			return selectedFields;
		}
	}

	public static class ExportDownloadEvent
	{
		private final StringBuffer stringBuffer;

		public ExportDownloadEvent(StringBuffer stringBuffer)
		{
			this.stringBuffer = stringBuffer;
		}

		public StringBuffer getStreamResource()
		{
			return stringBuffer;
		}
	}

	public static class ReportMileageUpdateEvent
	{
		private final Map<String, List<MileageValue>>	mileageMap;

		private final Map<String, Integer>				offsetValues;

		public ReportMileageUpdateEvent(Map<String, List<MileageValue>> mileageMap,
				Map<String, Integer> offsetValues)
		{
			this.mileageMap = mileageMap;
			this.offsetValues = offsetValues;
		}

		public Map<String, List<MileageValue>> getMileageMap()
		{
			return mileageMap;
		}

		public Map<String, Integer> getOffsetValues()
		{
			return offsetValues;
		}
	}

	public static class ReportSensorUpdateEvent
	{
		private final Map<String, List<SensorValue>> sensorMap;

		public ReportSensorUpdateEvent(Map<String, List<SensorValue>> sensorMap)
		{
			this.sensorMap = sensorMap;
		}

		public Map<String, List<SensorValue>> getSensorMap()
		{
			return sensorMap;
		}
	}

	public static class FleetBalancingGetEvent
	{
		private final String		tenantId;

		private final List<Wagon>	wagons;

		private final Integer		limit;

		private final Date			startDate, endDate;

		public FleetBalancingGetEvent(String tenantId, List<Wagon> wagons, Integer limit,
				Date startDate, Date endDate)
		{
			this.tenantId = tenantId;
			this.wagons = wagons;
			this.limit = limit;
			this.startDate = startDate;
			this.endDate = endDate;
		}

		public String getTenantId()
		{
			return tenantId;
		}

		public List<Wagon> getWagons()
		{
			return wagons;
		}

		public Integer getLimit()
		{
			return limit;
		}

		public Date getStartDate()
		{
			return startDate;
		}

		public Date getEndDate()
		{
			return endDate;
		}
	}

	public static class FleetBalancingFillChartEvent
	{
		private final Map<FleetBalancingType, List<Wagon>>	balancingMap;

		private final int									average;

		private final int									maxMileageDeviation;

		public FleetBalancingFillChartEvent(Map<FleetBalancingType, List<Wagon>> balancingMap,
				int average, int maxMileageDeviation)
		{
			this.balancingMap = balancingMap;
			this.average = average;
			this.maxMileageDeviation = maxMileageDeviation;
		}

		public Map<FleetBalancingType, List<Wagon>> getBalancingMap()
		{
			return balancingMap;
		}

		public int getAverage()
		{
			return average;
		}

		public int getMaxMileageDeviation()
		{
			return maxMileageDeviation;
		}
	}

	public static class NotificationAcknowledgeEvent
	{
		private final List<Notification>	notifications;

		private final User					user;

		public NotificationAcknowledgeEvent(List<Notification> notifications, User user)
		{
			this.notifications = notifications;
			this.user = user;
		}

		public List<Notification> getNotifications()
		{
			return notifications;
		}

		public User getUser()
		{
			return user;
		}
	}

	public static class ConfigurationsEvent
	{
		private final String tenantId;

		public ConfigurationsEvent(String tenantId)
		{
			this.tenantId = tenantId;
		}

		public String getTenantId()
		{
			return tenantId;
		}
	}

	public static class ConfigurationsSaveEvent
	{
		private final List<Configuration>	configurations;

		private final String				tenantId;

		public ConfigurationsSaveEvent(List<Configuration> configurations, String tenantId)
		{
			this.configurations = configurations;
			this.tenantId = tenantId;
		}

		public List<Configuration> getConfigurations()
		{
			return configurations;
		}

		public String getTenantId()
		{
			return tenantId;
		}
	}

	public static class ConfigurationsSaveAliasEvent
	{
		private final String	configurationId;

		private final String	alias;

		public ConfigurationsSaveAliasEvent(String alias, String configurationId)
		{
			this.configurationId = configurationId;
			this.alias = alias;
		}

		public String getConfigurationId()
		{
			return configurationId;
		}

		public String getAlias()
		{
			return alias;
		}
	}

	public static class NotificationsSaveAliasEvent
	{
		private final String	wagonId;

		private final String	alias;

		public NotificationsSaveAliasEvent(String alias, String wagonId)
		{
			this.wagonId = wagonId;
			this.alias = alias;
		}

		public String getWagonId()
		{
			return wagonId;
		}

		public String getAlias()
		{
			return alias;
		}
	}

	public static class WagonSetEvent
	{
		private final List<Wagon> wagons;

		public WagonSetEvent(List<Wagon> wagons)
		{
			this.wagons = wagons;
		}

		public List<Wagon> getWagons()
		{
			return wagons;
		}
	}

	public static class ConfigurationSetEvent
	{
		private final List<Configuration> configurations;

		public ConfigurationSetEvent(List<Configuration> configurations)
		{
			this.configurations = configurations;
		}

		public List<Configuration> getConfigurations()
		{
			return configurations;
		}
	}

	public static class NotificationSetEvent
	{
		private final List<Notification> notifications;

		public NotificationSetEvent(List<Notification> notifications)
		{
			this.notifications = notifications;
		}

		public List<Notification> getNotifications()
		{
			return notifications;
		}
	}

	public static class TagCreateOrUpdateEvent
	{
		private String	tenantId;

		private Tag		tag;

		public TagCreateOrUpdateEvent(String tenantId, Tag tag)
		{
			this.tenantId = tenantId;
			this.tag = tag;
		}

		public String getTenantId()
		{
			return tenantId;
		}

		public void setTenantId(String tenantId)
		{
			this.tenantId = tenantId;
		}

		public Tag getTag()
		{
			return tag;
		}

		public void setTag(Tag tag)
		{
			this.tag = tag;
		}
	}

	public static class TagAssignChangeEvent
	{
		List<Wagon>	listOfWagons;

		List<Tag>	selectedTags;

		boolean		assignFlag;

		public List<Wagon> getListOfWagons()
		{
			return listOfWagons;
		}

		public void setListOfWagons(List<Wagon> listOfWagons)
		{
			this.listOfWagons = listOfWagons;
		}

		public List<Tag> getSelectedTags()
		{
			return selectedTags;
		}

		public void setSelectedTags(List<Tag> selectedTags)
		{
			this.selectedTags = selectedTags;
		}

		public boolean isAssignFlag()
		{
			return assignFlag;
		}

		public void setAssignFlag(boolean assignFlag)
		{
			this.assignFlag = assignFlag;
		}

		public TagAssignChangeEvent(List<Wagon> wagons, List<Tag> selectedTags, boolean assignFlag)
		{
			this.listOfWagons = wagons;
			this.selectedTags = selectedTags;
			this.assignFlag = assignFlag;
		}
	}

	public static class DeleteTagEvent
	{
		private List<Tag> tagListToDelete;

		public DeleteTagEvent(List<Tag> tagListToDelete)
		{
			this.tagListToDelete = tagListToDelete;
		}

		public List<Tag> getTagListToDelete()
		{
			return tagListToDelete;
		}

		public void setTagListToDelete(List<Tag> tagListToDelete)
		{
			this.tagListToDelete = tagListToDelete;
		}
	}

	public static class TagSaveStatusEvent
	{
		private boolean	success;

		private String	message;

		private Tag		tag;

		public TagSaveStatusEvent(Tag tag, boolean success, String message)
		{
			this.success = success;
			this.message = message;
			this.tag = tag;
		}

		public boolean isSuccess()
		{
			return success;
		}

		public void setSuccess(boolean success)
		{
			this.success = success;
		}

		public String getMessage()
		{
			return message;
		}

		public void setMessage(String message)
		{
			this.message = message;
		}

		public Tag getTag()
		{
			return tag;
		}

		public void setTag(Tag tag)
		{
			this.tag = tag;
		}
	}

	public static class WagonSortAndFilterEvent
	{
		private final User		user;

		private final String	propertyToSort;

		private final boolean	ascending;

		private final String	filterText;

		public WagonSortAndFilterEvent(User user, String propertyToSort, boolean ascending,
				String filterText)
		{
			this.user = user;
			this.propertyToSort = propertyToSort;
			this.ascending = ascending;
			this.filterText = filterText;
		}

		public User getUser()
		{
			return user;
		}

		public String getPropertyToSort()
		{
			return propertyToSort;
		}

		public boolean isAscending()
		{
			return ascending;
		}

		public String getFilterText()
		{
			return filterText;
		}
	}

	public static class ConfigurationSortAndFilterEvent
	{
		private final String	tenantId;

		private final String	propertyToSort;

		private final boolean	ascending;

		private final String	filterText;

		public ConfigurationSortAndFilterEvent(String tenantId, String propertyToSort,
				boolean ascending, String filterText)
		{
			this.tenantId = tenantId;
			this.propertyToSort = propertyToSort;
			this.ascending = ascending;
			this.filterText = filterText;
		}

		public String getTenantId()
		{
			return tenantId;
		}

		public String getPropertyToSort()
		{
			return propertyToSort;
		}

		public boolean isAscending()
		{
			return ascending;
		}

		public String getFilterText()
		{
			return filterText;
		}
	}

	public static class NotificationSortAndFilterEvent
	{
		private final User			user;

		private final String		propertyToSort;

		private final boolean		ascending;

		private final String		filterText;

		private final boolean		acknowledged;

		private final List<String>	reasons;

		public NotificationSortAndFilterEvent(User user, String propertyToSort, boolean ascending,
				String filterText, boolean acknowledged, List<String> reasons)
		{
			this.user = user;
			this.propertyToSort = propertyToSort;
			this.ascending = ascending;
			this.filterText = filterText;
			this.acknowledged = acknowledged;
			this.reasons = reasons;
		}

		public User getUser()
		{
			return user;
		}

		public String getPropertyToSort()
		{
			return propertyToSort;
		}

		public boolean isAscending()
		{
			return ascending;
		}

		public String getFilterText()
		{
			return filterText;
		}

		public boolean isAcknowledged()
		{
			return acknowledged;
		}

		public List<String> getReasons()
		{
			return reasons;
		}
	}

	public static class FitToBoundsEvent
	{
		private final List<LatLon> bounds;

		public FitToBoundsEvent(List<LatLon> bounds)
		{
			this.bounds = bounds;
		}

		public List<LatLon> getBounds()
		{
			return bounds;
		}
	}

	public static class GeofenceSelectEvent
	{
		private final String geofenceId;

		public GeofenceSelectEvent(String geofenceId)
		{
			this.geofenceId = geofenceId;
		}

		public String getGeofenceId()
		{
			return geofenceId;
		}
	}

	public static class GeofenceSelectedEvent
	{
		private final Geofence geofence;

		public GeofenceSelectedEvent(Geofence geofence)
		{
			this.geofence = geofence;
		}

		public Geofence getGeofence()
		{
			return geofence;
		}
	}

	public static class GeofenceSaveEvent
	{
		private final Geofence	geofence;

		private final String	tenantId;

		public GeofenceSaveEvent(Geofence geofence, String tenantId)
		{
			this.geofence = geofence;
			this.tenantId = tenantId;
		}

		public Geofence getGeofence()
		{
			return geofence;
		}

		public String getTenantId()
		{
			return tenantId;
		}
	}

	public static class AlarmRuleSetEvent
	{
		private final List<AlarmRule> alarmRules;

		public AlarmRuleSetEvent(List<AlarmRule> alarmRules)
		{
			this.alarmRules = alarmRules;
		}

		public List<AlarmRule> getAlarmRules()
		{
			return alarmRules;
		}
	}

	public static class AlarmRuleRequestAllEvent
	{
		private final String tenantId;

		public AlarmRuleRequestAllEvent(String tenantId)
		{
			this.tenantId = tenantId;
		}

		public String getTenantId()
		{
			return tenantId;
		}
	}

	public static class AlarmRuleSentAllEvent
	{
		private final Map<AlarmRule, List<AlarmRule>>	alarmRules;

		private final List<AlarmRule>					alarmRulesList;

		public AlarmRuleSentAllEvent(Map<AlarmRule, List<AlarmRule>> alarmRules,
				List<AlarmRule> alarmRulesList)
		{
			this.alarmRules = alarmRules;
			this.alarmRulesList = alarmRulesList;
		}

		public Map<AlarmRule, List<AlarmRule>> getAlarmRules()
		{
			return alarmRules;
		}

		public List<AlarmRule> getAlarmRulesList()
		{
			return alarmRulesList;
		}
	}

	public static class AlarmsRuleEvent
	{
		private final String tenantId;

		public AlarmsRuleEvent(String tenantId)
		{
			this.tenantId = tenantId;
		}

		public String getTenantId()
		{
			return tenantId;
		}
	}

	public static class AlarmsRuleReadEvent
	{
		private final String id;

		public AlarmsRuleReadEvent(String id)
		{
			this.id = id;
		}

		public String getId()
		{
			return id;
		}
	}

	public static class AlarmsRuleSentEvent
	{
		private final AlarmRule alarmRule;

		public AlarmsRuleSentEvent(AlarmRule alarmRule)
		{
			this.alarmRule = alarmRule;
		}

		public AlarmRule getAlarmRule()
		{
			return alarmRule;
		}
	}

	public static class AlarmRulesSaveEvent
	{
		private final List<AlarmRule>	alarmRules;

		private final String			tenantId;

		public AlarmRulesSaveEvent(List<AlarmRule> alarmRules, String tenantId)
		{
			this.alarmRules = alarmRules;
			this.tenantId = tenantId;
		}

		public List<AlarmRule> getAlarmRules()
		{
			return alarmRules;
		}

		public String getTenantId()
		{
			return tenantId;
		}
	}

	public static class AlarmRulesDeleteEvent
	{
		private final List<AlarmRule>	alarmRules;

		private final String			tenantId;

		public AlarmRulesDeleteEvent(List<AlarmRule> alarmRules, String tenantId)
		{
			this.alarmRules = alarmRules;
			this.tenantId = tenantId;
		}

		public List<AlarmRule> getAlarmRules()
		{
			return alarmRules;
		}

		public String getTenantId()
		{
			return tenantId;
		}
	}

	public static class AlarmRulesSaveAliasEvent
	{
		private final String	wagonId;

		private final String	alias;

		public AlarmRulesSaveAliasEvent(String alias, String wagonId)
		{
			this.wagonId = wagonId;
			this.alias = alias;
		}

		public String getWagonId()
		{
			return wagonId;
		}

		public String getAlias()
		{
			return alias;
		}
	}

	public static class AlarmRuleSortAndFilterEvent
	{
		private final String	tenantId;

		private final String	propertyToSort;

		private final boolean	ascending;

		private final String	filterText;

		public AlarmRuleSortAndFilterEvent(String tenantId, String propertyToSort,
				boolean ascending, String filterText)
		{
			this.tenantId = tenantId;
			this.propertyToSort = propertyToSort;
			this.ascending = ascending;
			this.filterText = filterText;
		}

		public String getTenantId()
		{
			return tenantId;
		}

		public String getPropertyToSort()
		{
			return propertyToSort;
		}

		public boolean isAscending()
		{
			return ascending;
		}

		public String getFilterText()
		{
			return filterText;
		}
	}

	public static class AlarmRulesSavedEvent
	{

	}

	public static class RuleSaveEvent
	{
		private final Rule			rule;

		private final String		tenantId;

		private final List<Wagon>	primaryAssignedWagonsToRule;

		public RuleSaveEvent(Rule rule, String tenantId, List<Wagon> primaryAssignedWagonsToRule)
		{
			this.rule = rule;
			this.tenantId = tenantId;
			this.primaryAssignedWagonsToRule = primaryAssignedWagonsToRule;
		}

		public Rule getRule()
		{
			return rule;
		}

		public String getTenantId()
		{
			return tenantId;
		}

		public List<Wagon> getPrimaryAssignedWagonsToRule()
		{
			return primaryAssignedWagonsToRule;
		}
	}

	public static class RulesSaveAliasEvent
	{
		private final String	wagonId;

		private final String	alias;

		public RulesSaveAliasEvent(String alias, String wagonId)
		{
			this.wagonId = wagonId;
			this.alias = alias;
		}

		public String getWagonId()
		{
			return wagonId;
		}

		public String getAlias()
		{
			return alias;
		}
	}

	public static class RuleSortAndFilterEvent
	{
		private final String	tenantId;

		private final String	propertyToSort;

		private final boolean	ascending;

		private final String	filterText;

		public RuleSortAndFilterEvent(String tenantId, String propertyToSort, boolean ascending,
				String filterText)
		{
			this.tenantId = tenantId;
			this.propertyToSort = propertyToSort;
			this.ascending = ascending;
			this.filterText = filterText;
		}

		public String getTenantId()
		{
			return tenantId;
		}

		public String getPropertyToSort()
		{
			return propertyToSort;
		}

		public boolean isAscending()
		{
			return ascending;
		}

		public String getFilterText()
		{
			return filterText;
		}
	}

	public static class RulesDeleteEvent
	{
		private final List<Rule>	rules;

		private final String		tenantId;

		public RulesDeleteEvent(List<Rule> rules, String tenantId)
		{
			this.rules = rules;
			this.tenantId = tenantId;
		}

		public List<Rule> getRules()
		{
			return rules;
		}

		public String getTenantId()
		{
			return tenantId;
		}
	}

	public static class GeofenceDeleteEvent
	{
		private final Geofence geofence;

		public GeofenceDeleteEvent(Geofence geofence)
		{
			this.geofence = geofence;
		}

		public Geofence getGeofence()
		{
			return geofence;
		}

	}

	public static class GeofenceDeletedEvent
	{
		private final boolean deleted;

		public GeofenceDeletedEvent(boolean deleted)
		{
			this.deleted = deleted;
		}

		public boolean isDeleted()
		{
			return deleted;
		}

	}

	public static class RuleReadEvent
	{
		private final String id;

		public RuleReadEvent(String id)
		{
			this.id = id;
		}

		public String getId()
		{
			return id;
		}
	}

	public static class RuleSentAllEvent
	{
		private final List<Rule> rules;

		public RuleSentAllEvent(List<Rule> rules)
		{
			this.rules = rules;
		}

		public List<Rule> getRules()
		{
			return rules;
		}
	}

	public static class RuleSentEvent
	{
		private final Rule rule;

		public RuleSentEvent(Rule rule)
		{
			this.rule = rule;
		}

		public Rule getRule()
		{
			return rule;
		}
	}

	public static class RuleSavedEvent
	{

	}

	/**
	 * This event class is used to track the wagons which already have a temperature range rule and
	 * helps to show a notification in UI.
	 * This event class will be created if there are any wagons in rule creation assignment list
	 * already have HTR(Temperature Range). After the Database check, the names of
	 * the wagons and
	 * rule names are passed as
	 * String array to this event construction along with the Rule object which is going to be
	 * created.
	 * 
	 * @author ILS5KOR
	 *
	 */
	public static class TemperatureRangeRuleFailedSavedEvent
	{
		private final Rule		rule;

		private final String[]	wagonAliases;

		private final String[]	ruleNames;

		public TemperatureRangeRuleFailedSavedEvent(Rule rule, String[] wagonAliases,
				String[] ruleNames)
		{
			this.rule = rule;
			this.wagonAliases = wagonAliases;
			this.ruleNames = ruleNames;
		}

		public Rule getRule()
		{
			return rule;
		}

		public String[] getWagonAliases()
		{
			return wagonAliases;
		}

		public String[] getRuleNames()
		{
			return ruleNames;
		}
	}

	public static class ConfigurationsSavedEvent
	{
		private final List<Configuration> configurations;

		public ConfigurationsSavedEvent(List<Configuration> configurations)
		{
			this.configurations = configurations;
		}

		public List<Configuration> getConfigurations()
		{
			return configurations;
		}
	}

	public static class BrowserResizeEvent
	{

	}

	public static class UserLoggedOutEvent
	{

	}

	public static class SaveUserSettingsEvent
	{

	}

	public static class LoginFailedEvent
	{

	}

	public static class CommunicationProblemEvent
	{
		private final String messageCode;

		public CommunicationProblemEvent(String messageCode)
		{
			this.messageCode = messageCode;
		}

		public String getMessageCode()
		{
			return messageCode;
		}
	}

	public static class NotificationsCountUpdatedEvent
	{
	}

	public static class DashboardEditEvent
	{
		private final String name;

		public DashboardEditEvent(String name)
		{
			this.name = name;
		}

		public String getName()
		{
			return name;
		}

	}

	public static class PostViewChangeEvent
	{
		private final AmraView view;

		public PostViewChangeEvent(AmraView view)
		{
			this.view = view;
		}

		public AmraView getView()
		{
			return view;
		}
	}

	public static class CloseOpenWindowsEvent
	{
	}

	public static class ProfileUpdateEvent
	{

		private final User	user;

		private String		firstName;

		private String		lastName;

		private String		email;

		public ProfileUpdateEvent(User user, String firstName, String lastName, String email)
		{
			this.user = user;
			this.setFirstName(firstName);
			this.setLastName(lastName);
			this.setEmail(email);
		}

		public User getUser()
		{
			return user;
		}

		public String getFirstName()
		{
			return firstName;
		}

		public void setFirstName(String firstName)
		{
			this.firstName = firstName;
		}

		public String getLastName()
		{
			return lastName;
		}

		public void setLastName(String lastName)
		{
			this.lastName = lastName;
		}

		public String getEmail()
		{
			return email;
		}

		public void setEmail(String email)
		{
			this.email = email;
		}

	}

	public static class ProfileUpdatedEvent
	{

	}

	public static class ChangePasswordEvent
	{
		private final User		user;

		private final String	oldPassword;

		private final String	newPassword;

		public ChangePasswordEvent(User user, String oldPassword, String newPassword)
		{
			this.user = user;
			this.oldPassword = oldPassword;
			this.newPassword = newPassword;
		}

		public User getUser()
		{
			return user;
		}

		public String getOldPassword()
		{
			return oldPassword;
		}

		public String getNewPassword()
		{
			return newPassword;
		}
	}

	public static class PasswordChangedEvent
	{

	}

	public static class ResetPasswordEvent
	{
		private final User user;

		public ResetPasswordEvent(User user)
		{
			this.user = user;
		}

		public User getUser()
		{
			return user;
		}
	}

	public static class PasswordResetEvent
	{

	}

	public static class MaximizeDashboardPanelEvent
	{
		private final Component panel;

		public MaximizeDashboardPanelEvent(Component panel)
		{
			this.panel = panel;
		}

		public Component getPanel()
		{
			return panel;
		}
	}

	public static class MinimizeDashboardPanelEvent
	{
		private final Component panel;

		public MinimizeDashboardPanelEvent(Component panel)
		{
			this.panel = panel;
		}

		public Component getPanel()
		{
			return panel;
		}
	}

	public static class MapFilterEvent
	{

	}
}
