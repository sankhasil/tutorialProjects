
package com.bosch.si.amra.entity;

import java.util.ArrayList;
/**
 * @author sks9kor
 *         UserSettingsConfiguration class used to store the current user settings for the specific
 *         pages, e.g. Overview, Disponent view etc.
 *         The data is stored inside the session data. During logout the data is persisted on a
 *         database and will be retrieved during the next login.
 *
 */
import java.util.HashMap;
import java.util.Map;

import com.bosch.si.amra.constants.MongoConstants;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.vaadin.data.sort.SortOrder;
import com.vaadin.shared.data.sort.SortDirection;

public class UserSettingsConfiguration
{
	ArrayList<ColumnConfiguration>	userSettingsColumnConfigurations	= new ArrayList<>();

	SortOrder						sortedGridColumnConfigurations;

	Map<String, String>				filterMap							= new HashMap<>();

	public ArrayList<ColumnConfiguration> getUserSettingsColumnConfigurations()
	{
		return userSettingsColumnConfigurations;
	}

	public void setUserSettingsColumnConfigurations(
			ArrayList<ColumnConfiguration> userSettingsColumnConfigurations)
	{
		this.userSettingsColumnConfigurations = userSettingsColumnConfigurations;
	}

	public SortOrder getSortedGridColumnConfigurations()
	{

		return sortedGridColumnConfigurations;
	}

	public void setSortedGridColumnConfigurations(SortOrder sortedGridColumnConfigurations)
	{
		this.sortedGridColumnConfigurations = sortedGridColumnConfigurations;
	}

	public Map<String, String> getFilterMap()
	{
		return filterMap;
	}

	public void setFilterMap(Map<String, String> filterMap)
	{
		this.filterMap = filterMap;
	}

	public static DBObject config2DBObject(UserSettingsConfiguration configuration)
	{
		ArrayList<ColumnConfiguration> columOrder = configuration
				.getUserSettingsColumnConfigurations();
		BasicDBList columnsProperty = ColumnConfiguration.columnConfig2DBList(columOrder);
		DBObject updatedSettings = new BasicDBObject(MongoConstants.COLUMN_CONFIGURATION,
				columnsProperty);
		Map<String, String> filterMap = configuration.getFilterMap();
		if (!filterMap.isEmpty())
		{
			BasicDBList filterSettings = ColumnConfiguration.map2DBList(filterMap);
			updatedSettings.put(MongoConstants.FILTERS, filterSettings);
		}
		DBObject sortColumns = new BasicDBObject();
		SortOrder sortOrder = configuration.getSortedGridColumnConfigurations();
		if (sortOrder != null)
			sortColumns.put(sortOrder.getPropertyId().toString().replace(".", "_"),
					sortOrder.getDirection().equals(SortDirection.ASCENDING) ? true : false);
		updatedSettings.put(MongoConstants.SORTED_ORDER, sortColumns);
		return updatedSettings;
	}

	public static UserSettingsConfiguration dBObject2Config(DBObject sessionDataObject,
			String documentKey)
	{
		UserSettingsConfiguration userSettingsConfiguration = new UserSettingsConfiguration();
		DBObject userSettingsObject = (DBObject) sessionDataObject.get(documentKey);
		if (userSettingsObject != null && userSettingsObject.keySet().size() > 0)
		{
			BasicDBList columnConfigObjectList = (BasicDBList) userSettingsObject
					.get(MongoConstants.COLUMN_CONFIGURATION);
			ArrayList<ColumnConfiguration> userColumSettings = ColumnConfiguration
					.dBList2ColumnConfig(columnConfigObjectList);
			DBObject sortOrderObject = (DBObject) userSettingsObject
					.get(MongoConstants.SORTED_ORDER);
			if (sortOrderObject != null && sortOrderObject.keySet().size() > 0)
			{
				String sortOrderKey = sortOrderObject.keySet().iterator().next();
				SortDirection sortDirection = (boolean) sortOrderObject.get(sortOrderKey)
						? SortDirection.ASCENDING : SortDirection.DESCENDING;
				SortOrder sortedGridColumnConfigurations = new SortOrder(
						sortOrderKey.replace("_", "."), sortDirection);
				userSettingsConfiguration
						.setSortedGridColumnConfigurations(sortedGridColumnConfigurations);
			}
			userSettingsConfiguration.setUserSettingsColumnConfigurations(userColumSettings);
			if (userSettingsObject.containsField(MongoConstants.FILTERS))
			{
				BasicDBList columnFiltersList = (BasicDBList) userSettingsObject
						.get(MongoConstants.FILTERS);
				Map<String, String> filterMap = ColumnConfiguration.dBList2map(columnFiltersList);
				userSettingsConfiguration.setFilterMap(filterMap);
			}
		}
		return userSettingsConfiguration;
	}
}
