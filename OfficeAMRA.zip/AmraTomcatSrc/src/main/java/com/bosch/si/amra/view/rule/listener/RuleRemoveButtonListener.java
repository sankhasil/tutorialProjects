
package com.bosch.si.amra.view.rule.listener;

import com.bosch.si.amra.view.rule.RuleView;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;

public class RuleRemoveButtonListener implements ClickListener
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= -917853370711661212L;

	private final RuleView		view;

	public RuleRemoveButtonListener(RuleView view)
	{
		this.view = view;
	}

	@Override
	public void buttonClick(ClickEvent event)
	{
		view.removeRule();
	}
}
