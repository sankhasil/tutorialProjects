
package com.bosch.si.amra.view.formatter;

import com.bosch.si.amra.entity.Wagon;
import com.vaadin.data.Property;
import com.vaadin.server.FontAwesome;

public class AliasFormatter extends PropertyFormatter
{
	@Override
	public String format(Object rowId, Property<?> property, String result)
	{
		if (rowId instanceof Wagon)
		{
			Wagon wagon = (Wagon) rowId;
			if (wagon.getBoxId() != null)
			{
				result = new String(Character.toChars(FontAwesome.CHAIN.getCodepoint())) + " "
						+ result;
			}
		}
		return result;
	}
}
