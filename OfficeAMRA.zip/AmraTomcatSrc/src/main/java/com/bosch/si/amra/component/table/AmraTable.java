
package com.bosch.si.amra.component.table;

import com.bosch.si.amra.view.formatter.PropertyFormatter;
import com.vaadin.data.Property;
import com.vaadin.ui.Table;
import com.vaadin.ui.themes.ValoTheme;

public class AmraTable extends Table
{
	/**
	 * Serial version uid
	 */
	private static final long serialVersionUID = 5563074828565373656L;

	public AmraTable()
	{
		setSizeFull();
		addStyleName(ValoTheme.TABLE_BORDERLESS);
		addStyleName(ValoTheme.TABLE_NO_HORIZONTAL_LINES);
		addStyleName(ValoTheme.TABLE_COMPACT);
		setSelectable(true);
		setColumnCollapsingAllowed(true);
		setColumnReorderingAllowed(true);
		setSortAscending(false);
		setMultiSelect(true);
		setCacheRate(5);
		setImmediate(true);
	}

	@Override
	public String formatPropertyValue(Object rowId, Object colId, Property<?> property)
	{
		String result = super.formatPropertyValue(rowId, colId, property);
		PropertyFormatter formatter = PropertyFormatter.getFormatter(colId);
		return formatter.format(rowId, property, result);
	}
}
