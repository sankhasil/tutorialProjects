
package com.bosch.si.amra.view.notification.listener;

import com.bosch.si.amra.view.notification.NotificationView;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;

public class NotificationShowInTableButtonListener implements ClickListener
{
	/**
	 * Serial version uid
	 */
	private static final long		serialVersionUID	= 7072120974625202728L;

	private final NotificationView	view;

	public NotificationShowInTableButtonListener(NotificationView view)
	{
		this.view = view;
	}

	@Override
	public void buttonClick(ClickEvent event)
	{
		view.showNotificationsInTable();
	}
}
