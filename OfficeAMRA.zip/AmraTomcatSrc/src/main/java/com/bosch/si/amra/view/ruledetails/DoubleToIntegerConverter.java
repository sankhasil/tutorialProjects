
package com.bosch.si.amra.view.ruledetails;

import java.util.Locale;

import com.vaadin.data.util.converter.Converter;

public class DoubleToIntegerConverter implements Converter<Double, Integer>
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= 3426574393824931383L;

	@Override
	public Integer convertToModel(Double value, Class<? extends Integer> targetType, Locale locale)
			throws com.vaadin.data.util.converter.Converter.ConversionException
	{
		if (value != null)
		{
			return value.intValue();
		}
		return null;
	}

	@Override
	public Double convertToPresentation(Integer value, Class<? extends Double> targetType,
			Locale locale) throws com.vaadin.data.util.converter.Converter.ConversionException
	{
		if (value != null)
		{
			return value.doubleValue();
		}
		return null;
	}

	@Override
	public Class<Integer> getModelType()
	{
		return Integer.class;
	}

	@Override
	public Class<Double> getPresentationType()
	{
		return Double.class;
	}

}
