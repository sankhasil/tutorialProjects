
package com.bosch.si.amra.provider.details;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.constants.UIConstants;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.provider.DataProviderInitializer;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

/**
 * Provides methods for retrieving telematic data for a wagon
 *
 * @author toa1wa3
 */
@Component
public class DetailsDataProvider
{
	private static final int UNIX_TIME_FIRST_JANUARY_2016 = 1451606400;

	public List<Wagon> getTelematicDataForWagon(String wagonId)
	{
		if (wagonId == null || wagonId.isEmpty())
			throw new IllegalArgumentException(UIConstants.ID_MUST_NOT_BE_NULL);

		DBObject match = getMatchCriteria(wagonId);
		return executeQuery(match);
	}

	private List<Wagon> executeQuery(DBObject match)
	{
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DBCollection telematicUnwindCollection = mongoClient.getDB(DashboardUI.getMongoDatabase())
				.getCollection(DashboardUI.getTelematicUnwind());

		DBCursor telematicUnwindCursor = telematicUnwindCollection.find(match,
				new BasicDBObject(MongoConstants.DATA_ELEMENT + "." + MongoConstants.GPS_FIX, 1)
						.append(MongoConstants.DATA_ELEMENT + "." + MongoConstants.UNIX_TIME, 1)
						.append(MongoConstants.DATA_ELEMENT + "." + MongoConstants.COLLECT_CAUSE, 1)
						.append(MongoConstants.DATA_DATE, 1).append(MongoConstants.DATA_TIME, 1)
						.append(MongoConstants.ADDRESS, 1)
						.append(MongoConstants.DATA_ELEMENT + "." + MongoConstants.LATITUDE, 1)
						.append(MongoConstants.DATA_ELEMENT + "." + MongoConstants.LONGITUDE, 1))
				.sort(new BasicDBObject(
						MongoConstants.DATA_ELEMENT + "." + MongoConstants.UNIX_TIME, -1));
		List<Wagon> telematicDataForWagons = new ArrayList<>();
		telematicUnwindCursor.forEach(telematicObject -> {
			Wagon telematicDataForWagon = DataProviderInitializer
					.createWagonWithTelematicData(telematicObject);
			telematicDataForWagons.add(telematicDataForWagon);
		});
		return telematicDataForWagons;
	}

	private DBObject getMatchCriteria(String wagonId)
	{
		DBObject match = new BasicDBObject(MongoConstants.WAGON_ID, wagonId);
		BasicDBList or = new BasicDBList();
		or.add(gpsFixMatch());
		or.add(tripAndUnixTimeMatch(MongoConstants.TRIP_STARTED));
		or.add(tripAndUnixTimeMatch(MongoConstants.TRIP_ENDED));
		match.put("$or", or);
		return match;
	}

	private DBObject gpsFixMatch()
	{
		return new BasicDBObject(MongoConstants.DATA_ELEMENT + "." + MongoConstants.GPS_FIX, 3);
	}

	private DBObject tripAndUnixTimeMatch(String tripKey)
	{
		BasicDBList and = new BasicDBList();
		and.add(new BasicDBObject(MongoConstants.DATA_ELEMENT + "." + tripKey, 1));
		and.add(new BasicDBObject(MongoConstants.DATA_ELEMENT + "." + MongoConstants.UNIX_TIME,
				new BasicDBObject("$gte", UNIX_TIME_FIRST_JANUARY_2016)));
		return new BasicDBObject("$and", and);
	}
}