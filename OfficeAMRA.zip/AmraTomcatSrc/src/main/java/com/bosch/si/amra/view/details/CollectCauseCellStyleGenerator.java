
package com.bosch.si.amra.view.details;

import com.bosch.si.amra.constants.overview.OverviewConstants;
import com.bosch.si.amra.entity.Wagon;
import com.vaadin.ui.Grid.CellReference;
import com.vaadin.ui.Grid.CellStyleGenerator;

/**
 * Generator for styling the cell according to the collect cause
 *
 * @author toa1wa3
 *
 */
public class CollectCauseCellStyleGenerator implements CellStyleGenerator
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= -1864699301395248044L;

	private static final int	TRIP_ENDED_BIT		= 2;

	private static final int	TRIP_STARTED_BIT	= 4;

	@Override
	public String getStyle(CellReference cell)
	{
		if (OverviewConstants.COLLECT_CAUSE.equals(cell.getPropertyId()))
		{
			Wagon wagon = (Wagon) cell.getItemId();
			Integer collectCause = wagon.getCollectCause();
			if (collectCause != null)
			{
				if (((collectCause.intValue() >>> TRIP_ENDED_BIT) & 1) == 1)
					return "halt";
				else if (((collectCause.intValue() >>> TRIP_STARTED_BIT) & 1) == 1)
					return "move";
			}
		}
		return null;
	}

}
