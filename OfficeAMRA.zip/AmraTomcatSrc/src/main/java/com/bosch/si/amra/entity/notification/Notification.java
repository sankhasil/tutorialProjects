
package com.bosch.si.amra.entity.notification;

import java.io.Serializable;
import java.util.Date;

import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.constants.notification.NotificationConstants;
import com.bosch.si.amra.entity.LatLong;
import com.bosch.si.amra.entity.rule.Rule;
import com.bosch.si.amra.provider.DataProviderInitializer;
import com.mongodb.DBObject;

/**
 * Represents a notification object
 *
 * @author toa1wa3
 *
 */
public class Notification implements Serializable
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= 4672467587125643795L;

	private String				id;

	private String				alias;

	private String				reason;

	private Double				shockValue;

	private Double				latitude;

	private Double				longitude;

	private Address				address;

	private Priority			priority;

	private Date				timestamp;

	private boolean				acknowledged;

	private String				wagonId;

	private boolean				gpsFixed;

	private Rule				rule;

	public enum Priority
	{
		GREEN, YELLOW, RED;
	}

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public String getAlias()
	{
		return alias;
	}

	public void setAlias(String alias)
	{
		this.alias = alias;
	}

	public String getReason()
	{
		return reason;
	}

	public void setReason(String reason)
	{
		this.reason = reason;
	}

	public Double getShockValue()
	{
		return shockValue;
	}

	public void setShockValue(Double shockValue)
	{
		this.shockValue = shockValue;
	}

	public Rule getRule()
	{
		return rule;
	}

	public void setRule(Rule rule)
	{
		this.rule = rule;
	}

	public Address getAddress()
	{
		return address;
	}

	public void setAddress(Address address)
	{
		this.address = address;
	}

	public Priority getPriority()
	{
		return priority;
	}

	public void setPriority(Priority priority)
	{
		this.priority = priority;
	}

	public Date getTimestamp()
	{
		return timestamp;
	}

	public void setTimestamp(Date timestamp)
	{
		this.timestamp = timestamp;
	}

	public boolean isAcknowledged()
	{
		return acknowledged;
	}

	public void setAcknowledged(boolean acknowledged)
	{
		this.acknowledged = acknowledged;
	}

	public String getWagonId()
	{
		return wagonId;
	}

	public void setWagonId(String wagonId)
	{
		this.wagonId = wagonId;
	}

	public Double getLatitude()
	{
		return latitude;
	}

	public void setLatitude(Double latitude)
	{
		this.latitude = latitude;
	}

	public Double getLongitude()
	{
		return longitude;
	}

	public void setLongitude(Double longitude)
	{
		this.longitude = longitude;
	}

	public boolean isGpsFixed()
	{
		return gpsFixed;
	}

	public void setGpsFixed(boolean gpsFixed)
	{
		this.gpsFixed = gpsFixed;
	}

	public static Notification dbObject2Notification(DBObject notificationObject)
	{
		Notification notification = null;
		if (notificationObject != null)
		{
			notification = new Notification();
			notification.setGpsFixed(checkIfGpsFixed(
					(DBObject) notificationObject.get(MongoConstants.DATA_ELEMENT)));
			notification.setId((String) notificationObject.get(MongoConstants.ID));
			notification.setWagonId((String) notificationObject.get(MongoConstants.WAGON_ID));

			notification.setReason(getReason(notificationObject));
			notification.setShockValue(getShockValue(notificationObject));
			notification.setRule(getNotificationRule(notificationObject));
			notification.setAlias((String) notificationObject.get(NotificationConstants.ALIAS));

			if (notification.isGpsFixed())
			{
				LatLong position = getCurrentPosition(notificationObject);
				notification.setLatitude(position.getLat());
				notification.setLongitude(position.getLng());

				notification.setAddress(DataProviderInitializer.getAddress(notificationObject));
			}
			notification.setPriority(getPriority(notificationObject));
			notification.setTimestamp(getTimestamp(notificationObject));
			notification.setAcknowledged(
					(boolean) notificationObject.get(NotificationConstants.ACKNOWLEDGED));
		}
		return notification;
	}

	private static String getReason(DBObject notificationObject)
	{
		DBObject reasonObject = (DBObject) notificationObject.get(NotificationConstants.REASON);
		return (String) reasonObject.get(NotificationConstants.REASON_NAME);
	}

	private static Double getShockValue(DBObject notificationObject)
	{
		DBObject data = (DBObject) notificationObject.get(MongoConstants.DATA_ELEMENT);
		return (Double) data.get(MongoConstants.SHOCK_VALUE);
	}

	private static Rule getNotificationRule(DBObject notificationObject)
	{
		DBObject ruleObject = (DBObject) notificationObject.get(NotificationConstants.RULE);
		Rule rule = new Rule();

		if (ruleObject != null)
		{
			rule = new Rule();
			rule.setId((String) ruleObject.get(NotificationConstants.ID));
			rule.setName((String) ruleObject.get(NotificationConstants.REASON_NAME));
			rule.setRuleType((String) ruleObject.get(NotificationConstants.RULETYPE));
		}

		return rule;
	}

	private static LatLong getCurrentPosition(DBObject dbObject)
	{
		DBObject data = (DBObject) dbObject.get(MongoConstants.DATA_ELEMENT);
		Double latitude = (Double) data.get(MongoConstants.LATITUDE);
		Double longitude = (Double) data.get(MongoConstants.LONGITUDE);
		return new LatLong(latitude, longitude);
	}

	private static Priority getPriority(DBObject dbObject)
	{
		String priority = (String) dbObject.get(NotificationConstants.PRIORITY);
		return Priority.valueOf(priority);
	}

	private static Date getTimestamp(DBObject telematicData)
	{
		DBObject data = (DBObject) telematicData.get(MongoConstants.DATA_ELEMENT);
		return new Date(((Integer) data.get(MongoConstants.UNIX_TIME)).longValue() * 1000L);
	}

	private static boolean checkIfGpsFixed(DBObject dataElement)
	{
		return dataElement.get(MongoConstants.GPS_FIX) != null
				&& ((Integer) dataElement.get(MongoConstants.GPS_FIX))
						.compareTo(MongoConstants.GPS_FIX_LEVEL_TOP) == 0 ? true : false;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + (acknowledged ? 1231 : 1237);
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + ((alias == null) ? 0 : alias.hashCode());
		result = prime * result + (gpsFixed ? 1231 : 1237);
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((latitude == null) ? 0 : latitude.hashCode());
		result = prime * result + ((longitude == null) ? 0 : longitude.hashCode());
		result = prime * result + ((priority == null) ? 0 : priority.hashCode());
		result = prime * result + ((reason == null) ? 0 : reason.hashCode());
		result = prime * result + ((rule == null) ? 0 : rule.hashCode());
		result = prime * result + ((shockValue == null) ? 0 : shockValue.hashCode());
		result = prime * result + ((timestamp == null) ? 0 : timestamp.hashCode());
		result = prime * result + ((wagonId == null) ? 0 : wagonId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Notification other = (Notification) obj;
		if (acknowledged != other.acknowledged)
			return false;
		if (address == null)
		{
			if (other.address != null)
				return false;
		}
		else if (!address.equals(other.address))
			return false;
		if (alias == null)
		{
			if (other.alias != null)
				return false;
		}
		else if (!alias.equals(other.alias))
			return false;
		if (gpsFixed != other.gpsFixed)
			return false;
		if (id == null)
		{
			if (other.id != null)
				return false;
		}
		else if (!id.equals(other.id))
			return false;
		if (latitude == null)
		{
			if (other.latitude != null)
				return false;
		}
		else if (!latitude.equals(other.latitude))
			return false;
		if (longitude == null)
		{
			if (other.longitude != null)
				return false;
		}
		else if (!longitude.equals(other.longitude))
			return false;
		if (priority != other.priority)
			return false;
		if (reason == null)
		{
			if (other.reason != null)
				return false;
		}
		else if (!reason.equals(other.reason))
			return false;
		if (rule == null)
		{
			if (other.rule != null)
				return false;
		}
		else if (!rule.equals(other.rule))
			return false;
		if (shockValue == null)
		{
			if (other.shockValue != null)
				return false;
		}
		else if (!shockValue.equals(other.shockValue))
			return false;
		if (timestamp == null)
		{
			if (other.timestamp != null)
				return false;
		}
		else if (!timestamp.equals(other.timestamp))
			return false;
		if (wagonId == null)
		{
			if (other.wagonId != null)
				return false;
		}
		else if (!wagonId.equals(other.wagonId))
			return false;
		return true;
	}
}
