
package com.bosch.si.amra.constants.monitoring;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.bosch.si.amra.constants.MongoConstants;

public class AlarmConstants
{

	public static final String				ALIAS				= "alias";

	public static final String				ALIAS_TO_LOWERCASE	= "aliasLowerCase";

	public static final String				ALARM_NAME			= "name";

	public static final String				ALARM_ACTIVE		= "active";

	public static final String				ALARM_RULE_TYPE		= "ruleType";

	public static final String				ALARM_LIMIT			= "limit";

	public static final String				ALARM_UNIT			= "unit";

	public static final String				ALARM_CONDITION		= "condition";

	public static final String				ALARM_SEVERITY		= "severity";

	public static final String				TITLE_CAPTION		= "view.configuration.caption";

	public static final String				SAVE_CAPTION		= "view.configuration.button.save.caption";

	public static final String				SAVE_TOOLTIP		= "view.configuration.button.save.tooltip";

	public static final String				RESET_CAPTION		= "view.configuration.button.reset.caption";

	public static final String				RESET_TOOLTIP		= "view.configuration.button.reset.tooltip";

	public static final String				EDIT_CAPTION		= "view.configuration.checkbox.editable";

	public static final String				EDIT_TOOLTIP		= "view.configuration.checkbox.tooltip.editable";

	public static final String				FILTER_INPUT		= "view.configuration.input.filter";

	public static final String				COLUMN_HEADER		= "view.configuration.columnheader.";

	public static final Map<String, String>	MAPPING;

	static
	{
		Map<String, String> map = new HashMap<String, String>();
		map.put(ALIAS, MongoConstants.ALIAS_TO_LOWERCASE);
		map.put(ALARM_NAME, MongoConstants.SORT);
		map.put(ALARM_ACTIVE, MongoConstants.ALARM_ACTIVE);
		map.put(ALARM_RULE_TYPE, MongoConstants.ALARM_RULE_TYPE);
		map.put(ALARM_LIMIT, MongoConstants.ALARM_LIMIT);
		map.put(ALARM_UNIT, MongoConstants.ALARM_UNIT);
		map.put(ALARM_CONDITION, MongoConstants.ALARM_CONDITION);
		map.put(ALARM_SEVERITY, MongoConstants.ALARM_SEVERITY);
		MAPPING = Collections.unmodifiableMap(map);
	}

	public static final Map<Boolean, Integer> ASCENDING;

	static
	{
		Map<Boolean, Integer> map = new HashMap<Boolean, Integer>();
		map.put(true, 1);
		map.put(false, -1);
		ASCENDING = Collections.unmodifiableMap(map);
	}

}
