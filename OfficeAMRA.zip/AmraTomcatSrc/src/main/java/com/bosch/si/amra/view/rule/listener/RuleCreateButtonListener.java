
package com.bosch.si.amra.view.rule.listener;

import com.bosch.si.amra.view.rule.RuleView;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;

public class RuleCreateButtonListener implements ClickListener
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= -3588695258271082661L;

	private final RuleView		view;

	public RuleCreateButtonListener(RuleView view)
	{
		this.view = view;
	}

	@Override
	public void buttonClick(ClickEvent event)
	{
		view.showRuleDetails(null, false);
	}
}
