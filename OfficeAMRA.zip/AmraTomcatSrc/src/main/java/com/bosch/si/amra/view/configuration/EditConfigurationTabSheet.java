
package com.bosch.si.amra.view.configuration;

import java.util.List;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.component.grid.ConfigurationGrid;
import com.bosch.si.amra.entity.configuration.Configuration;
import com.vaadin.shared.ui.MarginInfo;
import com.vaadin.ui.TabSheet;
import com.vaadin.ui.VerticalLayout;

public class EditConfigurationTabSheet extends TabSheet
{
	private static final long serialVersionUID = -7336005145085313799L;

	EditConfigurationTabSheet(ConfigurationEditWindow configEditWindow,
			ConfigurationGrid configGrid, List<Configuration> configurations)
	{
		setId("editConfigTabSheet");
		VerticalLayout verticalLayout = new VerticalLayout();
		ConfigurationEditLayout editForm = new ConfigurationEditLayout(configEditWindow, configGrid,
				configurations);
		verticalLayout.setMargin(new MarginInfo(true, true, true, true));
		verticalLayout.addComponent(editForm);
		addTab(verticalLayout, DashboardUI.getMessageSource()
				.getMessage("view.configuration.subwindow.tab.general"));
		setWidth(500, Unit.PIXELS);
		setHeight(800, Unit.PIXELS);
	}

}
