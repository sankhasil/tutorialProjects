
package com.bosch.si.amra.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.constants.UIConstants;
import com.bosch.si.amra.entity.SensorData.BatterySeverity;
import com.bosch.si.amra.entity.notification.Address;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

public class Wagon implements Serializable
{
	private static final long	serialVersionUID	= 1L;

	private String				id;

	private Long				boxId;

	private String				alias;

	private WagonType			wagonType;

	private Date				createdTs			= new Date();

	private String				tenantId;

	private Integer				mileage;

	private Integer				batteryLevel;

	private BatterySeverity		batterySeverity;

	private LatLong				latLong;

	// time that meaning depends on the context for e.g it can be the last time when there was GPS
	// Fix 3 message
	private Date				timestamp;

	// the last contact time with the device
	private Date				timestampContact;

	private Integer				humidity;

	private Integer				temperature;

	private Integer				humidityTemperature;

	private Integer				t1Temperature;

	private Address				address;

	private List<Tag>			tags;

	private Integer				collectCause;

	private Integer				mileageOffset;

	private Integer				oldMileageOffset;

	private Integer				mileageDeviation;

	private Boolean				initial;

	public Wagon()
	{
	}

	public Wagon(String id, String alias, Integer mileageDeviation)
	{
		this.id = id;
		this.alias = alias;
		this.mileageDeviation = mileageDeviation;
	}

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public Long getBoxId()
	{
		return boxId;
	}

	public void setBoxId(Long boxId)
	{
		this.boxId = boxId;
	}

	public String getAlias()
	{
		return alias;
	}

	public void setAlias(String alias)
	{
		this.alias = alias;
	}

	public Integer getMileage()
	{
		return mileage;
	}

	public void setMileage(Integer mileage)
	{
		this.mileage = mileage;
	}

	public Integer getOldMileageOffset()
	{
		return oldMileageOffset;
	}

	public void setOldMileageOffset(Integer oldMileageOffset)
	{
		this.oldMileageOffset = oldMileageOffset;
	}

	public WagonType getWagonType()
	{
		return wagonType;
	}

	public void setWagonType(WagonType wagonType)
	{
		this.wagonType = wagonType;
	}

	public Date getCreatedTs()
	{
		if (createdTs == null)
		{
			return null;
		}
		return new Date(createdTs.getTime());
	}

	public Integer getBatteryLevel()
	{
		return batteryLevel;
	}

	public void setBatteryLevel(Integer batteryLevel)
	{
		this.batteryLevel = batteryLevel;
	}

	public void setCreatedTs(Date createdTs)
	{
		this.createdTs = createdTs;
	}

	public BatterySeverity getBatterySeverity()
	{
		return batterySeverity;
	}

	public void setBatterySeverity(BatterySeverity batterySeverity)
	{
		this.batterySeverity = batterySeverity;
	}

	public LatLong getLatLong()
	{
		return latLong;
	}

	public void setLatLong(LatLong latLong)
	{
		this.latLong = latLong;
	}

	public String getTenantId()
	{
		return tenantId;
	}

	public void setTenantId(String tenantId)
	{
		this.tenantId = tenantId;
	}

	public Integer getHumidity()
	{
		return humidity;
	}

	public void setHumidity(Integer humidity)
	{
		if (humidity != null && UIConstants.LOWERLIMIT_HUMIDITY <= humidity.intValue()
				&& humidity.intValue() <= UIConstants.UPPERLIMIT_HUMIDITY)
		{
			this.humidity = humidity;
		}
		else
		{
			this.humidity = null;
		}
	}

	public Integer getTemperature()
	{
		return temperature;
	}

	public void setTemperature(Integer temperature)
	{
		this.temperature = temperature;
	}

	public void setHumidityTemperature(Integer humidityTemperature)
	{
		if (humidityTemperature != null
				&& UIConstants.LOWERLIMIT_HUMIDITYTEMPERATURE <= humidityTemperature.intValue()
				&& humidityTemperature.intValue() <= UIConstants.UPPERLIMIT_HUMIDITYTEMPERATURE)
		{
			this.humidityTemperature = humidityTemperature;
		}
		else
		{
			this.humidityTemperature = null;
		}
	}

	public Integer getT1Temperature()
	{
		return t1Temperature;
	}

	public void setT1Temperature(Integer t1Temperature)
	{
		if (t1Temperature != null
				&& UIConstants.LOWERLIMIT_T1TEMPERATURE <= t1Temperature.intValue()
				&& t1Temperature.intValue() <= UIConstants.UPPERLIMIT_T1TEMPERATURE)
		{
			this.t1Temperature = t1Temperature;
		}
		else
		{
			this.t1Temperature = null;
		}
	}

	public Integer getHumidityTemperature()
	{
		return humidityTemperature;
	}

	public Date getTimestamp()
	{
		return timestamp;
	}

	public void setTimestamp(Date timestamp)
	{
		this.timestamp = timestamp;
	}

	public Date getTimestampContact()
	{
		return timestampContact;
	}

	public void setTimestampContact(Date timestampContact)
	{
		this.timestampContact = timestampContact;
	}

	public Address getAddress()
	{
		return address;
	}

	public void setAddress(Address address)
	{
		this.address = address;
	}

	public List<Tag> getTags()
	{
		return tags;
	}

	public void setTags(List<Tag> tags)
	{
		if (this.tags == null)
			this.tags = tags;
		else if (tags != null)
			this.tags.addAll(tags);
	}

	public Integer getCollectCause()
	{
		return collectCause;
	}

	public void setCollectCause(Integer collectCause)
	{
		this.collectCause = collectCause;
	}

	public Integer getMileageOffset()
	{
		return mileageOffset;
	}

	public void setMileageOffset(Integer mileageOffset)
	{
		this.mileageOffset = mileageOffset;
	}

	public Integer getMileageDeviation()
	{
		return mileageDeviation;
	}

	public void setMileageDeviation(Integer mileageDeviation)
	{
		this.mileageDeviation = mileageDeviation;
	}

	public Boolean getInitial()
	{
		return initial;
	}

	public void setInitial(Boolean initial)
	{
		this.initial = initial;
	}

	public static DBObject wagon2DBObject(Wagon wagon)
	{
		DBObject wagonObject = null;
		if (wagon != null)
		{
			wagonObject = new BasicDBObject();
			String id = wagon.getId();
			if (id == null)
			{
				id = UUID.randomUUID().toString();
			}
			wagonObject.put(MongoConstants.ID, id);
			if (wagon.getBoxId() != null)
			{
				wagonObject.put(MongoConstants.BOX_ID, wagon.getBoxId());
			}
			wagonObject.put(MongoConstants.ALIAS, wagon.getAlias());
			wagonObject.put(MongoConstants.SORT, wagon.getAlias().toLowerCase());
			wagonObject.put(MongoConstants.TIMESTAMP, wagon.getCreatedTs());
			wagonObject.put(MongoConstants.TENANT_ID, wagon.getTenantId());
			if (wagon.getWagonType() != null)
			{
				wagonObject.put(MongoConstants.WAGON_TYPE,
						buildWagonTypeObject(wagon.getWagonType()));
			}
			if (wagon.getTags() != null && wagon.getTags().size() > 0)
			{
				wagonObject.put(MongoConstants.WAGON_TAG, buildTagListObject(wagon.getTags()));
			}
			if (wagon.getMileageOffset() != null)
				wagonObject.put(MongoConstants.OFFSET, wagon.getMileageOffset());
		}
		return wagonObject;
	}

	public static Wagon dbObject2Wagon(DBObject dbObject)
	{
		Wagon wagon = null;
		if (dbObject != null)
		{
			wagon = new Wagon();
			wagon.setId((String) dbObject.get(MongoConstants.ID));
			wagon.setBoxId((Long) dbObject.get(MongoConstants.BOX_ID));
			wagon.setAlias((String) dbObject.get(MongoConstants.ALIAS));
			wagon.setCreatedTs((Date) dbObject.get(MongoConstants.TIMESTAMP));
			wagon.setTenantId((String) dbObject.get(MongoConstants.TENANT_ID));
			if (dbObject.get(MongoConstants.WAGON_TYPE) != null)
			{
				WagonType wagonType = buildWagonType(
						(DBObject) dbObject.get(MongoConstants.WAGON_TYPE));
				wagonType.setTenantId((String) dbObject.get(MongoConstants.TENANT_ID));
				wagon.setWagonType(wagonType);
			}
			if (dbObject.get(MongoConstants.WAGON_TAG) != null)
			{
				BasicDBList assignedWagonTags = (BasicDBList) dbObject
						.get(MongoConstants.WAGON_TAG);
				ArrayList<Tag> tagListForWagon = new ArrayList<Tag>();
				assignedWagonTags.forEach(eachTag -> {
					Tag tag = Tag.dbObjectShort2Tag((DBObject) eachTag);
					tagListForWagon.add(tag);
				});
				wagon.setTags(tagListForWagon);
			}
			if (dbObject.get(MongoConstants.OFFSET) != null)
				wagon.setMileageOffset((Integer) dbObject.get(MongoConstants.OFFSET));
		}
		return wagon;
	}

	private static DBObject buildWagonTypeObject(WagonType wagonType)
	{
		DBObject wagonTypeObject = new BasicDBObject(MongoConstants.ID, wagonType.getId());
		wagonTypeObject.put(MongoConstants.WAGON_TYPE_NAME, wagonType.getTypeName());
		wagonTypeObject.put(MongoConstants.SORT, wagonType.getTypeName().toLowerCase());
		return wagonTypeObject;
	}

	private static DBObject buildTagListObject(List<Tag> tags)
	{
		BasicDBList tagObjectList = new BasicDBList();
		tags.forEach(eachTag -> {
			DBObject tagObject = new BasicDBObject(MongoConstants.ID, eachTag.getId());
			tagObject.put(MongoConstants.TAG_NAME, eachTag.getTagName());
			tagObject.put(MongoConstants.SORT, eachTag.getTagName().toLowerCase());
			tagObjectList.add(tagObject);
		});

		return tagObjectList;
	}

	private static WagonType buildWagonType(DBObject wagonTypeOBject)
	{
		WagonType wagonType = new WagonType();
		wagonType.setId((String) wagonTypeOBject.get(MongoConstants.ID));
		wagonType.setTypeName((String) wagonTypeOBject.get(MongoConstants.WAGON_TYPE_NAME));
		return wagonType;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((alias == null) ? 0 : alias.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Wagon other = (Wagon) obj;
		if (alias == null)
		{
			if (other.alias != null)
				return false;
		}
		else if (!alias.equals(other.alias))
			return false;
		if (id == null)
		{
			if (other.id != null)
				return false;
		}
		else if (!id.equals(other.id))
			return false;
		return true;
	}
}
