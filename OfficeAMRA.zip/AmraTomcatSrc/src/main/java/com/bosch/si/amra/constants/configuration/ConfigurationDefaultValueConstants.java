
package com.bosch.si.amra.constants.configuration;

public class ConfigurationDefaultValueConstants
{
	/**
	 * Default value for F
	 */
	public static final Integer	FLASH_DATA_DEFAULT_VALUE			= 0;

	/**
	 * Default value for S
	 */
	public static final String	STATUS_DEFAULT_VALUE				= "0";

	/**
	 * Default value for HM
	 */
	public static final boolean	HUMIDITY_DEFAULT_VALUE				= false;

	/**
	 * Default value for HT
	 */
	public static final boolean	HUMIDITY_TEMPERATURE_DEFAULT_VALUE	= false;

	/**
	 * Default value for T1
	 */
	public static final boolean	TEMPERATURE_DEFAULT_VALUE			= false;

	/**
	 * Default value for DT
	 */
	public static final boolean	DEVICE_TEMPERATURE_DEFAULT_VALUE	= true;

	/**
	 * Default value for SX
	 */
	public static final Double	SHOCK_X_DEFAULT_VALUE				= 1.5;

	/**
	 * Default value for SY
	 */
	public static final Double	SHOCK_Y_DEFAULT_VALUE				= 1.5;

	/**
	 * Default value for SZ
	 */
	public static final Double	SHOCK_Z_DEFAULT_VALUE				= 1.5;

	/**
	 * Default value for CM
	 */
	public static final Integer	GPS_MOVING_DEFAULT_VALUE			= 3600;

	/**
	 * Default value for CS
	 */
	public static final Integer	GPS_TIME_BASED_DEFAULT_VALUE		= 86400;

	/**
	 * Default value for PM
	 */
	public static final Integer	GSM_MOVING_DEFAULT_VALUE			= 28800;

	/**
	 * Default value for PS
	 */
	public static final Integer	GSM_TIME_BASED_DEFAULT_VALUE		= 86400;

	/**
	 * Default value for RT
	 */
	public static final boolean	ROUTING_DEFAULT_VALUE				= true;

	/**
	 * Default value for BD
	 */
	public static final Integer	BUMP_DETECTION_DEFAULT_VALUE		= 14;

	/**
	 * Default value for AF
	 */
	public static final Integer	AQUITION_FREQUENCY_DEFAULT_VALUE	= 8;

}
