
package com.bosch.si.amra.view.geofence;

import java.util.List;

import com.vaadin.tapio.googlemaps.GoogleMap;
import com.vaadin.tapio.googlemaps.client.LatLon;
import com.vaadin.tapio.googlemaps.client.events.MapClickListener;
import com.vaadin.tapio.googlemaps.client.events.MarkerClickListener;
import com.vaadin.tapio.googlemaps.client.events.MarkerDragListener;
import com.vaadin.tapio.googlemaps.client.overlays.GoogleMapMarker;

/**
 * Map listener for clicking and dragging a marker and clicking on the map
 *
 * @author toa1wa3
 *
 */
public class GeofenceMapListener
		implements MapClickListener, MarkerClickListener, MarkerDragListener
{
	/**
	 * Serial version uid
	 */
	private static final long			serialVersionUID	= 4390701680337003786L;

	private final List<LatLon>			positions;

	private final List<GoogleMapMarker>	geofenceMarkers;

	private final GoogleMap				googleMap;

	public GeofenceMapListener(GoogleMap googleMap, List<LatLon> positions,
			List<GoogleMapMarker> geofenceMarkers)
	{
		this.googleMap = googleMap;
		this.positions = positions;
		this.geofenceMarkers = geofenceMarkers;
	}

	@Override
	public void markerDragged(GoogleMapMarker draggedMarker, LatLon oldPosition)
	{
		if (draggedMarker != null && oldPosition != null)
		{
			int index = positions.indexOf(oldPosition);
			positions.remove(oldPosition);
			positions.add(index, draggedMarker.getPosition());
		}
	}

	@Override
	public void markerClicked(GoogleMapMarker clickedMarker)
	{
		if (clickedMarker != null)
		{
			googleMap.removeMarker(clickedMarker);
			geofenceMarkers.remove(clickedMarker);
			positions.remove(clickedMarker.getPosition());
		}
	}

	@Override
	public void mapClicked(LatLon position)
	{
		if (position != null)
		{
			GoogleMapMarker googleMapMarker = new GoogleMapMarker("", position, true,
					"VAADIN/themes/dashboard/img/thumb-tack.png");
			googleMap.addMarker(googleMapMarker);
			geofenceMarkers.add(googleMapMarker);
			positions.add(position);
		}
	}

	public List<LatLon> getGeofenceCoordinates()
	{
		return positions;
	}

	public List<GoogleMapMarker> getGeofenceMarkers()
	{
		return geofenceMarkers;
	}
}
