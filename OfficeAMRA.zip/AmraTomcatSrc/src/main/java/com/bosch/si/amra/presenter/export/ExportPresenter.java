
package com.bosch.si.amra.presenter.export;

import com.bosch.si.amra.event.DashboardEvent.ExportGenerationEvent;
import com.google.common.eventbus.Subscribe;
import com.mongodb.AggregationOutput;
import com.mongodb.DBCursor;

public interface ExportPresenter
{
	/**
	 * @param event
	 *            {@link ExportGenerationEvent}
	 * @return DBCursor of the retrieved details for the CSV generation
	 */
	@Subscribe
	public DBCursor generateCSVExport(ExportGenerationEvent event);

	/**
	 * Aggregates the mileage for export
	 *
	 * @param sameDate
	 *            the Date used for the match in the aggregation
	 * @param wagonId
	 *            the wagonId used for the match in the aggregation
	 * @return the aggregation result
	 */
	public AggregationOutput aggregateMileage(String sameDate, String wagonId);
}
