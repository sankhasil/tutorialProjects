
package com.bosch.si.amra.common;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.vaadin.addons.locationtextfield.GeocodedLocation;
import org.vaadin.addons.locationtextfield.GeocodingException;
import org.vaadin.addons.locationtextfield.LocationType;

/**
 * Will be deleted when we use open cage data
 *
 * @author toa1wa3
 *
 */
public class AMRAGoogleGeocoder extends AMRAURLConnectionGeocoder<GeocodedLocation>
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= -8441029042716192721L;

	private static final String	URL					= "maps.googleapis.com/maps/api/geocode/json";

	private static final String	INSECURE_URL		= "http://" + URL;

	private static final String	SECURE_URL			= "https://" + URL;

	private String				language;

	private boolean				useSecureConnection;

	public AMRAGoogleGeocoder(String host, int port, boolean isProxyUsed, String language)
	{
		this.host = host;
		this.port = port;
		this.isProxyUsed = isProxyUsed;
		this.language = language;
	}

	protected String getURL(String address) throws UnsupportedEncodingException
	{
		return (this.useSecureConnection ? SECURE_URL : INSECURE_URL) + "?address="
				+ URLEncoder.encode(address, "UTF-8") + "&sensor=false&language=" + language;
	}

	protected Collection<GeocodedLocation> createLocations(String address, String input)
			throws GeocodingException
	{
		final Set<GeocodedLocation> locations = new LinkedHashSet<GeocodedLocation>();
		try
		{
			JSONObject obj = new JSONObject(input);
			if ("OK".equals(obj.getString("status")))
			{
				JSONArray results = obj.getJSONArray("results");
				boolean ambiguous = results.length() > 1;
				int limit = results.length();
				if (this.getLimit() > 0)
					limit = Math.min(this.getLimit(), limit);
				for (int i = 0; i < limit; i++)
				{
					JSONObject result = results.getJSONObject(i);
					GeocodedLocation loc = new GeocodedLocation();
					loc.setAmbiguous(ambiguous);
					loc.setOriginalAddress(address);
					loc.setGeocodedAddress(result.getString("formatted_address"));
					JSONArray components = result.getJSONArray("address_components");
					for (int j = 0; j < components.length(); j++)
					{
						JSONObject component = components.getJSONObject(j);
						String value = component.getString("short_name");
						JSONArray types = component.getJSONArray("types");
						for (int k = 0; k < types.length(); k++)
						{
							String type = types.getString(k);
							if ("street_number".equals(type))
								loc.setStreetNumber(value);
							else if ("route".equals(type))
								loc.setRoute(value);
							else if ("locality".equals(type))
								loc.setLocality(value);
							else if ("administrative_area_level_1".equals(type))
								loc.setAdministrativeAreaLevel1(value);
							else if ("administrative_area_level_2".equals(type))
								loc.setAdministrativeAreaLevel2(value);
							else if ("country".equals(type))
								loc.setCountry(value);
							else if ("postal_code".equals(type))
								loc.setPostalCode(value);
						}
					}
					JSONObject location = result.getJSONObject("geometry")
							.getJSONObject("location");
					loc.setLat(location.getDouble("lat"));
					loc.setLon(location.getDouble("lng"));
					loc.setType(getLocationType(result));
					locations.add(loc);
				}
			}
		}
		catch (JSONException e)
		{
			throw new GeocodingException(e.getMessage(), e);
		}
		return locations;
	}

	private LocationType getLocationType(JSONObject result) throws JSONException
	{
		if (!result.has("types"))
			return LocationType.UNKNOWN;
		JSONArray types = result.getJSONArray("types");
		for (int i = 0; i < types.length(); i++)
		{
			final String type = types.getString(i);
			if ("street_address".equals(type))
				return LocationType.STREET_ADDRESS;
			else if ("route".equals(type))
				return LocationType.ROUTE;
			else if ("intersection".equals(type))
				return LocationType.INTERSECTION;
			else if ("country".equals(type))
				return LocationType.COUNTRY;
			else if ("administrative_area_level_1".equals(type))
				return LocationType.ADMIN_LEVEL_1;
			else if ("administrative_area_level_2".equals(type))
				return LocationType.ADMIN_LEVEL_2;
			else if ("locality".equals(type))
				return LocationType.LOCALITY;
			else if ("neighborhood".equals(type))
				return LocationType.NEIGHBORHOOD;
			else if ("postal_code".equals(type))
				return LocationType.POSTAL_CODE;
			else if ("point_of_interest".equals(type))
				return LocationType.POI;
		}
		return LocationType.UNKNOWN;
	}

	public boolean isUseSecureConnection()
	{
		return useSecureConnection;
	}

	public void setUseSecureConnection(boolean useSecureConnection)
	{
		this.useSecureConnection = useSecureConnection;
	}
}
