
package com.bosch.si.amra.presenter.export;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.constants.UIConstants;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.event.DashboardEvent.ExportDownloadEvent;
import com.bosch.si.amra.event.DashboardEvent.ExportGenerationEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.provider.DataProviderInitializer;
import com.mongodb.AggregationOutput;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.vaadin.server.Page;

@Component
public class ExportPresenterImpl implements Serializable, ExportPresenter
{

	private static final String		N_A					= "N/A";

	private static final long		serialVersionUID	= 1L;

	private static final String		BOX_DATE_PATTERN	= "yy-MM-dd";

	private static final String		DECIMAL_PATTERN		= "0.0";

	private StringBuffer			csvStringBuffer;

	private Map<String, Boolean>	selectedFields;

	/**
	 * 
	 * @param collectionName
	 * @return
	 */
	private DBCollection getCollection(String collectionName)
	{
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection collection = db.getCollection(collectionName);
		return collection;
	}

	@Override
	public DBCursor generateCSVExport(ExportGenerationEvent event)
	{
		SimpleDateFormat format = new SimpleDateFormat(BOX_DATE_PATTERN);
		Date startDate = event.getStartDate();
		Date endDate = event.getEndDate();
		csvStringBuffer = new StringBuffer();
		selectedFields = event.getSelectedFields();
		List<Wagon> wagons = event.getWagons();

		DBCollection collection = getCollection(DashboardUI.getEventCollection());

		BasicDBList docIds = new BasicDBList();
		for (Wagon wagon : wagons)
		{
			docIds.add(wagon.getId());

		}

		DBObject inClause = new BasicDBObject("$in", docIds);
		DBObject toMatch = new BasicDBObject(MongoConstants.WAGON_ID, inClause);
		DBObject dateMatch = new BasicDBObject("$gte", format.format(startDate));
		dateMatch.put("$lte", format.format(endDate));
		toMatch.put("D.DA", dateMatch);
		toMatch.put("D.GF", 3);

		BasicDBObject includeProjection = generateMongoProjectionAndCSVHeader();

		DBObject sort = new BasicDBObject(new BasicDBObject("D.DA", -1));
		sort.put("D.TM", -1);

		DBCursor cursor = null;

		// prevent Overflow sort stage buffered data usage of 33554727 bytes exceeds internal
		long receivedRows = collection.count(toMatch);
		if (receivedRows > 40000)
		{
			cursor = collection.find(toMatch, includeProjection);
		}
		else
		{
			cursor = collection.find(toMatch, includeProjection).sort(sort);
		}

		generateCSVData(includeProjection, cursor);

		DashboardEventBus.post(new ExportDownloadEvent(csvStringBuffer));
		return cursor;
	}

	@Override
	public AggregationOutput aggregateMileage(String sameDate, String wagonId)
	{
		DBCollection collection = getCollection(DashboardUI.getMongoMileageCollection());

		DBObject toMatch = new BasicDBObject(MongoConstants.WAGON_ID, wagonId);
		toMatch.put(MongoConstants.DATE, sameDate);
		DBObject match = new BasicDBObject("$match", toMatch);

		DBObject groupData = new BasicDBObject("_id", "$WI");
		groupData.put(MongoConstants.MILEAGE, new BasicDBObject("$sum", "$KM"));
		DBObject group = new BasicDBObject("$group", groupData);

		AggregationOutput aggregate = null;
		if (collection != null)
		{
			aggregate = collection.aggregate(Arrays.asList(match, group));
		}
		return aggregate;
	}

	/**
	 * 
	 * @return
	 */
	private BasicDBObject generateMongoProjectionAndCSVHeader()
	{
		BasicDBObject includeProjection = new BasicDBObject();
		includeProjection.put(MongoConstants.ALIAS, 1);
		includeProjection.put(MongoConstants.WAGON_ID, 1);
		csvStringBuffer.append(
				DashboardUI.getMessageSource().getMessage("view.overview.columnheader.alias")
						+ ";");

		for (String key : selectedFields.keySet())

		{
			if (selectedFields.get(key))
			{
				// put together mongo projection
				if (!key.equals(MongoConstants.MILEAGE))
					includeProjection.put(MongoConstants.DATA_ELEMENT + "." + key,
							selectedFields.get(key) ? 1 : 0);

				// put together CSV-File Header
				csvStringBuffer.append(mongoConstantsToCSVHeader(key));

			}
		}
		csvStringBuffer.append('\n');
		return includeProjection;
	}

	/**
	 * 
	 * @param mongoConstants
	 * @return
	 */
	private String mongoConstantsToCSVHeader(String mongoConstants)
	{
		switch (mongoConstants)
		{
			case MongoConstants.ALIAS:
				return DashboardUI.getMessageSource()
						.getMessage("view.notification.columnheader.alias") + ";";
			case MongoConstants.DATE:
				return DashboardUI.getMessageSource().getMessage("view.export.checkbox.date") + ";";
			case MongoConstants.LONGITUDE:
				return DashboardUI.getMessageSource()
						.getMessage("view.notification.columnheader.longitude") + ";";
			case MongoConstants.LATITUDE:
				return DashboardUI.getMessageSource()
						.getMessage("view.notification.columnheader.latitude") + ";";
			case MongoConstants.ALTITUDE:
				return DashboardUI.getMessageSource()
						.getMessage("view.notification.columnheader.altitude") + ";";
			case MongoConstants.HUMIDITY:
				return DashboardUI.getMessageSource().getMessage("view.export.checkbox.humidity")
						+ ";";
			case MongoConstants.DEVICE_TEMPERATURE:
				return DashboardUI.getMessageSource()
						.getMessage("view.export.excel.devicetemperature") + ";";
			case MongoConstants.HUMIDITY_TEMPERATURE:
				return DashboardUI.getMessageSource()
						.getMessage("view.export.excel.humiditytemperature") + ";";
			case MongoConstants.SHOCK:
				return DashboardUI.getMessageSource().getMessage("view.export.checkbox.shockx")
						+ ";";
			case MongoConstants.MILEAGE:
				return DashboardUI.getMessageSource().getMessage("view.export.checkbox.mileage")
						+ ";";
			default:
				return "";
		}

	}

	/**
	 * 
	 * @param includeProjection
	 * @param cursorForTelematicData
	 */
	private void generateCSVData(BasicDBObject includeProjection, DBCursor cursorForTelematicData)
	{

		while (cursorForTelematicData.hasNext())
		{

			// Find out a way to repeate the same mileageData
			DBObject next = cursorForTelematicData.next();

			csvStringBuffer.append(next.get(MongoConstants.ALIAS));
			csvStringBuffer.append(";");

			DBObject telematicData = (DBObject) next.get("D");

			for (String key : selectedFields.keySet())
			{
				if (key.equals(MongoConstants.MILEAGE) && selectedFields.get(key))
				{
					addCSVMileageContent(next);
				}
				else if (selectedFields.get(key))
				{
					addCSVContent(key, telematicData);
				}
			}
			csvStringBuffer.append('\n');
		}
	}

	/**
	 * 
	 * @param resultDataObject
	 */
	private void addCSVMileageContent(DBObject resultDataObject)
	{
		DBObject telematicData = (DBObject) resultDataObject.get("D");
		Iterator<DBObject> aggregationObject = aggregateMileage(telematicData.get("DA").toString(),
				resultDataObject.get("WI").toString()).results().iterator();
		if (aggregationObject.hasNext())
		{
			DBObject mileageData = aggregationObject.next();
			if (mileageData != null)
			{
				csvStringBuffer.append(formatNumber(mileageData, MongoConstants.MILEAGE, ""));
			}
		}
	}

	/**
	 * adds the csv content
	 * 
	 * @param checkBoxValue
	 * @param telematicData
	 */
	private void addCSVContent(String checkBoxValue, DBObject telematicData)
	{
		switch (checkBoxValue)
		{
			case MongoConstants.DATE:
				try
				{
					String date = (String) telematicData.get(MongoConstants.DATE);
					String time = (String) telematicData.get(MongoConstants.TIME);
					String dateTime = date + " " + time;
					SimpleDateFormat dateFormat = new SimpleDateFormat("yy-MM-dd HH:mm:ss");
					dateFormat.setTimeZone(DashboardUI.getUserTimeZone());
					Date parsedDate = dateFormat.parse(dateTime);
					DateFormat formatter = new SimpleDateFormat(
							DashboardUI.getMessageSource().getMessage("date.format"));
					csvStringBuffer.append(formatter.format(parsedDate));

				}
				catch (ParseException e)
				{
					e.printStackTrace();
				}
				csvStringBuffer.append(";");
				break;
			case MongoConstants.LONGITUDE:
			case MongoConstants.LATITUDE:
				csvStringBuffer.append(formatNumber(telematicData, checkBoxValue, ".000000"));
				csvStringBuffer.append(";");
				break;
			case MongoConstants.SHOCK:
				csvStringBuffer.append(telematicData.get(checkBoxValue));
				csvStringBuffer.append(";");
				break;
			case MongoConstants.ALTITUDE:
			case MongoConstants.DEVICE_TEMPERATURE:
				csvStringBuffer.append(formatNumber(telematicData, checkBoxValue, DECIMAL_PATTERN));
				csvStringBuffer.append(";");
				break;
			case MongoConstants.HUMIDITY:
				appendValidValues(UIConstants.LOWERLIMIT_HUMIDITY, UIConstants.UPPERLIMIT_HUMIDITY,
						checkBoxValue, telematicData);
				break;
			case MongoConstants.HUMIDITY_TEMPERATURE:
				appendValidValues(UIConstants.LOWERLIMIT_HUMIDITYTEMPERATURE,
						UIConstants.UPPERLIMIT_HUMIDITYTEMPERATURE, checkBoxValue, telematicData);
				break;
			default:
				break;
		}
	}

	/**
	 * 
	 * @param lowerLimit
	 * @param upperLimit
	 * @param checkBoxValue
	 * @param telematicData
	 */
	private void appendValidValues(int lowerLimit, int upperLimit, String checkBoxValue,
			DBObject telematicData)
	{
		if (checkBoxValue != null)
		{
			Number data = (Number) telematicData.get(checkBoxValue);
			if (data != null && lowerLimit <= Integer.valueOf(data.intValue())
					&& Integer.valueOf(data.intValue()) <= upperLimit)
			{
				csvStringBuffer.append(formatNumber(telematicData, checkBoxValue, DECIMAL_PATTERN));
			}
			else
			{
				csvStringBuffer.append(N_A);
			}
			csvStringBuffer.append(";");
		}
	}

	/**
	 * Gets the locale specific symbols for decimal grouping separator.
	 * 
	 * @return
	 */
	private DecimalFormatSymbols getDecimalFormatSymbols()
	{
		Locale locale_code = Page.getCurrent().getWebBrowser().getLocale().getLanguage() == null
				? new Locale(DashboardUI.getMessageSource()
						.getMessage("vaadin.presenter.export.csv.language.locale"))
				: Page.getCurrent().getWebBrowser().getLocale();
		DecimalFormatSymbols localeSpecificDecimalFormatSymbols = new DecimalFormatSymbols(
				locale_code);
		localeSpecificDecimalFormatSymbols.setDecimalSeparator(DashboardUI.getMessageSource()
				.getMessage("vaadin.presenter.export.csv.separator.decimal").charAt(0));
		localeSpecificDecimalFormatSymbols.setGroupingSeparator(DashboardUI.getMessageSource()
				.getMessage("vaadin.presenter.export.csv.separator.group").charAt(0));
		return localeSpecificDecimalFormatSymbols;
	}

	/**
	 * Formats the number
	 * 
	 * @param telematicData
	 * @param checkBoxValue
	 * @param formatPattern
	 * @return
	 */
	private String formatNumber(DBObject telematicData, String checkBoxValue, String formatPattern)
	{
		DecimalFormatSymbols symbols = getDecimalFormatSymbols();
		NumberFormat numberFormat = new DecimalFormat(formatPattern, symbols);
		return numberFormat.format(telematicData.get(checkBoxValue)).toString();
	}
}
