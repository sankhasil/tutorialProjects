
package com.bosch.si.amra.component;

import java.util.Calendar;
import java.util.Date;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.event.DashboardEvent.CalculateMileageEvent;
import com.bosch.si.amra.event.DashboardEvent.UpdateEvent;
import com.bosch.si.amra.event.DashboardEvent.WagonSelectedEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.presenter.details.DetailsPresenterImpl;
import com.bosch.si.amra.view.UserNotification;
import com.google.common.eventbus.Subscribe;
import com.vaadin.data.Property.ValueChangeEvent;
import com.vaadin.data.Property.ValueChangeListener;
import com.vaadin.server.Responsive;
import com.vaadin.shared.ui.MarginInfo;
import com.vaadin.shared.ui.datefield.Resolution;
import com.vaadin.shared.ui.label.ContentMode;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Component;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Panel;
import com.vaadin.ui.PopupDateField;
import com.vaadin.ui.UI;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

/**
 * Mileage panel for calculating the mileage of a given means of transport for a given date range
 *
 * @author toa1wa3
 *
 */
public class MileagePanel extends Panel
{
	private static final long	serialVersionUID	= 4363097405470687223L;

	private PopupDateField		fromDateField;

	private PopupDateField		toDateField;

	private Label				mileageLabel;

	private Button				calculateButton;

	private Wagon				wagon;

	public MileagePanel()
	{
		DashboardEventBus.register(this);
		Responsive.makeResponsive(this);

		VerticalLayout verticalLayout = new VerticalLayout();
		setContent(verticalLayout);
		verticalLayout.setWidth("100%");
		verticalLayout.setMargin(new MarginInfo(true, false, true, false));
		verticalLayout.setSpacing(true);
		addStyleName(ValoTheme.PANEL_BORDERLESS);

		verticalLayout.addComponent(buildDatePicker());
		verticalLayout.addComponent(buildCalculateButton());
		verticalLayout.addComponent(buildResult());
		verticalLayout.setComponentAlignment(mileageLabel, Alignment.MIDDLE_CENTER);
		verticalLayout.setComponentAlignment(calculateButton, Alignment.MIDDLE_CENTER);
	}

	@SuppressWarnings ("serial")
	private Component buildDatePicker()
	{
		HorizontalLayout datePickerLayout = new HorizontalLayout();
		datePickerLayout.setWidth(100, Unit.PERCENTAGE);

		fromDateField = new PopupDateField(
				DashboardUI.getMessageSource().getMessage("view.mileage.popupdate.from"));
		fromDateField
				.setDateFormat(DashboardUI.getMessageSource().getMessage("date.format.picker"));
		fromDateField.setResolution(Resolution.DAY);
		fromDateField.setLocale(UI.getCurrent().getLocale());
		fromDateField.setImmediate(true);
		fromDateField.setLenient(true);
		fromDateField.addStyleName(ValoTheme.DATEFIELD_LARGE);
		fromDateField.setParseErrorMessage(
				DashboardUI.getMessageSource().getMessage("view.mileage.wrong.date"));

		fromDateField.setValidationVisible(true);
		fromDateField.setDateOutOfRangeMessage(
				DashboardUI.getMessageSource().getMessage("view.mileage.wrong.period"));
		fromDateField.setRequired(true);
		fromDateField.setRequiredError(
				DashboardUI.getMessageSource().getMessage("view.mileage.empty.date"));

		toDateField = new PopupDateField(
				DashboardUI.getMessageSource().getMessage("view.mileage.popupdate.to"));
		toDateField.setDateFormat(DashboardUI.getMessageSource().getMessage("date.format.picker"));
		toDateField.setResolution(Resolution.DAY);
		toDateField.setLocale(UI.getCurrent().getLocale());
		toDateField.setImmediate(true);
		toDateField.setLenient(true);
		toDateField.addStyleName(ValoTheme.DATEFIELD_LARGE);
		toDateField.setParseErrorMessage(
				DashboardUI.getMessageSource().getMessage("view.mileage.wrong.date"));
		toDateField.setValidationVisible(true);
		toDateField.setDateOutOfRangeMessage(
				DashboardUI.getMessageSource().getMessage("view.mileage.wrong.period"));
		toDateField.setRequired(true);
		toDateField.setRequiredError(
				DashboardUI.getMessageSource().getMessage("view.mileage.empty.date"));

		initializeDateFields();
		fromDateField.setRangeEnd(toDateField.getValue());
		toDateField.setRangeStart(fromDateField.getValue());
		fromDateField.addValueChangeListener(new ValueChangeListener()
		{

			@Override
			public void valueChange(ValueChangeEvent event)
			{
				toDateField.setRangeStart((Date) event.getProperty().getValue());
				enableButton();
			}
		});

		toDateField.addValueChangeListener(new ValueChangeListener()
		{

			@Override
			public void valueChange(ValueChangeEvent event)
			{
				fromDateField.setRangeEnd((Date) event.getProperty().getValue());
				enableButton();
			}
		});

		datePickerLayout.addComponent(fromDateField);
		datePickerLayout.addComponent(toDateField);
		datePickerLayout.setComponentAlignment(fromDateField, Alignment.MIDDLE_LEFT);
		datePickerLayout.setComponentAlignment(toDateField, Alignment.MIDDLE_RIGHT);

		return datePickerLayout;
	}

	private void enableButton()
	{

		if (fromDateField.isValid() && toDateField.isValid() && wagon != null)
		{
			calculateButton.setEnabled(true);
			fromDateField.setValidationVisible(false);
			toDateField.setValidationVisible(false);
		}
		else
		{
			calculateButton.setEnabled(false);
			fromDateField.setValidationVisible(true);
			toDateField.setValidationVisible(true);
		}
	}

	@SuppressWarnings ("serial")
	private Button buildCalculateButton()
	{
		calculateButton = new Button(
				DashboardUI.getMessageSource().getMessage("view.details.calculate"));
		calculateButton.addClickListener(new Button.ClickListener()
		{

			@Override
			public void buttonClick(ClickEvent event)
			{
				Calendar startDate = formatStartDate();
				Calendar endDate = formatEndDate();

				if (wagon != null)
				{
					DashboardEventBus.post(new CalculateMileageEvent(wagon.getId(),
							new Date(startDate.getTimeInMillis()),
							new Date(endDate.getTimeInMillis())));
				}
				else
				{
					new UserNotification("view.details.empty.wagon", 1000, false);
				}
			}
		});
		calculateButton.setEnabled(false);
		return calculateButton;
	}

	private Calendar formatStartDate()
	{
		Calendar startDate = Calendar.getInstance();
		startDate.setTime(fromDateField.getValue());
		startDate.set(Calendar.HOUR_OF_DAY, 0);
		startDate.set(Calendar.MINUTE, 0);
		startDate.set(Calendar.SECOND, 0);
		startDate.set(Calendar.MILLISECOND, 0);
		return startDate;
	}

	private Calendar formatEndDate()
	{
		Calendar endDate = Calendar.getInstance();
		endDate.setTime(toDateField.getValue());
		endDate.set(Calendar.HOUR_OF_DAY, 23);
		endDate.set(Calendar.MINUTE, 59);
		endDate.set(Calendar.SECOND, 59);
		endDate.set(Calendar.MILLISECOND, 999);
		return endDate;
	}

	private Component buildResult()
	{
		mileageLabel = new Label();
		mileageLabel.setSizeUndefined();
		mileageLabel.setContentMode(ContentMode.HTML);
		mileageLabel.setImmediate(true);

		return mileageLabel;
	}

	/**
	 * Called from {@link DetailsPresenterImpl} {@code calculateMileageForPeriod()}
	 *
	 * @param event
	 *            {@link UpdateEvent}
	 */
	@Subscribe
	public void updateMileageLabel(UpdateEvent event)
	{
		if (event.getValue() instanceof Integer)
		{
			mileageLabel.setValue(String.valueOf(event.getValue()) + " KM");
		}
	}

	@Subscribe
	public void wagonSelected(WagonSelectedEvent event)
	{
		initializeDateFields();
		mileageLabel.setValue("");
		wagon = event.getWagon();
		if (wagon != null)
		{
			calculateButton.setEnabled(true);
		}
		else
		{
			calculateButton.setEnabled(false);
		}
	}

	private void initializeDateFields()
	{
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.YEAR, calendar.get(Calendar.YEAR) - 1);
		fromDateField.setValue(new Date(calendar.getTimeInMillis()));
		toDateField.setValue(new Date());
	}

	public boolean isPeriodValid()
	{
		if (fromDateField.isValid() && toDateField.isValid())
		{
			Date from = fromDateField.getValue();
			Date to = toDateField.getValue();
			if (from != null && to != null)
			{
				if (from.getTime() <= to.getTime())
				{
					return true;
				}
				else
				{
					Notification.show(
							DashboardUI.getMessageSource().getMessage("view.mileage.wrong.period"));
					return false;
				}
			}
			else
			{
				Notification
						.show(DashboardUI.getMessageSource().getMessage("view.mileage.empty.date"));
				return false;
			}
		}
		else
		{
			return false;
		}
	}

	@Override
	public void detach()
	{
		super.detach();

		DashboardEventBus.unregister(this);
	}
}
