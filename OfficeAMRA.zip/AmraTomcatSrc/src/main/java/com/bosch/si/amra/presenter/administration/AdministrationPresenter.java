
package com.bosch.si.amra.presenter.administration;

import com.bosch.si.amra.event.DashboardEvent.CouplingEvent;
import com.bosch.si.amra.event.DashboardEvent.DecouplingEvent;
import com.bosch.si.amra.event.DashboardEvent.UpdateMeansOfTransportEvent;
import com.bosch.si.amra.event.DashboardEvent.WagonTypeEvent;
import com.bosch.si.amra.event.DashboardEvent.WagonTypeDeleteEvent;
import com.google.common.eventbus.Subscribe;

/**
 * Interface for {@link AdministrationPresenterImpl}. This is need for Spring because the actual
 * bean instance is a JDK dynamic proxy which implements the interface and calls the concrete
 * implementation
 *
 * @author toa1wa3
 *
 */
public interface AdministrationPresenter
{
	/**
	 * Updates meta data of a wagon
	 *
	 * @param event
	 *            {@link UpdateMeansOfTransportEvent}
	 */
	@Subscribe
	public void saveWagon(UpdateMeansOfTransportEvent event);

	/**
	 * Couples a wagon
	 *
	 * @param event
	 *            {@link CouplingEvent}
	 */
	@Subscribe
	public void coupleWagonWithBox(CouplingEvent event);

	/**
	 * Decouples a wagon
	 *
	 * @param event
	 *            {@link DecouplingEvent}
	 */
	@Subscribe
	public void decoupleWagonWithBox(DecouplingEvent event);

	/**
	 * Saves a WagonType
	 *
	 * @param event
	 *            {@link WagonTypeEvent}
	 */
	@Subscribe
	public void saveWagonType(WagonTypeEvent event);

	/**
	 * Deletes a WagonType
	 *
	 * @param event
	 *            {@link WagonTypeDeleteEvent}
	 */
	@Subscribe
	public void deleteWagonType(WagonTypeDeleteEvent event);
}
