
package com.bosch.si.amra.component;

import java.util.ArrayList;
import java.util.List;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.Wagon;
import com.vaadin.addon.charts.Chart;
import com.vaadin.addon.charts.model.ChartType;
import com.vaadin.addon.charts.model.Labels;
import com.vaadin.addon.charts.model.ListSeries;
import com.vaadin.addon.charts.model.PlotOptionsColumn;
import com.vaadin.addon.charts.model.Series;
import com.vaadin.addon.charts.model.Tooltip;
import com.vaadin.addon.charts.model.style.FontWeight;

/**
 * Represents the five top most wagons according to their mileage
 * 
 * @author toa1wa3
 * 
 */
public class TopMileageChart extends Chart
{

	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= -2936524049513403L;

	public TopMileageChart(List<Wagon> wagons)
	{
		setCaption(DashboardUI.getMessageSource().getMessage("view.dashboard.topmileage"));

		getConfiguration().setTitle("");
		getConfiguration().getChart().setType(ChartType.COLUMN);
		getConfiguration().getxAxis().getLabels().setEnabled(false);
		getConfiguration().getyAxis().setTitle(
				DashboardUI.getMessageSource().getMessage("view.dashboard.mileage") + " (km)");

		Tooltip tooltip = new Tooltip();
		tooltip.setFormatter("this.series.name +': '+ this.y +' km'");
		getConfiguration().setTooltip(tooltip);

		List<Series> series = new ArrayList<Series>();
		for (Wagon wagon : wagons)
		{
			if (wagon.getMileage() != null)
			{
				PlotOptionsColumn opts = new PlotOptionsColumn();
				opts.setBorderWidth(0);
				opts.setShadow(false);
				ListSeries item = new ListSeries(wagon.getAlias(), wagon.getMileage());
				item.setPlotOptions(opts);
				series.add(item);
			}
		}
		getConfiguration().setSeries(series);

		PlotOptionsColumn opts = new PlotOptionsColumn();
		opts.setGroupPadding(0);
		opts.setDataLabels(new Labels(true));
		opts.getDataLabels().getStyle().setFontWeight(FontWeight.BOLD);
		opts.getDataLabels().setFormatter("this.y + ' km'");
		getConfiguration().setPlotOptions(opts);

	}
}
