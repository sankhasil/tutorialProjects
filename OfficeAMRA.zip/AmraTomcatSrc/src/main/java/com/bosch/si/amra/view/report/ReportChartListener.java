
package com.bosch.si.amra.view.report;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.vaadin.addon.charts.Chart;
import com.vaadin.addon.charts.ChartSelectionEvent;
import com.vaadin.addon.charts.ChartSelectionListener;
import com.vaadin.ui.MenuBar.MenuItem;

public class ReportChartListener implements ChartSelectionListener
{
	/**
	 * Serial version uid
	 */
	private static final long		serialVersionUID	= -3938976283953204627L;

	private final Chart[]			charts;

	private final List<MenuItem>	resetZooms			= new ArrayList<MenuItem>();

	public ReportChartListener(Chart[] charts)
	{
		this.charts = charts;
	}

	@SuppressWarnings ("unchecked")
	@Override
	public void onSelection(ChartSelectionEvent event)
	{
		Double selectionStart = event.getSelectionStart();
		Double selectionEnd = event.getSelectionEnd();
		for (Chart chart : charts)
		{
			chart.getConfiguration().getxAxis().setExtremes(selectionStart, selectionEnd);
			Collection<ReportChartListener> listeners = (Collection<ReportChartListener>) chart
					.getListeners(event.getClass());
			for (ReportChartListener listener : listeners)
			{
				listener.setResetZoomVisible(true);
			}
		}
	}

	@SuppressWarnings ("unchecked")
	public void resetZoom()
	{
		for (Chart chart : charts)
		{
			Number number = null;
			chart.getConfiguration().getxAxis().setMin(number);
			chart.getConfiguration().getxAxis().setMax(number);
			chart.drawChart();
			Collection<ReportChartListener> listeners = (Collection<ReportChartListener>) chart
					.getListeners(ChartSelectionEvent.class);
			for (ReportChartListener listener : listeners)
			{
				listener.setResetZoomVisible(false);
			}
		}
	}

	public void addResetZoom(MenuItem resetZoom)
	{
		resetZooms.add(resetZoom);
	}

	public void setResetZoomVisible(boolean visible)
	{
		for (MenuItem resetZoom : resetZooms)
		{
			resetZoom.setVisible(visible);
		}
	}
}
