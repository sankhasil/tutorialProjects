
package com.bosch.si.amra.provider.geofence;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.constants.UIConstants;
import com.bosch.si.amra.entity.geofence.Geofence;
import com.bosch.si.amra.provider.DataProviderInitializer;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

/**
 * Specific data provider for geofence use cases
 *
 * @author toa1wa3
 *
 */
@Component
public class GeofenceDataProvider
{
	/**
	 * Retrieves all geofence for the given tenant
	 *
	 * @param tenantId
	 *            the tenantId
	 * @return list with all geofence for the given tenant with only name and id to store network
	 *          traffic
	 */
	public List<Geofence> getGeofencesForDisplaying(String tenantId)
	{
		if (tenantId == null || tenantId.isEmpty())
		{
			throw new IllegalArgumentException(UIConstants.TENANT_ID_MUST_NOT_BE_NULL);
		}

		DBCursor geofenceCursor = getGeofenceCursor(tenantId);
		return transformDBobject2Geofencing(geofenceCursor);
	}

	private DBCursor getGeofenceCursor(String tenantId)
	{
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection geofenceCollection = db.getCollection(DashboardUI.getGeofenceCollection());

		DBObject match = new BasicDBObject(MongoConstants.TENANT_ID, tenantId);
		DBObject fields = new BasicDBObject(MongoConstants.ID, 1);
		fields.put(MongoConstants.GEOFENCE_NAME, 1);

		return geofenceCollection.find(match, fields)
				.sort(new BasicDBObject(MongoConstants.SORT, 1));
	}

	private List<Geofence> transformDBobject2Geofencing(DBCursor geofencingCursor)
	{
		List<Geofence> geofenceList = new ArrayList<Geofence>();
		while (geofencingCursor.hasNext())
		{
			DBObject geofenceObject = geofencingCursor.next();
			Geofence geofence = Geofence.dbObject2Geofence(geofenceObject);
			geofenceList.add(geofence);
		}
		return geofenceList;
	}
}
