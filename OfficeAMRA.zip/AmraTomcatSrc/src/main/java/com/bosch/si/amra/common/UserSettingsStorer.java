
package com.bosch.si.amra.common;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.bosch.si.amra.component.filter.TimestampFilter;
import com.bosch.si.amra.component.grid.GridComponent;
import com.bosch.si.amra.constants.overview.OverviewConstants;
import com.bosch.si.amra.entity.ColumnConfiguration;
import com.bosch.si.amra.entity.UserSettingsConfiguration;
import com.bosch.si.amra.view.overview.OverviewGridFilterComponent.OverviewFilter;
import com.bosch.si.amra.view.overview.OverviewGridFilterComponent.OverviewTagFilter;
import com.vaadin.data.sort.SortOrder;
import com.vaadin.server.VaadinSession;
import com.vaadin.ui.AbstractComponent;
import com.vaadin.ui.Grid;
import com.vaadin.ui.Grid.Column;
import com.vaadin.ui.Grid.HeaderCell;

public class UserSettingsStorer
{
	public static void saveSessionUserSettings(GridComponent grid, String sessionAttribute)
	{
		UserSettingsConfiguration userSettingsConfigurationObject = new UserSettingsConfiguration();
		ArrayList<ColumnConfiguration> sessionConfiguration = new ArrayList<>();
		List<Column> sessionColumn = grid.getColumns();
		for (Column column : sessionColumn)
		{
			if (!grid.getColumn(column.getPropertyId()).isHidden())
			{
				ColumnConfiguration sessionConfigurationObject = new ColumnConfiguration();
				sessionConfigurationObject.setPropertyId(column.getPropertyId().toString());
				sessionConfigurationObject.setWidth(column.getWidth());
				sessionConfiguration.add(sessionConfigurationObject);
			}
		}
		userSettingsConfigurationObject.setUserSettingsColumnConfigurations(sessionConfiguration);
		List<SortOrder> sortOrderList = grid.getSortOrder();
		if (sortOrderList.size() > 0)
			userSettingsConfigurationObject.setSortedGridColumnConfigurations(sortOrderList.get(0));
		if (grid.getComponentToPidMap() != null)
		{
			Map<String, String> filterMap = createFilterMap(grid.getComponentToPidMap());
			userSettingsConfigurationObject.setFilterMap(filterMap);
		}
		VaadinSession.getCurrent().setAttribute(sessionAttribute, userSettingsConfigurationObject);
	}

	public static void fetchSessionUserSettings(Grid grid, String sessionAttribute,
			Object... propertyIds)
	{
		UserSettingsConfiguration userSettingsConfigurationObject = (UserSettingsConfiguration) VaadinSession
				.getCurrent().getAttribute(sessionAttribute);
		if (null != userSettingsConfigurationObject)
		{
			ArrayList<ColumnConfiguration> sessionConfiguration = userSettingsConfigurationObject
					.getUserSettingsColumnConfigurations();
			List<String> columnOrder = new ArrayList<>();
			for (ColumnConfiguration configuration : sessionConfiguration)
			{
				columnOrder.add(configuration.getPropertyId());
				grid.getColumn(configuration.getPropertyId()).setWidth(configuration.getWidth());
			}
			grid.setColumnOrder(columnOrder.toArray(new Object[columnOrder.size()]));
			if (userSettingsConfigurationObject.getSortedGridColumnConfigurations() != null)
			{
				List<SortOrder> sortedOrderList = new ArrayList<>();
				sortedOrderList
						.add(userSettingsConfigurationObject.getSortedGridColumnConfigurations());
				if (sortedOrderList.size() > 0)
				{
					grid.setSortOrder(sortedOrderList);
				}
			}
			if (columnOrder.size() > 0)
				Arrays.asList(propertyIds).stream().forEach(propertyId -> {
					if (!columnOrder.contains(propertyId.toString()))
						grid.getColumn(propertyId).setHidden(true);
				});
			Map<String, String> filterMap = userSettingsConfigurationObject.getFilterMap();
			if (!filterMap.isEmpty())
			{
				applyFilterSettings(filterMap, grid);
			}
		}
	}

	private static Map<String, String> createFilterMap(Map<AbstractComponent, Object> map)
	{
		Map<String, String> filterMap = new HashMap<>();
		for (Map.Entry<AbstractComponent, Object> entry : map.entrySet())
		{

			if (entry.getKey() instanceof TimestampFilter<?>)
			{
				TimestampFilter<?> timestampFilter = (TimestampFilter<?>) entry.getKey();
				if (!timestampFilter.isEmpty())
				{
					long timestampInMillis = timestampFilter.getValue().getTime();
					filterMap.put(entry.getValue().toString(), String.valueOf(timestampInMillis));
				}
			}
			else if (entry.getKey() instanceof OverviewTagFilter)
			{
				OverviewTagFilter overviewTagFilter = (OverviewTagFilter) entry.getKey();
				if (!StringUtils.isEmpty(overviewTagFilter.getValue()))
					filterMap.put(entry.getValue().toString(), overviewTagFilter.getValue());
			}
			else
			{
				OverviewFilter overviewFilter = (OverviewFilter) entry.getKey();
				if (!StringUtils.isEmpty(overviewFilter.getValue()))
					filterMap.put(entry.getValue().toString(), overviewFilter.getValue());
			}

		}
		return filterMap;
	}

	private static void applyFilterSettings(Map<String, String> filterMap, Grid grid)
	{
		HeaderCell cell;
		for (Map.Entry<String, String> entry : filterMap.entrySet())
		{
			if (entry.getKey().equals(OverviewConstants.TIMESTAMP))
			{
				String filterString = entry.getValue();
				Date date = new Date(Long.valueOf(filterString).longValue());
				cell = grid.getHeaderRow(1).getCell(entry.getKey());
				TimestampFilter<?> filter = ((TimestampFilter<?>) cell.getComponent());
				filter.setValue(date);

			}
			else if (entry.getKey().equals(OverviewConstants.TAGS))
			{
				cell = grid.getHeaderRow(1).getCell(entry.getKey());
				OverviewTagFilter filter = ((OverviewTagFilter) cell.getComponent());
				filter.setValue(entry.getValue());
			}
			else
			{
				cell = grid.getHeaderRow(1).getCell(entry.getKey());
				OverviewFilter filter = ((OverviewFilter) cell.getComponent());
				filter.setValue(entry.getValue());
			}
		}
	}
}
