
package com.bosch.si.amra.presenter.details;

import java.util.List;

import com.bosch.si.amra.entity.LatLong;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.event.DashboardEvent.CalculateMileageEvent;
import com.bosch.si.amra.event.DashboardEvent.ShowDetailsForWagonEvent;
import com.bosch.si.amra.event.DashboardEvent.ShowRouteEvent;
import com.google.common.eventbus.Subscribe;
import com.google.gwt.event.logical.shared.ShowRangeEvent;
import com.vaadin.tapio.googlemaps.client.LatLon;

/**
 * Interface for {@link DetailsPresenterImpl}. This is need for Spring because the actual
 * bean instance is a JDK dynamic proxy which implements ths interface and calls the concrete
 * implementation
 *
 * @author toa1wa3
 *
 */
public interface DetailsPresenter
{
	/**
	 * @param event
	 *            {@link ShowDetailsForWagonEvent}
	 * @return a {@link Wagon}
	 */
	@Subscribe
	public Wagon showDetailsForWagon(ShowDetailsForWagonEvent event);

	/**
	 * Calculates the total mileage for the given period
	 *
	 * @param event
	 *            {@link CalculateMileageEvent}
	 * @return calculated mileage for the given period
	 */
	@Subscribe
	public Integer calculateMileageForPeriod(CalculateMileageEvent event);

	/**
	 * Calculates the route for the given boxId and date range
	 *
	 * @param event
	 *            {@link ShowRouteEvent} Contains the boxId, the start and the end date of the range
	 * @return Calculated route for the given boxId and date range
	 */
	@Subscribe
	public Route calculateRoute(ShowRouteEvent event);

	/**
	 * Retrieves all positions sent from the box to visualize on the map
	 *
	 * @param event
	 *            {@link ShowRouteEvent} Contains the boxId, the start and the end date of the range
	 * @return all positions sent from the box
	 */
	public List<LatLong> getPositions(ShowRouteEvent event);

	/**
	 * Calculates the most north eastern point and the most south western point for the retrieved
	 * positions for a specific boxId in a given time range
	 *
	 * @param event
	 *            {@link ShowRangeEvent} Contains the boxId, the start and the end date of the range
	 * @return List of retrieved positions for a specific boxId in a given time range
	 */
	public List<LatLon> calculateBounds(ShowRouteEvent event);
}
