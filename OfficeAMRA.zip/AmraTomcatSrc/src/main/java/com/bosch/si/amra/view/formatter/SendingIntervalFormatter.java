
package com.bosch.si.amra.view.formatter;

import com.vaadin.data.Property;

public class SendingIntervalFormatter extends PropertyFormatter
{
	@Override
	public String format(Object rowId, Property<?> property, String result)
	{
		Integer interval = (Integer) property.getValue();
		int hour = interval / 3600;
		int minutes = (interval % 3600) / 60;
		return String.format("%02d:%02d", hour, minutes);
	}
}
