
package com.bosch.si.amra;

import java.lang.annotation.Annotation;
import java.util.Arrays;
import java.util.List;

import com.bosch.si.amra.constants.MetricsConstants;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.event.DashboardEvent.BrowserResizeEvent;
import com.bosch.si.amra.event.DashboardEvent.CloseOpenWindowsEvent;
import com.bosch.si.amra.event.DashboardEvent.NotificationsCountUpdatedEvent;
import com.bosch.si.amra.event.DashboardEvent.PostViewChangeEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.im.login.Role;
import com.bosch.si.amra.im.login.Role.Roles;
import com.bosch.si.amra.metrics.MetricsFactory;
import com.bosch.si.amra.metrics.MetricsLoggerFactory;
import com.bosch.si.amra.view.AmraView;
import com.vaadin.navigator.Navigator;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.navigator.ViewProvider;
import com.vaadin.server.VaadinSession;
import com.vaadin.ui.ComponentContainer;
import com.vaadin.ui.UI;

@SuppressWarnings ("serial")
public class DashboardNavigator extends Navigator
{
	private AmraView		errorView;

	private ViewProvider	errorViewProvider;

	public DashboardNavigator(ComponentContainer container)
	{
		super(UI.getCurrent(), container);

		initViewChangeListener();
		initViewProviders();
	}

	private void initViewChangeListener()
	{
		addViewChangeListener(new ViewChangeListener()
		{

			@Override
			public boolean beforeViewChange(ViewChangeEvent event)
			{
				return true;
			}

			@Override
			public void afterViewChange(ViewChangeEvent event)
			{
				MetricsFactory
						.createCounter(MetricsConstants.VIEW_VISIT_PREFIX, event.getViewName())
						.inc();
				MetricsLoggerFactory.log(MetricsConstants.VIEW_VISIT_PREFIX, event.getViewName());
				for (AmraView view : AmraView.values())
				{
					if (view.getViewName().equals(event.getViewName()))
					{
						DashboardEventBus.post(new PostViewChangeEvent(view));
						DashboardEventBus.post(new BrowserResizeEvent());
						DashboardEventBus.post(new CloseOpenWindowsEvent());
						DashboardEventBus.post(new NotificationsCountUpdatedEvent());
						break;
					}
				}
			}
		});
	}

	private void initViewProviders()
	{
		User user = (User) VaadinSession.getCurrent().getAttribute(User.class.getName());

		if (user.isEndcustomer() && !user.isAdmin() && !user.isSuperAdmin())
		{
			errorView = AmraView.DISPONENT;
		}
		else
		{
			errorView = AmraView.DASHBOARD;
		}

		for (final AmraView view : AmraView.values())
		{
			Annotation annotation = view.getViewClass().getAnnotation(Role.class);
			Role role = (Role) annotation;
			List<Roles> roles = Arrays.asList(role.value());
			if ((roles.contains(Roles.ENDCUSTOMER) && user.isEndcustomer())
					|| (roles.contains(Roles.USER) && (!user.isEndcustomer() || user.isDisponent()))
					|| (roles.contains(Roles.FLEETADMIN) && user.isAdmin())
					|| (roles.contains(Roles.SYSTEMADMIN) && user.isSuperAdmin()))
			{
				ViewProvider viewProvider = new ClassBasedViewProvider(view.getViewName(),
						view.getViewClass())
				{
					private View cachedInstance;

					@Override
					public View getView(String viewName)
					{
						View result = null;
						if (view.getViewName().equals(viewName))
						{
							if (view.isStateful())
							{
								// Stateful views get lazily instantiated
								if (cachedInstance == null)
								{
									cachedInstance = super.getView(view.getViewName());
								}
								result = cachedInstance;
							}
							else
							{
								// Non-stateful views get instantiated every time
								// they're navigated to
								result = super.getView(view.getViewName());
							}
						}
						return result;
					}
				};

				if (view == errorView)
				{
					errorViewProvider = viewProvider;
				}

				addProvider(viewProvider);
			}

			setErrorProvider(new ViewProvider()
			{
				@Override
				public String getViewName(String viewAndParameters)
				{
					return errorView.getViewName();
				}

				@Override
				public View getView(String viewName)
				{
					return errorViewProvider.getView(errorView.getViewName());
				}
			});
		}
	}
}
