
package com.bosch.si.amra.entity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.constants.overview.OverviewConstants;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

/**
 * @author sks9kor
 *         ColumnConfiguration class used to store the current user settings such as width for the
 *         overview grid which
 *         can then used to set the overviewGridColumnConfigurations property of the the
 *         OverViewConfiguration class
 * 
 */
public class ColumnConfiguration
{
	String	propertyId;

	Double	width;

	public String getPropertyId()
	{
		return propertyId;
	}

	public void setPropertyId(String propertyId)
	{
		this.propertyId = propertyId;
	}

	public Double getWidth()
	{
		return width;
	}

	public void setWidth(Double width)
	{
		this.width = width;
	}

	public static BasicDBList columnConfig2DBList(ArrayList<ColumnConfiguration> columOrder)
	{
		BasicDBList columnsProperty = new BasicDBList();
		for (ColumnConfiguration columnConfiguration : columOrder)
		{
			DBObject widthObject = new BasicDBObject(MongoConstants.WIDTH,
					columnConfiguration.getWidth());
			DBObject propertyObject = new BasicDBObject(
					columnConfiguration.getPropertyId().replace(".", "_"), widthObject);
			columnsProperty.add(propertyObject);
		}
		return columnsProperty;
	}

	public static BasicDBList map2DBList(Map<String, String> filterMap)
	{
		BasicDBList columnFilters = new BasicDBList();
		for (Map.Entry<String, String> entry : filterMap.entrySet())
		{
			DBObject filterValue = new BasicDBObject(MongoConstants.VALUE, entry.getValue());
			DBObject filteredColumn = new BasicDBObject(entry.getKey().replace(".", "_"),
					filterValue);
			columnFilters.add(filteredColumn);
		}
		return columnFilters;
	}

	public static ArrayList<ColumnConfiguration> dBList2ColumnConfig(
			BasicDBList columnConfigObjectList)
	{
		ArrayList<ColumnConfiguration> userColumSettings = new ArrayList<>();
		for (Object object : columnConfigObjectList)
		{
			DBObject columnConfig = (DBObject) object;
			String key = columnConfig.keySet().toString().replace("[", "").replace("]", "");
			DBObject widthObject = (DBObject) columnConfig.get(key);
			Double width = (Double) widthObject.get(MongoConstants.WIDTH);
			ColumnConfiguration columnConfiguration = new ColumnConfiguration();
			// since mongoDB doesn't accept a key with period for storage (i.e .) replace it by
			// different key
			if (key.equals(MongoConstants.MONGO_WAGON_TYPE_NAME))
				columnConfiguration.setPropertyId(OverviewConstants.WAGON_TYPE_NAME);
			else if (key.equals(MongoConstants.MONGO_COUNTRY))
				columnConfiguration.setPropertyId(OverviewConstants.COUNTRY);
			else if (key.equals(MongoConstants.MONGO_STREET_CITY))
				columnConfiguration.setPropertyId(OverviewConstants.STREET_CITY);
			else
				columnConfiguration.setPropertyId(key);
			columnConfiguration.setWidth(width);
			userColumSettings.add(columnConfiguration);
		}
		return userColumSettings;
	}

	public static Map<String, String> dBList2map(BasicDBList columnFiltersList)
	{
		Map<String, String> filterMap = new HashMap<>();
		for (Object object : columnFiltersList)
		{
			DBObject filterObject = (DBObject) object;
			String key = filterObject.keySet().toString().replace("[", "").replace("]", "");
			DBObject valueObject = (DBObject) filterObject.get(key);
			String value = (String) valueObject.get(MongoConstants.VALUE);
			if (key.equals(MongoConstants.MONGO_WAGON_TYPE_NAME))
				key = OverviewConstants.WAGON_TYPE_NAME;
			else if (key.equals(MongoConstants.MONGO_COUNTRY))
				key = OverviewConstants.COUNTRY;
			else if (key.equals(MongoConstants.MONGO_STREET_CITY))
				key = OverviewConstants.STREET_CITY;
			filterMap.put(key, value);
		}

		return filterMap;

	}

}
