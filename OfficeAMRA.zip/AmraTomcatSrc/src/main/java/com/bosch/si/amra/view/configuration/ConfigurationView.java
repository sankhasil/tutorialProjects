
package com.bosch.si.amra.view.configuration;

import java.util.Collection;
import java.util.List;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.component.grid.ConfigurationGrid;
import com.bosch.si.amra.constants.configuration.ConfigurationConstants;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.entity.configuration.Configuration;
import com.bosch.si.amra.event.DashboardEvent.ConfigurationsSavedEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.im.login.Role;
import com.bosch.si.amra.im.login.Role.Roles;
import com.bosch.si.amra.view.configuration.ConfigurationGeneratedContainer.ConfigurationBaseContainer;
import com.bosch.si.amra.view.configuration.ConfigurationGridFilterComponent.BooleanFilterHeader;
import com.bosch.si.amra.view.configuration.ConfigurationGridFilterComponent.ConfigurationGeneralFilterHeader;
import com.bosch.si.amra.view.configuration.ConfigurationGridFilterComponent.IntervalFilterHeader;
import com.bosch.si.amra.view.configuration.ConfigurationGridFilterComponent.TagFilterHeader;
import com.google.common.eventbus.Subscribe;

import com.vaadin.data.util.GeneratedPropertyContainer;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.event.ShortcutListener;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Page;
import com.vaadin.server.Responsive;
import com.vaadin.server.VaadinSession;
import com.vaadin.ui.Button;
import com.vaadin.ui.Component;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.UI;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

@Role ({ Roles.FLEETADMIN, Roles.SYSTEMADMIN })
public class ConfigurationView extends VerticalLayout implements View
{
	private static final long	serialVersionUID	= -8768522401217942052L;

	private ConfigurationGrid	grid;

	private Button				edit;

	private List<Configuration>	configurations;

	private final List<Wagon>	wagons;

	private final User			user				= (User) VaadinSession.getCurrent()
			.getAttribute(User.class.getName());

	public ConfigurationView()
	{
		configurations = DashboardUI.getConfigurationDataProvider()
				.getConfigurations(user.getTenant());
		wagons = DashboardUI.getDataProvider().getWagons(user);

		setSizeFull();
		addStyleName("configuration");
		DashboardEventBus.register(this);

		addComponent(buildToolbar());
		grid = buildGrid();
		addComponent(grid);

		setExpandRatio(grid, 1);

		addShortcutListener(new ShortcutListener("Clear", KeyCode.ESCAPE, null)
		{
			private static final long serialVersionUID = -3339707665857281493L;

			@Override
			public void handleAction(Object sender, Object target)
			{
				GeneratedPropertyContainer container = (GeneratedPropertyContainer) grid
						.getContainerDataSource();
				if (target != null && target instanceof BooleanFilterHeader)
					((BooleanFilterHeader) target).setValue(null);
				else if (target != null && target instanceof IntervalFilterHeader)
					((IntervalFilterHeader) target).setValue(null);
				else if (target != null && target instanceof ConfigurationGeneralFilterHeader)
					((ConfigurationGeneralFilterHeader) target).setValue(null);
				else if (target != null && target instanceof TagFilterHeader)
					((TagFilterHeader) target).setValue(null);
				Object pid = grid.getComponentToPidMap().get(target);
				if (pid != null)
				{
					ConfigurationGridFilterComponent.clearContainerFilters(pid, container);
				}
				grid.getSelectionModel().reset();
			}
		});
	}

	@Override
	public void detach()
	{
		super.detach();
		DashboardEventBus.unregister(this);
	}

	private Component buildToolbar()
	{
		HorizontalLayout header = new HorizontalLayout();
		header.addStyleName("viewheader");
		header.setSpacing(true);
		Responsive.makeResponsive(header);

		Label title = new Label(
				DashboardUI.getMessageSource().getMessage(ConfigurationConstants.TITLE_CAPTION));
		title.setSizeUndefined();
		title.addStyleName(ValoTheme.LABEL_H1);
		title.addStyleName(ValoTheme.LABEL_NO_MARGIN);
		header.addComponent(title);

		edit = buildEdit();
		HorizontalLayout tools = new HorizontalLayout(edit);
		tools.setSpacing(true);
		tools.addStyleName("toolbar");
		header.addComponent(tools);

		return header;
	}

	private ConfigurationGrid buildGrid()
	{
		ConfigurationGeneratedContainer configurationGeneratedContainer = new ConfigurationGeneratedContainer(
				new ConfigurationBaseContainer(configurations), wagons);
		ConfigurationGrid configurationGrid = new ConfigurationGrid(configurationGeneratedContainer,
				configurations, wagons, user);

		// handle selection changes
		configurationGrid.addSelectionListener(selectionEvent -> {
			Collection<Object> selected = configurationGrid.getSelectedRows();
			if (selected != null && !selected.isEmpty())
			{
				edit.setEnabled(true);
			}
			else
			{
				edit.setEnabled(false);
			}
		});

		return configurationGrid;
	}

	private Button buildEdit()
	{
		final Button edit = new Button(
				DashboardUI.getMessageSource().getMessage(ConfigurationConstants.EDIT_CAPTION));
		edit.setImmediate(true);
		edit.setDescription(
				DashboardUI.getMessageSource().getMessage(ConfigurationConstants.EDIT_TOOLTIP));
		edit.setIcon(FontAwesome.EDIT);
		edit.addStyleName(ValoTheme.BUTTON_ICON_ONLY);

		edit.addClickListener(event -> {
			if (grid.getEditedItemId() == null)
			{
				Collection<Object> selectedRows = grid.getSelectedRows();
				if (selectedRows != null && !selectedRows.isEmpty())
				{
					if (selectedRows.size() == 1)
					{
						grid.editItem(selectedRows.iterator().next());
					}
					else
					{
						ConfigurationEditWindow subWindow = new ConfigurationEditWindow(grid,
								configurations);
						UI.getCurrent().addWindow(subWindow);

					}
				}
			}
		});
		edit.setEnabled(false);
		return edit;
	}

	@Subscribe
	public void saveCurrentConfiguration(ConfigurationsSavedEvent event)
	{
		grid.updateConfigurations(event.getConfigurations());
		Notification notification = new Notification(
				DashboardUI.getMessageSource().getMessage("view.configuration.saved"));
		notification.setDelayMsec(1000);
		notification.show(Page.getCurrent());
	}

	@Override
	public void enter(ViewChangeEvent event)
	{
	}
}
