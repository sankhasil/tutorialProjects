
package com.bosch.si.amra.constants.overview;

public class OverviewConstants
{
	public static final String		ALIAS								= "alias";

	public static final String		SORT								= "sort";

	public static final String		WAGON_TYPE							= "wagonType";

	public static final String		WAGON_TYPE_NAME						= "wagonType.typeName";

	public static final String		MILEAGE								= "mileage";

	public static final String		HUMIDITY							= "humidity";

	public static final String		DEVICE_TEMPERATURE					= "temperature";

	public static final String		HUMIDITY_TEMPERATURE				= "humidityTemperature";

	public static final String		TEMPERATURE							= "t1Temperature";

	public static final String		ADDRESS								= "address";

	public static final String		STREET								= "address.street";

	public static final String		CITY								= "address.city";

	public static final String		COUNTRY								= "address.country";

	public static final String		STREET_CITY							= "address.streetAndCity";

	public static final String		BATTERY_LEVEL						= "batteryLevel";

	public static final String		TIMESTAMP							= "timestamp";

	public static final String		TIMESTAMP_CONTACT					= "timestampContact";

	public static final String		TAGS								= "tags";

	public static final String		COLLECT_CAUSE						= "collectCause";

	public static final int			ADDRESS_COLUMN_WIDTH				= 310;

	public static final int			TRANSPORT_TYPE_COLUMN_WIDTH			= 230;

	public static final int			SMALL_COLUMN_WIDTH					= 100;

	public static final int			TIMESTAMP_COLUMN_WIDTH				= 220;

	public static final int			MEANS_OF_TRANSPORT_COLUMN_WIDTH		= 273;

	public static final int			END_CUSTOMER_ADDRESS_COLUMN_WIDTH	= 390;

	public static final int			END_CUSTOMER_COUNTRY_COLUMN_WIDTH	= 219;

	public static final int			END_CUSTOMER_ALIAS_COLUMN_WIDTH		= 380;

	public static final String		HIDE_AND_SHOW_HEADERS				= "view.overview.header.";

	public static final String[]	DEFAULT_VISIBLE						= { ALIAS };

	public static final Object[]	DEFAULT_PROPERTY_IDS				= { ALIAS, WAGON_TYPE_NAME,
			TAGS, MILEAGE, HUMIDITY, DEVICE_TEMPERATURE, HUMIDITY_TEMPERATURE, STREET_CITY, COUNTRY,
			TIMESTAMP, BATTERY_LEVEL, TIMESTAMP_CONTACT };

	public static final Object[]	ENDCUSTOMER_PROPERTY_IDS			= { ALIAS, WAGON_TYPE_NAME,
			STREET_CITY, COUNTRY, TIMESTAMP, TIMESTAMP_CONTACT };
}
