
package com.bosch.si.amra.view.configuration;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import com.bosch.si.amra.constants.configuration.ConfigurationConstants;
import com.bosch.si.amra.entity.Tag;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.entity.configuration.Configuration;
import com.vaadin.data.Item;
import com.vaadin.data.util.BeanContainer;
import com.vaadin.data.util.GeneratedPropertyContainer;
import com.vaadin.data.util.PropertyValueGenerator;
import com.vaadin.data.util.filter.UnsupportedFilterException;

public class ConfigurationGeneratedContainer extends GeneratedPropertyContainer
{
	private static final long serialVersionUID = -1749523785053428294L;

	public ConfigurationGeneratedContainer(ConfigurationBaseContainer container,
			Collection<Wagon> wagons)
	{
		super(container);
		addGeneratedColumns(wagons);
	}

	private void addGeneratedColumns(Collection<Wagon> wagons)
	{
		addGeneratedProperty(ConfigurationConstants.WAGON_TYPE, new PropertyValueGenerator<String>()
		{
			private static final long serialVersionUID = -3009941130724161085L;

			@Override
			public String getValue(Item item, Object itemId, Object propertyId)
			{
				String alias = (String) item.getItemProperty(ConfigurationConstants.ALIAS)
						.getValue();
				Optional<Wagon> matchingWagon = wagons.stream()
						.filter(wagon -> wagon.getAlias().equals(alias)).findFirst();
				if (matchingWagon.isPresent())
				{
					return matchingWagon.get().getWagonType() != null
							? matchingWagon.get().getWagonType().getTypeName() : null;
				}
				else
				{
					return null;
				}
			}

			@Override
			public Class<String> getType()
			{
				return String.class;
			}

			@Override
			public Filter modifyFilter(Filter filter) throws UnsupportedFilterException
			{
				return filter;
			}
		});

		addGeneratedProperty(ConfigurationConstants.TAGS, new PropertyValueGenerator<List<Tag>>()
		{
			private static final long serialVersionUID = -3574705109004807259L;

			@Override
			public List<Tag> getValue(Item item, Object itemId, Object propertyId)
			{
				List<Tag> tagsValue = null;
				String alias = (String) item.getItemProperty(ConfigurationConstants.ALIAS)
						.getValue();
				Optional<Wagon> matchingWagon = wagons.stream()
						.filter(wagon -> wagon.getAlias().equals(alias)).findFirst();
				if (matchingWagon.isPresent())
				{
					tagsValue = matchingWagon.get().getTags();
				}
				return tagsValue != null ? tagsValue : new ArrayList<Tag>();
			}

			@SuppressWarnings ("unchecked")
			@Override
			public Class<List<Tag>> getType()
			{
				return (Class<List<Tag>>) (Class<?>) List.class;
			}

			@Override
			public Filter modifyFilter(Filter filter) throws UnsupportedFilterException
			{
				return filter;
			}
		});
	}

	public static class ConfigurationBaseContainer extends BeanContainer<String, Configuration>
	{
		private static final long serialVersionUID = -1749523785053428294L;

		public ConfigurationBaseContainer(Collection<Configuration> configurations)
		{
			super(Configuration.class);
			setBeanIdProperty("id");
			addAll(configurations);
		}

		@Override
		public Collection<?> getSortableContainerPropertyIds()
		{
			return Arrays.asList(ConfigurationConstants.PROPERTY_IDS);
		}
	}
}
