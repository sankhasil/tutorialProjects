
package com.bosch.si.amra.view.disponent;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.event.DashboardEvent.MaximizeDashboardPanelEvent;
import com.bosch.si.amra.event.DashboardEvent.MinimizeDashboardPanelEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Page;
import com.vaadin.server.Sizeable.Unit;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Component;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.MenuBar;
import com.vaadin.ui.MenuBar.Command;
import com.vaadin.ui.MenuBar.MenuItem;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Notification.Type;
import com.vaadin.ui.themes.ValoTheme;

/**
 * Content wrapper for custom components
 *
 * @author toa1wa3
 *
 */
public class DisponentContentWrapper
{
	private MenuBar		tools	= new MenuBar();

	private MenuItem	max;

	@SuppressWarnings ("serial")
	public Component createContentWrapper(Component content, final String code,
			String panelSlotStyle, float height)
	{
		final CssLayout slot = new CssLayout();
		slot.setWidth("100%");
		// This heigth must be set for google maps in order to be able to auto zoom the map due to
		// resizing the window
		slot.setHeight(height, Unit.PERCENTAGE);
		slot.addStyleName(panelSlotStyle);

		CssLayout card = new CssLayout();
		card.setWidth("100%");
		card.setHeight("100%");
		card.addStyleName(ValoTheme.LAYOUT_CARD);

		HorizontalLayout toolbar = new HorizontalLayout();
		toolbar.addStyleName("disponent-panel-toolbar");
		toolbar.setWidth("100%");

		Label caption = new Label(content.getCaption());
		caption.addStyleName(ValoTheme.LABEL_H4);
		caption.addStyleName(ValoTheme.LABEL_COLORED);
		caption.addStyleName(ValoTheme.LABEL_NO_MARGIN);
		content.setCaption(null);

		tools = new MenuBar();
		tools.addStyleName(ValoTheme.MENUBAR_BORDERLESS);
		MenuItem help = tools.addItem("", FontAwesome.QUESTION_CIRCLE, new Command()
		{
			@Override
			public void menuSelected(MenuItem selectedItem)
			{
				Notification notification = new Notification(
						DashboardUI.getMessageSource().getMessage("slot.help"),
						DashboardUI.getMessageSource().getMessage(code), Type.HUMANIZED_MESSAGE);
				notification.setHtmlContentAllowed(true);
				notification.show(Page.getCurrent());
			}
		});
		help.setStyleName("icon-only");
		max = tools.addItem("", FontAwesome.EXPAND, new Command()
		{

			@Override
			public void menuSelected(MenuItem selectedItem)
			{
				if (!slot.getStyleName().contains("max"))
				{
					selectedItem.setIcon(FontAwesome.COMPRESS);
					DashboardEventBus.post(new MaximizeDashboardPanelEvent(slot));
				}
				else
				{
					slot.removeStyleName("max");
					selectedItem.setIcon(FontAwesome.EXPAND);
					DashboardEventBus.post(new MinimizeDashboardPanelEvent(slot));
				}
			}
		});
		max.setStyleName("icon-only");
		MenuItem root = tools.addItem("", FontAwesome.COG, null);
		root.addItem("Configure", new Command()
		{
			@Override
			public void menuSelected(MenuItem selectedItem)
			{
				Notification.show("Not implemented in this demo");
			}
		});
		root.addSeparator();
		root.addItem("Close", new Command()
		{
			@Override
			public void menuSelected(MenuItem selectedItem)
			{
				Notification.show("Not implemented in this demo");
			}
		});

		toolbar.addComponents(caption, tools);
		toolbar.setExpandRatio(caption, 1);
		toolbar.setComponentAlignment(caption, Alignment.MIDDLE_LEFT);

		card.addComponents(toolbar, content);
		slot.addComponent(card);
		return slot;
	}

	public MenuBar getTools()
	{
		return tools;
	}

	public MenuItem getMax()
	{
		return max;
	}
}
