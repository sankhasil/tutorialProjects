
package com.bosch.si.amra.view.notification.converter;

import java.util.Locale;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.notification.Notification.Priority;
import com.vaadin.data.util.converter.Converter;

/**
 * Formats the priority according to the displaying language
 *
 * @author toa1wa3
 *
 */
public class PriorityConverter implements Converter<String, Priority>
{
	/**
	 * Serial version uid
	 */
	private static final long serialVersionUID = 7257786027863351110L;

	@Override
	public Priority convertToModel(String value, Class<? extends Priority> targetType,
			Locale locale) throws com.vaadin.data.util.converter.Converter.ConversionException
	{
		return null;
	}

	@Override
	public String convertToPresentation(Priority value, Class<? extends String> targetType,
			Locale locale) throws com.vaadin.data.util.converter.Converter.ConversionException
	{
		if (value != null)
			return DashboardUI.getMessageSource()
					.getMessage("view.notification.priority." + value.name().toLowerCase());
		return null;
	}

	@Override
	public Class<Priority> getModelType()
	{
		return Priority.class;
	}

	@Override
	public Class<String> getPresentationType()
	{
		return String.class;
	}

}
