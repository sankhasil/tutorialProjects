
package com.bosch.si.amra.constants.rule;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.bosch.si.amra.constants.MongoConstants;

public class RuleConstants
{
	public static final String				RULE_NAME					= MongoConstants.ALARM_NAME;

	public static final String				RULE_ACTIVE					= MongoConstants.ALARM_ACTIVE;

	public static final String				RULE_TYPE					= MongoConstants.ALARM_RULE_TYPE;

	public static final String				RULE_LIMIT					= MongoConstants.ALARM_LIMIT;

	public static final String				RULE_RANGE_MAX				= MongoConstants.ALARM_MAX_RANGE;

	public static final String				RULE_RANGE_MIN				= MongoConstants.ALARM_MIN_RANGE;

	public static final String				RULE_UNIT					= MongoConstants.ALARM_UNIT;

	public static final String				RULE_CONDITION				= MongoConstants.ALARM_CONDITION;

	public static final String				RULE_SEVERITY				= MongoConstants.ALARM_SEVERITY;

	public static final String				RULE_EMAIL					= "email";

	public static final String				TITLE_CAPTION				= "view.rule.caption";

	public static final String				CREATE_TOOLTIP				= "view.alarm.button.create.tooltip";

	public static final String				SAVE_TOOLTIP				= "view.alarm.button.save.tooltip";

	public static final String				EDIT_TOOLTIP				= "view.alarm.button.edit.tooltip";

	public static final String				DELETE_TOOLTIP				= "view.alarm.button.remove.tooltip";

	public static final String				COPY_TOOLTIP				= "view.alarm.button.copy.tooltip";

	public static final String				CANCEL_TOOLTIP				= "view.alarm.button.cancel.tooltip";

	public static final String				FILTER_INPUT				= "view.alarm.input.filter";

	public static final String				COLUMN_HEADER				= "view.alarm.columnheader.";

	public static final String[]			DEFAULT_COLLAPSIBLE			= { RULE_LIMIT, RULE_UNIT,
			RULE_RANGE_MIN, RULE_RANGE_MAX, RULE_CONDITION, RULE_SEVERITY };

	public static final Object[]			VISIBLE_PROPERTY_IDS		= { RULE_NAME, RULE_ACTIVE,
			RULE_TYPE, RULE_CONDITION, RULE_LIMIT, RULE_RANGE_MIN, RULE_RANGE_MAX, RULE_UNIT,
			RULE_SEVERITY };

	public static final Object[]			PROPERTY_IDS				= { RULE_NAME, RULE_ACTIVE,
			RULE_TYPE, RULE_CONDITION, RULE_LIMIT, RULE_UNIT, RULE_RANGE_MIN, RULE_RANGE_MAX,
			RULE_SEVERITY, RULE_EMAIL };

	public static final String				COPY_POST_FIX				= "view.alarm.copy.postfix";

	public static final String				HUMIDITY_TEMPERATURE_RANGE	= "HTR";

	// public static final String IN_RANGE = "range.in";
	public static final String				OUT_RANGE					= "range.out";

	public static final Map<String, String>	MAPPING;

	static
	{
		Map<String, String> map = new HashMap<String, String>();
		map.put(RULE_NAME, MongoConstants.SORT);
		map.put(RULE_ACTIVE, MongoConstants.ALARM_ACTIVE);
		map.put(RULE_TYPE, MongoConstants.ALARM_RULE_TYPE);
		map.put(RULE_LIMIT, MongoConstants.ALARM_LIMIT);
		map.put(RULE_RANGE_MIN, MongoConstants.ALARM_MIN_RANGE);
		map.put(RULE_RANGE_MAX, MongoConstants.ALARM_MAX_RANGE);
		map.put(RULE_UNIT, MongoConstants.ALARM_UNIT);
		map.put(RULE_CONDITION, MongoConstants.ALARM_CONDITION);
		map.put(RULE_SEVERITY, MongoConstants.ALARM_SEVERITY);
		MAPPING = Collections.unmodifiableMap(map);
	}

	public static final Map<Boolean, Integer> ASCENDING;

	static
	{
		Map<Boolean, Integer> map = new HashMap<Boolean, Integer>();
		map.put(true, 1);
		map.put(false, -1);
		ASCENDING = Collections.unmodifiableMap(map);
	}

}
