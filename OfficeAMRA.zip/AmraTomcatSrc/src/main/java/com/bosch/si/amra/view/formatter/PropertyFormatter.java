
package com.bosch.si.amra.view.formatter;

import com.bosch.si.amra.constants.configuration.ConfigurationConstants;
import com.bosch.si.amra.constants.overview.OverviewConstants;
import com.bosch.si.amra.constants.rule.RuleConstants;
import com.vaadin.data.Property;

public abstract class PropertyFormatter
{
	public static PropertyFormatter getFormatter(Object colId)
	{
		switch ((String) colId)
		{
			case OverviewConstants.ALIAS:
				return new AliasFormatter();
			case ConfigurationConstants.HUMIDITY:
			case ConfigurationConstants.HUMIDITY_TEMPERATURE:
			case ConfigurationConstants.TEMPERATURE:
			case ConfigurationConstants.DEVICE_TEMPERATURE:
			case ConfigurationConstants.ROUTING:
				return new SensorFormatter();
			case ConfigurationConstants.SHOCK_X:
			case ConfigurationConstants.SHOCK_Y:
			case ConfigurationConstants.SHOCK_Z:
				return new ShockFormatter();
			case ConfigurationConstants.GPS_MOVING:
			case ConfigurationConstants.GPS_TIME_BASED:
			case ConfigurationConstants.GSM_MOVING:
			case ConfigurationConstants.GSM_TIME_BASED:
				return new SendingIntervalFormatter();
			case ConfigurationConstants.FLASH_DATA:
				return new FlashDataFormatter();
			case RuleConstants.RULE_NAME:
				return new RuleNameFormatter();
			case RuleConstants.RULE_SEVERITY:
				return new RuleSeverityFormatter();
			case RuleConstants.RULE_ACTIVE:
				return new RuleActiveFormatter();
			case RuleConstants.RULE_TYPE:
				return new RuleTypeFormatter();
			case RuleConstants.RULE_UNIT:
				return new RuleUnitFormatter();
			case RuleConstants.RULE_CONDITION:
				return new RuleConditionFormatter();
			default:
				return new DefaultFormatter();
		}
	}

	public abstract String format(Object rowId, Property<?> property, String result);
}
