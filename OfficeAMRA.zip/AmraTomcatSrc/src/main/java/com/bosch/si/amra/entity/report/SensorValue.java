
package com.bosch.si.amra.entity.report;

import java.io.Serializable;
import java.util.Date;

import com.bosch.si.amra.constants.UIConstants;

/**
 * Represents a value returned from the aggreagtion for displaying the reports of event data
 * 
 * @author toa1wa3
 * 
 */
public class SensorValue implements Serializable
{

	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= -1487687148597685109L;

	private Date				timestamp;

	private Integer				temperature;

	private Integer				humidityTemperature;

	private Integer				humidity;

	private String				city;

	public SensorValue()
	{

	}

	public Date getTimestamp()
	{
		return timestamp;
	}

	public void setTimestamp(Date timestamp)
	{
		this.timestamp = timestamp;
	}

	public Integer getTemperature()
	{
		return temperature;
	}

	public void setTemperature(Integer temperature)
	{
		this.temperature = temperature;
	}

	public void setHumidityTemperature(Integer humidityTemperature)
	{
		if (UIConstants.LOWERLIMIT_HUMIDITYTEMPERATURE <= humidityTemperature.intValue()
				&& humidityTemperature.intValue() <= UIConstants.UPPERLIMIT_HUMIDITYTEMPERATURE)
		{
			this.humidityTemperature = humidityTemperature;
		}
		else
		{
			this.humidityTemperature = null;
		}
	}

	public Integer getHumidityTemperature()
	{
		return humidityTemperature;
	}

	public Integer getHumidity()
	{
		return humidity;
	}

	public void setHumidity(Integer humidity)
	{
		if (UIConstants.LOWERLIMIT_HUMIDITY <= humidity.intValue()
				&& humidity.intValue() <= UIConstants.UPPERLIMIT_HUMIDITY)
		{
			this.humidity = humidity;
		}
		else
		{
			this.humidity = null;
		}
	}

	public String getCity()
	{
		return city;
	}

	public void setCity(String city)
	{
		this.city = city;
	}
}
