
package com.bosch.si.amra.presenter.configuration;

import java.util.List;

import com.bosch.si.amra.entity.configuration.Configuration;
import com.bosch.si.amra.event.DashboardEvent.ConfigurationSortAndFilterEvent;
import com.bosch.si.amra.event.DashboardEvent.ConfigurationsEvent;
import com.bosch.si.amra.event.DashboardEvent.ConfigurationsSaveAliasEvent;
import com.bosch.si.amra.event.DashboardEvent.ConfigurationsSaveEvent;
import com.google.common.eventbus.Subscribe;
import com.mongodb.WriteResult;

/**
 * Interface for {@link ConfigurationPresenterImpl}. This is need for Spring because the actual
 * bean instance is a JDK dynamic proxy which implements ths interface and calls the concrete
 * implementation
 *
 * @author toa1wa3
 *
 */
public interface ConfigurationPresenter
{
	/**
	 * Retrieves the configurations for the given tenant
	 *
	 * @param event
	 *            {@link ConfigurationsEvent} contains tenantId
	 * @return Retrieved configurations for the given tenant
	 */
	@Subscribe
	public List<Configuration> getConfigurations(ConfigurationsEvent event);

	/**
	 * Stores the configuration for means of transport
	 *
	 * @param event
	 *            {@link ConfigurationsSaveEvent}
	 */
	@Subscribe
	public void saveConfigurations(ConfigurationsSaveEvent event);

	/**
	 * Stores the alias changes of configurations
	 *
	 * @param event
	 *            {@link ConfigurationsSaveAliasEvent}
	 * @return Stores the alias changes of configurations and returns the WriteResult
	 */
	@Subscribe
	public WriteResult saveAliasInConfigurations(ConfigurationsSaveAliasEvent event);

	/**
	 * Sorts the configurations according to the given property and the ordering
	 *
	 * @param event
	 *            {@link ConfigurationSortAndFilterEvent}. Contains the property, the order, the
	 *            tenant ID and optional the filter text to sort
	 * @return Sorted list of configurations
	 */
	@Subscribe
	public List<Configuration> sortAndFilter(ConfigurationSortAndFilterEvent event);
}
