
package com.bosch.si.amra.provider.rule;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.constants.UIConstants;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.entity.rule.Rule;
import com.bosch.si.amra.provider.DataProviderInitializer;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

@Component
public class RuleDataProvider
{
	public List<Rule> getRules(String tenantId)
	{
		if (tenantId == null || tenantId.isEmpty())
		{
			throw new IllegalArgumentException(UIConstants.TENANT_ID_MUST_NOT_BE_NULL);
		}
		DBCursor ruleCursor = getRuleCursor(tenantId);
		return transformDBobject2Rule(ruleCursor);
	}

	private DBCursor getRuleCursor(String tenantId)
	{
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection ruleCollection = db.getCollection(DashboardUI.getRuleCollection());

		DBObject match = new BasicDBObject(MongoConstants.TENANT_ID, tenantId);

		return ruleCollection.find(match).sort(new BasicDBObject(MongoConstants.SORT, 1));
	}

	public List<Rule> transformDBobject2Rule(DBCursor ruleCursor)
	{
		List<Rule> ruleList = new ArrayList<Rule>();
		while (ruleCursor.hasNext())
		{
			DBObject ruleObject = ruleCursor.next();
			Rule rule = Rule.dbObject2Rule(ruleObject);
			ruleList.add(rule);
		}
		return ruleList;
	}

	/**
	 * Returns all those wagons of the target rule which are already assigned to some other rule
	 * from the same 'ruleType' as the target rule.
	 * 
	 * @param tenantId
	 *            The tenant's id.
	 * @param targetRule
	 *            The desired rule.
	 * @return A set of wagons which are already assigned to some other rule from the same
	 *         'ruleType'.
	 */
	public Set<Wagon> getAlreadyAssignedWagonsToRules(String tenantId, Rule targetRule)
	{

		List<Rule> rulesWithAssignedWagons = getRulesWithSameRuleTypeAndAssignedWagons(tenantId,
				targetRule);
		Set<Wagon> alreadyAssignedWagons = new HashSet<>();
		rulesWithAssignedWagons.forEach(rule -> alreadyAssignedWagons.addAll(
				rule.getWagons().stream().filter(wagon -> targetRule.getWagons().contains(wagon))
						.collect(Collectors.toList())));
		return alreadyAssignedWagons;
	}

	/**
	 * Returns the rules from the same rule type as the target rule and which have assigned at least
	 * one wagon as the assigned wagons to the target rule.
	 * 
	 * @param tenantId
	 *            The tenant's id.
	 * @param targetRule
	 *            The desired rule.
	 * @return A list of rules which comply with the criteria.
	 */
	public List<Rule> getRulesWithSameRuleTypeAndAssignedWagons(String tenantId, Rule targetRule)
	{
		BasicDBList wagonIds = new BasicDBList();
		targetRule.getWagons().forEach(wagon -> wagonIds.add(wagon.getId()));

		DBObject match = new BasicDBObject();
		match.put(MongoConstants.TENANT_ID, tenantId);
		match.put(MongoConstants.ID, new BasicDBObject("$ne", targetRule.getId()));
		match.put(MongoConstants.ALARM_RULE_TYPE, targetRule.getRuleType());
		match.put(MongoConstants.RULE_WAGONS + "." + MongoConstants.WAGON_ID,
				new BasicDBObject("$in", wagonIds));

		DBCollection ruleCollection = DataProviderInitializer
				.getCollection(DashboardUI.getRuleCollection());
		DBCursor ruleCursor = ruleCollection.find(match)
				.sort(new BasicDBObject(MongoConstants.SORT, 1));
		List<Rule> resultRules = transformDBobject2Rule(ruleCursor);
		return resultRules;
	}

}
