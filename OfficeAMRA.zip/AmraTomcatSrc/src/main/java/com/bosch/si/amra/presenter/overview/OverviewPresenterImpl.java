
package com.bosch.si.amra.presenter.overview;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.constants.UIConstants;
import com.bosch.si.amra.entity.Tag;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.event.DashboardEvent.DeleteTagEvent;
import com.bosch.si.amra.event.DashboardEvent.TagAssignChangeEvent;
import com.bosch.si.amra.event.DashboardEvent.TagCreateOrUpdateEvent;
import com.bosch.si.amra.event.DashboardEvent.TagSaveStatusEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.provider.DataProviderInitializer;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.DuplicateKeyException;
import com.mongodb.MongoClient;
import com.mongodb.util.JSON;

/**
 * Implementation of overview presenter
 *
 * @author toa1wa3
 *
 */
@Component
public class OverviewPresenterImpl implements OverviewPresenter, Serializable
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= 2032433891620439397L;

	private static final Logger	logger				= LoggerFactory
			.getLogger(OverviewPresenterImpl.class);

	/**
	 * This method is used for creating or updating the tag information.
	 *
	 * @param event
	 *            TagCreateOrUpdateEvent
	 */
	@Override
	public void createOrUpdateTag(TagCreateOrUpdateEvent event)
	{
		String tenantId = event.getTenantId();
		Tag tag = event.getTag();
		isTenantNull(tenantId);
		if (tag != null)
		{
			DBObject tagDbObject = Tag.tag2DBObject(tag);
			// TODO change the log level to "debug" later.
			logger.info("created or updated tag : {}", JSON.serialize(tagDbObject).toString());
			DBCollection tagCollection = getTagCollection();
			try
			{
				tagCollection.save(tagDbObject);
				if (StringUtils.isNotEmpty(tag.getId()) && tag.isAssigned())
				{
					DBCollection wagonCollection = getWagonCollection();
					DBCollection currentCollection = getCurrentCollection();
					DBObject queryForFind = new BasicDBObject(
							MongoConstants.WAGON_TAG + "." + MongoConstants.ID, tag.getId());
					Map<String, String> tagMapForUpdating = new HashMap<String, String>();
					tagMapForUpdating.put(
							MongoConstants.WAGON_TAG + ".$." + MongoConstants.TAG_NAME,
							tag.getTagName());
					tagMapForUpdating.put(MongoConstants.WAGON_TAG + ".$." + MongoConstants.SORT,
							tag.getTagName().toLowerCase());
					DBObject queryForUpdate = new BasicDBObject("$set",
							new BasicDBObject(tagMapForUpdating));
					currentCollection.update(queryForFind, queryForUpdate, false, true);
					wagonCollection.update(queryForFind, queryForUpdate, false, true);

				}
				DashboardEventBus.post(new TagSaveStatusEvent(tag, true, ""));
			}
			catch (DuplicateKeyException de)
			{
				DashboardEventBus.post(new TagSaveStatusEvent(tag, false, de.getMessage()));
				logger.debug("Tag {} already exists for the tenant {}", tag.getTagName(), tenantId);
				logger.error(de.getMessage());
			}
		}

	}

	/**
	 * This mehtod is used for assign or unassign tag(s) to/from wagon(s)
	 *
	 * @param event
	 *            TagAssignChangeEvent
	 */
	@Override
	public void changeTagAssignmentToWagon(TagAssignChangeEvent event)
	{
		List<Wagon> wagonsToSaveWithAssignedTags = event.getListOfWagons();
		DBCollection wagonCollection = getWagonCollection();
		DBCollection currentCollection = getCurrentCollection();
		wagonsToSaveWithAssignedTags.forEach(wagon -> {
			DBObject queryToWagon = new BasicDBObject(MongoConstants.ID, wagon.getId())
					.append(MongoConstants.TENANT_ID, wagon.getTenantId());
			DBObject tagListObject = null;

			if (event.isAssignFlag())
				tagListObject = new BasicDBObject("$addToSet", new BasicDBObject(
						MongoConstants.WAGON_TAG,
						new BasicDBObject("$each", buildTagListObject(event.getSelectedTags()))));
			else
				tagListObject = new BasicDBObject("$pull",
						new BasicDBObject(MongoConstants.WAGON_TAG,
								buildTagListIdsForRemove(event.getSelectedTags())));
			wagonCollection.update(queryToWagon, tagListObject, false, true);
			currentCollection.update(queryToWagon, tagListObject, false, true);
			// TODO change the log level to "debug" later.
			logger.info("{} wagon to be assign/unassign with {} Tag", wagon.getAlias(),
					event.getSelectedTags().stream().map(tag -> tag.getTagName())
							.collect(Collectors.toList()));
		});

		if (!wagonsToSaveWithAssignedTags.isEmpty())
			updateTagCollectionForAssignUnassign(event);
	}

	/**
	 * Method to update tag collection for assigns and unassigns
	 *
	 * @param event
	 *            TagAssignChangeEvent
	 */
	private void updateTagCollectionForAssignUnassign(TagAssignChangeEvent event)
	{
		DBCollection tagCollection = getTagCollection();
		DBObject tagUpdateObject = new BasicDBObject(MongoConstants.TAG_ASSIGNED,
				event.isAssignFlag());
		BasicDBList toAssignTagList = new BasicDBList();
		List<String> filteredTagIds = null;
		if (event.isAssignFlag())
			filteredTagIds = event.getSelectedTags().stream()
					.filter(tagObject -> !tagObject.isAssigned())
					.map(tagMapper -> tagMapper.getId()).collect(Collectors.toList());
		else
			filteredTagIds = event.getSelectedTags().stream()
					.filter(tagObject -> tagObject.isAssigned() && !event.getListOfWagons().stream()
							.anyMatch(wagonMatch -> wagonMatch.getTags().contains(tagObject)))
					.map(tagMapper -> tagMapper.getId()).collect(Collectors.toList());

		toAssignTagList.addAll(filteredTagIds);
		// TODO change the log level to "debug" later.
		logger.info("{} tags updated for Assigned flag", filteredTagIds);

		if (filteredTagIds != null && !filteredTagIds.isEmpty())
			tagCollection.update(
					new BasicDBObject(MongoConstants.ID, new BasicDBObject("$in", toAssignTagList)),
					new BasicDBObject("$set", tagUpdateObject), false, true);

	}

	@Override
	public void deleteTags(DeleteTagEvent event)
	{
		List<Tag> tagListFromEvent = event.getTagListToDelete();
		DBCollection tagCollection = getTagCollection();
		if (tagListFromEvent.size() > 0)
		{
			DBObject removeQuery = buildTagListIdsForRemove(tagListFromEvent);
			tagCollection.remove(removeQuery);
			logger.info("{} is/are removed.", tagListFromEvent.stream().map(tag -> tag.getTagName())
					.collect(Collectors.toList()));
		}
	}

	private static DBObject buildTagListObject(List<Tag> tags)
	{
		BasicDBList tagObjectList = new BasicDBList();
		tags.stream().filter(tag -> !tag.getId().isEmpty()).forEach(eachTag -> {
			DBObject tagObject = new BasicDBObject(MongoConstants.ID, eachTag.getId());
			tagObject.put(MongoConstants.TAG_NAME, eachTag.getTagName());
			tagObject.put(MongoConstants.SORT, eachTag.getTagName().toLowerCase());
			tagObjectList.add(tagObject);
		});

		return tagObjectList;
	}

	private DBObject buildTagListIdsForRemove(List<Tag> listOfTags)
	{
		return new BasicDBObject(MongoConstants.ID,
				new BasicDBObject("$in", listOfTags.stream().map(tagMapper -> tagMapper.getId())
						.collect(Collectors.toCollection(BasicDBList::new))));
	}

	private void isTenantNull(String tenantId)
	{
		if (tenantId == null || tenantId.isEmpty())
		{
			throw new IllegalArgumentException(UIConstants.TENANT_ID_MUST_NOT_BE_NULL);
		}
	}

	private DB getMongoDBObject()
	{
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		return db;
	}

	private DBCollection getCurrentCollection()
	{

		return getMongoDBObject().getCollection(DashboardUI.getMongoCurrentCollection());
	}

	private DBCollection getTagCollection()
	{
		return getMongoDBObject().getCollection(DashboardUI.getMongoTagCollection());
	}

	private DBCollection getWagonCollection()
	{
		return getMongoDBObject().getCollection(DashboardUI.getWagonCollection());
	}

}
