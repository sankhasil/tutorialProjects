/**
 * 
 */

package com.bosch.si.amra.view.overview;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.NoSuchElementException;

import org.apache.commons.lang3.StringUtils;

import com.bosch.si.amra.entity.Tag;
import com.vaadin.data.util.converter.Converter;

/**
 * @author ils5kor
 *
 */
public class TagListToTagNameConverter implements Converter<String, ArrayList<Tag>>
{

	private static final long	serialVersionUID	= -7950935100304943929L;

	private ArrayList<Tag>		listOfTag;

	@Override
	public String convertToPresentation(ArrayList<Tag> value, Class<? extends String> targetType,
			Locale locale) throws Converter.ConversionException
	{

		try
		{
			listOfTag = value;
			return value.stream()
					.filter(element -> element != null
							&& StringUtils.isNotEmpty(element.getTagName()))
					.map(tagMapper -> tagMapper.getTagName())
					.reduce((firstTag, secondTag) -> firstTag + "," + secondTag).get();
		}
		catch (NoSuchElementException e)
		{
			return "";
		}
	}

	@Override
	public ArrayList<Tag> convertToModel(String value, Class<? extends ArrayList<Tag>> targetType,
			Locale locale) throws com.vaadin.data.util.converter.Converter.ConversionException
	{
		return listOfTag;
	}

	@Override
	public Class<ArrayList<Tag>> getModelType()
	{
		return (Class<ArrayList<Tag>>) (Class<?>) List.class;
	}

	@Override
	public Class<String> getPresentationType()
	{
		return String.class;
	}

}
