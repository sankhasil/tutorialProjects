
package com.bosch.si.amra.view.notification.grid;

import java.util.Arrays;
import java.util.Collection;

import com.bosch.si.amra.constants.notification.NotificationConstants;
import com.bosch.si.amra.entity.notification.Notification;
import com.vaadin.data.util.BeanItemContainer;

public class NotificationContainer extends BeanItemContainer<Notification>
{
	/**
	 * Serial version uid
	 */
	private static final long serialVersionUID = 4822821758860373405L;

	public NotificationContainer(Class<? super Notification> type,
			Collection<? extends Notification> collection) throws IllegalArgumentException
	{
		super(type, collection);
		addNestedContainerProperty(NotificationConstants.LATITUDE);
		addNestedContainerProperty(NotificationConstants.LONGITUDE);
		addNestedContainerProperty(NotificationConstants.COUNTRY);
		addNestedContainerProperty(NotificationConstants.STREET_CITY);
		addNestedContainerProperty(
				NotificationConstants.RULE + "." + NotificationConstants.RULETYPE);
	}

	@Override
	public Collection<?> getSortableContainerPropertyIds()
	{
		return Arrays.asList(NotificationConstants.PROPERTY_IDS);
	}
}
