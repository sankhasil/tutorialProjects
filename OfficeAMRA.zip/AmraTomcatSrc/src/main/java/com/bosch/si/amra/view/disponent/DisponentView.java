
package com.bosch.si.amra.view.disponent;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.common.GoogleMapUtilFactory;
import com.bosch.si.amra.common.UserSettingsStorer;
import com.bosch.si.amra.component.OpenInfoWindowOnMarkerClickListener;
import com.bosch.si.amra.component.filter.TimestampFilter;
import com.bosch.si.amra.component.grid.HistoryGrid;
import com.bosch.si.amra.component.grid.OverviewGrid;
import com.bosch.si.amra.component.map.CustomizedGoogleMapInfoWindow;
import com.bosch.si.amra.component.map.Map;
import com.bosch.si.amra.constants.UIConstants;
import com.bosch.si.amra.constants.disponent.DisponentViewConstants;
import com.bosch.si.amra.constants.overview.OverviewConstants;
import com.bosch.si.amra.entity.LatLong;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.event.DashboardEvent;
import com.bosch.si.amra.event.DashboardEvent.MapFilterEvent;
import com.bosch.si.amra.event.DashboardEvent.MaximizeDashboardPanelEvent;
import com.bosch.si.amra.event.DashboardEvent.MinimizeDashboardPanelEvent;
import com.bosch.si.amra.event.DashboardEvent.SaveUserSettingsEvent;
import com.bosch.si.amra.event.DashboardEvent.WagonSetEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.im.login.Role;
import com.bosch.si.amra.im.login.Role.Roles;
import com.bosch.si.amra.view.overview.OverviewContainer;
import com.bosch.si.amra.view.overview.OverviewGridFilterComponent.OverviewFilter;
import com.bosch.si.amra.view.overview.OverviewGridFilterComponent.OverviewTagFilter;
import com.bosch.si.amra.view.overview.OverviewGridFilterComponent.SearchFilter;
import com.google.common.eventbus.Subscribe;
import com.vaadin.data.sort.SortOrder;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.event.ShortcutListener;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.server.Page;
import com.vaadin.server.Responsive;
import com.vaadin.server.VaadinSession;
import com.vaadin.tapio.googlemaps.client.LatLon;
import com.vaadin.tapio.googlemaps.client.overlays.GoogleMapMarker;
import com.vaadin.ui.Component;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.DateField;
import com.vaadin.ui.Grid.SelectionMode;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Notification.Type;
import com.vaadin.ui.Panel;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

@Role ({ Roles.ENDCUSTOMER, Roles.USER, Roles.FLEETADMIN, Roles.SYSTEMADMIN, })
@SuppressWarnings ("serial")
public class DisponentView extends Panel implements View
{
	private final User						user	= (User) VaadinSession.getCurrent()
			.getAttribute(User.class.getName());

	private List<Wagon>						wagons;

	private final VerticalLayout			root;

	private CssLayout						disponentPanels;

	private Map								map;

	private HistoryGrid						historyGrid;

	private OverviewGrid					overviewGrid;

	private CustomizedGoogleMapInfoWindow	selectedInfoWindow;

	private Wagon							selectedWagon;

	public DisponentView()
	{
		wagons = DashboardUI.getDataProvider().getWagonsWithCurrentValues(user);

		addStyleName(ValoTheme.PANEL_BORDERLESS);
		setSizeFull();
		DashboardEventBus.register(this);

		root = new VerticalLayout();
		root.setSizeFull();
		root.setMargin(true);
		root.addStyleName("disponent-view");
		setContent(root);
		Responsive.makeResponsive(root);

		root.addComponent(buildHeader());

		Component content = buildContent();
		root.addComponent(content);
		root.setExpandRatio(content, 1);

		addShortcutListener(new ShortcutListener("Clear", KeyCode.ESCAPE, null)
		{
			@SuppressWarnings ("unchecked")
			@Override
			public void handleAction(Object sender, Object target)
			{
				BeanItemContainer<Wagon> container = (BeanItemContainer<Wagon>) overviewGrid
						.getContainerDataSource();
				if (target != null && target instanceof OverviewFilter)
					((OverviewFilter) target).setValue(null);
				else if (target != null && target instanceof TimestampFilter)
					((DateField) target).setValue(null);
				else if (target != null && target instanceof OverviewTagFilter)
					((OverviewTagFilter) target).setValue(null);
				else if (target != null && target instanceof SearchFilter)
					((SearchFilter) target).setValue("");
				Object pid = overviewGrid.getComponentToPidMap().get(target);
				if (pid != null)
					container.removeContainerFilters(pid);
				DashboardEventBus.post(new MapFilterEvent());
			}
		});
	}

	private Component buildHeader()
	{
		HorizontalLayout header = new HorizontalLayout();
		header.addStyleName("viewheader");
		header.setSpacing(true);

		Label titleLabel = new Label(
				DashboardUI.getMessageSource().getMessage("view.disponent.caption"));
		titleLabel.setSizeUndefined();
		titleLabel.addStyleName(ValoTheme.LABEL_H1);
		titleLabel.addStyleName(ValoTheme.LABEL_NO_MARGIN);
		header.addComponent(titleLabel);

		HorizontalLayout tools = new HorizontalLayout();
		tools.setSpacing(true);
		tools.addStyleName("toolbar");
		header.addComponent(tools);

		return header;
	}

	private Component buildContent()
	{
		disponentPanels = new CssLayout();
		disponentPanels.addStyleName("disponent-panels");
		Responsive.makeResponsive(disponentPanels);

		disponentPanels.addComponent(buildHistory());
		disponentPanels.addComponent(buildMap());
		disponentPanels.addComponent(buildOverview());

		return disponentPanels;
	}

	private Component buildHistory()
	{
		BeanItemContainer<Wagon> telematicContainer = new BeanItemContainer<Wagon>(Wagon.class);
		telematicContainer.addNestedContainerProperty(OverviewConstants.STREET_CITY);
		telematicContainer.addNestedContainerProperty(OverviewConstants.COUNTRY);
		historyGrid = new HistoryGrid(telematicContainer);
		historyGrid.addSelectionListener(listener -> {
			closeAllInfoWindows();
			map.clearMarkers();
			if (listener.getSelected().isEmpty())
			{
				map.setInfowindow(null);
				if (selectedWagon != null)
				{
					DashboardEventBus.post(new MapFilterEvent());
					centerMapOnSelectedWagon(selectedWagon);
					markSelectedInfoWindow(selectedWagon);
				}
			}
			else
			{
				Wagon wagon = (Wagon) historyGrid.getSelectedRow();
				if (wagon != null)
				{

					if (wagon.getLatLong() != null)
					{
						LatLon latLon = new LatLon(wagon.getLatLong().getLat(),
								wagon.getLatLong().getLng());
						map.setInfowindow(GoogleMapUtilFactory
								.buildGoogleMapSmallInfoWindow(selectedWagon.getAlias(),
										wagon.getTimestamp(), latLon)
								.setAddress(wagon.getAddress()).setTimestamp(wagon.getTimestamp()));
						if (!map.getMarkerToggle().isChecked() || map.isMarkerToggleDefault())
							map.openInfoWindow(map.getInfowindow());
						else
						{
							Wagon newWagon = new Wagon();
							newWagon.setAlias(selectedWagon.getAlias());
							newWagon.setAddress(wagon.getAddress());
							newWagon.setTimestamp(wagon.getTimestamp());
							GoogleMapMarker mapMarker = GoogleMapUtilFactory
									.buildGoogleMapMarker(latLon, selectedWagon.getAlias());
							CustomizedGoogleMapInfoWindow fullInfoWindow = GoogleMapUtilFactory
									.buildGoogleMapFullInfoWindow(newWagon, latLon, mapMarker);
							map.setFullInfoWindow(fullInfoWindow);
							map.getFullGoogleMapInfoWindows().add(fullInfoWindow);
							OpenInfoWindowOnMarkerClickListener mapMarkerListner = new OpenInfoWindowOnMarkerClickListener(
									map, mapMarker, fullInfoWindow);
							map.addMarkerClickListener(mapMarkerListner);
							map.addMarker(mapMarker);
						}
						centerMapOnSelectedWagon(selectedWagon);
						map.setCenter(latLon);
					}
					else
						Notification.show(DashboardUI.getMessageSource()
								.getMessage("view.disponent.no.latlong.data"));
				}
			}
		});

		return new DisponentContentWrapper().createContentWrapper(historyGrid,
				"view.details.telematic.history.tooltip", "disponent-panel-slot", 60);
	}

	private Component buildMap()
	{
		map = new Map(wagons);
		DisponentContentWrapper wrapper = new DisponentContentWrapper();
		Component contentWrapper = wrapper.createContentWrapper(map, "view.dashboard.map.help",
				"disponent-panel-slot", 60);
		map.buildMarkerToggle(wrapper.getTools(), wrapper.getMax());
		return contentWrapper;
	}

	@SuppressWarnings ("unchecked")
	private Component buildOverview()
	{
		OverviewContainer overviewContainer = new OverviewContainer(wagons);
		overviewContainer.addNestedContainerProperty(OverviewConstants.WAGON_TYPE_NAME);
		overviewContainer.addNestedContainerProperty(OverviewConstants.STREET_CITY);
		overviewContainer.addNestedContainerProperty(OverviewConstants.COUNTRY);
		overviewContainer.addNestedContainerProperty(OverviewConstants.TAGS);
		overviewGrid = new OverviewGrid(overviewContainer, wagons);
		overviewGrid.setCaption(
				DashboardUI.getMessageSource().getMessage("view.disponent.history.caption"));
		overviewGrid.setSelectionMode(SelectionMode.SINGLE);
		overviewGrid.addSelectionListener(listener -> {
			historyGrid.deselectAll();
			if (listener.getSelected().isEmpty())
			{
				BeanItemContainer<Wagon> container = (BeanItemContainer<Wagon>) historyGrid
						.getContainerDataSource();
				map.setInfowindow(null);
				container.removeAllItems();
				selectedWagon = null;
				zoomMap();
			}
			else
			{
				selectedWagon = (Wagon) overviewGrid.getSelectedRow();
				DashboardEventBus.post(new DashboardEvent.ShowDetailsForWagonEvent(selectedWagon,
						user.getTenant()));
				if (map.getInfowindow() != null && map.isInfoWindowOpen(map.getInfowindow()))
					map.closeInfoWindow(map.getInfowindow());
			}
			DashboardEventBus.post(new MapFilterEvent());
			unmarkPreviouslySelectedInfoWindow();
			if (selectedWagon != null)
			{
				centerMapOnSelectedWagon(selectedWagon);
				markSelectedInfoWindow(selectedWagon);
			}
		});
		Arrays.asList(OverviewGrid.getColumnIds(user)).forEach(propertyId -> {
			String propertyName = (String) propertyId;
			overviewGrid.getDefaultHeaderRow().getCell(propertyName).setHtml(
					DashboardUI.getMessageSource().getMessage("view.disponent.columnheader."
							+ propertyName.toString().toLowerCase()));
		});
		return new DisponentContentWrapper().createContentWrapper(overviewGrid,
				"view.disponent.overview.help", "disponent-panel-full-slot", 40);
	}

	private void unmarkPreviouslySelectedInfoWindow()
	{
		if (selectedInfoWindow != null)
			selectedInfoWindow.setLatestInfoWindow(false);
	}

	private void markSelectedInfoWindow(Wagon selectedWagon)
	{
		selectedInfoWindow = map.getSelectedInfoWindow(selectedWagon.getLatLong());
		if (selectedInfoWindow != null)
		{
			selectedInfoWindow.setLatestInfoWindow(true);
			selectedInfoWindow.setzIndex(GoogleMapUtilFactory.Z_INDEX += 2);
		}
	}

	private void centerMapOnSelectedWagon(Wagon selectedWagon)
	{
		if (selectedWagon != null && selectedWagon.getLatLong() != null)
		{
			LatLong position = selectedWagon.getLatLong();
			map.setCenter(new LatLon(position.getLat(), position.getLng()));
			map.setZoom(10);
		}
		else
		{
			Notification.show(
					DashboardUI.getMessageSource().getMessage("view.disponent.no.position.data"),
					Type.HUMANIZED_MESSAGE);
			zoomMap();
			map.markAsDirty();
		}
	}

	private void zoomMap()
	{
		List<LatLon> positions = wagons.stream().filter(wagon -> wagon.getLatLong() != null)
				.map(wagon -> new LatLon(wagon.getLatLong().getLat(), wagon.getLatLong().getLng()))
				.collect(Collectors.toList());
		GoogleMapUtilFactory.autoZoomMap(positions, map);
	}

	@SuppressWarnings ("unchecked")
	@Subscribe
	public void fillHistoryData(WagonSetEvent event)
	{
		List<Wagon> wagons = event.getWagons();
		BeanItemContainer<Wagon> container = (BeanItemContainer<Wagon>) historyGrid
				.getContainerDataSource();
		container.removeAllItems();
		container.addAll(wagons);
		sort();
	}

	private void sort()
	{
		List<SortOrder> sortOrderList = historyGrid.getSortOrder();
		if (sortOrderList != null && !sortOrderList.isEmpty())
		{
			SortOrder sortOrder = sortOrderList.get(0);
			historyGrid.sort(sortOrder.getPropertyId(), sortOrder.getDirection());
		}
	}

	@Override
	public void enter(ViewChangeEvent event)
	{
		Page.getCurrent().getStyles().add(".gm-style-iw + div {display: none;}");
		DashboardEventBus.post(new MapFilterEvent());
	}

	@Subscribe
	public void maximizePanel(MaximizeDashboardPanelEvent event)
	{
		for (Iterator<Component> it = disponentPanels.iterator(); it.hasNext();)
		{
			Component c = it.next();
			c.removeStyleName("max");
			c.setVisible(false);
		}
		event.getPanel().addStyleName("max");
		event.getPanel().setVisible(true);

		for (Iterator<Component> it = root.iterator(); it.hasNext();)
		{
			it.next().setVisible(false);
		}
		disponentPanels.setVisible(true);
	}

	@Subscribe
	public void minimizePanel(MinimizeDashboardPanelEvent event)
	{
		for (Iterator<Component> it = disponentPanels.iterator(); it.hasNext();)
		{
			Component c = it.next();
			c.removeStyleName("max");
			c.setVisible(true);
		}

		for (Iterator<Component> it = root.iterator(); it.hasNext();)
		{
			it.next().setVisible(true);
		}
	}

	@Subscribe
	public void saveSessionData(SaveUserSettingsEvent event)
	{
		UserSettingsStorer.saveSessionUserSettings(overviewGrid,
				UIConstants.DISPONENT_VIEW_SESSION_OBJECT);
		UserSettingsStorer.saveSessionUserSettings(historyGrid,
				UIConstants.DISPONENT_HISTORY_SESSION_OBJECT);
	}

	@Subscribe
	public void filterMap(MapFilterEvent event)
	{
		List<String> aliasList = getFilteredWagonAliasList(
				(BeanItemContainer<Wagon>) overviewGrid.getContainerDataSource());
		closeAllInfoWindows();
		map.clearMarkers();
		if (aliasList != null && !aliasList.isEmpty())
		{
			if (!map.getMarkerToggle().isChecked() || map.isMarkerToggleDefault())
			{
				map.getGoogleMapInfoWindows().forEach(infoWindow -> {
					if (aliasList.contains(infoWindow.getAlias()))
						map.openInfoWindow(infoWindow);
				});
				unmarkPreviouslySelectedInfoWindow();
			}
			else
			{
				map.getGoogleMapInfoWindows().forEach(infoWindow -> {
					if (aliasList.contains(infoWindow.getAlias()))
					{
						GoogleMapMarker mapMarker = GoogleMapUtilFactory.buildGoogleMapMarker(
								infoWindow.getPosition(), infoWindow.getAlias());
						CustomizedGoogleMapInfoWindow fullInfoWindowForMarker = GoogleMapUtilFactory
								.buildGoogleMapFullInfoWindow(
										getWagonByAlias(
												(BeanItemContainer<Wagon>) overviewGrid
														.getContainerDataSource(),
												infoWindow.getAlias()),
										infoWindow.getPosition(), mapMarker);
						OpenInfoWindowOnMarkerClickListener mapMarkerListner = new OpenInfoWindowOnMarkerClickListener(
								map, mapMarker, fullInfoWindowForMarker);
						map.getFullGoogleMapInfoWindows().add(fullInfoWindowForMarker);
						map.addMarkerClickListener(mapMarkerListner);
						map.addMarker(mapMarker);
						map.setCenter(infoWindow.getPosition());
					}
				});
			}
			map.setAliasList(aliasList);
			map.getMarkerToggle().setEnabled(true);
		}
		else
			map.getMarkerToggle().setEnabled(false);

	}

	public void closeAllInfoWindows()
	{
		map.getGoogleMapInfoWindows().forEach(infowindow -> {
			map.closeInfoWindow(infowindow);
		});
		map.getFullGoogleMapInfoWindows().forEach(infowindow -> {
			map.closeInfoWindow(infowindow);
		});
		if (map.getInfowindow() != null)
			map.closeInfoWindow(map.getInfowindow());
		if (map.getFullInfoWindow() != null)
			map.closeInfoWindow(map.getFullInfoWindow());
	}

	private static List<String> getFilteredWagonAliasList(
			BeanItemContainer<Wagon> wagonGridCurrentContainer)
	{
		return wagonGridCurrentContainer.getItemIds().stream().map(wagon -> wagon.getAlias())
				.collect(Collectors.toList());
	}

	private static Wagon getWagonByAlias(BeanItemContainer<Wagon> wagonGridCurrentContainer,
			String alias)
	{
		return wagonGridCurrentContainer.getItemIds().stream()
				.filter(wagon -> wagon.getAlias().equals(alias)).collect(Collectors.toList())
				.get(0);
	}

	@Override
	public void attach()
	{
		super.attach();
		UserSettingsStorer.fetchSessionUserSettings(overviewGrid,
				UIConstants.DISPONENT_VIEW_SESSION_OBJECT, OverviewGrid.getColumnIds(user));
		UserSettingsStorer.fetchSessionUserSettings(historyGrid,
				UIConstants.DISPONENT_HISTORY_SESSION_OBJECT, DisponentViewConstants.PROPERTY_IDS);
	}

	@Override
	public void detach()
	{
		super.detach();
		DashboardEventBus.unregister(this);
		UserSettingsStorer.saveSessionUserSettings(overviewGrid,
				UIConstants.DISPONENT_VIEW_SESSION_OBJECT);
		UserSettingsStorer.saveSessionUserSettings(historyGrid,
				UIConstants.DISPONENT_HISTORY_SESSION_OBJECT);
	}
}
