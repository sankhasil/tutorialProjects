
package com.bosch.si.amra.entity;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

public class WagonUser
{
	private String	userId;

	private String	userName;

	private boolean	isEndCustomer;

	private Date	activationTime;

	private String	wagonId;

	private String	wagonAlias;

	public WagonUser(String userId, String userName, boolean isEndCustomer, Date activationTime,
			String wagonId, String wagonAlias)
	{
		this.userId = userId;
		this.userName = userName;
		this.isEndCustomer = isEndCustomer;
		this.activationTime = activationTime;
		this.wagonId = wagonId;
		this.wagonAlias = wagonAlias;
	}

	public String getUserId()
	{
		return userId;
	}

	public void setUserId(String userId)
	{
		this.userId = userId;
	}

	public String getUserName()
	{
		return userName;
	}

	public void setUserName(String userName)
	{
		this.userName = userName;
	}

	public boolean isEndCustomer()
	{
		return isEndCustomer;
	}

	public void setEndCustomer(boolean isEndCustomer)
	{
		this.isEndCustomer = isEndCustomer;
	}

	public Date getActivationTime()
	{
		return activationTime;
	}

	public void setActivationTime(Date activationTime)
	{
		this.activationTime = activationTime;
	}

	public String getWagonId()
	{
		return wagonId;
	}

	public void setWagonId(String wagonId)
	{
		this.wagonId = wagonId;
	}

	public String getWagonAlias()
	{
		return wagonAlias;
	}

	public void setWagonAlias(String wagonAlias)
	{
		this.wagonAlias = wagonAlias;
	}

	public String getDescription()
	{
		return formatDescription(userName, isEndCustomer, activationTime);
	}

	public static String formatDescription(String name, boolean isEndCustomer, Date activationDate)
	{
		StringBuilder sb = new StringBuilder();
		sb.append(name);
		if (isEndCustomer)
		{
			sb.append(" ");
			sb.append("\ud83d\udc64");
		}

		if (activationDate != null)
		{
			SimpleDateFormat dateFormater = new SimpleDateFormat(
					DashboardUI.getMessageSource().getMessage("date.format.picker"));
			dateFormater.setTimeZone(DashboardUI.getUserTimeZone());
			sb.append(" [").append(dateFormater.format(activationDate)).append("]");
		}

		return sb.toString();
	}

	public static DBObject user2DBObject(WagonUser wagon2User)
	{
		DBObject dbObject = null;
		if (wagon2User != null)
		{
			dbObject = new BasicDBObject(MongoConstants.ID, wagon2User.getUserId());
			dbObject.put(MongoConstants.ALIAS, wagon2User.getUserName());
			if (wagon2User.getActivationTime() != null)
			{
				dbObject.put(MongoConstants.ACTIVATION_TIME,
						wagon2User.getActivationTime().getTime());
			}
		}
		return dbObject;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		result = prime * result + ((userName == null) ? 0 : userName.hashCode());
		result = prime * result + ((wagonId == null) ? 0 : wagonId.hashCode());
		result = prime * result + ((wagonAlias == null) ? 0 : wagonAlias.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		WagonUser other = (WagonUser) obj;
		if (userId == null)
		{
			if (other.userId != null)
				return false;
		}
		else if (!userId.equals(other.userId))
			return false;

		if (userName == null)
		{
			if (other.userName != null)
				return false;
		}
		else if (!userName.equals(other.userName))
			return false;

		if (wagonId == null)
		{
			if (other.wagonId != null)
				return false;
		}
		else if (!wagonId.equals(other.wagonId))
			return false;

		if (wagonAlias == null)
		{
			if (other.wagonAlias != null)
				return false;
		}
		else if (!wagonAlias.equals(other.wagonAlias))
			return false;

		return true;
	}
}
