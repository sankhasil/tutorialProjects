
package com.bosch.si.amra.constants.configuration;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.bosch.si.amra.constants.MongoConstants;
import com.vaadin.server.FontAwesome;

public class ConfigurationConstants
{
	public static final String				ALIAS									= "alias";

	public static final String				SORT									= "sort";

	public static final String				FLASH_DATA								= "flashData";

	public static final String				STATUS									= "status";

	public static final String				HUMIDITY								= "humidity";

	public static final String				HUMIDITY_TEMPERATURE					= "humidityTemperature";

	public static final String				TEMPERATURE								= "temperature";

	public static final String				DEVICE_TEMPERATURE						= "deviceTemperature";

	public static final String				SHOCK_X									= "shockX";

	public static final String				SHOCK_Y									= "shockY";

	public static final String				SHOCK_Z									= "shockZ";

	public static final String				ROUTING									= "routing";

	public static final String				GPS_MOVING								= "gpsMoving";

	public static final String				GPS_TIME_BASED							= "gpsTimeBased";

	public static final String				GSM_MOVING								= "gsmMoving";

	public static final String				GSM_TIME_BASED							= "gsmTimeBased";

	public static final String				WAGON_TYPE								= "wagonType";

	public static final String				TAGS									= "tags";

	public static final String				TITLE_CAPTION							= "view.configuration.caption";

	public static final String				EDIT_CAPTION							= "view.configuration.checkbox.editable";

	public static final String				EDIT_TOOLTIP							= "view.configuration.checkbox.tooltip.editable";

	public static final String				SAVE_TOOLTIP							= "view.configuration.button.save.tooltip";

	public static final String				RESET_TOOLTIP							= "view.configuration.button.reset.tooltip";

	public static final String				RESET_CAPTION							= "view.configuration.button.reset.caption";

	public static final String				COLUMN_HEADER							= "view.configuration.columnheader.";

	public static final String				SUBWINDOW_COMPONENT_CAPTION				= "view.configuration.subwindow.";

	public static final Object[]			PROPERTY_IDS							= { ALIAS, TAGS,
			WAGON_TYPE, HUMIDITY, HUMIDITY_TEMPERATURE, TEMPERATURE, DEVICE_TEMPERATURE, ROUTING,
			SHOCK_X, SHOCK_Y, SHOCK_Z, GPS_MOVING, GPS_TIME_BASED, GSM_MOVING, GSM_TIME_BASED,
			FLASH_DATA, STATUS };

	public static final int					TRANSPORT_TYPE_COLUMN_WIDTH				= 230;

	public static final int					MEANS_OF_TRANSPORT_COLUMN_WIDTH			= 273;

	public static final int					DEFAULT_COLUMN_WIDTH					= 127;

	public static final String				HIDE_AND_SHOW_HEADERS					= "view.configuration.header.";

	public static final int					MINIMUM_INTERVAL						= 15 * 60;

	public static final int					MAXIMUM_INTERVAL						= 99 * 60 * 60;

	public static final int					MINIMUM_FW_VERSION						= 0;

	public static final int					MAXIMUM_FW_VERSION						= 999999;

	public static final int					MINIMUM_STATUS							= 1;

	public static final int					MAXIMUM_STATUS							= 60;

	public static final String				ON										= new String(
			Character.toChars(FontAwesome.CHECK.getCodepoint()));

	public static final String				OFF										= new String(
			Character.toChars(FontAwesome.TIMES.getCodepoint()));;

	public static final String				STYLE_GRID_TEXT_CENTER_ALIGN			= "grid-text-center-align";

	public static final String				STYLE_EDIT_TAB_TEXT_FIELD_RIGHT_ALIGN	= "editTab-text-right-align";

	public static final String				TEXT_NOT_IMPLEMEMENTED					= "Not implemented in this demo";

	public static final Map<String, String>	MAPPING;

	static
	{
		Map<String, String> map = new HashMap<String, String>();
		map.put(ALIAS, MongoConstants.SORT);
		map.put(FLASH_DATA, MongoConstants.FLASH_DATA);
		map.put(STATUS, MongoConstants.STATUS);
		map.put(HUMIDITY, MongoConstants.HUMIDITY);
		map.put(HUMIDITY_TEMPERATURE, MongoConstants.HUMIDITY_TEMPERATURE);
		map.put(TEMPERATURE, MongoConstants.TEMPERATURE);
		map.put(DEVICE_TEMPERATURE, MongoConstants.DEVICE_TEMPERATURE);
		map.put(ROUTING, MongoConstants.ROUTING);
		map.put(SHOCK_X, MongoConstants.SHOCK_X);
		map.put(SHOCK_Y, MongoConstants.SHOCK_Y);
		map.put(SHOCK_Z, MongoConstants.SHOCK_Z);
		map.put(GPS_MOVING, MongoConstants.GPS_MOVING);
		map.put(GPS_TIME_BASED, MongoConstants.GPS_TIME_BASED);
		map.put(GSM_MOVING, MongoConstants.GSM_MOVING);
		map.put(GSM_TIME_BASED, MongoConstants.GSM_TIME_BASED);
		MAPPING = Collections.unmodifiableMap(map);
	}

	public static final Map<Boolean, Integer> ASCENDING;

	static
	{
		Map<Boolean, Integer> map = new HashMap<Boolean, Integer>();
		map.put(true, 1);
		map.put(false, -1);
		ASCENDING = Collections.unmodifiableMap(map);
	}
}
