
package com.bosch.si.amra.common;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.context.NoSuchMessageException;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.component.map.CustomizedGoogleMapInfoWindow;
import com.bosch.si.amra.entity.LatLong;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.entity.notification.Address;
import com.bosch.si.amra.entity.notification.Notification;
import com.vaadin.server.Page;
import com.vaadin.tapio.googlemaps.GoogleMap;
import com.vaadin.tapio.googlemaps.client.LatLon;
import com.vaadin.tapio.googlemaps.client.overlays.GoogleMapInfoWindow;
import com.vaadin.tapio.googlemaps.client.overlays.GoogleMapMarker;
import com.vaadin.ui.JavaScriptFunction;

import elemental.json.JsonArray;

/**
 * @author toa1wa3
 *
 *         Provides methods for the google map, e.g. creating a marker, infow window with specific
 *         data
 */
public class GoogleMapUtilFactory
{
	private static final String	DECIMAL_PATTERN	= "0.0";

	private static final int	IW_MAX_WIDTH	= 140;

	private static final String	IW_HEIGHT		= "32px";

	private static final String	IW_WIDTH		= "108px";

	public static int			Z_INDEX			= 50;

	private static final double	SHIFTING_FACTOR	= 1.5;

	/**
	 * Creates a {@link LatLon} out of the latitude and longitude of the wagon's position
	 *
	 * @param position
	 *            The position of the wagon
	 * @return A {@link LatLon} with the position of the wagon
	 */
	public static LatLon buildLocation(LatLong position)
	{
		Double latitude = Double.valueOf(position.getLat());
		Double longitude = Double.valueOf(position.getLng());

		LatLon location = new LatLon(latitude.doubleValue(), longitude.doubleValue());
		return location;
	}

	/**
	 * Creates a google map marker with the location and alias from the wagon. The marker's
	 * animation is disabled
	 *
	 * @param location
	 *            The position of the wagon
	 * @param alias
	 *            The alias of the wagon
	 * @return A n animated google map marker with the position of the wagon and its alias
	 */
	public static GoogleMapMarker buildGoogleMapMarker(LatLon location, String alias)
	{
		GoogleMapMarker amraBoxLocationMarker = new GoogleMapMarker(alias, location, false, null);
		amraBoxLocationMarker.setAnimationEnabled(false);

		return amraBoxLocationMarker;
	}

	/**
	 * Building a small infow window containing the alias and timestamp to be displayed when only
	 * info windows are available
	 *
	 * The infow window is restricet in width with 104px (maximum width also) and in height with
	 * 32px.
	 * The zIndex is initially set to 50
	 *
	 * @param wagonAlias
	 *            The alias of the wagon
	 * @param timestamp
	 *            The timestamp of the wagon
	 * @param location
	 *            To position the infow window
	 * @return A small infow window with a position to display some information
	 */
	public static CustomizedGoogleMapInfoWindow buildGoogleMapSmallInfoWindow(String wagonAlias,
			Date timestamp, LatLon location)
	{
		String alias = wagonAlias.length() > 19 ? wagonAlias.substring(0, 20).concat("...")
				: wagonAlias;
		String html = "<h5 style=\"margin-top: -4px; margin-bottom: -2px; font-size: 11px;\">"
				+ alias
				+ "</h5><p style=\"margin-top: 0px; margin-bottom: -1px; font-size: 11px;\">"
				+ getFormattedTimestamp(timestamp) + "</p>";

		CustomizedGoogleMapInfoWindow smallAmraBoxInfoWindow = new CustomizedGoogleMapInfoWindow(
				html);
		smallAmraBoxInfoWindow.setPosition(location);
		smallAmraBoxInfoWindow.setMaxWidth(IW_MAX_WIDTH);
		smallAmraBoxInfoWindow.setWidth(IW_WIDTH);
		smallAmraBoxInfoWindow.setHeight(IW_HEIGHT);
		smallAmraBoxInfoWindow.setzIndex(Z_INDEX);
		smallAmraBoxInfoWindow.setAlias(wagonAlias);

		return smallAmraBoxInfoWindow;
	}

	/**
	 * Building a rich infow window containing the alias, timestamp and the address
	 *
	 * @param wagon
	 *            Get the alias, timestamp and address from the wagon
	 * @param location
	 *            To position the infow window
	 * @param marker
	 *            The marker to attach the infow window to
	 * @return A rich infow window attached to a marker
	 */
	public static CustomizedGoogleMapInfoWindow buildGoogleMapFullInfoWindow(Wagon wagon,
			LatLon location, GoogleMapMarker marker)
	{
		String fullHtmlContent = getFormattedAlias(wagon.getAlias()) + "<p>"
				+ getFormattedTimestamp(wagon.getTimestamp()) + "</p><p>"
				+ getFormattedAddress(wagon.getAddress()) + "</p>";
		CustomizedGoogleMapInfoWindow fullAmraBoxInfoWindow = new CustomizedGoogleMapInfoWindow(
				fullHtmlContent, marker);
		fullAmraBoxInfoWindow.setPosition(location);
		return fullAmraBoxInfoWindow;
	}

	/**
	 * Building a notification infow window containing the alias, priority, rule type, address and
	 * timestamp
	 *
	 * @param notificationMarker
	 *            A marker for notification purposes
	 * @param notification
	 *            The notification holding the data
	 * @return A notification marker with alias, priority, rule type, address and timestamp
	 */
	public static GoogleMapInfoWindow buildNotificationMarkerWindow(
			GoogleMapMarker notificationMarker, Notification notification)
	{
		String html = getFormattedAlias(notification.getAlias()) + "<p style=\"color: "
				+ getFormattedPriority(notification) + "\">"
				+ DashboardUI.getMessageSource()
						.getMessage("view.notification.priority."
								+ notification.getPriority().name().toLowerCase())
				+ "</p>" + getFormattedRuleType(notification) + "</br>"
				+ getFormattedAddress(notification.getAddress()) + "</br>"
				+ getFormattedTimestamp(notification.getTimestamp()) + "";

		GoogleMapInfoWindow notificationWindow = new GoogleMapInfoWindow(html, notificationMarker);
		notificationWindow.setWidth("100%");
		notificationWindow.setHeight("100%");
		return notificationWindow;
	}

	private static String getFormattedAlias(String alias)
	{
		return "<h5>" + alias + "</h5>";
	}

	public static String getFormattedPriority(Notification notification)
	{
		String color = notification.getPriority().name().toLowerCase().equals("yellow") ? "orange"
				: notification.getPriority().name().toLowerCase();
		return color;
	}

	private static String getFormattedTimestamp(Date timestamp)
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				DashboardUI.getMessageSource().getMessage("date.format"));
		dateFormat.setTimeZone(DashboardUI.getUserTimeZone());
		String timestampFormatted = dateFormat.format(timestamp);
		return timestampFormatted;
	}

	private static String getFormattedAddress(Address address)
	{
		return (address != null && address.getFormattedAddress() != null)
				? address.getFormattedAddress() : "";
	}

	private static String getFormattedRuleType(Notification notification)
	{
		try
		{
			String type = notification.getRule() != null
					? notification.getRule().getRuleType().toLowerCase() : "";
			String typeMessage = DashboardUI.getMessageSource()
					.getMessage("view.notification.reason." + type);
			if (notification.getShockValue() != null)
				typeMessage += " ("
						+ getNumberFormat().format(notification.getShockValue()).toString() + "g)";
			return typeMessage;
		}
		catch (NoSuchMessageException exception)
		{
			return "";
		}
	}

	private static NumberFormat getNumberFormat()
	{
		return new DecimalFormat(DECIMAL_PATTERN,
				new DecimalFormatSymbols(Page.getCurrent().getWebBrowser().getLocale()));
	}

	/**
	 * Fit to bounds implementation
	 *
	 * @param positions
	 *            List of positions
	 * @param googleMap
	 *            the GoogleMap
	 */
	public static void autoZoomMap(List<LatLon> positions, GoogleMap googleMap)
	{
		if (positions != null && positions.size() > 0)
		{
			List<Double> lat = positions.stream().map(mapper -> mapper.getLat())
					.collect(Collectors.toList());
			Double latMax = lat.stream().reduce(Double::max).get();
			Double latMin = lat.stream().reduce(Double::min).get();
			List<Double> lon = positions.stream().map(mapper -> mapper.getLon())
					.collect(Collectors.toList());
			Double lonMax = lon.stream().reduce(Double::max).get();
			Double lonMin = lon.stream().reduce(Double::min).get();

			LatLon boundsNE = new LatLon(latMax + SHIFTING_FACTOR, lonMax + SHIFTING_FACTOR);
			LatLon boundsSW = new LatLon(latMin - SHIFTING_FACTOR, lonMin - SHIFTING_FACTOR);
			googleMap.fitToBounds(boundsNE, boundsSW);
		}
	}

	/**
	 * This function is created within the namespace of the vaadin context. The function info is
	 * callled when an info window is clicked and the id is passed as argument. This id is used to
	 * execute an other javascript function. This function increases the z-Index by two to guarantee
	 * that the clicked info window is the one on top of the others
	 */
	public static void buildJavaScriptFunction()
	{
		Page.getCurrent().getJavaScript().addFunction("com.bosch.si.amra.info",
				new JavaScriptFunction()
				{
					private static final long serialVersionUID = -991637781065479631L;

					@Override
					public void call(JsonArray arguments)
					{
						Z_INDEX += 2;
						String id = arguments.getString(0);
						Page.getCurrent().getJavaScript()
								.execute("var parent = document.getElementById('" + id
										+ "').style.zIndex = " + Z_INDEX + "");
					}
				});
	}
}
