
package com.bosch.si.amra.provider;

import java.io.IOException;
import java.io.InputStream;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.entity.rule.Rule;
import com.bosch.si.amra.provider.rule.RuleDataProvider;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.util.JSON;

import mockit.Expectations;
import mockit.Mocked;

@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (locations = "file:src/test/resources/spring-servlet.xml")
public class RuleDataProviderTest
{
	private static final String	TENANT_ID	= "1798c300-c27f-11e4-81a3-0050569350e8";

	@Autowired
	private RuleDataProvider	ruleDataProvider;

	@Value ("${MONGO_HOST}")
	public String				MONGO_HOST;

	@Value ("${MONGO_PORT}")
	public Integer				MONGO_PORT;

	@Value ("${MONGO_DATABASE}")
	public String				MONGO_DATABASE;

	@Value ("${MONGO_USERNAME}")
	public String				MONGO_USERNAME;

	@Value ("${MONGO_PASSWORD}")
	public String				MONGO_PASSWORD;

	@Value ("${RULE_COLLECTION}")
	public String				RULE_COLLECTION;

	@Value ("${USE_PROXY}")
	public String				PROXY;

	@Mocked
	DashboardUI					dashboardUi;

	@Before
	public void setup() throws IOException
	{
		fillTestDB();
	}

	@After
	public void tearDown() throws IOException
	{
		deleteTestDB();
	}

	@Test
	public void getRulesTest() throws UnknownHostException
	{
		getMongoClient();
		List<Rule> rules = ruleDataProvider.getRules(TENANT_ID);
		Assert.assertNotNull(rules);
		Assert.assertEquals(8, rules.size());
		for (Rule rule : rules)
		{
			Assert.assertNotNull("Rule must not be null", rule);
			Assert.assertNotNull("Rule name must not be null", rule.getName());
			Assert.assertNotNull("Rule id must not be null", rule.getId());
		}
	}

	@Test (expected = IllegalArgumentException.class)
	public void getRulesNullTenantTest()
	{
		ruleDataProvider.getRules(null);
	}

	@Test (expected = IllegalArgumentException.class)
	public void getRulesEmptyTenantTest()
	{
		ruleDataProvider.getRules("");
	}

	@Test
	public void getRulesNotExistingTenantTest() throws UnknownHostException
	{
		getMongoClient();
		List<Rule> rules = ruleDataProvider.getRules("notExistingTenant");
		Assert.assertNotNull(rules);
		Assert.assertEquals(0, rules.size());
	}

	@Test
	public void getRulesSimilartTypeForATenantTest() throws UnknownHostException
	{
		getMongoClient();
		Rule targetRule = new Rule();
		targetRule.setId("6c48de74-c9ad-4b26-95ec-4cd8ac21bf13");
		targetRule.setRuleType("HM");
		List<Wagon> targetWagonList = new ArrayList<>();
		Wagon targetWagon = new Wagon();
		targetWagon.setId("002fbeb5-6283-401f-88f9-78acfd1a5380");
		targetWagonList.add(targetWagon);
		targetRule.setWagons(targetWagonList);
		List<Rule> rules = ruleDataProvider.getRulesWithSameRuleTypeAndAssignedWagons(TENANT_ID,
				targetRule);
		Assert.assertNotNull(rules);
		Assert.assertEquals(5, rules.size());
	}

	private MongoClient getMongoClient() throws UnknownHostException
	{
		new Expectations()
		{
			{
				DashboardUI.getMongoUsername();
				returns(MONGO_USERNAME);
				DashboardUI.getMongoPassword();
				returns(MONGO_PASSWORD);
				DashboardUI.getMongoDatabase();
				returns(MONGO_DATABASE);
				DashboardUI.getMongoHost();
				returns(MONGO_HOST);
				DashboardUI.getMongoPort();
				returns(MONGO_PORT);
				DashboardUI.getRuleCollection();
				returns(RULE_COLLECTION);
			}
		};
		DataProviderInitializer.createMongoClient();
		return DataProviderInitializer.getMongoClient();
	}

	@SuppressWarnings ("unchecked")
	private void fillTestDB() throws IOException
	{

		MongoClient mongoClient = getMongoClient();

		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection collection = db.getCollection(DashboardUI.getRuleCollection());
		InputStream testMessage = RuleDataProviderTest.class
				.getResourceAsStream("/testData/rule/rule.json");
		String message = IOUtils.toString(testMessage, "UTF-8");

		Object parse = JSON.parse(message);
		List<DBObject> objectToSave = (List<DBObject>) parse;
		collection.insert(objectToSave);
	}

	private void deleteTestDB() throws IOException
	{
		MongoClient mongoClient = getMongoClient();

		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection collection = db.getCollection(DashboardUI.getRuleCollection());
		collection.remove(new BasicDBObject());
	}
}
