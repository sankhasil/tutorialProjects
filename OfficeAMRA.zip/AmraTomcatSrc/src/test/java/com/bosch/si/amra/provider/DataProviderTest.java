
package com.bosch.si.amra.provider;

import java.io.IOException;
import java.io.InputStream;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.io.IOUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.entity.WagonType;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.util.JSON;

import mockit.Expectations;
import mockit.Mocked;

@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (locations = "file:src/test/resources/spring-servlet.xml")
public class DataProviderTest
{
	private static final String	TENANT_ID_CBEAA370_88		= "cbeaa370-c11d-11e1-8ba8-d4bed92ae488";

	private static final String	USER_ID_7523A8E0_E9			= "7523a8e0-6e39-11e4-8035-0050569350e9";

	private static final String	USER_ID_7523A8E0_E8			= "7523a8e0-6e39-11e4-8035-0050569350e8";

	private static final Long	BOX_ID_123456789012346L		= new Long(123456789012346L);

	private static final Long	BOX_ID_577777777777789L		= new Long(577777777777789L);

	private static final Long	BOX_ID_123456789012347L		= new Long(123456789012347L);

	private static final String	WAGON_ID_5A3E9BDE_EZ		= "5a3e9bde-5bfe-4697-8929-f7dcd76c93ez";

	private static final String	WAGON_ID_6FF79722_5E		= "6ff79722-f6ab-4515-9702-95cfa5d5845e";

	private static final String	WAGON_ID_5A3E9BDE_EC		= "5a3e9bde-5bfe-4697-8929-f7dcd76c93ec";

	private static final String	WAGON_ID_5A3E9BDE_EB		= "5a3e9bde-5bfe-4697-8929-f7dcd76c93eb";

	private static final String	WAGON_TYPE_ID_DC8CDF67_EG	= "dc8cdf67-818a-4641-b0fc-da6b533787eg";

	private static final String	WAGON_TYPE_ID_DC8CDF67_EE	= "dc8cdf67-818a-4641-b0fc-da6b533787ee";

	private static final String	WAGON_TYPE_TEST				= "Test";

	private static final String	WAGON_ALIAS_TESTWAGON_5		= "Testwagon 5";

	private static final String	WAGON_ALIAS_TESTWAGON_2		= "Testwagon 2";

	private static final String	WAGON_ALIAS_TEST_WAGON1		= "TestWagon1";

	private static final String	WAGON_ALIAS_TEST_WAGON2		= "TestWagon2";

	private static final String	DATE_FORMAT					= "dd.MM.yyyy HH:mm:ss";

	@Autowired
	private NewDataProvider		newDataProvider;

	@Value ("${MONGO_HOST}")
	public String				MONGO_HOST;

	@Value ("${MONGO_PORT}")
	public Integer				MONGO_PORT;

	@Value ("${MONGO_DATABASE}")
	public String				MONGO_DATABASE;

	@Value ("${MONGO_USERNAME}")
	public String				MONGO_USERNAME;

	@Value ("${MONGO_PASSWORD}")
	public String				MONGO_PASSWORD;

	@Value ("${MONGO_COLLECTION}")
	public String				MONGO_COLLECTION;

	@Value ("${MILEAGE_COLLECTION}")
	public String				MILEAGE_COLLECTION;

	@Value ("${ROUTING_COLLECTION}")
	public String				ROUTING_COLLECTION;

	@Value ("${CURRENT_COLLECTION}")
	public String				CURRENT_COLLECTION;

	@Value ("${WAGON_COLLECTION}")
	public String				WAGON_COLLECTION;

	@Value ("${WAGON_TYPE_COLLECTION}")
	public String				WAGON_TYPE_COLLECITON;

	@Value ("${USE_PROXY}")
	public String				PROXY;

	@Mocked
	DashboardUI					dashboardUi;

	@After
	public void tearDown() throws UnknownHostException
	{
		MongoClient mongoClient = getMongoClient();

		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection collection = db.getCollection(DashboardUI.getMongoCurrentCollection());
		collection.remove(new BasicDBObject());
		collection = db.getCollection(DashboardUI.getWagonCollection());
		collection.remove(new BasicDBObject());
		collection = db.getCollection(DashboardUI.getWagonTypeCollection());
		collection.remove(new BasicDBObject());
		collection = db.getCollection(DashboardUI.getMongoMileageCollection());
		collection.remove(new BasicDBObject());
	}

	@Test
	public void getWagonsTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		List<Wagon> wagons = newDataProvider.getWagons(createUser());
		Assert.assertNotNull(wagons);
		Assert.assertTrue(wagons.size() > 0);
	}

	@Test
	public void getWagonsForDisponentTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		User disponent = createUser();
		disponent.setAdmin(false);
		disponent.setId(USER_ID_7523A8E0_E8);
		List<Wagon> wagons = newDataProvider.getWagons(disponent);
		Assert.assertNotNull(wagons);
		Assert.assertEquals(2, wagons.size());
		for (Wagon wagon : wagons)
		{
			if (wagon.getId().equals(WAGON_ID_5A3E9BDE_EC))
			{
				Assert.assertEquals(WAGON_ALIAS_TEST_WAGON2, wagon.getAlias());
				Assert.assertEquals(BOX_ID_123456789012346L, wagon.getBoxId());
				Assert.assertEquals(TENANT_ID_CBEAA370_88, wagon.getTenantId());
				Assert.assertNotNull(wagon.getWagonType());
				Assert.assertEquals(WAGON_TYPE_TEST, wagon.getWagonType().getTypeName());
				Assert.assertEquals(WAGON_TYPE_ID_DC8CDF67_EE, wagon.getWagonType().getId());
			}
			if (wagon.getId().equals(WAGON_ID_5A3E9BDE_EB))
			{
				Assert.assertEquals(WAGON_ALIAS_TEST_WAGON1, wagon.getAlias());
				Assert.assertEquals(BOX_ID_123456789012347L, wagon.getBoxId());
				Assert.assertEquals(TENANT_ID_CBEAA370_88, wagon.getTenantId());
				Assert.assertNotNull(wagon.getWagonType());
				Assert.assertEquals(WAGON_TYPE_TEST, wagon.getWagonType().getTypeName());
				Assert.assertEquals(WAGON_TYPE_ID_DC8CDF67_EE, wagon.getWagonType().getId());
			}
		}
	}

	@Test
	public void getWagonsForEndCustomerTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		User endCustomer = createUser();
		endCustomer.setAdmin(false);
		endCustomer.setEndCustomer(true);
		endCustomer.setId(USER_ID_7523A8E0_E9);
		List<Wagon> wagons = newDataProvider.getWagons(endCustomer);
		Assert.assertNotNull(wagons);
		Assert.assertEquals(1, wagons.size());
		for (Wagon wagon : wagons)
		{
			if (wagon.getId().equals(WAGON_ID_6FF79722_5E))
			{
				Assert.assertEquals(WAGON_ALIAS_TESTWAGON_5, wagon.getAlias());
				Assert.assertEquals(BOX_ID_577777777777789L, wagon.getBoxId());
				Assert.assertEquals(TENANT_ID_CBEAA370_88, wagon.getTenantId());
				Assert.assertNotNull(wagon.getWagonType());
				Assert.assertEquals(WAGON_ALIAS_TESTWAGON_5, wagon.getWagonType().getTypeName());
				Assert.assertEquals(WAGON_TYPE_ID_DC8CDF67_EG, wagon.getWagonType().getId());
			}
		}
	}

	@Test
	public void getWagonsShortTest() throws IOException
	{
		getMongoClient();
		fillTestDB("/testData/wagon/wagonWithPositiveOffset.json");
		List<Wagon> wagons = newDataProvider.getWagonsShort(createUser());
		Assert.assertNotNull(wagons);
		Assert.assertTrue(wagons.size() > 0);
		Wagon wagon = wagons.get(0);
		Assert.assertNotNull(wagon);
		Assert.assertNotNull(wagon.getId());
		Assert.assertNotNull(wagon.getBoxId());
		Assert.assertNotNull(wagon.getAlias());
		Assert.assertNull(wagon.getTenantId());
		Assert.assertNull(wagon.getAddress());
		Assert.assertNull(wagon.getCreatedTs());
		Assert.assertNull(wagon.getHumidity());
		Assert.assertNull(wagon.getHumidityTemperature());
		Assert.assertNull(wagon.getLatLong());
		Assert.assertNull(wagon.getMileage());
		Assert.assertNull(wagon.getT1Temperature());
		Assert.assertNull(wagon.getTemperature());
		Assert.assertNull(wagon.getTimestamp());
		Assert.assertNull(wagon.getTimestampContact());
		Assert.assertNull(wagon.getWagonType());
		Assert.assertNotNull(wagon.getMileageOffset());
		Assert.assertEquals(new Integer(123), wagon.getMileageOffset());
	}

	@Test
	public void getWagonsShortForDisponentTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		User disponent = createUser();
		disponent.setAdmin(false);
		disponent.setId(USER_ID_7523A8E0_E8);
		List<Wagon> wagons = newDataProvider.getWagonsShort(disponent);
		Assert.assertNotNull(wagons);
		Assert.assertEquals(2, wagons.size());
		for (Wagon wagon : wagons)
		{
			if (wagon.getId().equals(WAGON_ID_5A3E9BDE_EC))
				Assert.assertEquals(WAGON_ALIAS_TEST_WAGON2, wagon.getAlias());
			if (wagon.getId().equals(WAGON_ID_5A3E9BDE_EB))
				Assert.assertEquals(WAGON_ALIAS_TEST_WAGON1, wagon.getAlias());
		}
	}

	@Test
	public void getWagonsShortForEndCustomerTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		User endCustomer = createUser();
		endCustomer.setAdmin(false);
		endCustomer.setEndCustomer(true);
		endCustomer.setId(USER_ID_7523A8E0_E9);
		List<Wagon> wagons = newDataProvider.getWagonsShort(endCustomer);
		Assert.assertNotNull(wagons);
		Assert.assertEquals(1, wagons.size());
		for (Wagon wagon : wagons)
		{
			if (wagon.getId().equals(WAGON_ID_6FF79722_5E))
				Assert.assertEquals(WAGON_ALIAS_TESTWAGON_5, wagon.getAlias());
		}
	}

	@Test
	public void getWagonTypesTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		List<WagonType> wagonTypes = newDataProvider.getWagonTypes(TENANT_ID_CBEAA370_88);
		Assert.assertNotNull(wagonTypes);
		Assert.assertTrue(wagonTypes.size() > 0);
	}

	@Test
	public void getWagonsWithTelematicData() throws IOException
	{
		getMongoClient();
		fillTestDB();
		List<Wagon> wagonsWithTelematicData = newDataProvider
				.getWagonsWithCurrentValues(createUser());
		Assert.assertNotNull(wagonsWithTelematicData);
		Assert.assertTrue(wagonsWithTelematicData.size() >= 2);
		for (Wagon wagon : wagonsWithTelematicData)
		{
			if (wagon.getId().equals(WAGON_ID_5A3E9BDE_EB))
			{
				Assert.assertEquals(BOX_ID_123456789012347L, wagon.getBoxId());
				Assert.assertEquals(new Integer(880), wagon.getMileage());
			}
		}
	}

	@Test
	public void getCurrentValuesForWagonsTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		List<Wagon> wagonsWithCurrentValues = newDataProvider
				.getWagonsWithCurrentValues(createUser());
		Assert.assertNotNull(wagonsWithCurrentValues);
		Assert.assertTrue(wagonsWithCurrentValues.size() > 0);
		for (Wagon wagon : wagonsWithCurrentValues)
		{
			if (wagon.getId().equals(WAGON_ID_5A3E9BDE_EC))
			{
				Assert.assertEquals(BOX_ID_123456789012346L, wagon.getBoxId());
				Assert.assertEquals(WAGON_ALIAS_TESTWAGON_2, wagon.getAlias());
				Assert.assertEquals(new Integer(49), wagon.getHumidity());
				Assert.assertEquals(new Integer(31), wagon.getHumidityTemperature());
				Assert.assertEquals(new Integer(10), wagon.getTemperature());
				Assert.assertNotNull(wagon.getLatLong());
				Assert.assertEquals(48.889366, wagon.getLatLong().getLat(), 0);
				Assert.assertEquals(9.199039000000001, wagon.getLatLong().getLng(), 0);
				Assert.assertEquals(TENANT_ID_CBEAA370_88, wagon.getTenantId());
				Assert.assertNotNull(wagon.getAddress());
				Assert.assertEquals("Friedrichstraße 71, 71638 Ludwigsburg, Deutschland",
						wagon.getAddress().getFormattedAddress());
				Assert.assertEquals("71638 Ludwigsburg", wagon.getAddress().getCity());
				Assert.assertEquals("Friedrichstraße 71", wagon.getAddress().getStreet());
				Assert.assertEquals("Deutschland", wagon.getAddress().getCountry());
				Assert.assertEquals(new Integer(500), wagon.getMileage());

				TimeZone userTimeZone = TimeZone.getTimeZone("Europe/Berlin");
				SimpleDateFormat displayFormat = new SimpleDateFormat(DATE_FORMAT);
				displayFormat.setTimeZone(userTimeZone);
				String dateFormatted = displayFormat.format(wagon.getTimestamp());
				Assert.assertEquals("14.01.2015 08:03:45", dateFormatted);

				userTimeZone = TimeZone.getTimeZone("Europe/London");
				displayFormat = new SimpleDateFormat(DATE_FORMAT);
				displayFormat.setTimeZone(userTimeZone);
				dateFormatted = displayFormat.format(wagon.getTimestamp());
				Assert.assertEquals("14.01.2015 07:03:45", dateFormatted);

				userTimeZone = TimeZone.getTimeZone("Africa/Algiers");
				displayFormat = new SimpleDateFormat(DATE_FORMAT);
				displayFormat.setTimeZone(userTimeZone);
				dateFormatted = displayFormat.format(wagon.getTimestamp());
				Assert.assertEquals("14.01.2015 08:03:45", dateFormatted);

				userTimeZone = TimeZone.getTimeZone("UTC");
				displayFormat = new SimpleDateFormat(DATE_FORMAT);
				displayFormat.setTimeZone(userTimeZone);
				dateFormatted = displayFormat.format(wagon.getTimestampContact());
				Assert.assertEquals("14.01.2015 07:03:45", dateFormatted);
			}
			if (wagon.getId().equals(WAGON_ID_5A3E9BDE_EZ))
			{
				TimeZone userTimeZone = TimeZone.getTimeZone("Europe/Berlin");
				SimpleDateFormat displayFormat = new SimpleDateFormat(DATE_FORMAT);
				displayFormat.setTimeZone(userTimeZone);
				String dateFormatted = displayFormat.format(wagon.getTimestamp());
				Assert.assertEquals("13.05.2015 20:13:30", dateFormatted);

				userTimeZone = TimeZone.getTimeZone("Europe/London");
				displayFormat = new SimpleDateFormat(DATE_FORMAT);
				displayFormat.setTimeZone(userTimeZone);
				dateFormatted = displayFormat.format(wagon.getTimestamp());
				Assert.assertEquals("13.05.2015 19:13:30", dateFormatted);

				userTimeZone = TimeZone.getTimeZone("Africa/Algiers");
				displayFormat = new SimpleDateFormat(DATE_FORMAT);
				displayFormat.setTimeZone(userTimeZone);
				dateFormatted = displayFormat.format(wagon.getTimestamp());
				Assert.assertEquals("13.05.2015 19:13:30", dateFormatted);

				userTimeZone = TimeZone.getTimeZone("UTC");
				displayFormat = new SimpleDateFormat(DATE_FORMAT);
				displayFormat.setTimeZone(userTimeZone);
				dateFormatted = displayFormat.format(wagon.getTimestampContact());
				Assert.assertEquals("13.05.2015 18:13:30", dateFormatted);
			}
		}
	}

	@Test
	public void getCurrentValuesForWagonsForDisponentTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		User disponent = createUser();
		disponent.setAdmin(false);
		disponent.setId(USER_ID_7523A8E0_E8);
		List<Wagon> wagonsWithCurrentValues = newDataProvider.getWagonsWithCurrentValues(disponent);
		Assert.assertNotNull(wagonsWithCurrentValues);
		Assert.assertEquals(2, wagonsWithCurrentValues.size());
		for (Wagon wagon : wagonsWithCurrentValues)
		{
			if (wagon.getId().equals(WAGON_ID_5A3E9BDE_EC))
			{
				Assert.assertEquals(BOX_ID_123456789012346L, wagon.getBoxId());
				Assert.assertEquals(WAGON_ALIAS_TESTWAGON_2, wagon.getAlias());
				Assert.assertEquals(new Integer(49), wagon.getHumidity());
				Assert.assertEquals(new Integer(31), wagon.getHumidityTemperature());
				Assert.assertEquals(new Integer(10), wagon.getTemperature());
				Assert.assertNotNull(wagon.getLatLong());
				Assert.assertEquals(48.889366, wagon.getLatLong().getLat(), 0);
				Assert.assertEquals(9.199039000000001, wagon.getLatLong().getLng(), 0);
				Assert.assertEquals(TENANT_ID_CBEAA370_88, wagon.getTenantId());
				Assert.assertNotNull(wagon.getAddress());
				Assert.assertEquals("Friedrichstraße 71, 71638 Ludwigsburg, Deutschland",
						wagon.getAddress().getFormattedAddress());
				Assert.assertEquals("71638 Ludwigsburg", wagon.getAddress().getCity());
				Assert.assertEquals("Friedrichstraße 71", wagon.getAddress().getStreet());
				Assert.assertEquals("Deutschland", wagon.getAddress().getCountry());
				Assert.assertEquals(new Integer(500), wagon.getMileage());

				TimeZone userTimeZone = TimeZone.getTimeZone("Europe/Berlin");
				SimpleDateFormat displayFormat = new SimpleDateFormat(DATE_FORMAT);
				displayFormat.setTimeZone(userTimeZone);
				String dateFormatted = displayFormat.format(wagon.getTimestamp());
				Assert.assertEquals("14.01.2015 08:03:45", dateFormatted);

				userTimeZone = TimeZone.getTimeZone("Europe/London");
				displayFormat = new SimpleDateFormat(DATE_FORMAT);
				displayFormat.setTimeZone(userTimeZone);
				dateFormatted = displayFormat.format(wagon.getTimestamp());
				Assert.assertEquals("14.01.2015 07:03:45", dateFormatted);

				userTimeZone = TimeZone.getTimeZone("Africa/Algiers");
				displayFormat = new SimpleDateFormat(DATE_FORMAT);
				displayFormat.setTimeZone(userTimeZone);
				dateFormatted = displayFormat.format(wagon.getTimestamp());
				Assert.assertEquals("14.01.2015 08:03:45", dateFormatted);

				userTimeZone = TimeZone.getTimeZone("UTC");
				displayFormat = new SimpleDateFormat(DATE_FORMAT);
				displayFormat.setTimeZone(userTimeZone);
				dateFormatted = displayFormat.format(wagon.getTimestampContact());
				Assert.assertEquals("14.01.2015 07:03:45", dateFormatted);
			}
			if (wagon.getId().equals(WAGON_ID_5A3E9BDE_EB))
			{
				TimeZone userTimeZone = TimeZone.getTimeZone("Europe/Berlin");
				SimpleDateFormat displayFormat = new SimpleDateFormat(DATE_FORMAT);
				displayFormat.setTimeZone(userTimeZone);
				String dateFormatted = displayFormat.format(wagon.getTimestamp());
				Assert.assertEquals("11.01.2015 18:28:19", dateFormatted);

				userTimeZone = TimeZone.getTimeZone("Europe/London");
				displayFormat = new SimpleDateFormat(DATE_FORMAT);
				displayFormat.setTimeZone(userTimeZone);
				dateFormatted = displayFormat.format(wagon.getTimestamp());
				Assert.assertEquals("11.01.2015 17:28:19", dateFormatted);

				userTimeZone = TimeZone.getTimeZone("Africa/Algiers");
				displayFormat = new SimpleDateFormat(DATE_FORMAT);
				displayFormat.setTimeZone(userTimeZone);
				dateFormatted = displayFormat.format(wagon.getTimestamp());
				Assert.assertEquals("11.01.2015 18:28:19", dateFormatted);

				userTimeZone = TimeZone.getTimeZone("UTC");
				displayFormat = new SimpleDateFormat(DATE_FORMAT);
				displayFormat.setTimeZone(userTimeZone);
				dateFormatted = displayFormat.format(wagon.getTimestampContact());
				Assert.assertEquals("11.01.2015 17:28:19", dateFormatted);
			}
		}
	}

	@Test
	public void getCurrentValuesForWagonsForEndCustomerTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		User endCustomer = createUser();
		endCustomer.setAdmin(false);
		endCustomer.setEndCustomer(true);
		endCustomer.setId(USER_ID_7523A8E0_E9);
		List<Wagon> wagonsWithCurrentValues = newDataProvider
				.getWagonsWithCurrentValues(endCustomer);
		Assert.assertNotNull(wagonsWithCurrentValues);
		Assert.assertEquals(1, wagonsWithCurrentValues.size());
		for (Wagon wagon : wagonsWithCurrentValues)
		{
			if (wagon.getId().equals(WAGON_ID_6FF79722_5E))
			{
				Assert.assertEquals(BOX_ID_577777777777789L, wagon.getBoxId());
				Assert.assertEquals(WAGON_ALIAS_TESTWAGON_5, wagon.getAlias());
				Assert.assertEquals(TENANT_ID_CBEAA370_88, wagon.getTenantId());
				Assert.assertNotNull(wagon.getAddress());
				Assert.assertEquals("Peter-Rosegger-Straße 90, 72762 Reutlingen, Deutschland",
						wagon.getAddress().getFormattedAddress());
				Assert.assertEquals("72762 Reutlingen", wagon.getAddress().getCity());
				Assert.assertEquals("Peter-Rosegger-Straße 90", wagon.getAddress().getStreet());
				Assert.assertEquals("Deutschland", wagon.getAddress().getCountry());

				TimeZone userTimeZone = TimeZone.getTimeZone("UTC");
				SimpleDateFormat displayFormat = new SimpleDateFormat(DATE_FORMAT);
				displayFormat.setTimeZone(userTimeZone);
				String dateFormatted = displayFormat.format(wagon.getTimestamp());
				Assert.assertEquals("13.05.2015 18:13:30", dateFormatted);
			}
		}
	}

	@Test (expected = IllegalArgumentException.class)
	public void getWagonsWithNullTenantTest()
	{
		newDataProvider.getWagons(null);
	}

	@Test (expected = IllegalArgumentException.class)
	public void getWagonsWithEmptyTenantTest()
	{
		User user = new User();
		user.setTenant("");
		newDataProvider.getWagons(user);
	}

	@Test (expected = IllegalArgumentException.class)
	public void getWagonsShortWithNullTenantTest()
	{
		newDataProvider.getWagonsShort(null);
	}

	@Test (expected = IllegalArgumentException.class)
	public void getWagonsShortWithEmptyTenantTest()
	{
		User user = new User();
		user.setTenant("");
		newDataProvider.getWagonsShort(user);
	}

	@Test (expected = IllegalArgumentException.class)
	public void getWagonTypessWithNullTenantTest()
	{
		newDataProvider.getWagonTypes(null);
	}

	@Test (expected = IllegalArgumentException.class)
	public void getWagonTypessWithEmptyTenantTest()
	{
		newDataProvider.getWagonTypes("");
	}

	private MongoClient getMongoClient() throws UnknownHostException
	{
		new Expectations()
		{
			{
				DashboardUI.getMongoUsername();
				returns(MONGO_USERNAME);
				DashboardUI.getMongoPassword();
				returns(MONGO_PASSWORD);
				DashboardUI.getMongoDatabase();
				returns(MONGO_DATABASE);
				DashboardUI.getMongoHost();
				returns(MONGO_HOST);
				DashboardUI.getMongoPort();
				returns(MONGO_PORT);
				DashboardUI.getMongoCurrentCollection();
				returns(CURRENT_COLLECTION);
				DashboardUI.getWagonTypeCollection();
				returns(WAGON_TYPE_COLLECITON);
				DashboardUI.getWagonCollection();
				returns(WAGON_COLLECTION);
				DashboardUI.getMongoMileageCollection();
				returns(MILEAGE_COLLECTION);
			}
		};
		DataProviderInitializer.createMongoClient();
		return DataProviderInitializer.getMongoClient();
	}

	@SuppressWarnings ("unchecked")
	private void fillTestDB(String... values) throws IOException
	{
		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection collection = db.getCollection(DashboardUI.getMongoCurrentCollection());
		InputStream testMessage = AggregationDataProviderTest.class
				.getResourceAsStream("/testData/current/current.json");
		String message = IOUtils.toString(testMessage, "UTF-8");

		Object parse = JSON.parse(message);
		List<DBObject> objectListToSave = (List<DBObject>) parse;
		collection.insert(objectListToSave);

		collection = db.getCollection(DashboardUI.getWagonTypeCollection());
		testMessage = this.getClass().getResourceAsStream("/testData/wagonType/wagonType.json");
		String wagonType = IOUtils.toString(testMessage, "UTF-8");

		parse = JSON.parse(wagonType);
		objectListToSave = (List<DBObject>) parse;
		collection.insert(objectListToSave);

		collection = db.getCollection(DashboardUI.getWagonCollection());
		String wagonResourcePath = (values.length == 0 ? "/testData/wagon/wagon.json" : values[0]);
		testMessage = this.getClass().getResourceAsStream(wagonResourcePath);
		String wagon = IOUtils.toString(testMessage, "UTF-8");

		parse = JSON.parse(wagon);
		objectListToSave = (List<DBObject>) parse;
		collection.insert(objectListToSave);

		collection = db.getCollection(DashboardUI.getMongoMileageCollection());
		testMessage = this.getClass().getResourceAsStream("/testData/mileage/mileage.json");
		String mileage = IOUtils.toString(testMessage, "UTF-8");

		parse = JSON.parse(mileage);
		objectListToSave = (List<DBObject>) parse;
		collection.insert(objectListToSave);
	}

	private User createUser()
	{
		User user = new User();
		user.setTenant(TENANT_ID_CBEAA370_88);
		user.setAdmin(true);
		return user;
	}
}
