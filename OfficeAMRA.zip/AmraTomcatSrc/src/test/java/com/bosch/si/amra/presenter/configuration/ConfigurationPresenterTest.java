
package com.bosch.si.amra.presenter.configuration;

import java.io.IOException;
import java.io.InputStream;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.apache.commons.io.IOUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.entity.configuration.Configuration;
import com.bosch.si.amra.event.DashboardEvent.ConfigurationSortAndFilterEvent;
import com.bosch.si.amra.event.DashboardEvent.ConfigurationsSaveAliasEvent;
import com.bosch.si.amra.event.DashboardEvent.ConfigurationsSaveEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.provider.DataProviderInitializer;
import com.bosch.si.amra.provider.configuration.ConfigurationDataProvider;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.mongodb.WriteResult;
import com.mongodb.util.JSON;

import mockit.Expectations;
import mockit.Mocked;

@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (locations = "file:src/test/resources/spring-servlet.xml")
@PrepareForTest ({ DashboardUI.class })
public class ConfigurationPresenterTest
{
	@Autowired
	private ConfigurationPresenter		configurationPresenter;

	@Autowired
	private ConfigurationDataProvider	configurationDataProvider;

	@Mocked
	final DashboardEventBus				eventBus	= null;

	@Mocked
	DashboardUI							dashboardUi;

	@Value ("${MONGO_HOST}")
	public String						MONGO_HOST;

	@Value ("${MONGO_PORT}")
	public Integer						MONGO_PORT;

	@Value ("${MONGO_DATABASE}")
	public String						MONGO_DATABASE;

	@Value ("${MONGO_USERNAME}")
	public String						MONGO_USERNAME;

	@Value ("${MONGO_PASSWORD}")
	public String						MONGO_PASSWORD;

	@Value ("${CONFIGURATION_COLLECTION}")
	public String						CONFIGURATION_COLLECTION;

	@Value ("${EVENT_COLLECTION}")
	public String						TELEMATIC_COLLECTION;

	@Before
	public void setUp()
	{
		MockitoAnnotations.initMocks(this);
	}

	@After
	public void tearDown() throws UnknownHostException
	{
		new Expectations()
		{
			{
				DashboardUI.getEventCollection();
				returns(TELEMATIC_COLLECTION);
			}
		};
		List<DBCollection> collections = getCollection();
		collections.forEach(collection -> {
			if (collection != null)
			{
				collection.remove(new BasicDBObject());
			}
		});
	}

	@Test
	public void saveConfigurationTest() throws UnknownHostException
	{
		MongoClient mongoClient = getMongoClient();

		ConfigurationsSaveEvent event = new ConfigurationsSaveEvent(createConfigurations(),
				"1798c300-c27f-11e4-81a3-0050569350e8");
		configurationPresenter.saveConfigurations(event);

		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection collection = db.getCollection(DashboardUI.getConfigurationCollection());
		DBCursor find = collection
				.find(new BasicDBObject("TI", "1798c300-c27f-11e4-81a3-0050569350e8"));
		Assert.assertNotNull(find);
		Assert.assertTrue(find.count() == 5);
	}

	@Test
	public void saveConfigurationRoutingDisabledTest() throws IOException
	{
		new Expectations()
		{
			{
				DashboardUI.getEventCollection();
				returns(TELEMATIC_COLLECTION);
			}
		};
		MongoClient mongoClient = getMongoClient();
		fillTelematic(mongoClient);

		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection telematicCollection = db.getCollection(DashboardUI.getEventCollection());
		Assert.assertEquals(22, telematicCollection.count());
		int count = telematicCollection.find(new BasicDBObject(MongoConstants.PROCESSED, false))
				.count();
		Assert.assertEquals(2, count);
		count = telematicCollection.find(new BasicDBObject(MongoConstants.PROCESSED, true)).count();
		Assert.assertEquals(20, count);

		List<Configuration> configurations = Arrays.asList(
				createConfigurationWithRoutingDisabled("Test-cbi",
						"cbeaa370-c11d-11e1-8ba8-d4bed92ae488",
						"6ff79722-f6ab-4514-9702-94cfa5d5846e", 777777777777789l),
				createConfigurationWithRoutingDisabled("Test-cbi1",
						"cbeaa370-c11d-11e1-8ba8-d4bed92ae489",
						"6ff79722-f6ab-4514-9702-94cfa5d5846d", 777777777777799l));
		ConfigurationsSaveEvent event = new ConfigurationsSaveEvent(configurations,
				"cbeaa370-c11d-11e1-8ba8-d4bed92ae488");
		configurationPresenter.saveConfigurations(event);

		count = telematicCollection.find(new BasicDBObject(MongoConstants.PROCESSED, false))
				.count();
		Assert.assertEquals(0, count);
		count = telematicCollection.find(new BasicDBObject(MongoConstants.PROCESSED, true)).count();
		Assert.assertEquals(22, count);
	}

	@Test
	public void updateConfigurationPresenterTest() throws UnknownHostException
	{
		MongoClient mongoClient = getMongoClient();

		ConfigurationsSaveEvent event = new ConfigurationsSaveEvent(createConfigurations(),
				"1798c300-c27f-11e4-81a3-0050569350e8");
		configurationPresenter.saveConfigurations(event);

		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection collection = db.getCollection(DashboardUI.getConfigurationCollection());
		DBObject configurationObject = collection.findOne(new BasicDBObject("alias", "Test0"));
		Configuration configuration = convertToConfiguration(configurationObject);
		configuration.setAlias("Other Alias");
		configuration.setHumidity(true);
		configuration.setGsmMoving(36900);

		event = new ConfigurationsSaveEvent(Arrays.asList(configuration),
				"1798c300-c27f-11e4-81a3-0050569350e8");
		configurationPresenter.saveConfigurations(event);

		configurationObject = collection.findOne(new BasicDBObject("alias", "Other Alias"));

		Assert.assertNotNull(configurationObject);
		configuration = convertToConfiguration(configurationObject);
		Assert.assertTrue(configuration.isHumidity());
		Assert.assertEquals("Other Alias", configuration.getAlias());
		Assert.assertEquals(new Integer(36900), configuration.getGsmMoving());
	}

	@Test
	public void saveAliasInConfigurationsTest() throws UnknownHostException
	{
		MongoClient mongoClient = getMongoClient();

		ConfigurationsSaveEvent event = new ConfigurationsSaveEvent(createConfigurations(),
				"1798c300-c27f-11e4-81a3-0050569350e8");
		configurationPresenter.saveConfigurations(event);

		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection collection = db.getCollection(DashboardUI.getConfigurationCollection());
		DBObject configurationObject = collection.findOne(new BasicDBObject("alias", "Test0"));
		Configuration configuration = convertToConfiguration(configurationObject);
		String configurationId = configuration.getId();

		ConfigurationsSaveAliasEvent saveAliasEvent = new ConfigurationsSaveAliasEvent(
				"Other Test0", configurationId);
		configurationPresenter.saveAliasInConfigurations(saveAliasEvent);

		configurationObject = collection.findOne(new BasicDBObject("_id", configurationId));

		Assert.assertNotNull(configurationObject);
		configuration = convertToConfiguration(configurationObject);
		Assert.assertEquals("Other Test0", configuration.getAlias());
	}

	@Test
	public void sortAliasConfigurationsTest() throws IOException
	{
		getMongoClient();
		new Expectations()
		{
			{
				DashboardUI.getConfigurationDataProvider();
				returns(configurationDataProvider);
			}
		};
		fillTestDB();

		ConfigurationSortAndFilterEvent event = new ConfigurationSortAndFilterEvent(
				"1798c300-c27f-11e4-81a3-0050569350e8", "alias", true, null);
		List<Configuration> sortAndFilter = configurationPresenter.sortAndFilter(event);
		Assert.assertNotNull(sortAndFilter);
		Assert.assertTrue(sortAndFilter.size() == 11);

		Configuration firstConfiguration = sortAndFilter.get(0);
		Assert.assertEquals("a1231684", firstConfiguration.getAlias());

		Configuration lastConfiguration = sortAndFilter.get(sortAndFilter.size() - 1);
		Assert.assertEquals("Äpf4708", lastConfiguration.getAlias());
	}

	@Test
	public void filterAliasConfigurationsTest() throws IOException
	{
		getMongoClient();
		new Expectations()
		{
			{
				DashboardUI.getConfigurationDataProvider();
				returns(configurationDataProvider);
			}
		};
		fillTestDB();

		ConfigurationSortAndFilterEvent event = new ConfigurationSortAndFilterEvent(
				"1798c300-c27f-11e4-81a3-0050569350e8", "alias", true, "Äpf");
		List<Configuration> sortAndFilter = configurationPresenter.sortAndFilter(event);
		Assert.assertNotNull(sortAndFilter);
		Assert.assertTrue(sortAndFilter.size() == 4);

		Configuration firstConfiguration = sortAndFilter.get(0);
		Assert.assertEquals("Äpf1973", firstConfiguration.getAlias());

		Configuration lastConfiguration = sortAndFilter.get(sortAndFilter.size() - 1);
		Assert.assertEquals("Äpf4708", lastConfiguration.getAlias());
	}

	/**
	 * All wagons with WI 992d077f-460c-4038-9454-2bff56929a7e changed alias and sort to Geänderter
	 * Wagen (geänderter wagen)
	 *
	 * @throws UnknownHostException
	 */
	@Test
	public void saveAliasInNotificationTest() throws UnknownHostException
	{
		MongoClient mongoClient = getMongoClient();

		String uuid = UUID.randomUUID().toString();
		Configuration configuration = new Configuration();
		configuration.setId(uuid);
		configuration.setAlias("Test");
		configuration.setHumidity(false);
		configuration.setHumidityTemperature(false);
		configuration.setTemperature(false);
		configuration.setDeviceTemperature(true);
		configuration.setRouting(true);
		configuration.setShockX(3.5d);
		configuration.setShockY(2.5d);
		configuration.setShockZ(1.5d);
		configuration.setGpsMoving(30600);
		configuration.setGpsMoving(86400);
		configuration.setGsmMoving(14400);
		configuration.setGsmTimeBased(42300);
		configuration.setTenantId("1798c300-c27f-11e4-81a3-0050569350e8");
		configuration.setWagonId("002fbeb5-6283-401f-88f9-78acfd1a5972");
		configuration.setBoxId(123456789012345l);

		ConfigurationsSaveEvent event = new ConfigurationsSaveEvent(Arrays.asList(configuration),
				"1798c300-c27f-11e4-81a3-0050569350e8");
		configurationPresenter.saveConfigurations(event);
		WriteResult writeResult = configurationPresenter.saveAliasInConfigurations(
				new ConfigurationsSaveAliasEvent("Geänderter Wagen", uuid));

		Assert.assertEquals(1, writeResult.getN());

		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection collection = db.getCollection(DashboardUI.getConfigurationCollection());
		DBCursor configurations = collection.find(new BasicDBObject("_id", uuid));
		Assert.assertEquals(1, configurations.count());
		DBObject notification = configurations.next();
		Assert.assertEquals("Geänderter Wagen", notification.get("alias"));
		Assert.assertEquals("geänderter wagen", notification.get("sort"));
		Assert.assertEquals(3.5, notification.get("SX"));
		Assert.assertEquals(2.5, notification.get("SY"));
		Assert.assertEquals(1.5, notification.get("SZ"));
	}

	/**
	 * Trying to update alias of not existing wagon
	 *
	 * @throws UnknownHostException
	 */
	@Test
	public void saveAliasForNotExistingConfigurationInNotificationTest() throws UnknownHostException
	{
		getMongoClient();
		WriteResult writeResult = configurationPresenter
				.saveAliasInConfigurations(new ConfigurationsSaveAliasEvent("Geänderter Wagen",
						"992d077f-460c-4038-9454-2bff56929a7e"));
		Assert.assertNotNull(writeResult);
		Assert.assertEquals(0, writeResult.getN());
		Assert.assertNull(writeResult.getUpsertedId());
	}

	/**
	 * Trying to update alias of not existing wagon
	 *
	 * @throws UnknownHostException
	 */
	@Test
	public void saveAliasForNotNullConfigurationIdInNotificationTest() throws UnknownHostException
	{
		getMongoClient();
		WriteResult writeResult = configurationPresenter.saveAliasInConfigurations(
				new ConfigurationsSaveAliasEvent("Geänderter Wagen", null));
		Assert.assertNull(writeResult);
	}

	/**
	 * Test for New Default Keys are saving or not
	 *
	 * @throws UnknownHostException
	 */
	@Test
	public void saveNewBumpDetectionAndAquitionFrequecyInConfigurationTest()
			throws UnknownHostException
	{
		MongoClient mongoClient = getMongoClient();

		ConfigurationsSaveEvent event = new ConfigurationsSaveEvent(createConfigurations(),
				"1798c300-c27f-11e4-81a3-0050569350e8");
		configurationPresenter.saveConfigurations(event);

		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection collection = db.getCollection(DashboardUI.getConfigurationCollection());
		BasicDBObject findCriteria = new BasicDBObject("BD", 14);
		findCriteria.put("AF", 8);
		DBCursor find = collection.find(findCriteria);
		Assert.assertNotNull(find);
		Assert.assertTrue(find.count() == 5);
	}

	private List<Configuration> createConfigurations()
	{
		List<Configuration> configurations = new ArrayList<Configuration>();
		for (int i = 0; i < 5; i++)
		{
			Configuration configuration = new Configuration();
			configuration.setId(UUID.randomUUID().toString());
			configuration.setAlias("Test" + i);
			configuration.setHumidity(false);
			configuration.setHumidityTemperature(false);
			configuration.setTemperature(false);
			configuration.setDeviceTemperature(true);
			configuration.setRouting(true);
			configuration.setShockX(3.5d);
			configuration.setShockY(4.5d);
			configuration.setShockZ(1.5d);
			configuration.setGpsMoving(30600);
			configuration.setGpsMoving(86400);
			configuration.setGsmMoving(14400);
			configuration.setGsmTimeBased(42300);
			configuration.setBumpDuration(14);
			configuration.setAquisitionFrequency(8);
			configuration.setTenantId("1798c300-c27f-11e4-81a3-0050569350e8");
			configuration.setWagonId("002fbeb5-6283-401f-88f9-78acfd1a5380");
			configuration.setBoxId(123456789012345l + i);
			configurations.add(configuration);
		}
		return configurations;
	}

	private Configuration createConfigurationWithRoutingDisabled(String alias, String tenantId,
			String wagonId, Long boxId)
	{
		Configuration configuration = new Configuration();
		configuration.setId(UUID.randomUUID().toString());
		configuration.setAlias(alias);
		configuration.setHumidity(false);
		configuration.setHumidityTemperature(false);
		configuration.setTemperature(false);
		configuration.setDeviceTemperature(true);
		configuration.setRouting(false);
		configuration.setShockX(3.5d);
		configuration.setShockY(4.5d);
		configuration.setShockZ(1.5d);
		configuration.setGpsMoving(30600);
		configuration.setGpsMoving(86400);
		configuration.setGsmMoving(14400);
		configuration.setGsmTimeBased(42300);
		configuration.setBumpDuration(14);
		configuration.setAquisitionFrequency(8);
		configuration.setTenantId(tenantId);
		configuration.setWagonId(wagonId);
		configuration.setBoxId(boxId);
		return configuration;
	}

	private Configuration convertToConfiguration(DBObject object)
	{
		Configuration configuration = new Configuration((String) object.get("_id"),
				(String) object.get("alias"), (Integer) object.get("F"), (String) object.get("S"),
				(Boolean) object.get("HM"), (Boolean) object.get("HT"), (Boolean) object.get("T1"),
				(Boolean) object.get("DT"), (Double) object.get("SX"), (Double) object.get("SY"),
				(Double) object.get("SZ"), (Boolean) object.get("RT"), (Integer) object.get("CM"),
				(Integer) object.get("CS"), (Integer) object.get("PM"), (Integer) object.get("PS"),
				(Integer) object.get("BD"), (Integer) object.get("AF"), (String) object.get("WI"),
				(String) object.get("TI"), (Long) object.get("BI"));
		return configuration;
	}

	private MongoClient getMongoClient() throws UnknownHostException
	{
		new Expectations()
		{
			{
				DashboardUI.getMongoUsername();
				returns(MONGO_USERNAME);
				DashboardUI.getMongoPassword();
				returns(MONGO_PASSWORD);
				DashboardUI.getMongoDatabase();
				returns(MONGO_DATABASE);
				DashboardUI.getMongoHost();
				returns(MONGO_HOST);
				DashboardUI.getMongoPort();
				returns(MONGO_PORT);
				DashboardUI.getConfigurationCollection();
				returns(CONFIGURATION_COLLECTION);
			}
		};
		DataProviderInitializer.createMongoClient();
		return DataProviderInitializer.getMongoClient();
	}

	@SuppressWarnings ("unchecked")
	private void fillTestDB() throws IOException
	{

		MongoClient mongoClient;

		MongoCredential credential = MongoCredential.createMongoCRCredential(
				DashboardUI.getMongoUsername(), DashboardUI.getMongoDatabase(),
				DashboardUI.getMongoPassword().toCharArray());
		mongoClient = new MongoClient(
				new ServerAddress(DashboardUI.getMongoHost(), DashboardUI.getMongoPort()),
				Arrays.asList(credential));

		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());

		// Fill configuration collection
		DBCollection collection = db.getCollection(DashboardUI.getConfigurationCollection());
		InputStream testMessage = ConfigurationPresenterTest.class
				.getResourceAsStream("/testData/configurations/configurations.json");

		String message = IOUtils.toString(testMessage, "UTF-8");
		Object parse = JSON.parse(message);
		List<DBObject> objectToSave = (List<DBObject>) parse;
		collection.insert(objectToSave);
	}

	@SuppressWarnings ("unchecked")
	private void fillTelematic(MongoClient client) throws IOException
	{
		DB db = client.getDB(DashboardUI.getMongoDatabase());

		// Fill configuration collection
		DBCollection collection = db.getCollection(DashboardUI.getEventCollection());
		InputStream testMessage = ConfigurationPresenterTest.class
				.getResourceAsStream("/testData/telematic/telematicForDisablingRouting.json");

		String message = IOUtils.toString(testMessage, "UTF-8");
		Object parse = JSON.parse(message);
		List<DBObject> objectToSave = (List<DBObject>) parse;
		collection.insert(objectToSave);
	}

	private List<DBCollection> getCollection() throws UnknownHostException
	{
		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection collection = db.getCollection(DashboardUI.getConfigurationCollection());
		DBCollection telematicCollection = db.getCollection(DashboardUI.getEventCollection());
		return Arrays.asList(collection, telematicCollection);
	}
}
