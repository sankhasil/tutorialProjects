
package com.bosch.si.amra.view.formatter;

import java.util.Arrays;
import java.util.Locale;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.component.table.AmraTable;
import com.bosch.si.amra.constants.configuration.ConfigurationConstants;
import com.bosch.si.amra.constants.notification.NotificationConstants;
import com.bosch.si.amra.constants.overview.OverviewConstants;
import com.bosch.si.amra.constants.rule.RuleConstants;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.entity.configuration.Configuration;
import com.bosch.si.amra.entity.notification.Notification;
import com.bosch.si.amra.entity.rule.Rule;
import com.bosch.si.amra.entity.rule.Rule.Severity;
import com.bosch.si.fleet.common.internationalization.I18n;
import com.vaadin.data.util.ObjectProperty;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Page;

import mockit.Expectations;
import mockit.Mocked;
import mockit.integration.junit4.JMockit;

@RunWith (JMockit.class)
public class FormatterTest
{
	private AmraTable table;

	@Before
	public void setup()
	{
		table = new AmraTable();
	}

	@Test
	public void aliasForCoupledWagonFormatterTest()
	{
		Wagon wagon = new Wagon();
		wagon.setAlias("TestAlias");
		wagon.setBoxId(111111111111111l);
		String formatPropertyValue = table.formatPropertyValue(wagon, OverviewConstants.ALIAS,
				new ObjectProperty<String>("TestAlias"));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals(
				new String(Character.toChars(FontAwesome.CHAIN.getCodepoint())) + " " + "TestAlias",
				formatPropertyValue);
	}

	@Test
	public void aliasForNotCoupledWagonFormatterTest()
	{
		Wagon wagon = new Wagon();
		wagon.setAlias("TestAlias");
		String formatPropertyValue = table.formatPropertyValue(wagon, OverviewConstants.ALIAS,
				new ObjectProperty<String>("TestAlias"));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("TestAlias", formatPropertyValue);
	}

	@Test
	public void aliasForNotificationFormatterTest()
	{
		Notification notification = new Notification();
		notification.setAlias("TestAlias");
		String formatPropertyValue = table.formatPropertyValue(notification,
				NotificationConstants.ALIAS, new ObjectProperty<String>("TestAlias"));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("TestAlias", formatPropertyValue);
	}

	@Test
	public void aliasForConfigurationFormatterTest()
	{
		Configuration configuration = new Configuration();
		configuration.setAlias("TestAlias");
		String formatPropertyValue = table.formatPropertyValue(configuration,
				ConfigurationConstants.ALIAS, new ObjectProperty<String>("TestAlias"));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("TestAlias", formatPropertyValue);
	}

	@Test
	public void humiditySensorTrueFormatterTest()
	{
		Configuration configuration = new Configuration();
		configuration.setHumidity(true);
		String formatPropertyValue = table.formatPropertyValue(configuration,
				ConfigurationConstants.HUMIDITY, new ObjectProperty<Boolean>(true));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals(new String(Character.toChars(FontAwesome.CHECK.getCodepoint())),
				formatPropertyValue);
	}

	@Test
	public void humiditySensorFalseFormatterTest()
	{
		Configuration configuration = new Configuration();
		configuration.setHumidity(false);
		String formatPropertyValue = table.formatPropertyValue(configuration,
				ConfigurationConstants.HUMIDITY, new ObjectProperty<Boolean>(false));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals(new String(Character.toChars(FontAwesome.TIMES.getCodepoint())),
				formatPropertyValue);
	}

	@Test
	public void humidityTemperatureSensorTrueFormatterTest()
	{
		Configuration configuration = new Configuration();
		configuration.setHumidity(true);
		String formatPropertyValue = table.formatPropertyValue(configuration,
				ConfigurationConstants.HUMIDITY_TEMPERATURE, new ObjectProperty<Boolean>(true));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals(new String(Character.toChars(FontAwesome.CHECK.getCodepoint())),
				formatPropertyValue);
	}

	@Test
	public void humidityTemperatureSensorFalseFormatterTest()
	{
		Configuration configuration = new Configuration();
		configuration.setHumidity(false);
		String formatPropertyValue = table.formatPropertyValue(configuration,
				ConfigurationConstants.HUMIDITY_TEMPERATURE, new ObjectProperty<Boolean>(false));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals(new String(Character.toChars(FontAwesome.TIMES.getCodepoint())),
				formatPropertyValue);
	}

	@Test
	public void temperatureSensorTrueFormatterTest()
	{
		Configuration configuration = new Configuration();
		configuration.setHumidity(true);
		String formatPropertyValue = table.formatPropertyValue(configuration,
				ConfigurationConstants.TEMPERATURE, new ObjectProperty<Boolean>(true));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals(new String(Character.toChars(FontAwesome.CHECK.getCodepoint())),
				formatPropertyValue);
	}

	@Test
	public void temperatureSensorFalseFormatterTest()
	{
		Configuration configuration = new Configuration();
		configuration.setHumidity(false);
		String formatPropertyValue = table.formatPropertyValue(configuration,
				ConfigurationConstants.TEMPERATURE, new ObjectProperty<Boolean>(false));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals(new String(Character.toChars(FontAwesome.TIMES.getCodepoint())),
				formatPropertyValue);
	}

	@Test
	public void deviceTemperatureSensorTrueFormatterTest()
	{
		Configuration configuration = new Configuration();
		configuration.setHumidity(true);
		String formatPropertyValue = table.formatPropertyValue(configuration,
				ConfigurationConstants.DEVICE_TEMPERATURE, new ObjectProperty<Boolean>(true));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals(new String(Character.toChars(FontAwesome.CHECK.getCodepoint())),
				formatPropertyValue);
	}

	@Test
	public void deviceTemperatureSensorFalseFormatterTest()
	{
		Configuration configuration = new Configuration();
		configuration.setHumidity(false);
		String formatPropertyValue = table.formatPropertyValue(configuration,
				ConfigurationConstants.DEVICE_TEMPERATURE, new ObjectProperty<Boolean>(false));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals(new String(Character.toChars(FontAwesome.TIMES.getCodepoint())),
				formatPropertyValue);
	}

	@Test
	public void routingSensorTrueFormatterTest()
	{
		Configuration configuration = new Configuration();
		configuration.setHumidity(true);
		String formatPropertyValue = table.formatPropertyValue(configuration,
				ConfigurationConstants.ROUTING, new ObjectProperty<Boolean>(true));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals(new String(Character.toChars(FontAwesome.CHECK.getCodepoint())),
				formatPropertyValue);
	}

	@Test
	public void routingSensorFalseFormatterTest()
	{
		Configuration configuration = new Configuration();
		configuration.setHumidity(false);
		String formatPropertyValue = table.formatPropertyValue(configuration,
				ConfigurationConstants.ROUTING, new ObjectProperty<Boolean>(false));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals(new String(Character.toChars(FontAwesome.TIMES.getCodepoint())),
				formatPropertyValue);
	}

	@Test
	public void sensorNotConfigurationFormatterTest()
	{
		Wagon wagon = new Wagon();
		String formatPropertyValue = table.formatPropertyValue(wagon,
				ConfigurationConstants.ROUTING, new ObjectProperty<Boolean>(false));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("false", formatPropertyValue);
	}

	@Test
	public void shockXGermanFormatterTest(final @Mocked Page page)
	{
		new Expectations()
		{
			{
				Page.getCurrent().getWebBrowser().getLocale();
				returns(new Locale("de"));
			}
		};
		Configuration configuration = new Configuration();
		configuration.setShockX(20.55555);
		String formatPropertyValue = table.formatPropertyValue(configuration,
				ConfigurationConstants.SHOCK_X, new ObjectProperty<Double>(20.55555));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("20,6", formatPropertyValue);
	}

	@Test
	public void shockYGermanFormatterTest(final @Mocked Page page)
	{
		new Expectations()
		{
			{
				Page.getCurrent().getWebBrowser().getLocale();
				returns(new Locale("de"));
			}
		};
		Configuration configuration = new Configuration();
		configuration.setShockY(20.55555);
		String formatPropertyValue = table.formatPropertyValue(configuration,
				ConfigurationConstants.SHOCK_Y, new ObjectProperty<Double>(20.55555));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("20,6", formatPropertyValue);
	}

	@Test
	public void shockZGermanFormatterTest(final @Mocked Page page)
	{
		new Expectations()
		{
			{
				Page.getCurrent().getWebBrowser().getLocale();
				returns(new Locale("de"));
			}
		};
		Configuration configuration = new Configuration();
		configuration.setShockZ(20.55555);
		String formatPropertyValue = table.formatPropertyValue(configuration,
				ConfigurationConstants.SHOCK_Z, new ObjectProperty<Double>(20.55555));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("20,6", formatPropertyValue);
	}

	@Test
	public void shockXEnglishFormatterTest(final @Mocked Page page)
	{
		new Expectations()
		{
			{
				Page.getCurrent().getWebBrowser().getLocale();
				returns(new Locale("en"));
			}
		};
		Configuration configuration = new Configuration();
		configuration.setShockX(20.55555);
		String formatPropertyValue = table.formatPropertyValue(configuration,
				ConfigurationConstants.SHOCK_X, new ObjectProperty<Double>(20.55555));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("20.6", formatPropertyValue);
	}

	@Test
	public void shockYEnglishFormatterTest(final @Mocked Page page)
	{
		new Expectations()
		{
			{
				Page.getCurrent().getWebBrowser().getLocale();
				returns(new Locale("en"));
			}
		};
		Configuration configuration = new Configuration();
		configuration.setShockY(20.55555);
		String formatPropertyValue = table.formatPropertyValue(configuration,
				ConfigurationConstants.SHOCK_Y, new ObjectProperty<Double>(20.55555));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("20.6", formatPropertyValue);
	}

	@Test
	public void shockZEnglishFormatterTest(final @Mocked Page page)
	{
		new Expectations()
		{
			{
				Page.getCurrent().getWebBrowser().getLocale();
				returns(new Locale("en"));
			}
		};
		Configuration configuration = new Configuration();
		configuration.setShockZ(20.55555);
		String formatPropertyValue = table.formatPropertyValue(configuration,
				ConfigurationConstants.SHOCK_Z, new ObjectProperty<Double>(20.55555));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("20.6", formatPropertyValue);
	}

	@Test
	public void gpsMovingSendingIntervalFormatterTest()
	{
		Configuration configuration = new Configuration();
		configuration.setGpsMoving(28800);
		String formatPropertyValue = table.formatPropertyValue(configuration,
				ConfigurationConstants.GPS_MOVING, new ObjectProperty<Integer>(28800));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("08:00", formatPropertyValue);
	}

	@Test
	public void gpsTimeBasedSendingIntervalFormatterTest()
	{
		Configuration configuration = new Configuration();
		configuration.setGpsTimeBased(86400);
		String formatPropertyValue = table.formatPropertyValue(configuration,
				ConfigurationConstants.GPS_TIME_BASED, new ObjectProperty<Integer>(86400));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("24:00", formatPropertyValue);
	}

	@Test
	public void gsmMovingSendingIntervalFormatterTest()
	{
		Configuration configuration = new Configuration();
		configuration.setGsmMoving(28800);
		String formatPropertyValue = table.formatPropertyValue(configuration,
				ConfigurationConstants.GSM_MOVING, new ObjectProperty<Integer>(28800));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("08:00", formatPropertyValue);
	}

	@Test
	public void gsmTimeBasedSendingIntervalFormatterTest()
	{
		Configuration configuration = new Configuration();
		configuration.setGsmTimeBased(86400);
		String formatPropertyValue = table.formatPropertyValue(configuration,
				ConfigurationConstants.GSM_TIME_BASED, new ObjectProperty<Integer>(86400));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("24:00", formatPropertyValue);
	}

	@Test
	public void flashDataGermanFormatterTest(final @Mocked Page page)
	{
		new Expectations()
		{
			{
				Page.getCurrent().getWebBrowser().getLocale();
				returns(new Locale("de"));
			}
		};
		Configuration configuration = new Configuration();
		configuration.setFlashData(100000);
		String formatPropertyValue = table.formatPropertyValue(configuration,
				ConfigurationConstants.FLASH_DATA, new ObjectProperty<Integer>(100000));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("100.000", formatPropertyValue);
	}

	@Test
	public void flashDataEnglishFormatterTest(final @Mocked Page page)
	{
		new Expectations()
		{
			{
				Page.getCurrent().getWebBrowser().getLocale();
				returns(new Locale("en"));
			}
		};
		Configuration configuration = new Configuration();
		configuration.setFlashData(100000);
		String formatPropertyValue = table.formatPropertyValue(configuration,
				ConfigurationConstants.FLASH_DATA, new ObjectProperty<Integer>(100000));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("100,000", formatPropertyValue);
	}

	@Test
	public void ruleNameFormatterTest()
	{
		Rule rule = new Rule();
		rule.setName("Testrule");
		rule.setWagons(Arrays.asList(new Wagon()));
		String formatPropertyValue = table.formatPropertyValue(rule, RuleConstants.RULE_NAME,
				new ObjectProperty<String>("Testrule"));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals(
				new String(Character.toChars(FontAwesome.CHAIN.getCodepoint())) + " " + "Testrule",
				formatPropertyValue);
	}

	@Test
	public void ruleNameEmptyFormatterTest()
	{
		Rule rule = new Rule();
		rule.setName("Testrule");
		String formatPropertyValue = table.formatPropertyValue(rule, RuleConstants.RULE_NAME,
				new ObjectProperty<String>("Testrule"));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("Testrule", formatPropertyValue);
	}

	@Test
	public void severityFormatterTest(final @Mocked I18n i18n, final @Mocked DashboardUI ui)
	{
		new Expectations()
		{
			{
				DashboardUI.getMessageSource().getMessage(
						"view.alarm.selectseverity." + Severity.RED.name().toLowerCase());
				returns("Hoch");
			}
		};
		Rule rule = new Rule();
		rule.setSeverity(Severity.RED);
		String formatPropertyValue = table.formatPropertyValue(rule, RuleConstants.RULE_SEVERITY,
				new ObjectProperty<Severity>(Severity.RED));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("Hoch", formatPropertyValue);
	}

	@Test
	public void severityNullFormatterTest()
	{
		Rule rule = new Rule();
		ObjectProperty<Severity> objectProperty = new ObjectProperty<Severity>(Severity.RED);
		objectProperty.setValue(null);
		String formatPropertyValue = table.formatPropertyValue(rule, RuleConstants.RULE_SEVERITY,
				objectProperty);
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("", formatPropertyValue);
	}

	@Test
	public void ruleActiveTrueFormatterTest()
	{
		Rule rule = new Rule();
		rule.setActive(true);
		String formatPropertyValue = table.formatPropertyValue(rule, RuleConstants.RULE_ACTIVE,
				new ObjectProperty<Boolean>(true));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals(new String(Character.toChars(FontAwesome.CHECK.getCodepoint())),
				formatPropertyValue);
	}

	@Test
	public void ruleActiveFalseFormatterTest()
	{
		Rule rule = new Rule();
		rule.setActive(false);
		String formatPropertyValue = table.formatPropertyValue(rule, RuleConstants.RULE_ACTIVE,
				new ObjectProperty<Boolean>(false));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals(new String(Character.toChars(FontAwesome.TIMES.getCodepoint())),
				formatPropertyValue);
	}

	@Test
	public void ruleTypeFormatterTest(final @Mocked I18n i18n, final @Mocked DashboardUI ui)
	{
		new Expectations()
		{
			{
				DashboardUI.getMessageSource().getMessage("view.alarm.selecttype.hm");
				returns("Relative Luftfeuchtigkeit in \u0025");
			}
		};
		Rule rule = new Rule();
		rule.setRuleType("HM");
		String formatPropertyValue = table.formatPropertyValue(rule, RuleConstants.RULE_TYPE,
				new ObjectProperty<String>("HM"));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("Relative Luftfeuchtigkeit in \u0025", formatPropertyValue);
	}

	@Test
	public void ruleTypeNullFormatterTest()
	{
		Rule rule = new Rule();
		ObjectProperty<String> objectProperty = new ObjectProperty<String>("HM");
		objectProperty.setValue(null);
		String formatPropertyValue = table.formatPropertyValue(rule, RuleConstants.RULE_TYPE,
				objectProperty);
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("", formatPropertyValue);
	}

	@Test
	public void ruleTypeHumidityUnitFormatterTest(final @Mocked I18n i18n,
			final @Mocked DashboardUI ui)
	{
		new Expectations()
		{
			{
				DashboardUI.getMessageSource().getMessage("view.alarm.unit.percent");
				returns("\u0025");
			}
		};
		Rule rule = new Rule();
		rule.setRuleType("HM");
		String formatPropertyValue = table.formatPropertyValue(rule, RuleConstants.RULE_UNIT,
				new ObjectProperty<String>("HM"));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("\u0025", formatPropertyValue);
	}

	@Test
	public void ruleTypeHumidityTemperatureUnitFormatterTest(final @Mocked I18n i18n,
			final @Mocked DashboardUI ui)
	{
		new Expectations()
		{
			{
				DashboardUI.getMessageSource().getMessage("view.alarm.unit.celsius");
				returns("\u00B0C");
			}
		};
		Rule rule = new Rule();
		rule.setRuleType("HT");
		String formatPropertyValue = table.formatPropertyValue(rule, RuleConstants.RULE_UNIT,
				new ObjectProperty<String>("HT"));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("\u00B0C", formatPropertyValue);
	}

	@Test
	public void ruleTypeDeviceTemperatureUnitFormatterTest(final @Mocked I18n i18n,
			final @Mocked DashboardUI ui)
	{
		new Expectations()
		{
			{
				DashboardUI.getMessageSource().getMessage("view.alarm.unit.celsius");
				returns("\u00B0C");
			}
		};
		Rule rule = new Rule();
		rule.setRuleType("DT");
		String formatPropertyValue = table.formatPropertyValue(rule, RuleConstants.RULE_UNIT,
				new ObjectProperty<String>("DT"));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("\u00B0C", formatPropertyValue);
	}

	@Test
	public void ruleTypeMileageUnitFormatterTest(final @Mocked I18n i18n,
			final @Mocked DashboardUI ui)
	{
		new Expectations()
		{
			{
				DashboardUI.getMessageSource().getMessage("view.alarm.unit.km");
				returns("KM");
			}
		};
		Rule rule = new Rule();
		rule.setRuleType("KM");
		String formatPropertyValue = table.formatPropertyValue(rule, RuleConstants.RULE_UNIT,
				new ObjectProperty<String>("KM"));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("KM", formatPropertyValue);
	}

	@Test
	public void ruleTypeNullUnitFormatterTest()
	{
		Rule rule = new Rule();
		rule.setRuleType("notexsiting");
		String formatPropertyValue = table.formatPropertyValue(rule, RuleConstants.RULE_UNIT,
				new ObjectProperty<String>("notexsiting"));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("notexsiting", formatPropertyValue);
	}

	@Test
	public void ruleAConditionFormatterTest(final @Mocked I18n i18n, final @Mocked DashboardUI ui)
	{
		new Expectations()
		{
			{
				DashboardUI.getMessageSource().getMessage("view.alarm.selectcondition.gt");
				returns("gr\u00F6\u00DFer als");
			}
		};
		Rule rule = new Rule();
		rule.setCondition("gt");
		String formatPropertyValue = table.formatPropertyValue(rule, RuleConstants.RULE_CONDITION,
				new ObjectProperty<String>("gt"));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("gr\u00F6\u00DFer als", formatPropertyValue);
	}

	@Test
	public void ruleAConditionNullFormatterTest()
	{
		Rule rule = new Rule();
		String formatPropertyValue = table.formatPropertyValue(rule, RuleConstants.RULE_CONDITION,
				new ObjectProperty<String>("gt"));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("", formatPropertyValue);
	}

	@Test
	public void defaultFormatterTest()
	{
		Wagon wagon = new Wagon();
		String formatPropertyValue = table.formatPropertyValue(wagon, "",
				new ObjectProperty<String>("Default"));
		Assert.assertNotNull(formatPropertyValue);
		Assert.assertEquals("Default", formatPropertyValue);
	}
}
