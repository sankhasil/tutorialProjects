
package com.bosch.si.amra.presenter.rule;

import java.io.IOException;
import java.io.InputStream;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.commons.io.IOUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.constants.rule.RuleConstants;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.entity.geofence.Geofence;
import com.bosch.si.amra.entity.rule.Rule;
import com.bosch.si.amra.entity.rule.Rule.Severity;
import com.bosch.si.amra.event.DashboardEvent.RuleReadEvent;
import com.bosch.si.amra.event.DashboardEvent.RuleSaveEvent;
import com.bosch.si.amra.event.DashboardEvent.RuleSortAndFilterEvent;
import com.bosch.si.amra.event.DashboardEvent.RulesDeleteEvent;
import com.bosch.si.amra.event.DashboardEvent.RulesSaveAliasEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.provider.DataProviderInitializer;
import com.bosch.si.amra.provider.rule.RuleDataProvider;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.WriteResult;
import com.mongodb.util.JSON;

import mockit.Expectations;
import mockit.Mocked;

@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (locations = "file:src/test/resources/spring-servlet.xml")
@PrepareForTest ({ DashboardUI.class })
public class RulePresenterTest
{
	private static final String	TEST_WAGON_ALIAS	= "ZTest1";

	private static final String	TEST_WAGON_ID		= "002fbeb5-6283-401f-88f9-78acfd1a5380";

	private static final String	ANONYMOUS_EMAIL		= "anonymous@xyz.com";

	private static final String	SUDHEESH_EMAIL		= "SudheeshVailankatil.Krishna@bosch-si.com";

	private static final String	TEST_TENANT_ID		= "1798c300-c27f-11e4-81a3-0050569350e8";

	@Autowired
	private RulePresenter		rulePresenter;

	@Autowired
	private RuleDataProvider	ruleDataProvider;

	@Mocked
	final DashboardEventBus		eventBus			= null;

	@Mocked
	DashboardUI					dashboardUi;

	@Value ("${MONGO_HOST}")
	public String				MONGO_HOST;

	@Value ("${MONGO_PORT}")
	public Integer				MONGO_PORT;

	@Value ("${MONGO_DATABASE}")
	public String				MONGO_DATABASE;

	@Value ("${MONGO_USERNAME}")
	public String				MONGO_USERNAME;

	@Value ("${MONGO_PASSWORD}")
	public String				MONGO_PASSWORD;

	@Value ("${RULE_COLLECTION}")
	public String				RULE_COLLECTION;

	@Value ("${WAGON_COLLECTION}")
	public String				WAGON_COLLECTION;

	@Value ("${CONFIGURATION_COLLECTION}")
	private String				CONFIGURATION_COLLECTION;

	@SuppressWarnings ("unchecked")
	@Before
	public void setUp() throws IOException
	{

		DBCollection collection = getCollection();
		InputStream testMessage = RulePresenterTest.class
				.getResourceAsStream("/testData/rule/rule.json");
		String message = IOUtils.toString(testMessage, "UTF-8");

		Object parse = JSON.parse(message);
		List<DBObject> objectToSave = (List<DBObject>) parse;
		collection.insert(objectToSave);
	}

	@After
	public void tearDown() throws UnknownHostException
	{
		DBCollection collection = getCollection();
		if (collection != null)
		{
			collection.remove(new BasicDBObject());
		}
	}

	@Test
	public void getRuleTest() throws UnknownHostException
	{
		getMongoClient();
		Rule rule = rulePresenter
				.getRule(new RuleReadEvent("6c48de74-c9ad-4b26-95ec-4cd8ac21bf13"));
		Assert.assertNotNull(rule);
		Assert.assertEquals("6c48de74-c9ad-4b26-95ec-4cd8ac21bf13", rule.getId());
		Assert.assertEquals("ÄRule911", rule.getName());
		Assert.assertEquals(true, rule.getActive());
		Assert.assertEquals("HM", rule.getRuleType());
		Assert.assertEquals(Severity.GREEN, rule.getSeverity());
		Assert.assertEquals(TEST_TENANT_ID, rule.getTenantId());
		List<Wagon> wagons = rule.getWagons();
		Assert.assertNotNull(wagons);
		Assert.assertTrue(wagons.size() == 1);
		for (Wagon wagon : wagons)
		{
			Assert.assertNotNull(wagon);
			Assert.assertEquals("5a3e9bde-5bfe-4697-8929-f7dcd76c93ez", wagon.getId());
			Assert.assertEquals("ÄTest0", wagon.getAlias());
			Assert.assertTrue(wagon.getInitial());
		}
		Assert.assertTrue(SUDHEESH_EMAIL.equals(rule.getEmail()));
	}

	@Test
	public void getRulesTest() throws UnknownHostException
	{

		getMongoClient();
		List<Rule> ruleList = ruleDataProvider.getRules(TEST_TENANT_ID);
		Assert.assertNotNull(ruleList);
		Assert.assertEquals(8, ruleList.size());
		for (Rule rule : ruleList)
		{
			if (rule.getName().equals("ÄRule911"))
			{
				Assert.assertEquals("6c48de74-c9ad-4b26-95ec-4cd8ac21bf13", rule.getId());
				Assert.assertEquals(true, rule.getActive());
				Assert.assertEquals("HM", rule.getRuleType());
				Assert.assertEquals(Severity.GREEN, rule.getSeverity());
				Assert.assertEquals(TEST_TENANT_ID, rule.getTenantId());
				List<Wagon> wagons = rule.getWagons();
				Assert.assertNotNull(wagons);
				Assert.assertTrue(wagons.size() == 1);
				for (Wagon wagon : wagons)
				{
					Assert.assertNotNull(wagon);
					Assert.assertEquals("5a3e9bde-5bfe-4697-8929-f7dcd76c93ez", wagon.getId());
					Assert.assertEquals("ÄTest0", wagon.getAlias());
					Assert.assertTrue(wagon.getInitial());
				}
			}
			else if (rule.getName().equals("ZRule1066"))
			{
				List<Wagon> wagons = rule.getWagons();
				Assert.assertNotNull(wagons);
				Assert.assertTrue(wagons.size() == 2);
				for (Wagon wagon : wagons)
				{
					Assert.assertNotNull(wagon);
					if (wagon.getId().equals(TEST_WAGON_ID))
					{
						Assert.assertEquals(TEST_WAGON_ALIAS, wagon.getAlias());
						Assert.assertFalse(wagon.getInitial());
					}
				}
				Assert.assertTrue(rule.getLimit() == 80);
				Assert.assertEquals("gt", rule.getCondition());
				Assert.assertEquals(Severity.GREEN, rule.getSeverity());
				Assert.assertEquals("HM", rule.getRuleType());
				Assert.assertTrue(rule.getActive());
			}
			else if (rule.getName().equals("BetaRule9721"))
			{
				List<Wagon> wagons = rule.getWagons();
				Assert.assertNotNull(wagons);
				Assert.assertTrue(wagons.size() == 1);
				for (Wagon wagon : wagons)
				{
					Assert.assertNotNull(wagon);
					if (wagon.getId().equals(TEST_WAGON_ID))
					{
						Assert.assertEquals("Zoo1066", wagon.getAlias());
						Assert.assertFalse(wagon.getInitial());
					}
					if (wagon.getId().equals("012fbeb5-6283-401f-88f9-78acfd1a5380"))
					{
						Assert.assertEquals("Zack001", wagon.getAlias());
						Assert.assertTrue(wagon.getInitial());
					}
				}
				Geofence geofence = rule.getGeofence();
				Assert.assertEquals("Berlin", geofence.getName());
				Assert.assertEquals("out", rule.getCondition());
				Assert.assertEquals(Severity.GREEN, rule.getSeverity());
				Assert.assertEquals("GEOFENCE", rule.getRuleType());
				Assert.assertTrue(rule.getActive());
			}
		}
	}

	@Test
	public void deleteAlarmRulesTest() throws UnknownHostException
	{
		new Expectations()
		{
			{
				DashboardUI.getRuleDataProvider();
				returns(ruleDataProvider);
			}
		};
		getMongoClient();

		Rule aR = new Rule();
		List<Rule> deleteRuleList = new ArrayList<Rule>();
		aR.setId("b11abec6-5efa-40fb-9913-b72172b7749c");
		deleteRuleList.add(aR);

		rulePresenter.deleteRules(new RulesDeleteEvent(deleteRuleList, TEST_TENANT_ID));

		List<Rule> ruleList = ruleDataProvider.getRules(TEST_TENANT_ID);
		Assert.assertNotNull(ruleList);
		Assert.assertEquals(7, ruleList.size());
	}

	@Test
	public void saveRuleTest() throws UnknownHostException
	{
		getMongoClient();

		Rule rule = createRule();
		rule.setWagons(Arrays.asList(createWagon(TEST_WAGON_ID, TEST_WAGON_ALIAS)));
		RuleSaveEvent event = new RuleSaveEvent(rule, TEST_TENANT_ID, null);
		rulePresenter.saveRule(event);

		DBCollection collection = getCollection();
		DBCursor find = collection.find(new BasicDBObject("TI", TEST_TENANT_ID));
		Assert.assertNotNull(find);
		Assert.assertTrue(find.count() == 9);
		find = collection.find(new BasicDBObject("wagons.initial", true));
		Assert.assertNotNull(find);
		Assert.assertTrue(find.count() == 3);
		BasicDBList list = new BasicDBList();
		list.add(SUDHEESH_EMAIL);
		list.add("SudheeshVailankatil.Krishna@in.bosch");
		find = collection.find(new BasicDBObject("email", list));
		Assert.assertNotNull(find);
	}

	@Test
	public void createHTRRuleTest() throws UnknownHostException
	{
		new Expectations()
		{
			{
				DashboardUI.getConfigurationCollection();
				returns(CONFIGURATION_COLLECTION);
			}
		};
		getMongoClient();
		Rule firstHTRRule = createRule();
		firstHTRRule.setRuleType(RuleConstants.HUMIDITY_TEMPERATURE_RANGE);
		firstHTRRule.setCondition(RuleConstants.OUT_RANGE);
		firstHTRRule.setLimit(null);
		firstHTRRule.setMaxRange(20);
		firstHTRRule.setMinRange(-30);
		firstHTRRule.setWagons(Arrays.asList(createWagon(TEST_WAGON_ID, TEST_WAGON_ALIAS)));

		RuleSaveEvent first_event = new RuleSaveEvent(firstHTRRule, TEST_TENANT_ID, null);
		Assert.assertNotNull(rulePresenter.saveRule(first_event));

		DBCollection collection = getCollection();
		BasicDBObject findCriteria = new BasicDBObject(MongoConstants.TENANT_ID, TEST_TENANT_ID);
		findCriteria.put(MongoConstants.ALARM_RULE_TYPE, RuleConstants.HUMIDITY_TEMPERATURE_RANGE);
		DBCursor find = collection.find(findCriteria);
		Assert.assertNotNull(find);
		Assert.assertTrue(find.count() == 1);

		DBCollection configCollection = getConfigurationCollection();
		BasicDBObject findCriteriaForConfiguration = new BasicDBObject(MongoConstants.WAGON_ID,
				TEST_WAGON_ID);
		findCriteria.put(MongoConstants.SORT, TEST_WAGON_ALIAS.toLowerCase());
		findCriteria.put(MongoConstants.TEMPERATURE_RANGE_MAX, 20);
		findCriteria.put(MongoConstants.TEMPERATURE_RANGE_MIN, -30);

		DBCursor findConfig = configCollection.find(findCriteriaForConfiguration);
		Assert.assertNotNull(findConfig);
		Assert.assertTrue(findConfig.count() == 1);

	}

	@Test
	public void updateRuleTest() throws UnknownHostException
	{
		getMongoClient();
		Rule ruleToUpdate = ruleDataProvider.getRules(TEST_TENANT_ID).get(0);
		ruleToUpdate.setEmail(ANONYMOUS_EMAIL);
		ruleToUpdate.setCondition(MongoConstants.LESSER_THAN);
		RuleSaveEvent event = new RuleSaveEvent(ruleToUpdate, TEST_TENANT_ID, null);
		rulePresenter.saveRule(event);

		DBCollection collection = getCollection();
		BasicDBObject findCriteria = new BasicDBObject(MongoConstants.TENANT_ID, TEST_TENANT_ID);
		findCriteria.put(MongoConstants.ID, ruleToUpdate.getId());
		findCriteria.put(MongoConstants.EMAIL, ANONYMOUS_EMAIL);
		findCriteria.put(MongoConstants.SENSORVALUES_ELEMENT + "." + MongoConstants.ALARM_CONDITION,
				MongoConstants.LESSER_THAN);

		DBCursor find = collection.find(findCriteria);
		Assert.assertNotNull(find);
		Assert.assertTrue(find.count() == 1);

		List<Wagon> wagons = ruleToUpdate.getWagons();
		DBObject next = find.next();
		Assert.assertNotNull(next);
		BasicDBList wagonsList = (BasicDBList) next.get(MongoConstants.RULE_WAGONS);
		Assert.assertTrue(wagons.size() == wagonsList.size());
		for (Wagon wagon : wagons)
		{
			for (Object wagonObject : wagonsList)
			{
				DBObject wagonObj = (DBObject) wagonObject;
				if (wagon.getId().equals(wagonObj.get(MongoConstants.ID)))
					Assert.assertEquals(wagon.getInitial(),
							wagonObj.get(MongoConstants.ALARM_INITIAL));
			}
		}
	}

	@Test
	public void createTwoHTRRuleAssigningSameWagonTest() throws UnknownHostException
	{
		new Expectations()
		{
			{
				DashboardUI.getConfigurationCollection();
				returns(CONFIGURATION_COLLECTION);
			}
		};
		getMongoClient();
		Rule firstHTRRule = createRule();
		firstHTRRule.setRuleType(RuleConstants.HUMIDITY_TEMPERATURE_RANGE);
		firstHTRRule.setCondition(RuleConstants.OUT_RANGE);
		firstHTRRule.setLimit(null);
		firstHTRRule.setMaxRange(20);
		firstHTRRule.setMinRange(-30);
		firstHTRRule.setWagons(Arrays.asList(createWagon(TEST_WAGON_ID, TEST_WAGON_ALIAS)));

		RuleSaveEvent first_event = new RuleSaveEvent(firstHTRRule, TEST_TENANT_ID, null);
		Assert.assertNotNull(rulePresenter.saveRule(first_event));

		DBCollection collection = getCollection();
		BasicDBObject findCriteria = new BasicDBObject(MongoConstants.TENANT_ID, TEST_TENANT_ID);
		findCriteria.put(MongoConstants.ALARM_RULE_TYPE, RuleConstants.HUMIDITY_TEMPERATURE_RANGE);
		DBCursor find = collection.find(findCriteria);
		Assert.assertNotNull(find);
		Assert.assertTrue(find.count() == 1);

		Rule secondRule = createRule();
		secondRule.setRuleType(RuleConstants.HUMIDITY_TEMPERATURE_RANGE);
		secondRule.setCondition(RuleConstants.OUT_RANGE);
		secondRule.setLimit(null);
		secondRule.setMaxRange(26);
		secondRule.setMinRange(-37);
		secondRule.setWagons(
				Arrays.asList(createWagon("012fbeb5-6283-401f-88f9-78acfd1a5380", "Zack001"),
						createWagon(TEST_WAGON_ID, TEST_WAGON_ALIAS)));
		RuleSaveEvent second_event = new RuleSaveEvent(secondRule, TEST_TENANT_ID, null);
		Assert.assertNull(rulePresenter.saveRule(second_event));
	}

	@Test (expected = IllegalArgumentException.class)
	public void saveRuleForEmptyTenantTest()
	{
		rulePresenter.saveRule(new RuleSaveEvent(createRule(), "", null));
	}

	@Test (expected = IllegalArgumentException.class)
	public void saveRuleForNullTenantTest()
	{
		rulePresenter.saveRule(new RuleSaveEvent(createRule(), null, null));
	}

	@Test (expected = IllegalArgumentException.class)
	public void saveRuleForNullRuleTest()
	{
		rulePresenter.saveRule(new RuleSaveEvent(null, TEST_TENANT_ID, null));
	}

	@Test (expected = IllegalArgumentException.class)
	public void saveRuleForBothNullTest()
	{
		rulePresenter.saveRule(new RuleSaveEvent(null, null, null));
	}

	@Test
	public void sortlimitRuleTest() throws UnknownHostException
	{
		new Expectations()
		{
			{
				DashboardUI.getRuleDataProvider();
				returns(ruleDataProvider);
			}
		};
		getMongoClient();

		RuleSortAndFilterEvent event = new RuleSortAndFilterEvent(TEST_TENANT_ID, "limit", true,
				null);
		List<Rule> sortAndFilter = rulePresenter.sortAndFilter(event);
		Assert.assertNotNull(sortAndFilter);
		Assert.assertNotNull(sortAndFilter.size());

		Assert.assertTrue(sortAndFilter.size() == 8);

		Rule firstRule = sortAndFilter.get(0);
		Assert.assertEquals("BetaRule9721", firstRule.getName());

		Rule secondRule = sortAndFilter.get(1);
		Assert.assertEquals("ZRule2077", secondRule.getName());

		Rule lastRule = sortAndFilter.get(sortAndFilter.size() - 1);
		Assert.assertEquals("ZRule1007", lastRule.getName());
	}

	@Test
	public void sortRuleNullPropertyTest() throws UnknownHostException
	{
		getMongoClient();
		new Expectations()
		{
			{
				DashboardUI.getRuleDataProvider();
				returns(ruleDataProvider);
			}
		};

		RuleSortAndFilterEvent event = new RuleSortAndFilterEvent(TEST_TENANT_ID, null, true, null);
		List<Rule> sortAndFilter = rulePresenter.sortAndFilter(event);
		Assert.assertNotNull(sortAndFilter);
		Assert.assertTrue(sortAndFilter.size() == 8);

		Rule firstRule = sortAndFilter.get(0);
		Assert.assertEquals("BetaRule972", firstRule.getName());

		Rule lastRule = sortAndFilter.get(sortAndFilter.size() - 1);
		Assert.assertEquals("ÄRule911", lastRule.getName());
	}

	@Test
	public void filterRuleTest() throws UnknownHostException
	{
		new Expectations()
		{
			{
				DashboardUI.getRuleDataProvider();
				returns(ruleDataProvider);
			}
		};
		getMongoClient();

		RuleSortAndFilterEvent event = new RuleSortAndFilterEvent(TEST_TENANT_ID, "limit", true,
				"ZRule10");
		List<Rule> sortAndFilter = rulePresenter.sortAndFilter(event);
		Assert.assertNotNull(sortAndFilter);
		Assert.assertTrue(sortAndFilter.size() == 3);

		Rule firstRule = sortAndFilter.get(0);
		Assert.assertEquals("ZRule1077", firstRule.getName());

		Rule lastRule = sortAndFilter.get(sortAndFilter.size() - 1);
		Assert.assertEquals("ZRule1007", lastRule.getName());
	}

	@Test (expected = IllegalArgumentException.class)
	public void sortAndFilterWithNullTenantTest()
	{
		rulePresenter.sortAndFilter(new RuleSortAndFilterEvent(null, "alias", true, "Zac"));
	}

	@Test (expected = IllegalArgumentException.class)
	public void sortAndFilterWithEmptyTenantTest()
	{
		rulePresenter.sortAndFilter(new RuleSortAndFilterEvent("", "alias", true, "Zac"));
	}

	@Test
	public void saveAliasForRuleTest() throws UnknownHostException
	{
		getMongoClient();
		WriteResult writeResult = rulePresenter
				.saveAliasInRules(new RulesSaveAliasEvent("Geänderter Wagen", TEST_WAGON_ID));
		Assert.assertNotNull(writeResult);
		Assert.assertEquals(6, writeResult.getN());
		Assert.assertNull(writeResult.getUpsertedId());

		Rule rule = rulePresenter
				.getRule(new RuleReadEvent("9a2e5292-3b56-4d7f-8f26-5de5ed2c9920"));
		List<Wagon> wagons = rule.getWagons();
		Assert.assertNotNull(wagons);
		Assert.assertTrue(wagons.size() == 2);
		for (Wagon wagon : wagons)
		{
			Assert.assertNotNull(wagon);
			if (wagon.getId().equals(TEST_WAGON_ID))
			{
				Assert.assertEquals(TEST_WAGON_ID, wagon.getId());
				Assert.assertEquals("Geänderter Wagen", wagon.getAlias());
			}
		}
	}

	/**
	 * Trying to update alias of not existing wagon
	 *
	 * @throws UnknownHostException
	 */
	@Test
	public void saveAliasForNotExistingRuleTest() throws UnknownHostException
	{
		getMongoClient();
		WriteResult writeResult = rulePresenter.saveAliasInRules(new RulesSaveAliasEvent(
				"Geänderter Wagen", "992d077f-460c-4038-9454-2bff56929a7e"));
		Assert.assertNotNull(writeResult);
		Assert.assertEquals(0, writeResult.getN());
		Assert.assertNull(writeResult.getUpsertedId());
	}

	/**
	 * Trying to update alias of not existing wagon
	 *
	 * @throws UnknownHostException
	 */
	@Test
	public void saveAliasForNullWagonIdTest() throws UnknownHostException
	{
		WriteResult writeResult = rulePresenter
				.saveAliasInRules(new RulesSaveAliasEvent("Geänderter Wagen", null));
		Assert.assertNull(writeResult);
	}

	@Test
	public void saveAliasForNullAliasTest() throws UnknownHostException
	{
		WriteResult writeResult = rulePresenter.saveAliasInRules(
				new RulesSaveAliasEvent(null, "5a3e9bde-5bfe-4697-8929-f7dcd76c93ez"));
		Assert.assertNull(writeResult);
	}

	@Test
	public void saveAliasForBothNullTest() throws UnknownHostException
	{
		WriteResult writeResult = rulePresenter
				.saveAliasInRules(new RulesSaveAliasEvent(null, null));
		Assert.assertNull(writeResult);
	}

	private Wagon createWagon(String wagonId, String alias)
	{
		Wagon wagon = new Wagon();
		wagon.setId(wagonId);
		wagon.setAlias(alias);
		wagon.setInitial(true);
		return wagon;
	}

	private Rule createRule()
	{
		Rule rule = new Rule();
		rule.setId(UUID.randomUUID().toString());
		rule.setCondition("gt");
		rule.setLimit(50);
		rule.setName("Example Rule");
		rule.setRuleType("HM");
		rule.setSeverity(Severity.GREEN);
		rule.setTenantId(TEST_TENANT_ID);
		rule.setTimestamp(new Date());
		rule.setActive(true);
		rule.setEmail(
				"SudheeshVailankatil.Krishna@bosch-si.com,SudheeshVailankatil.Krishna@in.bosch");
		return rule;
	}

	private MongoClient getMongoClient() throws UnknownHostException
	{
		new Expectations()
		{
			{
				DashboardUI.getMongoUsername();
				returns(MONGO_USERNAME);
				DashboardUI.getMongoPassword();
				returns(MONGO_PASSWORD);
				DashboardUI.getMongoDatabase();
				returns(MONGO_DATABASE);
				DashboardUI.getMongoHost();
				returns(MONGO_HOST);
				DashboardUI.getMongoPort();
				returns(MONGO_PORT);
				DashboardUI.getRuleCollection();
				returns(RULE_COLLECTION);

			}
		};
		DataProviderInitializer.createMongoClient();
		return DataProviderInitializer.getMongoClient();
	}

	private DBCollection getCollection() throws UnknownHostException
	{
		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection collection = db.getCollection(DashboardUI.getRuleCollection());
		return collection;
	}

	private DBCollection getConfigurationCollection() throws UnknownHostException
	{
		new Expectations()
		{
			{
				DashboardUI.getConfigurationCollection();
				returns(CONFIGURATION_COLLECTION);

			}

		};
		DataProviderInitializer.createMongoClient();
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection collection = db.getCollection(DashboardUI.getConfigurationCollection());
		return collection;
	}
}
