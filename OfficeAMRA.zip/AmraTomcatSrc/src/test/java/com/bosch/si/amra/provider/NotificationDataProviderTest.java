
package com.bosch.si.amra.provider;

import java.io.IOException;
import java.io.InputStream;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.io.IOUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.notification.Address;
import com.bosch.si.amra.entity.notification.Notification;
import com.bosch.si.amra.entity.notification.Notification.Priority;
import com.bosch.si.amra.entity.rule.Rule;
import com.bosch.si.amra.provider.notification.NotificationDataProvider;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.util.JSON;

import mockit.Expectations;
import mockit.Mocked;

@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (locations = "file:src/test/resources/spring-servlet.xml")
public class NotificationDataProviderTest
{
	@Autowired
	private NotificationDataProvider	notificationDataProvider;

	@Value ("${MONGO_HOST}")
	public String						MONGO_HOST;

	@Value ("${MONGO_PORT}")
	public Integer						MONGO_PORT;

	@Value ("${MONGO_DATABASE}")
	public String						MONGO_DATABASE;

	@Value ("${MONGO_USERNAME}")
	public String						MONGO_USERNAME;

	@Value ("${MONGO_PASSWORD}")
	public String						MONGO_PASSWORD;

	@Value ("${NOTIFICATION_COLLECTION}")
	public String						NOTIFICATION_COLLECTION;

	@Value ("${WAGON_COLLECTION}")
	public String						WAGON_COLLECTION;

	@Mocked
	DashboardUI							dashboardUi;

	@After
	public void tearDown() throws UnknownHostException
	{
		getMongoClient();
		additionalCollectionExpectation();
		DBCollection collection = getCollection(DashboardUI.getNotificationCollection());
		collection.remove(new BasicDBObject());
		collection = getCollection(DashboardUI.getWagonCollection());
		collection.remove(new BasicDBObject());
	}

	@Test
	public void getAllNotificiationsTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		List<Notification> notifications = notificationDataProvider.getNotifications(createUser(),
				false, true);
		Assert.assertNotNull(notifications);
		Assert.assertTrue(notifications.size() == 10);
		for (Notification notification : notifications)
		{
			if (notification.getId().equals("917d8a68-4f99-4b39-8826-1bd4aa9dcb9b"))
			{
				Assert.assertEquals(new Double(51.318408), notification.getLatitude());
				Assert.assertEquals(new Double(11.226064), notification.getLongitude());
				Assert.assertEquals(Priority.YELLOW, notification.getPriority());
				Assert.assertEquals("SHUNTING_SHOCK_DETECTED_RX", notification.getReason());
				Assert.assertEquals("992d077f-460c-4038-9454-2bff56929a7e",
						notification.getWagonId());
				Address address = notification.getAddress();
				Assert.assertNotNull(address);
				Assert.assertEquals("Unstrut-Radweg", address.getStreet().trim());
				Assert.assertEquals("06577 Heldrungen", address.getCity().trim());
				Assert.assertEquals("Germany", address.getCountry());
				Rule rule = notification.getRule();
				Assert.assertNotNull(rule);
				Assert.assertEquals("", rule.getId());
				Assert.assertEquals("SHUNTING_SHOCK_DETECTED_RX", rule.getName());
				Assert.assertEquals("SHUNTING_SHOCK_DETECTED_RX", rule.getRuleType());
			}
		}
	}

	@Test
	public void getAllNotificiationsForDisponentTest() throws IOException
	{
		getMongoClient();
		additionalCollectionExpectation();
		fillTestDBForDisponents();
		User disponent = createUser();
		disponent.setAdmin(false);
		disponent.setId("7523a8e0-6e39-11e4-8035-0050569350e8");
		List<Notification> notifications = notificationDataProvider.getNotifications(disponent,
				false, true);
		Assert.assertNotNull(notifications);
		Assert.assertTrue(notifications.size() == 9);
	}

	/**
	 * Tests that if user has disponent and endcustomer roles it is handled as disponent.
	 */
	@Test
	public void getAllNotificiationsForUserDisponentAndEndcustomerTest() throws IOException
	{
		getMongoClient();
		additionalCollectionExpectation();
		fillTestDBForDisponents();
		User user = createUser();
		user.setAdmin(false);
		user.setDisponent(true);
		user.setEndCustomer(true);
		user.setId("7523a8e0-6e39-11e4-8035-0050569350e8");
		List<Notification> notifications = notificationDataProvider.getNotifications(user, false,
				true);
		Assert.assertNotNull(notifications);
		Assert.assertTrue(notifications.size() == 9);
	}

	@Test
	public void getTopFiveNotificationsTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		List<Notification> notifications = notificationDataProvider.getNotifications(createUser(),
				true, true);
		Assert.assertNotNull(notifications);
		Assert.assertTrue(notifications.size() == 5);
		Notification notification = notifications.get(0);
		Assert.assertEquals("d944dec5-8a03-4552-bdef-e13d308a2298", notification.getId());
		Assert.assertEquals(new Double(51.318408), notification.getLatitude());
		Assert.assertEquals(new Double(11.226064), notification.getLongitude());
		Assert.assertEquals(Priority.YELLOW, notification.getPriority());
		Assert.assertEquals("SHUNTING_SHOCK_DETECTED_RX", notification.getReason());
		Assert.assertEquals("992d077f-460c-4038-9454-2bff56929a7e", notification.getWagonId());
		Address address = notification.getAddress();
		Assert.assertNotNull(address);
		Assert.assertEquals("Unstrut-Radweg", address.getStreet().trim());
		Assert.assertEquals("06577 Heldrungen", address.getCity().trim());
		Assert.assertEquals("Germany", address.getCountry());
		Rule rule = notification.getRule();
		Assert.assertNotNull(rule);
		Assert.assertEquals("", rule.getId());
		Assert.assertEquals("SHUNTING_SHOCK_DETECTED_RX", rule.getName());
		Assert.assertEquals("SHUNTING_SHOCK_DETECTED_RX", rule.getRuleType());
	}

	@Test
	public void getTopFiveNotificationsForDisponentTest() throws IOException
	{
		getMongoClient();
		additionalCollectionExpectation();
		fillTestDBForDisponents();
		User disponent = createUser();
		disponent.setAdmin(false);
		disponent.setId("7523a8e0-6e39-11e4-8035-0050569350e8");
		List<Notification> notifications = notificationDataProvider.getNotifications(disponent,
				true, true);
		Assert.assertNotNull(notifications);
		Assert.assertTrue(notifications.size() == 5);
	}

	@Test
	public void getAcknowledgedNotificationsTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		List<Notification> notifications = notificationDataProvider.getNotifications(createUser(),
				false, false);
		Assert.assertNotNull(notifications);
		Assert.assertTrue(notifications.size() == 7);
	}

	@Test
	public void getAcknowledgedNotificationsForDisponentTest() throws IOException
	{
		getMongoClient();
		additionalCollectionExpectation();
		fillTestDBForDisponents();
		User disponent = createUser();
		disponent.setAdmin(false);
		disponent.setId("7523a8e0-6e39-11e4-8035-0050569350e8");
		List<Notification> notifications = notificationDataProvider.getNotifications(disponent,
				false, false);
		Assert.assertNotNull(notifications);
		Assert.assertTrue(notifications.size() == 6);
	}

	@Test
	public void getAcknowledgedTopFiveNotificationsTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		List<Notification> notifications = notificationDataProvider.getNotifications(createUser(),
				true, false);
		Assert.assertNotNull(notifications);
		Assert.assertTrue(notifications.size() == 5);
	}

	@Test
	public void getAcknowledgedTopFiveNotificationsForDisponentTest() throws IOException
	{
		getMongoClient();
		additionalCollectionExpectation();
		fillTestDBForDisponents();
		User disponent = createUser();
		disponent.setAdmin(false);
		disponent.setId("7523a8e0-6e39-11e4-8035-0050569350e8");
		List<Notification> notifications = notificationDataProvider.getNotifications(disponent,
				true, false);
		Assert.assertNotNull(notifications);
		Assert.assertTrue(notifications.size() == 5);
	}

	@Test
	public void getNotificationsCheckTimestampForStuttgartTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		List<Notification> notifications = notificationDataProvider.getNotifications(createUser(),
				false, true);
		Assert.assertNotNull(notifications);
		Assert.assertTrue(notifications.size() == 10);
		TimeZone userTimeZone = TimeZone.getTimeZone("Europe/Berlin");
		SimpleDateFormat displayFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
		displayFormat.setTimeZone(userTimeZone);

		for (Notification notification : notifications)
		{
			if (notification.getId().equals("917d8a68-4f99-4b39-8826-1bd4aa9dcb9b"))
			{
				String dateFormatted = displayFormat.format(notification.getTimestamp());
				Assert.assertEquals("02.01.2015 03:02:02", dateFormatted);
			}
			if (notification.getId().equals("d944dec5-8a03-4552-bdef-e13d308a2298"))
			{
				String dateFormatted = displayFormat.format(notification.getTimestamp());
				Assert.assertEquals("05.05.2015 16:01:01", dateFormatted);
			}
		}
	}

	@Test
	public void getNotificationsCheckTimestampForLondonTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		List<Notification> notifications = notificationDataProvider.getNotifications(createUser(),
				false, true);
		Assert.assertNotNull(notifications);
		Assert.assertTrue(notifications.size() == 10);
		TimeZone userTimeZone = TimeZone.getTimeZone("Europe/London");
		SimpleDateFormat displayFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
		displayFormat.setTimeZone(userTimeZone);

		for (Notification notification : notifications)
		{
			if (notification.getId().equals("917d8a68-4f99-4b39-8826-1bd4aa9dcb9b"))
			{
				String dateFormatted = displayFormat.format(notification.getTimestamp());
				Assert.assertEquals("02.01.2015 02:02:02", dateFormatted);
			}
			if (notification.getId().equals("d944dec5-8a03-4552-bdef-e13d308a2298"))
			{
				String dateFormatted = displayFormat.format(notification.getTimestamp());
				Assert.assertEquals("05.05.2015 15:01:01", dateFormatted);
			}
		}
	}

	@Test
	public void getNotificationsCheckTimestampForAlgierWithoutDSTTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		List<Notification> notifications = notificationDataProvider.getNotifications(createUser(),
				false, true);
		Assert.assertNotNull(notifications);
		Assert.assertTrue(notifications.size() == 10);
		TimeZone userTimeZone = TimeZone.getTimeZone("Africa/Algiers");
		SimpleDateFormat displayFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
		displayFormat.setTimeZone(userTimeZone);

		for (Notification notification : notifications)
		{
			if (notification.getId().equals("917d8a68-4f99-4b39-8826-1bd4aa9dcb9b"))
			{
				String dateFormatted = displayFormat.format(notification.getTimestamp());
				Assert.assertEquals("02.01.2015 03:02:02", dateFormatted);
			}
			if (notification.getId().equals("d944dec5-8a03-4552-bdef-e13d308a2298"))
			{
				String dateFormatted = displayFormat.format(notification.getTimestamp());
				Assert.assertEquals("05.05.2015 15:01:01", dateFormatted);
			}
		}
	}

	@Test
	public void unreadNotificationsCountTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		int unreadNotificationsCount = notificationDataProvider
				.getUnreadNotificationsCount(createUser());
		Assert.assertEquals(7, unreadNotificationsCount);
	}

	@Test
	public void unreadNotificationsCountForDisponentTest() throws IOException
	{
		getMongoClient();
		additionalCollectionExpectation();
		fillTestDBForDisponents();
		User disponent = createUser();
		disponent.setAdmin(false);
		disponent.setId("7523a8e0-6e39-11e4-8035-0050569350e8");
		int unreadNotificationsCount = notificationDataProvider
				.getUnreadNotificationsCount(disponent);
		Assert.assertEquals(6, unreadNotificationsCount);
	}

	@Test
	public void unreadNotificationsCountForEndCustomerTest() throws IOException
	{
		getMongoClient();
		additionalCollectionExpectation();
		fillTestDBForEndCustomers();
		User endCustomer = createUser();
		endCustomer.setAdmin(false);
		endCustomer.setEndCustomer(true);
		endCustomer.setId("7523a8e0-6e39-11e4-8035-0050569350e9");
		int unreadNotificationsCount = notificationDataProvider
				.getUnreadNotificationsCount(endCustomer);
		Assert.assertEquals(0, unreadNotificationsCount);
	}

	@Test
	public void getNotificationsForEndCustomerTest() throws IOException
	{
		getMongoClient();
		additionalCollectionExpectation();
		fillTestDBForEndCustomers();
		User endCustomer = createUser();
		endCustomer.setAdmin(false);
		endCustomer.setEndCustomer(true);
		endCustomer.setId("7523a8e0-6e39-11e4-8035-0050569350e9");
		List<Notification> notificationsForWagonsWithAssignedEndCustomer = notificationDataProvider
				.getNotifications(endCustomer, false, true);
		Assert.assertNotNull(notificationsForWagonsWithAssignedEndCustomer);
		Assert.assertEquals(1, notificationsForWagonsWithAssignedEndCustomer.size());
	}

	private MongoClient getMongoClient() throws UnknownHostException
	{
		new Expectations()
		{
			{
				DashboardUI.getMongoUsername();
				returns(MONGO_USERNAME);
				DashboardUI.getMongoPassword();
				returns(MONGO_PASSWORD);
				DashboardUI.getMongoDatabase();
				returns(MONGO_DATABASE);
				DashboardUI.getMongoHost();
				returns(MONGO_HOST);
				DashboardUI.getMongoPort();
				returns(MONGO_PORT);
				DashboardUI.getNotificationCollection();
				returns(NOTIFICATION_COLLECTION);
			}
		};
		DataProviderInitializer.createMongoClient();
		return DataProviderInitializer.getMongoClient();
	}

	private void additionalCollectionExpectation()
	{
		new Expectations()
		{
			{
				DashboardUI.getWagonCollection();
				returns(WAGON_COLLECTION);
			}
		};
	}

	@SuppressWarnings ("unchecked")
	private void fillTestDB() throws IOException
	{

		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection collection = db.getCollection(DashboardUI.getNotificationCollection());
		InputStream testMessage = NotificationDataProviderTest.class
				.getResourceAsStream("/testData/notification/notifications.json");
		String message = IOUtils.toString(testMessage, "UTF-8");

		Object parse = JSON.parse(message);
		List<DBObject> objectToSave = (List<DBObject>) parse;
		collection.insert(objectToSave);
	}

	@SuppressWarnings ("unchecked")
	private void fillTestDBForDisponents() throws IOException
	{

		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection collection = db.getCollection(DashboardUI.getNotificationCollection());
		InputStream testMessage = NotificationDataProviderTest.class
				.getResourceAsStream("/testData/notification/notificationsForDisponent.json");
		String message = IOUtils.toString(testMessage, "UTF-8");

		Object parse = JSON.parse(message);
		List<DBObject> objectToSave = (List<DBObject>) parse;
		collection.insert(objectToSave);

		collection = db.getCollection(DashboardUI.getWagonCollection());
		testMessage = this.getClass().getResourceAsStream("/testData/wagon/wagon.json");
		message = IOUtils.toString(testMessage, "UTF-8");

		parse = JSON.parse(message);
		objectToSave = (List<DBObject>) parse;
		collection.insert(objectToSave);
	}

	@SuppressWarnings ("unchecked")
	private void fillTestDBForEndCustomers() throws IOException
	{

		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection collection = db.getCollection(DashboardUI.getNotificationCollection());
		InputStream testMessage = NotificationDataProviderTest.class
				.getResourceAsStream("/testData/notification/notificationsForEndCustomer.json");
		String message = IOUtils.toString(testMessage, "UTF-8");

		Object parse = JSON.parse(message);
		List<DBObject> objectToSave = (List<DBObject>) parse;
		collection.insert(objectToSave);

		collection = db.getCollection(DashboardUI.getWagonCollection());
		testMessage = this.getClass().getResourceAsStream("/testData/wagon/wagon.json");
		message = IOUtils.toString(testMessage, "UTF-8");

		parse = JSON.parse(message);
		objectToSave = (List<DBObject>) parse;
		collection.insert(objectToSave);
	}

	private DBCollection getCollection(String collectionName) throws UnknownHostException
	{
		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		return db.getCollection(collectionName);
	}

	private User createUser()
	{
		User user = new User();
		user.setTenant("cbeaa370-c11d-11e1-8ba8-d4bed92ae488");
		user.setAdmin(true);
		return user;
	}
}
