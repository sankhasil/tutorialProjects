
package com.bosch.si.amra.presenter.role;

import java.io.IOException;
import java.io.InputStream;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.entity.WagonUser;
import com.bosch.si.amra.event.DashboardEvent.AssignUserToWagonsEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.provider.DataProviderInitializer;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.WriteResult;
import com.mongodb.util.JSON;

import mockit.Expectations;
import mockit.Mocked;

@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (locations = "file:src/test/resources/spring-servlet.xml")
@PrepareForTest ({ DashboardUI.class })
public class RolePresenterTest
{
	private static final String	USERNAME_INST_KRMA2		= "inst-krma2";

	private static final String	USERNAME_INST_KRMA		= "inst-krma";

	private static final String	USERNAME_AE_BETH		= "ae-beth";

	private static final String	USERNAME_ALEKS			= "Aleks";

	private static final String	USER_ID_15FB7B90_E9		= "15fb7b90-6b3c-11e4-87b1-0050569350e9";

	private static final String	USER__ID_15FB7B90_E8	= "15fb7b90-6b3c-11e4-87b1-0050569350e8";

	private static final String	USER_ID_00F95B30_E8		= "00f95b30-717d-11e4-90de-0050569350e8";

	private static final String	USER_ID_7523A8E0_E8		= "7523a8e0-6e39-11e4-8035-0050569350e8";

	private static final String	WAGON_ID_6FF79722_6E	= "6ff79722-f6ab-4514-9702-94cfa5d5846e";

	@Autowired
	private RolePresenter		disponentsPresenter;

	@Mocked
	final DashboardEventBus		eventBus				= null;

	@Mocked
	DashboardUI					dashboardUi;

	@Value ("${MONGO_HOST}")
	public String				MONGO_HOST;

	@Value ("${MONGO_PORT}")
	public Integer				MONGO_PORT;

	@Value ("${MONGO_DATABASE}")
	public String				MONGO_DATABASE;

	@Value ("${MONGO_USERNAME}")
	public String				MONGO_USERNAME;

	@Value ("${MONGO_PASSWORD}")
	public String				MONGO_PASSWORD;

	@Value ("${WAGON_COLLECTION}")
	public String				WAGON_COLLECTION;

	@Before
	public void setUp() throws IOException
	{
		MockitoAnnotations.initMocks(this);
	}

	@After
	public void tearDown() throws UnknownHostException
	{
		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection collection = db.getCollection(DashboardUI.getWagonCollection());
		collection.remove(new BasicDBObject());
	}

	@Test
	public void assignNewUsers2WagonTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		WriteResult[] result = disponentsPresenter.saveUser2WagonAssignment(
				new AssignUserToWagonsEvent(createSelectedUsers(), WAGON_ID_6FF79722_6E));
		Assert.assertEquals(2, result.length);
		Assert.assertEquals(1, result[0].getN());
		Assert.assertEquals(1, result[1].getN());

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject wagon = wagonCollection
				.findOne(new BasicDBObject(MongoConstants.ID, WAGON_ID_6FF79722_6E));
		Assert.assertTrue(wagon.containsField(MongoConstants.DISPONENTS));
		Assert.assertTrue(wagon.containsField(MongoConstants.ENDCUSTOMERS));
		BasicDBList disponents = (BasicDBList) wagon.get(MongoConstants.DISPONENTS);
		BasicDBList endCustomers = (BasicDBList) wagon.get(MongoConstants.ENDCUSTOMERS);
		Assert.assertEquals(3, disponents.size());
		Assert.assertEquals(4, endCustomers.size());
	}

	@Test
	public void assignUsers2WagonToExistingAssignmentTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		List<WagonUser> createSelectedUsers = createSelectedUsers();
		createSelectedUsers
				.add(new WagonUser(USER_ID_7523A8E0_E8, USERNAME_ALEKS, false, null, null, null));
		createSelectedUsers
				.add(new WagonUser(USER_ID_00F95B30_E8, USERNAME_AE_BETH, false, null, null, null));
		createSelectedUsers.add(
				new WagonUser(USER__ID_15FB7B90_E8, USERNAME_INST_KRMA, false, null, null, null));
		createSelectedUsers.add(new WagonUser(USER_ID_15FB7B90_E9, USERNAME_INST_KRMA2, true,
				new Date(), null, null));
		WriteResult[] result = disponentsPresenter.saveUser2WagonAssignment(
				new AssignUserToWagonsEvent(createSelectedUsers, WAGON_ID_6FF79722_6E));
		Assert.assertEquals(2, result.length);
		Assert.assertEquals(1, result[0].getN());
		Assert.assertEquals(1, result[1].getN());

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject wagon = wagonCollection
				.findOne(new BasicDBObject(MongoConstants.ID, WAGON_ID_6FF79722_6E));
		Assert.assertTrue(wagon.containsField(MongoConstants.DISPONENTS));
		Assert.assertTrue(wagon.containsField(MongoConstants.ENDCUSTOMERS));
		BasicDBList disponents = (BasicDBList) wagon.get(MongoConstants.DISPONENTS);
		BasicDBList endCustomers = (BasicDBList) wagon.get(MongoConstants.ENDCUSTOMERS);
		Assert.assertEquals(6, disponents.size());
		Assert.assertEquals(5, endCustomers.size());
	}

	@Test
	public void assignNoUsers2WagonTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		WriteResult[] result = disponentsPresenter.saveUser2WagonAssignment(
				new AssignUserToWagonsEvent(new ArrayList<WagonUser>(), WAGON_ID_6FF79722_6E));
		Assert.assertEquals(2, result.length);
		Assert.assertEquals(1, result[0].getN());
		Assert.assertEquals(1, result[1].getN());

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject wagon = wagonCollection
				.findOne(new BasicDBObject(MongoConstants.ID, WAGON_ID_6FF79722_6E));
		Assert.assertTrue(wagon.containsField(MongoConstants.DISPONENTS));
		BasicDBList disponents = (BasicDBList) wagon.get(MongoConstants.DISPONENTS);
		BasicDBList endCustomers = (BasicDBList) wagon.get(MongoConstants.ENDCUSTOMERS);
		Assert.assertEquals(0, disponents.size());
		Assert.assertEquals(0, endCustomers.size());
	}

	@Test (expected = IllegalArgumentException.class)
	public void assignDisponent2WagonWithNoSelectedWagonTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		disponentsPresenter
				.saveUser2WagonAssignment(new AssignUserToWagonsEvent(createSelectedUsers(), null));
	}

	private List<WagonUser> createSelectedUsers()
	{
		List<WagonUser> selectedWagons = new ArrayList<>();
		for (int i = 0; i < 3; i++)
		{
			selectedWagons
					.add(new WagonUser(String.valueOf(i), "Test" + i, false, null, null, null));
		}

		for (int i = 4; i < 8; i++)
		{
			selectedWagons.add(
					new WagonUser(String.valueOf(i), "Test" + i, true, new Date(), null, null));
		}
		return selectedWagons;
	}

	private MongoClient getMongoClient() throws UnknownHostException
	{
		new Expectations()
		{
			{
				DashboardUI.getMongoUsername();
				returns(MONGO_USERNAME);
				DashboardUI.getMongoPassword();
				returns(MONGO_PASSWORD);
				DashboardUI.getMongoDatabase();
				returns(MONGO_DATABASE);
				DashboardUI.getMongoHost();
				returns(MONGO_HOST);
				DashboardUI.getMongoPort();
				returns(MONGO_PORT);
				DashboardUI.getWagonCollection();
				returns(WAGON_COLLECTION);
			}
		};
		DataProviderInitializer.createMongoClient();
		return DataProviderInitializer.getMongoClient();
	}

	@SuppressWarnings ("unchecked")
	private void fillTestDB() throws IOException
	{
		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection collection = db.getCollection(DashboardUI.getWagonCollection());
		InputStream testMessage = this.getClass()
				.getResourceAsStream("/testData/wagon/wagonUsers.json");
		String message = IOUtils.toString(testMessage, "UTF-8");

		Object parse = JSON.parse(message);
		List<DBObject> objectListToSave = (List<DBObject>) parse;
		collection.insert(objectListToSave);
	}

	private DBCollection getCollection(String collectionName)
	{
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection collection = db.getCollection(collectionName);
		return collection;
	}
}
