
package com.bosch.si.amra.view.notification.filter;

import java.util.Locale;

import org.junit.Assert;
import org.junit.Test;

import com.bosch.si.amra.constants.notification.NotificationConstants;
import com.bosch.si.amra.entity.notification.Notification;
import com.vaadin.data.util.BeanItem;
import com.vaadin.server.Page;

import mockit.Expectations;
import mockit.Mocked;

public class PositionFilterTest
{
	@Test
	public void latitudeAndLongitudeGermanFilterTest(@Mocked Page page)
	{
		new Expectations()
		{
			{
				Page.getCurrent().getWebBrowser().getLocale();
				returns(Locale.GERMAN);
			}
		};

		PositionFilter latitudeFilter = new PositionFilter(NotificationConstants.LATITUDE, "50,4");
		PositionFilter longitudeFilter = new PositionFilter(NotificationConstants.LONGITUDE, "9,7");

		Notification notification = getNotification();

		boolean latitudePasses = latitudeFilter.passesFilter(notification,
				new BeanItem<Notification>(notification));
		Assert.assertTrue(latitudePasses);
		boolean longitudePasses = longitudeFilter.passesFilter(notification,
				new BeanItem<Notification>(notification));
		Assert.assertTrue(longitudePasses);
	}

	@Test
	public void latitudeAndLongitudeEnglishFilterTest(@Mocked Page page)
	{
		new Expectations()
		{
			{
				Page.getCurrent().getWebBrowser().getLocale();
				returns(Locale.ENGLISH);
			}
		};

		PositionFilter latitudeFilter = new PositionFilter(NotificationConstants.LATITUDE, "50.4");
		PositionFilter longitudeFilter = new PositionFilter(NotificationConstants.LONGITUDE, "9.7");

		Notification notification = getNotification();

		boolean latitudePasses = latitudeFilter.passesFilter(notification,
				new BeanItem<Notification>(notification));
		Assert.assertTrue(latitudePasses);
		boolean longitudePasses = longitudeFilter.passesFilter(notification,
				new BeanItem<Notification>(notification));
		Assert.assertTrue(longitudePasses);
	}

	@Test
	public void latitudeAndLongitudeGermanNoFilterTest(@Mocked Page page)
	{
		new Expectations()
		{
			{
				Page.getCurrent().getWebBrowser().getLocale();
				returns(Locale.GERMAN);
			}
		};

		PositionFilter latitudeFilter = new PositionFilter(NotificationConstants.LATITUDE, "1");
		PositionFilter longitudeFilter = new PositionFilter(NotificationConstants.LONGITUDE, "1");

		Notification notification = getNotification();

		boolean latitudePasses = latitudeFilter.passesFilter(notification,
				new BeanItem<Notification>(notification));
		Assert.assertFalse(latitudePasses);
		boolean longitudePasses = longitudeFilter.passesFilter(notification,
				new BeanItem<Notification>(notification));
		Assert.assertFalse(longitudePasses);
	}

	@Test
	public void latitudeAndLongitudeEnglishNoFilterTest(@Mocked Page page)
	{
		new Expectations()
		{
			{
				Page.getCurrent().getWebBrowser().getLocale();
				returns(Locale.ENGLISH);
			}
		};

		PositionFilter latitudeFilter = new PositionFilter(NotificationConstants.LATITUDE, "1");
		PositionFilter longitudeFilter = new PositionFilter(NotificationConstants.LONGITUDE, "1");

		Notification notification = getNotification();

		boolean latitudePasses = latitudeFilter.passesFilter(notification,
				new BeanItem<Notification>(notification));
		Assert.assertFalse(latitudePasses);
		boolean longitudePasses = longitudeFilter.passesFilter(notification,
				new BeanItem<Notification>(notification));
		Assert.assertFalse(longitudePasses);
	}

	@Test
	public void nullPropertyTest()
	{
		PositionFilter latitudeFilter = new PositionFilter(NotificationConstants.LATITUDE, "50");

		Notification notification = new Notification();

		boolean latitudePasses = latitudeFilter.passesFilter(notification,
				new BeanItem<Notification>(notification));
		Assert.assertFalse(latitudePasses);
	}

	@Test
	public void nullValueTest()
	{
		PositionFilter latitudeFilter = new PositionFilter(NotificationConstants.LATITUDE, "50");

		Notification notification = new Notification();
		notification.setLatitude(null);

		boolean latitudePasses = latitudeFilter.passesFilter(notification,
				new BeanItem<Notification>(notification));
		Assert.assertFalse(latitudePasses);
	}

	@Test
	public void wrongTypeTest()
	{
		PositionFilter latitudeFilter = new PositionFilter(NotificationConstants.REASON, "50");

		Notification notification = new Notification();
		notification.setReason("Humidity");

		boolean latitudePasses = latitudeFilter.passesFilter(notification,
				new BeanItem<Notification>(notification));
		Assert.assertFalse(latitudePasses);
	}

	public Notification getNotification()
	{
		Notification notification = new Notification();
		notification.setLatitude(50.45);
		notification.setLongitude(9.7);
		return notification;
	}

}
