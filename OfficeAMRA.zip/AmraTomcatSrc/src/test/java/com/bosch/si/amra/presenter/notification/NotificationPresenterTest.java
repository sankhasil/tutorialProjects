
package com.bosch.si.amra.presenter.notification;

import java.io.IOException;
import java.io.InputStream;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.notification.Notification;
import com.bosch.si.amra.event.DashboardEvent.NotificationAcknowledgeEvent;
import com.bosch.si.amra.event.DashboardEvent.NotificationsSaveAliasEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.provider.DataProviderInitializer;
import com.bosch.si.amra.provider.NotificationDataProviderTest;
import com.bosch.si.amra.provider.notification.NotificationDataProvider;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.WriteResult;
import com.mongodb.util.JSON;

import mockit.Expectations;
import mockit.Mocked;

@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (locations = "file:src/test/resources/spring-servlet.xml")
@PrepareForTest ({ DashboardUI.class })
public class NotificationPresenterTest
{
	@Autowired
	NotificationPresenter		notificationPresenter;

	@Autowired
	NotificationDataProvider	notificationDataProvider;

	@Mocked
	final DashboardEventBus		eventBus	= null;

	@Mocked
	DashboardUI					dashboardUi;

	@Value ("${MONGO_HOST}")
	public String				MONGO_HOST;

	@Value ("${MONGO_PORT}")
	public Integer				MONGO_PORT;

	@Value ("${MONGO_DATABASE}")
	public String				MONGO_DATABASE;

	@Value ("${MONGO_USERNAME}")
	public String				MONGO_USERNAME;

	@Value ("${MONGO_PASSWORD}")
	public String				MONGO_PASSWORD;

	@Value ("${NOTIFICATION_COLLECTION}")
	public String				NOTIFICATION_COLLECTION;

	@Value ("${WAGON_COLLECTION}")
	public String				WAGON_COLLECTION;

	@Before
	public void setup() throws IOException
	{
	}

	@After
	public void tearDown() throws UnknownHostException
	{
		getMongoClient();
		additionalCollectionExpectation();
		DBCollection collection = getCollection(DashboardUI.getNotificationCollection());
		collection.remove(new BasicDBObject());
		collection = getCollection(DashboardUI.getWagonCollection());
		collection.remove(new BasicDBObject());
	}

	@Test
	public void counTest() throws IOException
	{
		getMongoClient();
		DBCollection collection = getCollection(DashboardUI.getNotificationCollection());
		fillTestDB();
		long count = collection.count();
		Assert.assertEquals(10, count);
	}

	@Test
	public void acknowledgeTest() throws IOException
	{
		getMongoClient();
		DBCollection collection = getCollection(DashboardUI.getNotificationCollection());
		fillTestDB();
		notificationPresenter.acknowledgeNotifications(
				new NotificationAcknowledgeEvent(createNotificationsList(), createUser()));
		DBCursor acknowledged = collection.find(new BasicDBObject("acknowledged", true));
		Assert.assertEquals(6, acknowledged.count());
	}

	@Test
	public void acknowledgeForDisponentsTest() throws IOException
	{
		getMongoClient();
		DBCollection collection = getCollection(DashboardUI.getNotificationCollection());
		additionalCollectionExpectation();
		fillTestDBForDisponents();
		User disponent = createUser();
		disponent.setAdmin(false);
		disponent.setId("7523a8e0-6e39-11e4-8035-0050569350e8");
		List<Notification> notifications = new ArrayList<Notification>();
		Notification notification = new Notification();
		notification.setAcknowledged(false);
		notification.setId("931f4e7c-1b50-47a2-a44b-9455b30c642d");
		notifications.add(notification);
		notificationPresenter.acknowledgeNotifications(
				new NotificationAcknowledgeEvent(notifications, disponent));
		DBCursor acknowledged = collection.find(new BasicDBObject("acknowledged", true));
		Assert.assertEquals(4, acknowledged.count());
	}

	@Test
	public void acknowledgeAlreadyAcknowledgedTest() throws IOException
	{
		getMongoClient();
		DBCollection collection = getCollection(DashboardUI.getNotificationCollection());
		fillTestDB();
		List<Notification> notifications = new ArrayList<Notification>(createNotificationsList());
		Notification notification = new Notification();
		notification.setAcknowledged(true);
		notification.setId("931f4e7c-1b50-47a2-a44b-9455b30c642d");
		notifications.add(notification);
		notificationPresenter.acknowledgeNotifications(
				new NotificationAcknowledgeEvent(notifications, createUser()));
		DBCursor acknowledged = collection.find(new BasicDBObject("acknowledged", true));
		Assert.assertEquals(6, acknowledged.count());
	}

	/**
	 * All wagons with WI 992d077f-460c-4038-9454-2bff56929a7e changed alias and sort to Geänderter
	 * Wagen (geänderter wagen)
	 *
	 * @throws IOException
	 */
	@Test
	public void saveAliasInNotificationTest() throws IOException
	{
		getMongoClient();
		DBCollection collection = getCollection(DashboardUI.getNotificationCollection());
		fillTestDB();
		WriteResult writeResult = notificationPresenter
				.saveAliasInNotifications(new NotificationsSaveAliasEvent("Geänderter Wagen",
						"992d077f-460c-4038-9454-2bff56929a7e"));

		Assert.assertEquals(8, writeResult.getN());

		DBCursor acknowledged = collection
				.find(new BasicDBObject("WI", "992d077f-460c-4038-9454-2bff56929a7e"));
		Assert.assertEquals(8, acknowledged.count());
		while (acknowledged.hasNext())
		{
			DBObject notification = acknowledged.next();
			Assert.assertEquals("Geänderter Wagen", notification.get("alias"));
			Assert.assertEquals("geänderter wagen", notification.get("sort"));
		}
	}

	/**
	 * Trying to update alias of not existing wagon
	 *
	 * @throws UnknownHostException
	 */
	@Test
	public void saveAliasForNotExistingWagonInNotificationTest() throws UnknownHostException
	{
		getMongoClient();
		WriteResult writeResult = notificationPresenter
				.saveAliasInNotifications(new NotificationsSaveAliasEvent("Geänderter Wagen",
						"992d077f-460c-4038-9454-2bff56929a83"));
		Assert.assertNotNull(writeResult);
		Assert.assertEquals(0, writeResult.getN());
		Assert.assertNull(writeResult.getUpsertedId());
	}

	@Test (expected = IllegalArgumentException.class)
	public void saveAliasForNullAliasInNotificationTest()
	{
		notificationPresenter.saveAliasInNotifications(
				new NotificationsSaveAliasEvent(null, "992d077f-460c-4038-9454-2bff56929a83"));
	}

	@Test (expected = IllegalArgumentException.class)
	public void saveAliasForEmptyAliasInNotificationTest()
	{
		notificationPresenter.saveAliasInNotifications(
				new NotificationsSaveAliasEvent("", "992d077f-460c-4038-9454-2bff56929a83"));
	}

	@Test (expected = IllegalArgumentException.class)
	public void saveAliasForNullWagonIdInNotificationTest()
	{
		notificationPresenter.saveAliasInNotifications(
				new NotificationsSaveAliasEvent("Geänderter Wagen", null));
	}

	@Test (expected = IllegalArgumentException.class)
	public void saveAliasForEmptyWagonIdInNotificationTest()
	{
		notificationPresenter
				.saveAliasInNotifications(new NotificationsSaveAliasEvent("Geänderter Wagen", ""));
	}

	private MongoClient getMongoClient() throws UnknownHostException
	{
		new Expectations()
		{
			{
				DashboardUI.getMongoUsername();
				returns(MONGO_USERNAME);
				DashboardUI.getMongoPassword();
				returns(MONGO_PASSWORD);
				DashboardUI.getMongoDatabase();
				returns(MONGO_DATABASE);
				DashboardUI.getMongoHost();
				returns(MONGO_HOST);
				DashboardUI.getMongoPort();
				returns(MONGO_PORT);
				DashboardUI.getNotificationCollection();
				returns(NOTIFICATION_COLLECTION);
			}
		};
		DataProviderInitializer.createMongoClient();
		return DataProviderInitializer.getMongoClient();
	}

	private void additionalCollectionExpectation()
	{
		new Expectations()
		{
			{
				DashboardUI.getWagonCollection();
				returns(WAGON_COLLECTION);
			}
		};
	}

	private List<Notification> createNotificationsList()
	{
		List<Notification> notifications = new ArrayList<Notification>();
		Notification notification = new Notification();
		notification.setAcknowledged(false);
		notification.setId("17aa1f5b-f165-44a4-8f97-b42b9e987b8c");
		notifications.add(notification);
		notification = new Notification();
		notification.setAcknowledged(false);
		notification.setId("c6ef1d04-23a2-4397-a6e6-1643133f5de5");
		notifications.add(notification);
		notification = new Notification();
		notification.setAcknowledged(false);
		notification.setId("917d8a68-4f99-4b39-8826-1bd4aa9dcb9b");
		notifications.add(notification);
		return notifications;
	}

	private DBCollection getCollection(String collection) throws UnknownHostException
	{
		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		return db.getCollection(collection);
	}

	@SuppressWarnings ("unchecked")
	private void fillTestDB() throws IOException
	{

		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection collection = db.getCollection(DashboardUI.getNotificationCollection());
		InputStream testMessage = this.getClass()
				.getResourceAsStream("/testData/notification/notifications.json");
		String message = IOUtils.toString(testMessage, "UTF-8");

		Object parse = JSON.parse(message);
		List<DBObject> objectListToSave = (List<DBObject>) parse;
		collection.insert(objectListToSave);
	}

	@SuppressWarnings ("unchecked")
	private void fillTestDBForDisponents() throws IOException
	{
		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection collection = db.getCollection(DashboardUI.getNotificationCollection());
		InputStream testMessage = NotificationDataProviderTest.class
				.getResourceAsStream("/testData/notification/notificationsForDisponent.json");
		String message = IOUtils.toString(testMessage, "UTF-8");

		Object parse = JSON.parse(message);
		List<DBObject> objectToSave = (List<DBObject>) parse;
		collection.insert(objectToSave);

		collection = db.getCollection(DashboardUI.getWagonCollection());
		testMessage = this.getClass().getResourceAsStream("/testData/wagon/wagon.json");
		message = IOUtils.toString(testMessage, "UTF-8");

		parse = JSON.parse(message);
		objectToSave = (List<DBObject>) parse;
		collection.insert(objectToSave);
	}

	private User createUser()
	{
		User user = new User();
		user.setTenant("cbeaa370-c11d-11e1-8ba8-d4bed92ae488");
		user.setAdmin(true);
		return user;
	}
}
