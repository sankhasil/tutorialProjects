
package com.bosch.si.amra.presenter.details;

import java.io.IOException;
import java.io.InputStream;
import java.net.UnknownHostException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.LatLong;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.event.DashboardEvent.CalculateMileageEvent;
import com.bosch.si.amra.event.DashboardEvent.RouteUpdateEvent;
import com.bosch.si.amra.event.DashboardEvent.ShowDetailsForWagonEvent;
import com.bosch.si.amra.event.DashboardEvent.ShowRouteEvent;
import com.bosch.si.amra.event.DashboardEvent.UpdateEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.provider.DataProviderInitializer;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.util.JSON;
import com.vaadin.tapio.googlemaps.client.LatLon;

import mockit.Expectations;
import mockit.Mocked;
import mockit.Verifications;

@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (locations = "file:src/test/resources/spring-servlet.xml")
@PrepareForTest ({ DashboardUI.class })
public class DetailsPresenterTest
{
	@Autowired
	private DetailsPresenter	detailsPresenter;

	@Mocked
	final DashboardEventBus		eventBus	= null;

	@Mocked
	DashboardUI					dashboardUi;

	@Value ("${MONGO_HOST}")
	public String				MONGO_HOST;

	@Value ("${MONGO_PORT}")
	public Integer				MONGO_PORT;

	@Value ("${MONGO_DATABASE}")
	public String				MONGO_DATABASE;

	@Value ("${MONGO_USERNAME}")
	public String				MONGO_USERNAME;

	@Value ("${MONGO_PASSWORD}")
	public String				MONGO_PASSWORD;

	@Value ("${EVENT_COLLECTION}")
	public String				EVENT_COLLECTION;

	@Value ("${MILEAGE_COLLECTION}")
	public String				MILEAGE_COLLECTION;

	@Value ("${ROUTING_COLLECTION}")
	public String				ROUTING_COLLECTION;

	@Value ("${CURRENT_COLLECTION}")
	public String				CURRENT_COLLECTION;

	@Value ("${WAGON_COLLECTION}")
	public String				WAGON_COLLECTION;

	@Value ("${WAGON_TYPE_COLLECTION}")
	public String				WAGON_TYPE_COLLECITON;

	@Value ("${CONFIGURATION_COLLECTION}")
	public String				CONFIGURATION_COLLECTION;

	@Before
	public void setUp() throws IOException
	{
		MockitoAnnotations.initMocks(this);
	}

	@After
	public void tearDown() throws UnknownHostException
	{
		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection collection = db.getCollection(DashboardUI.getWagonCollection());
		collection.remove(new BasicDBObject());
		collection = db.getCollection(DashboardUI.getWagonTypeCollection());
		collection.remove(new BasicDBObject());
		collection = db.getCollection(DashboardUI.getMongoCurrentCollection());
		collection.remove(new BasicDBObject());
		collection = db.getCollection(DashboardUI.getEventCollection());
		collection.remove(new BasicDBObject());
		collection = db.getCollection(DashboardUI.getMongoRoutingCollection());
		collection.remove(new BasicDBObject());
		collection = db.getCollection(DashboardUI.getMongoMileageCollection());
		collection.remove(new BasicDBObject());
	}

	@Test
	public void getCurrentValuesForWagonTest() throws IOException
	{
		getMongoClient();
		new Expectations()
		{
			{
				DashboardUI.getMongoCurrentCollection();
				returns(CURRENT_COLLECTION);
				DashboardUI.getMongoMileageCollection();
				returns(MILEAGE_COLLECTION);
			}
		};
		fillTestDB();
		Wagon wagon = new Wagon();
		wagon.setId("5a3e9bde-5bfe-4697-8929-f7dcd76c93ec");
		Wagon showDetailsForWagon = detailsPresenter.showDetailsForWagon(
				new ShowDetailsForWagonEvent(wagon, "cbeaa370-c11d-11e1-8ba8-d4bed92ae488"));
		Assert.assertNotNull(showDetailsForWagon);
		Assert.assertNotNull(showDetailsForWagon.getLatLong());
		Assert.assertEquals(48.889366, showDetailsForWagon.getLatLong().getLat(), 0);
		Assert.assertEquals(9.199039000000001, showDetailsForWagon.getLatLong().getLng(), 0);
		Assert.assertEquals(new Integer(49), showDetailsForWagon.getHumidity());
		Assert.assertEquals(new Integer(10), showDetailsForWagon.getTemperature());
		Assert.assertEquals(new Integer(31), showDetailsForWagon.getHumidityTemperature());
		Assert.assertNotNull(showDetailsForWagon.getAddress());
		Assert.assertEquals("Friedrichstraße 71, 71638 Ludwigsburg, Deutschland",
				showDetailsForWagon.getAddress().getFormattedAddress());
		Assert.assertEquals("71638 Ludwigsburg", showDetailsForWagon.getAddress().getCity());
		Assert.assertEquals("Friedrichstraße 71", showDetailsForWagon.getAddress().getStreet());
		Assert.assertEquals("Deutschland", showDetailsForWagon.getAddress().getCountry());
	}

	/**
	 * Range for humidity and humidity temperature exceeded (HM = 1.5 and HT = -39.227051)
	 *
	 * @throws IOException
	 */
	@Test
	public void getCurrentInvalidValuesForWagonTest() throws IOException
	{
		getMongoClient();
		new Expectations()
		{
			{
				DashboardUI.getMongoCurrentCollection();
				returns(CURRENT_COLLECTION);
				DashboardUI.getMongoMileageCollection();
				returns(MILEAGE_COLLECTION);
			}
		};
		fillTestDB();
		Wagon wagon = new Wagon();
		wagon.setId("5a3e9bde-5bfe-4697-8929-f7dcd76c93eb");
		Wagon showDetailsForWagon = detailsPresenter.showDetailsForWagon(
				new ShowDetailsForWagonEvent(wagon, "cbeaa370-c11d-11e1-8ba8-d4bed92ae488"));
		Assert.assertNotNull(showDetailsForWagon);
		Assert.assertNotNull(showDetailsForWagon.getLatLong());
		Assert.assertEquals(48.904158, showDetailsForWagon.getLatLong().getLat(), 0);
		Assert.assertEquals(9.215601, showDetailsForWagon.getLatLong().getLng(), 0);
		Assert.assertNull(showDetailsForWagon.getHumidity());
		Assert.assertEquals(new Integer(5), showDetailsForWagon.getTemperature());
		Assert.assertNull(showDetailsForWagon.getHumidityTemperature());
	}

	@Test (expected = IllegalArgumentException.class)
	public void wagonNullTest() throws IOException
	{
		detailsPresenter.showDetailsForWagon(
				new ShowDetailsForWagonEvent(null, "cbeaa370-c11d-11e1-8ba8-d4bed92ae488"));
	}

	@Test (expected = IllegalArgumentException.class)
	public void tenantNullTest() throws IOException
	{
		Wagon wagon = new Wagon();
		wagon.setId("5a3e9bde-5bfe-4697-8929-f7dcd76c93eb");
		detailsPresenter.showDetailsForWagon(new ShowDetailsForWagonEvent(wagon, null));
	}

	@Test (expected = IllegalArgumentException.class)
	public void tenantEmptyTest() throws IOException
	{
		Wagon wagon = new Wagon();
		wagon.setId("5a3e9bde-5bfe-4697-8929-f7dcd76c93eb");
		detailsPresenter.showDetailsForWagon(new ShowDetailsForWagonEvent(wagon, ""));
	}

	@Test (expected = IllegalArgumentException.class)
	public void bothNullTest() throws IOException
	{
		detailsPresenter.showDetailsForWagon(new ShowDetailsForWagonEvent(null, null));
	}

	@Test
	public void calculateMileageForBoxIdTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		Calendar calendar = Calendar.getInstance();
		calendar.set(2014, 8, 8);
		Integer calculateMileageForPeriod = detailsPresenter.calculateMileageForPeriod(
				new CalculateMileageEvent("5a3e9bde-5bfe-4697-8929-f7dcd76c93ef",
						new Date(calendar.getTimeInMillis()), new Date()));
		Assert.assertEquals(1082, calculateMileageForPeriod.intValue());
		new Verifications()
		{
			{
				{
					DashboardEventBus.post(new UpdateEvent(any));
				}
			};
		};
	}

	@Test (expected = IllegalArgumentException.class)
	public void calculateNullBoxIdWagonTest()
	{
		detailsPresenter
				.calculateMileageForPeriod(new CalculateMileageEvent(null, new Date(), new Date()));
	}

	@Test (expected = IllegalArgumentException.class)
	public void calculateEmptyBoxIdWagonTest()
	{
		detailsPresenter
				.calculateMileageForPeriod(new CalculateMileageEvent(null, new Date(), new Date()));
	}

	@Test (expected = IllegalArgumentException.class)
	public void calculateStartDateNullWagonTest()
	{
		detailsPresenter.calculateMileageForPeriod(new CalculateMileageEvent(
				"5a3e9bde-5bfe-4697-8929-f7dcd76c93eb", null, new Date()));
	}

	@Test (expected = IllegalArgumentException.class)
	public void calculateEndDateNullWagonTest()
	{
		detailsPresenter.calculateMileageForPeriod(new CalculateMileageEvent(
				"5a3e9bde-5bfe-4697-8929-f7dcd76c93eb", new Date(), null));
	}

	@Test (expected = IllegalArgumentException.class)
	public void calculateNullWagonTest()
	{
		detailsPresenter.calculateMileageForPeriod(new CalculateMileageEvent(null, null, null));
	}

	@Test
	public void calculateRouteTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		DataProviderInitializer.createMongoClient();
		Calendar calendar = Calendar.getInstance();
		calendar.set(2014, 8, 8);
		Route calculateRoute = detailsPresenter
				.calculateRoute(new ShowRouteEvent("5a3e9bde-5bfe-4697-8929-f7dcd76c93eb",
						new Date(calendar.getTimeInMillis()), new Date()));
		Assert.assertNotNull(calculateRoute);
		Assert.assertEquals(2188, calculateRoute.getRoute().size());
		Assert.assertEquals(4, calculateRoute.getPositions().size());
		new Verifications()
		{
			{
				{
					DashboardEventBus.post(new RouteUpdateEvent((Route) any));
				}
			};
		};
	}

	@Test
	public void calculateRouteShowOnlyPositionsTest() throws IOException
	{
		fillTelematicAndRouting();
		Calendar calendar = Calendar.getInstance();
		calendar.set(2016, 0, 6);
		Route calculateRoute = detailsPresenter
				.calculateRoute(new ShowRouteEvent("6ff79722-f6ab-4514-9702-94cfa5d5846e",
						new Date(calendar.getTimeInMillis()), new Date()));
		Assert.assertNotNull(calculateRoute);
		Assert.assertEquals(0, calculateRoute.getRoute().size());
		Assert.assertEquals(10, calculateRoute.getPositions().size());
		new Verifications()
		{
			{
				{
					DashboardEventBus.post(new RouteUpdateEvent((Route) any));
				}
			};
		};
	}

	@Test
	public void calculateRouteShowRouteAndPositionsTest() throws IOException
	{
		fillTelematicAndRouting();
		Calendar calendar = Calendar.getInstance();
		calendar.set(2016, 0, 4);
		Route calculateRoute = detailsPresenter
				.calculateRoute(new ShowRouteEvent("6ff79722-f6ab-4514-9702-94cfa5d5846e",
						new Date(calendar.getTimeInMillis()), new Date()));
		Assert.assertNotNull(calculateRoute);
		Assert.assertEquals(1248, calculateRoute.getRoute().size());
		Assert.assertEquals(20, calculateRoute.getPositions().size());
		new Verifications()
		{
			{
				{
					DashboardEventBus.post(new RouteUpdateEvent((Route) any));
				}
			};
		};
	}

	@Test (expected = IllegalArgumentException.class)
	public void calculateRouteNullBoxIdWagonTest()
	{
		detailsPresenter.calculateRoute(new ShowRouteEvent(null, new Date(), new Date()));
	}

	@Test (expected = IllegalArgumentException.class)
	public void calculateRouteEmptyBoxIdWagonTest()
	{
		detailsPresenter.calculateRoute(new ShowRouteEvent(null, new Date(), new Date()));
	}

	@Test (expected = IllegalArgumentException.class)
	public void calculateRouteStartDateNullWagonTest()
	{
		detailsPresenter.calculateRoute(
				new ShowRouteEvent("5a3e9bde-5bfe-4697-8929-f7dcd76c93eb", null, new Date()));
	}

	@Test (expected = IllegalArgumentException.class)
	public void calculateRouteEndDateNullWagonTest()
	{
		detailsPresenter.calculateRoute(
				new ShowRouteEvent("5a3e9bde-5bfe-4697-8929-f7dcd76c93eb", new Date(), null));
	}

	@Test (expected = IllegalArgumentException.class)
	public void calculateRouteNullWagonTest()
	{
		detailsPresenter.calculateRoute(new ShowRouteEvent(null, null, null));
	}

	@Test
	public void getPositionsTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		DataProviderInitializer.createMongoClient();
		Calendar calendar = Calendar.getInstance();
		calendar.set(2014, 8, 8);
		List<LatLong> positions = detailsPresenter
				.getPositions(new ShowRouteEvent("5a3e9bde-5bfe-4697-8929-f7dcd76c93eb",
						new Date(calendar.getTimeInMillis()), new Date()));
		Assert.assertEquals(4, positions.size());
		Assert.assertEquals(51.353812, positions.get(0).getLat(), 0);
		Assert.assertEquals(51.25023, positions.get(3).getLat(), 0);
	}

	@Test (expected = IllegalArgumentException.class)
	public void getPositionsNullBoxIdWagonTest()
	{
		detailsPresenter.getPositions(new ShowRouteEvent(null, new Date(), new Date()));
	}

	@Test (expected = IllegalArgumentException.class)
	public void getPositionsEmptyBoxIdWagonTest()
	{
		detailsPresenter.getPositions(new ShowRouteEvent(null, new Date(), new Date()));
	}

	@Test (expected = IllegalArgumentException.class)
	public void getPositionsStartDateNullWagonTest()
	{
		detailsPresenter.getPositions(
				new ShowRouteEvent("5a3e9bde-5bfe-4697-8929-f7dcd76c93eb", null, new Date()));
	}

	@Test (expected = IllegalArgumentException.class)
	public void getPositionsEndDateNullWagonTest()
	{
		detailsPresenter.getPositions(
				new ShowRouteEvent("5a3e9bde-5bfe-4697-8929-f7dcd76c93eb", new Date(), null));
	}

	@Test (expected = IllegalArgumentException.class)
	public void getPositionsNullWagonTest()
	{
		detailsPresenter.getPositions(new ShowRouteEvent(null, null, null));
	}

	@Test
	public void calculateBoundsTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		Calendar calendar = Calendar.getInstance();
		calendar.set(2014, 8, 8);
		List<LatLon> bounds = detailsPresenter
				.calculateBounds(new ShowRouteEvent("5a3e9bde-5bfe-4697-8929-f7dcd76c93eb",
						new Date(calendar.getTimeInMillis()), new Date()));
		Assert.assertEquals(2, bounds.size());

		LatLon northEasternBound = bounds.get(0);
		LatLon southWesternBound = bounds.get(1);

		Assert.assertEquals(52.403934, northEasternBound.getLat(), 0);
		Assert.assertEquals(12.573855, northEasternBound.getLon(), 0);
		Assert.assertEquals(52.144477, southWesternBound.getLat(), 0);
		Assert.assertEquals(11.218848, southWesternBound.getLon(), 0);
	}

	@Test (expected = IllegalArgumentException.class)
	public void calculateBoundsNullBoxIdWagonTest()
	{
		detailsPresenter.calculateBounds(new ShowRouteEvent(null, new Date(), new Date()));
	}

	@Test (expected = IllegalArgumentException.class)
	public void calculateBoundsEmptyBoxIdWagonTest()
	{
		detailsPresenter.calculateBounds(new ShowRouteEvent(null, new Date(), new Date()));
	}

	@Test (expected = IllegalArgumentException.class)
	public void calculateBoundsStartDateNullWagonTest()
	{
		detailsPresenter.calculateBounds(
				new ShowRouteEvent("5a3e9bde-5bfe-4697-8929-f7dcd76c93eb", null, new Date()));
	}

	@Test (expected = IllegalArgumentException.class)
	public void calculateBoundsEndDateNullWagonTest()
	{
		detailsPresenter.calculateBounds(
				new ShowRouteEvent("5a3e9bde-5bfe-4697-8929-f7dcd76c93eb", new Date(), null));
	}

	@Test (expected = IllegalArgumentException.class)
	public void calculateBoundsNullWagonTest()
	{
		detailsPresenter.calculateBounds(new ShowRouteEvent(null, null, null));
	}

	private MongoClient getMongoClient() throws UnknownHostException
	{
		new Expectations()
		{
			{
				DashboardUI.getMongoUsername();
				returns(MONGO_USERNAME);
				DashboardUI.getMongoPassword();
				returns(MONGO_PASSWORD);
				DashboardUI.getMongoDatabase();
				returns(MONGO_DATABASE);
				DashboardUI.getMongoHost();
				returns(MONGO_HOST);
				DashboardUI.getMongoPort();
				returns(MONGO_PORT);
				DashboardUI.getWagonTypeCollection();
				returns(WAGON_TYPE_COLLECITON);
				DashboardUI.getWagonCollection();
				returns(WAGON_COLLECTION);
				DashboardUI.getMongoCurrentCollection();
				returns(CURRENT_COLLECTION);
				DashboardUI.getEventCollection();
				returns(EVENT_COLLECTION);
				DashboardUI.getMongoRoutingCollection();
				returns(ROUTING_COLLECTION);
				DashboardUI.getMongoMileageCollection();
				returns(MILEAGE_COLLECTION);
			}
		};
		DataProviderInitializer.createMongoClient();
		return DataProviderInitializer.getMongoClient();
	}

	private MongoClient getMongoClientForTelematicAndRouting() throws UnknownHostException
	{
		new Expectations()
		{
			{
				DashboardUI.getMongoUsername();
				returns(MONGO_USERNAME);
				DashboardUI.getMongoPassword();
				returns(MONGO_PASSWORD);
				DashboardUI.getMongoDatabase();
				returns(MONGO_DATABASE);
				DashboardUI.getMongoHost();
				returns(MONGO_HOST);
				DashboardUI.getMongoPort();
				returns(MONGO_PORT);
				DashboardUI.getEventCollection();
				returns(EVENT_COLLECTION);
				DashboardUI.getMongoRoutingCollection();
				returns(ROUTING_COLLECTION);
			}
		};
		DataProviderInitializer.createMongoClient();
		return DataProviderInitializer.getMongoClient();
	}

	@SuppressWarnings ("unchecked")
	private void fillTestDB() throws IOException
	{
		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection collection = db.getCollection(DashboardUI.getMongoCurrentCollection());
		InputStream testMessage = this.getClass()
				.getResourceAsStream("/testData/current/current.json");
		String message = IOUtils.toString(testMessage, "UTF-8");

		Object parse = JSON.parse(message);
		List<DBObject> objectListToSave = (List<DBObject>) parse;
		collection.insert(objectListToSave);

		collection = db.getCollection(DashboardUI.getWagonTypeCollection());
		testMessage = this.getClass().getResourceAsStream("/testData/wagonType/wagonType.json");

		String wagonType = IOUtils.toString(testMessage, "UTF-8");
		parse = JSON.parse(wagonType);
		objectListToSave = (List<DBObject>) parse;
		collection.insert(objectListToSave);

		collection = db.getCollection(DashboardUI.getWagonCollection());
		testMessage = this.getClass().getResourceAsStream("/testData/wagon/wagon.json");
		String wagon = IOUtils.toString(testMessage, "UTF-8");

		parse = JSON.parse(wagon);
		objectListToSave = (List<DBObject>) parse;
		collection.insert(objectListToSave);

		collection = db.getCollection(DashboardUI.getEventCollection());
		testMessage = this.getClass().getResourceAsStream("/testData/telematic/mainTelematic.json");
		String telematic = IOUtils.toString(testMessage, "UTF-8");

		parse = JSON.parse(telematic);
		objectListToSave = (List<DBObject>) parse;
		collection.insert(objectListToSave);

		collection = db.getCollection(DashboardUI.getMongoRoutingCollection());
		testMessage = this.getClass().getResourceAsStream("/testData/routing/routing.json");
		String routing = IOUtils.toString(testMessage, "UTF-8");

		parse = JSON.parse(routing);
		objectListToSave = (List<DBObject>) parse;
		collection.insert(objectListToSave);

		collection = db.getCollection(DashboardUI.getMongoMileageCollection());
		testMessage = this.getClass().getResourceAsStream("/testData/mileage/mileage.json");
		String mileage = IOUtils.toString(testMessage, "UTF-8");

		parse = JSON.parse(mileage);
		objectListToSave = (List<DBObject>) parse;
		collection.insert(objectListToSave);
	}

	@SuppressWarnings ("unchecked")
	private void fillTelematicAndRouting() throws IOException
	{
		MongoClient mongoClient = getMongoClientForTelematicAndRouting();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection collection = db.getCollection(DashboardUI.getEventCollection());
		InputStream testMessage = this.getClass()
				.getResourceAsStream("/testData/telematic/telematicWithoutRouting.json");
		String message = IOUtils.toString(testMessage, "UTF-8");

		Object parse = JSON.parse(message);
		List<DBObject> objectListToSave = (List<DBObject>) parse;
		collection.insert(objectListToSave);

		collection = db.getCollection(DashboardUI.getMongoRoutingCollection());
		testMessage = this.getClass()
				.getResourceAsStream("/testData/routing/routingWithMorePositions.json");

		String wagonType = IOUtils.toString(testMessage, "UTF-8");
		parse = JSON.parse(wagonType);
		objectListToSave = (List<DBObject>) parse;
		collection.insert(objectListToSave);
	}
}
