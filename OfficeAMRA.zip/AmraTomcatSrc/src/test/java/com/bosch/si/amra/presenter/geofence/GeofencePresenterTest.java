
package com.bosch.si.amra.presenter.geofence;

import java.io.IOException;
import java.io.InputStream;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.geofence.Geofence;
import com.bosch.si.amra.event.DashboardEvent.GeofenceDeleteEvent;
import com.bosch.si.amra.event.DashboardEvent.GeofenceSaveEvent;
import com.bosch.si.amra.event.DashboardEvent.GeofenceSelectEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.presenter.rule.RulePresenterTest;
import com.bosch.si.amra.provider.DataProviderInitializer;
import com.bosch.si.amra.provider.configuration.ConfigurationDataProvider;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.WriteResult;
import com.mongodb.util.JSON;
import com.vaadin.tapio.googlemaps.client.LatLon;

import mockit.Expectations;
import mockit.Mocked;

@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (locations = "file:src/test/resources/spring-servlet.xml")
@PrepareForTest ({ DashboardUI.class })
public class GeofencePresenterTest
{
	@Autowired
	private GeofencePresenter			geofencePresenter;

	@Autowired
	private ConfigurationDataProvider	configurationDataProvider;

	@Mocked
	final DashboardEventBus				eventBus	= null;

	@Mocked
	DashboardUI							dashboardUi;

	@Value ("${MONGO_HOST}")
	public String						MONGO_HOST;

	@Value ("${MONGO_PORT}")
	public Integer						MONGO_PORT;

	@Value ("${MONGO_DATABASE}")
	public String						MONGO_DATABASE;

	@Value ("${MONGO_USERNAME}")
	public String						MONGO_USERNAME;

	@Value ("${MONGO_PASSWORD}")
	public String						MONGO_PASSWORD;

	@Value ("${GEOFENCE_COLLECTION}")
	public String						GEOFENCE_COLLECTION;

	@Value ("${RULE_COLLECTION}")
	public String						RULE_COLLECTION;

	@Value ("${USE_PROXY}")
	public String						PROXY;

	@Before
	public void setUp() throws IOException
	{
		fillTestDB();
	}

	@After
	public void tearDown() throws IOException
	{
		deleteTestDB();
	}

	@Test
	public void saveGeofenceTest()
	{
		initMongoDB();
		Geofence geofence = createGeofence();
		WriteResult saveGeofence = geofencePresenter.saveGeofence(
				new GeofenceSaveEvent(geofence, "1798c300-c27f-11e4-81a3-0050569350e8"));
		Assert.assertNotNull(saveGeofence);
		Assert.assertEquals(1, saveGeofence.getN());
	}

	@Test (expected = IllegalArgumentException.class)
	public void saveNullGeofenceTest()
	{
		geofencePresenter
				.saveGeofence(new GeofenceSaveEvent(null, "1798c300-c27f-11e4-81a3-0050569350e8"));
	}

	@Test (expected = IllegalArgumentException.class)
	public void saveNullTenantGeofenceTest()
	{
		geofencePresenter.saveGeofence(new GeofenceSaveEvent(createGeofence(), null));
	}

	@Test (expected = IllegalArgumentException.class)
	public void saveEmptyTenantGeofenceTest()
	{
		geofencePresenter.saveGeofence(new GeofenceSaveEvent(createGeofence(), ""));
	}

	@Test (expected = IllegalArgumentException.class)
	public void saveBothNulltGeofenceTest()
	{
		geofencePresenter.saveGeofence(new GeofenceSaveEvent(null, null));
	}

	@Test
	public void saveGeofenceExistingTest()
	{
		initMongoDB();
		Geofence geofence = createGeofence();
		geofence.setName("Berlin");
		WriteResult saveGeofence = geofencePresenter.saveGeofence(
				new GeofenceSaveEvent(geofence, "1798c300-c27f-11e4-81a3-0050569350e8"));
		Assert.assertNull(saveGeofence);
	}

	@Test
	public void saveGeofenceInOtherTenantTest()
	{
		initMongoDB();
		Geofence geofence = createGeofence();
		geofence.setName("Berlin");
		geofence.setTenantId("otherTenant");
		WriteResult saveGeofence = geofencePresenter
				.saveGeofence(new GeofenceSaveEvent(geofence, "otherTenant"));
		Assert.assertNotNull(saveGeofence);
		Assert.assertEquals(1, saveGeofence.getN());
	}

	@Test
	public void saveMalformedGeofenceTest()
	{
		initMongoDB();
		Geofence geofence = createMalformedGeofence();
		WriteResult saveGeofence = geofencePresenter.saveGeofence(
				new GeofenceSaveEvent(geofence, "1798c300-c27f-11e4-81a3-0050569350e8"));
		Assert.assertNull(saveGeofence);
	}

	@Test (expected = IllegalArgumentException.class)
	public void saveGeofenceWithoutNameTest()
	{
		Geofence geofence = createGeofence();
		geofence.setName(null);
		geofencePresenter.saveGeofence(
				new GeofenceSaveEvent(geofence, "1798c300-c27f-11e4-81a3-0050569350e8"));
	}

	@Test (expected = IllegalArgumentException.class)
	public void saveGeofenceWithEmptyNameTest()
	{
		Geofence geofence = createGeofence();
		geofence.setName("");
		geofencePresenter.saveGeofence(
				new GeofenceSaveEvent(geofence, "1798c300-c27f-11e4-81a3-0050569350e8"));
	}

	@Test (expected = IllegalArgumentException.class)
	public void saveGeofenceWithDashNameTest()
	{
		Geofence geofence = createGeofence();
		geofence.setName("-");
		geofencePresenter.saveGeofence(
				new GeofenceSaveEvent(geofence, "1798c300-c27f-11e4-81a3-0050569350e8"));
	}

	@Test
	public void showGeofenceTest()
	{
		initMongoDB();
		Geofence geofence = geofencePresenter
				.showGeofence(new GeofenceSelectEvent("2d600c2c-5a03-4708-8fd1-0dfda62f38de"));
		Assert.assertNotNull(geofence);
		Assert.assertEquals("Germany", geofence.getName());
		Assert.assertEquals("This is a test description", geofence.getDescription());
		Assert.assertEquals("1798c300-c27f-11e4-81a3-0050569350e8", geofence.getTenantId());
		Assert.assertEquals(3, geofence.getPositions().size());
	}

	@Test
	public void deleteGeofenceSuccessfulTest()
	{
		new Expectations()
		{
			{
				DashboardUI.getRuleCollection();
				returns(RULE_COLLECTION);
			}
		};
		initMongoDB();
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection geofenceCollection = db.getCollection(DashboardUI.getGeofenceCollection());
		DBObject countObject = new BasicDBObject("TI", "1798c300-c27f-11e4-81a3-0050569350e8");
		long numberOfGeofence = geofenceCollection.count(countObject);
		Assert.assertEquals(8, numberOfGeofence);
		Geofence geofence = createGeofence();
		geofence.setId("d3006b36-deee-4f50-8b61-1fa7653900a6");
		geofencePresenter.deleteGeofence(new GeofenceDeleteEvent(geofence));
		numberOfGeofence = geofenceCollection.count(countObject);
		Assert.assertEquals(7, numberOfGeofence);
	}

	@Test
	public void deleteGeofenceNotSuccessfulTest()
	{

		new Expectations()
		{
			{
				DashboardUI.getRuleCollection();
				returns(RULE_COLLECTION);
			}
		};
		initMongoDB();
		MongoClient mongoClient = DataProviderInitializer.getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection geofenceCollection = db.getCollection(DashboardUI.getGeofenceCollection());
		DBObject countObject = new BasicDBObject("TI", "1798c300-c27f-11e4-81a3-0050569350e8");
		long numberOfGeofence = geofenceCollection.count(countObject);
		Assert.assertEquals(8, numberOfGeofence);
		Geofence geofence = createGeofence();
		geofence.setId("5cc84ff2-13a1-4e20-b518-6b358178b274");
		geofencePresenter.deleteGeofence(new GeofenceDeleteEvent(geofence));
		numberOfGeofence = geofenceCollection.count(countObject);
		Assert.assertEquals(8, numberOfGeofence);
	}

	@Test (expected = IllegalArgumentException.class)
	public void showGeofenceNullTest()
	{
		geofencePresenter.showGeofence(new GeofenceSelectEvent(null));
	}

	@Test (expected = IllegalArgumentException.class)
	public void showGeofenceEmptyTest()
	{
		geofencePresenter.showGeofence(new GeofenceSelectEvent(""));
	}

	@Test
	public void showGeofenceNotExistingTest()
	{
		initMongoDB();
		Geofence geofence = geofencePresenter.showGeofence(new GeofenceSelectEvent("notExisting"));
		Assert.assertNull(geofence);
	}

	private void initMongoDB()
	{
		new Expectations()
		{
			{
				DashboardUI.getMongoUsername();
				returns(MONGO_USERNAME);
				DashboardUI.getMongoPassword();
				returns(MONGO_PASSWORD);
				DashboardUI.getMongoDatabase();
				returns(MONGO_DATABASE);
				DashboardUI.getMongoHost();
				returns(MONGO_HOST);
				DashboardUI.getMongoPort();
				returns(MONGO_PORT);
				DashboardUI.getGeofenceCollection();
				returns(GEOFENCE_COLLECTION);
			}
		};
		try
		{
			DataProviderInitializer.createMongoClient();
		}
		catch (UnknownHostException e)
		{
			e.printStackTrace();
		}
	}

	private Geofence createGeofence()
	{
		Geofence geofence = new Geofence();
		geofence.setName("TestGeofence");
		geofence.setDescription("Test description");
		List<LatLon> positions = Arrays.asList(new LatLon(0.0, 100.0), new LatLon(0.0, 101.0),
				new LatLon(1.0, 101.0), new LatLon(0.1, 100.0), new LatLon(0.0, 100.0));
		geofence.setPositions(positions);
		geofence.setTenantId("1798c300-c27f-11e4-81a3-0050569350e8");
		geofence.setTimestamp(new Date());
		return geofence;
	}

	/**
	 * Last point is not equal to first point => malformed geofence
	 *
	 * @return
	 */
	private Geofence createMalformedGeofence()
	{
		Geofence geofence = new Geofence();
		geofence.setName("MalformedGeofence");
		geofence.setDescription("Test description");
		List<LatLon> positions = Arrays.asList(new LatLon(0.0, 100.0), new LatLon(0.0, 101.0));
		geofence.setPositions(positions);
		geofence.setTenantId("1798c300-c27f-11e4-81a3-0050569350e8");
		geofence.setTimestamp(new Date());
		return geofence;
	}

	@SuppressWarnings ("unchecked")
	private void fillTestDB() throws IOException
	{
		new Expectations()
		{
			{
				DashboardUI.getGeofenceCollection();
				returns(GEOFENCE_COLLECTION);
				DashboardUI.getRuleCollection();
				returns(RULE_COLLECTION);
			}
		};

		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection collection = db.getCollection(DashboardUI.getGeofenceCollection());
		InputStream testMessage = GeofencePresenterTest.class
				.getResourceAsStream("/testData/geofence/geofenceData.json");
		String message = IOUtils.toString(testMessage, "UTF-8");

		Object parse = JSON.parse(message);
		List<DBObject> objectToSave = (List<DBObject>) parse;
		collection.insert(objectToSave);

		MongoClient mongoClientR = getMongoClient();
		DB dbr = mongoClientR.getDB(DashboardUI.getMongoDatabase());

		DBCollection ruleCollection = dbr.getCollection(DashboardUI.getRuleCollection());
		InputStream ruleTestMessage = RulePresenterTest.class
				.getResourceAsStream("/testData/rule/rule.json");
		String rulemessage = IOUtils.toString(ruleTestMessage, "UTF-8");

		Object ruleParse = JSON.parse(rulemessage);
		List<DBObject> ruleObjectToSave = (List<DBObject>) ruleParse;
		ruleCollection.insert(ruleObjectToSave);
	}

	private void deleteTestDB() throws IOException
	{
		new Expectations()
		{
			{
				DashboardUI.getGeofenceCollection();
				returns(GEOFENCE_COLLECTION);
				DashboardUI.getRuleCollection();
				returns(RULE_COLLECTION);
			}
		};

		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection collection = db.getCollection(DashboardUI.getGeofenceCollection());
		collection.remove(new BasicDBObject());

		DBCollection ruleCollection = db.getCollection(DashboardUI.getRuleCollection());
		ruleCollection.remove(new BasicDBObject());
	}

	private MongoClient getMongoClient() throws UnknownHostException
	{
		new Expectations()
		{
			{
				DashboardUI.getMongoUsername();
				returns(MONGO_USERNAME);
				DashboardUI.getMongoPassword();
				returns(MONGO_PASSWORD);
				DashboardUI.getMongoDatabase();
				returns(MONGO_DATABASE);
				DashboardUI.getMongoHost();
				returns(MONGO_HOST);
				DashboardUI.getMongoPort();
				returns(MONGO_PORT);
			}
		};
		DataProviderInitializer.createMongoClient();
		return DataProviderInitializer.getMongoClient();
	}
}
