
package com.bosch.si.amra.presenter.fleetbalancing;

import java.io.IOException;
import java.io.InputStream;
import java.net.UnknownHostException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.apache.commons.io.IOUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.event.DashboardEvent.FleetBalancingFillChartEvent;
import com.bosch.si.amra.event.DashboardEvent.FleetBalancingGetEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.provider.DataProviderInitializer;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.util.JSON;

import mockit.Expectations;
import mockit.Mocked;

@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (locations = "file:src/test/resources/spring-servlet.xml")
public class FleetBalancingPresenterTest
{
	@Autowired
	private FleetBalancingPresenter	fleetBalancingPresenter;

	@Mocked
	final DashboardEventBus			eventBus	= null;

	@Mocked
	DashboardUI						dashboardUi;

	@Value ("${MONGO_HOST}")
	public String					MONGO_HOST;

	@Value ("${MONGO_PORT}")
	public Integer					MONGO_PORT;

	@Value ("${MONGO_DATABASE}")
	public String					MONGO_DATABASE;

	@Value ("${MONGO_USERNAME}")
	public String					MONGO_USERNAME;

	@Value ("${MONGO_PASSWORD}")
	public String					MONGO_PASSWORD;

	@Value ("${MILEAGE_COLLECTION}")
	public String					MILEAGE_COLLECTION;

	@After
	public void tearDown() throws UnknownHostException
	{
		MongoClient mongoClient = getMongoClient();
		if (mongoClient != null)
		{
			DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());

			DBCollection mileageCollection = db
					.getCollection(DashboardUI.getMongoMileageCollection());
			mileageCollection.remove(new BasicDBObject());
		}
		mongoClient.close();
	}

	/**
	 * A test with thre wagons. Two of them have a total mileage and for the one the mileage is not
	 * there. This should be considered 0. The map should contain tow keys, positives and negatives.
	 * For the positives there must be one wagon and for the negatives two.
	 * 
	 * @author toa1wa3
	 * @throws ParseException
	 *             - Is thrown if the date cannot be parsed
	 * @throws IOException
	 *             - If something wents wrong during filling up the test db
	 */
	@Test
	public void getFleetBalancingMap() throws ParseException, IOException
	{
		fillTestDB("/testData/fleetbalancing/mileage.json");
		SimpleDateFormat dateFormatUTC = new SimpleDateFormat("yy-MM-dd");
		dateFormatUTC.setTimeZone(TimeZone.getTimeZone("UTC"));
		Date startDate = dateFormatUTC.parse("16-03-22");
		Date endDate = dateFormatUTC.parse("16-07-15");
		FleetBalancingFillChartEvent fleetBalancingFillChartEvent = fleetBalancingPresenter
				.getBalancingMap(new FleetBalancingGetEvent("cbeaa370-c11d-11e1-8ba8-d4bed92ae488",
						createWagons(), 20, startDate, endDate));
		Assert.assertNotNull(fleetBalancingFillChartEvent);
		Map<FleetBalancingType, List<Wagon>> balancingMap = fleetBalancingFillChartEvent
				.getBalancingMap();
		Assert.assertNotNull(balancingMap);
		Assert.assertEquals(2, balancingMap.size());
		List<Wagon> positives = balancingMap.get(FleetBalancingType.POSITIVES);
		Assert.assertNotNull(positives);
		Assert.assertEquals(1, positives.size());
		Wagon positiveFleetBalancingWagon = positives.get(0);
		checkWagonAttributes(positiveFleetBalancingWagon, new Integer(312), "INST353816054766557",
				"f9c36cc8-0c71-4c9f-a0e5-3e59758fa3bb");
		List<Wagon> negatives = balancingMap.get(FleetBalancingType.NEGATIVES);
		Assert.assertNotNull(negatives);
		Assert.assertEquals(2, negatives.size());
		for (Wagon negativeFleetBalancingWagon : negatives)
		{
			if (negativeFleetBalancingWagon.getAlias().equals("Wagen 0815"))
				checkWagonAttributes(negativeFleetBalancingWagon, new Integer(-104), "Wagen 0815",
						"91b7a464-6573-48a1-a0d2-95c0cf0b4a5d");
			else
				checkWagonAttributes(negativeFleetBalancingWagon, new Integer(-207), "TestWagon",
						"f46c9397-3879-44f0-877f-1d8678ad0ceb");
		}
		int average = fleetBalancingFillChartEvent.getAverage();
		Assert.assertEquals(207, average);
		int maxMileageDeviation = fleetBalancingFillChartEvent.getMaxMileageDeviation();
		Assert.assertEquals(312, maxMileageDeviation);
	}

	@Test
	public void getFleetBalancingMapWithLowPerformer() throws IOException, ParseException
	{
		fillTestDB("/testData/fleetbalancing/mileageWithLowPerformer.json");
		SimpleDateFormat dateFormatUTC = new SimpleDateFormat("yy-MM-dd");
		dateFormatUTC.setTimeZone(TimeZone.getTimeZone("UTC"));
		Date startDate = dateFormatUTC.parse("16-03-22");
		Date endDate = dateFormatUTC.parse("16-07-15");
		FleetBalancingFillChartEvent fleetBalancingFillChartEvent = fleetBalancingPresenter
				.getBalancingMap(new FleetBalancingGetEvent("cbeaa370-c11d-11e1-8ba8-d4bed92ae488",
						createLowPerformingWagons(), 20, startDate, endDate));
		Assert.assertNotNull(fleetBalancingFillChartEvent);
		Map<FleetBalancingType, List<Wagon>> balancingMap = fleetBalancingFillChartEvent
				.getBalancingMap();
		Assert.assertNotNull(balancingMap);
		Assert.assertEquals(2, balancingMap.size());
		List<Wagon> positives = balancingMap.get(FleetBalancingType.POSITIVES);
		Assert.assertNotNull(positives);
		Assert.assertEquals(3, positives.size());
		for (Wagon positiveFleetBalancingWagon : positives)
		{
			if (positiveFleetBalancingWagon.getAlias().equals("Wagen 0815"))
				checkWagonAttributes(positiveFleetBalancingWagon, new Integer(1300), "Wagen 0815",
						"91b7a464-6573-48a1-a0d2-95c0cf0b4a5d");
			else if (positiveFleetBalancingWagon.getAlias().equals("Wagen 0816"))
				checkWagonAttributes(positiveFleetBalancingWagon, new Integer(1835), "Wagen 0816",
						"91b7a464-6573-48a1-a0d2-95c0cf0b4a4d");
			else if (positiveFleetBalancingWagon.getAlias().equals("Wagen 0817"))
				checkWagonAttributes(positiveFleetBalancingWagon, new Integer(1237), "Wagen 0817",
						"91b7a464-6573-48a1-a0d2-95c0cf0b4a5e");
		}
		List<Wagon> negatives = balancingMap.get(FleetBalancingType.NEGATIVES);
		Assert.assertNotNull(negatives);
		Assert.assertEquals(1, negatives.size());
		Wagon negativeFleetBalancingWagon = negatives.get(0);
		checkWagonAttributes(negativeFleetBalancingWagon, new Integer(-4372), "Wagen 0818",
				"91b7a464-6573-48a1-a0d2-95c0cf0b4a6d");
		int average = fleetBalancingFillChartEvent.getAverage();
		Assert.assertEquals(12378, average);
		int maxMileageDeviation = fleetBalancingFillChartEvent.getMaxMileageDeviation();
		Assert.assertEquals(4372, maxMileageDeviation);
	}

	@Test (expected = IllegalArgumentException.class)
	public void getFleetBalancingEmptyTenantMap() throws IOException, ParseException
	{
		fillTestDB("/testData/fleetbalancing/mileage.json");
		SimpleDateFormat dateFormatUTC = new SimpleDateFormat("yy-MM-dd");
		dateFormatUTC.setTimeZone(TimeZone.getTimeZone("UTC"));
		Date startDate = dateFormatUTC.parse("16-03-22");
		Date endDate = dateFormatUTC.parse("16-07-15");
		fleetBalancingPresenter.getBalancingMap(
				new FleetBalancingGetEvent("", createWagons(), 20, startDate, endDate));
	}

	@Test
	public void getFleetBalancingEmptyWagonsMap() throws IOException, ParseException
	{
		fillTestDB("/testData/fleetbalancing/mileage.json");
		SimpleDateFormat dateFormatUTC = new SimpleDateFormat("yy-MM-dd");
		dateFormatUTC.setTimeZone(TimeZone.getTimeZone("UTC"));
		Date startDate = dateFormatUTC.parse("16-03-22");
		Date endDate = dateFormatUTC.parse("16-07-15");
		FleetBalancingFillChartEvent fleetBalancingFillChartEvent = fleetBalancingPresenter
				.getBalancingMap(new FleetBalancingGetEvent("cbeaa370-c11d-11e1-8ba8-d4bed92ae488",
						new ArrayList<>(), 20, startDate, endDate));
		Assert.assertNull(fleetBalancingFillChartEvent);
	}

	@Test (expected = IllegalArgumentException.class)
	public void getFleetBalancingNullTenantIdMap() throws IOException, ParseException
	{
		fillTestDB("/testData/fleetbalancing/mileage.json");
		SimpleDateFormat dateFormatUTC = new SimpleDateFormat("yy-MM-dd");
		dateFormatUTC.setTimeZone(TimeZone.getTimeZone("UTC"));
		Date startDate = dateFormatUTC.parse("16-03-22");
		Date endDate = dateFormatUTC.parse("16-07-15");
		fleetBalancingPresenter.getBalancingMap(
				new FleetBalancingGetEvent(null, createWagons(), 20, startDate, endDate));
	}

	@Test (expected = IllegalArgumentException.class)
	public void getFleetBalancingNullWagonsMap() throws IOException, ParseException
	{
		fillTestDB("/testData/fleetbalancing/mileage.json");
		SimpleDateFormat dateFormatUTC = new SimpleDateFormat("yy-MM-dd");
		dateFormatUTC.setTimeZone(TimeZone.getTimeZone("UTC"));
		Date startDate = dateFormatUTC.parse("16-03-22");
		Date endDate = dateFormatUTC.parse("16-07-15");
		fleetBalancingPresenter.getBalancingMap(new FleetBalancingGetEvent(
				"cbeaa370-c11d-11e1-8ba8-d4bed92ae488", null, 20, startDate, endDate));
	}

	@Test (expected = IllegalArgumentException.class)
	public void getFleetBalancingNullLimitMap() throws IOException, ParseException
	{
		fillTestDB("/testData/fleetbalancing/mileage.json");
		SimpleDateFormat dateFormatUTC = new SimpleDateFormat("yy-MM-dd");
		dateFormatUTC.setTimeZone(TimeZone.getTimeZone("UTC"));
		Date startDate = dateFormatUTC.parse("16-03-22");
		Date endDate = dateFormatUTC.parse("16-07-15");
		fleetBalancingPresenter.getBalancingMap(new FleetBalancingGetEvent(
				"cbeaa370-c11d-11e1-8ba8-d4bed92ae488", createWagons(), null, startDate, endDate));
	}

	@Test (expected = IllegalArgumentException.class)
	public void getFleetBalancingNullStartDateMap() throws IOException, ParseException
	{
		fillTestDB("/testData/fleetbalancing/mileage.json");
		SimpleDateFormat dateFormatUTC = new SimpleDateFormat("yy-MM-dd");
		dateFormatUTC.setTimeZone(TimeZone.getTimeZone("UTC"));
		Date endDate = dateFormatUTC.parse("16-07-15");
		fleetBalancingPresenter.getBalancingMap(new FleetBalancingGetEvent(
				"cbeaa370-c11d-11e1-8ba8-d4bed92ae488", createWagons(), 20, null, endDate));
	}

	@Test (expected = IllegalArgumentException.class)
	public void getFleetBalancingNullEndDateMap() throws ParseException, IOException
	{
		fillTestDB("/testData/fleetbalancing/mileage.json");
		SimpleDateFormat dateFormatUTC = new SimpleDateFormat("yy-MM-dd");
		dateFormatUTC.setTimeZone(TimeZone.getTimeZone("UTC"));
		Date startDate = dateFormatUTC.parse("16-03-22");
		fleetBalancingPresenter.getBalancingMap(new FleetBalancingGetEvent(
				"cbeaa370-c11d-11e1-8ba8-d4bed92ae488", createWagons(), 20, startDate, null));
	}

	private void checkWagonAttributes(Wagon balancingFleetWagon, Integer mileageDeviation,
			String alias, String id)
	{
		Assert.assertNotNull(balancingFleetWagon);
		Assert.assertEquals(mileageDeviation, balancingFleetWagon.getMileageDeviation());
		Assert.assertEquals(alias, balancingFleetWagon.getAlias());
		Assert.assertEquals(id, balancingFleetWagon.getId());
	}

	private List<Wagon> createWagons()
	{
		Wagon wagon1 = new Wagon();
		wagon1.setId("f9c36cc8-0c71-4c9f-a0e5-3e59758fa3bb");
		wagon1.setAlias("INST353816054766557");
		Wagon wagon2 = new Wagon();
		wagon2.setId("f46c9397-3879-44f0-877f-1d8678ad0ceb");
		wagon2.setAlias("TestWagon");
		Wagon wagon3 = new Wagon();
		wagon3.setId("91b7a464-6573-48a1-a0d2-95c0cf0b4a5d");
		wagon3.setAlias("Wagen 0815");
		return Arrays.asList(wagon1, wagon2, wagon3);
	}

	private List<Wagon> createLowPerformingWagons()
	{
		Wagon wagon1 = new Wagon();
		wagon1.setId("91b7a464-6573-48a1-a0d2-95c0cf0b4a5d");
		wagon1.setAlias("Wagen 0815");
		Wagon wagon2 = new Wagon();
		wagon2.setId("91b7a464-6573-48a1-a0d2-95c0cf0b4a4d");
		wagon2.setAlias("Wagen 0816");
		Wagon wagon3 = new Wagon();
		wagon3.setId("91b7a464-6573-48a1-a0d2-95c0cf0b4a5e");
		wagon3.setAlias("Wagen 0817");
		Wagon wagon4 = new Wagon();
		wagon4.setId("91b7a464-6573-48a1-a0d2-95c0cf0b4a6d");
		wagon4.setAlias("Wagen 0818");
		return Arrays.asList(wagon1, wagon2, wagon3, wagon4);
	}

	private MongoClient getMongoClient() throws UnknownHostException
	{
		new Expectations()
		{
			{
				DashboardUI.getMongoUsername();
				returns(MONGO_USERNAME);
				DashboardUI.getMongoPassword();
				returns(MONGO_PASSWORD);
				DashboardUI.getMongoDatabase();
				returns(MONGO_DATABASE);
				DashboardUI.getMongoHost();
				returns(MONGO_HOST);
				DashboardUI.getMongoPort();
				returns(MONGO_PORT);
				DashboardUI.getMongoMileageCollection();
				returns(MILEAGE_COLLECTION);
			}
		};
		DataProviderInitializer.createMongoClient();
		return DataProviderInitializer.getMongoClient();
	}

	@SuppressWarnings ("unchecked")
	private void fillTestDB(String filename) throws IOException
	{
		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection mileageCollection = db.getCollection(DashboardUI.getMongoMileageCollection());
		InputStream testMileageMessage = this.getClass().getResourceAsStream(filename);
		String mileageMessage = IOUtils.toString(testMileageMessage, "UTF-8");

		Object mileageParse = JSON.parse(mileageMessage);
		List<DBObject> mileageListToSave = (List<DBObject>) mileageParse;
		mileageCollection.insert(mileageListToSave);
	}
}
