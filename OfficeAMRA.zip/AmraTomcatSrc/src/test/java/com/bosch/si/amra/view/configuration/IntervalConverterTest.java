
package com.bosch.si.amra.view.configuration;

import java.util.Locale;

import org.junit.Assert;
import org.junit.Test;

import com.bosch.si.amra.view.configuration.converter.IntervalConverter;
import com.vaadin.data.util.converter.Converter.ConversionException;

public class IntervalConverterTest
{
	private final IntervalConverter intervalConverter = new IntervalConverter();

	@Test
	public void nullTest()
	{
		Integer convertToModel = intervalConverter.convertToModel(null, Integer.class,
				Locale.getDefault());
		Assert.assertNull(convertToModel);
	}

	@Test
	public void emptyTest()
	{
		Integer convertToModel = intervalConverter.convertToModel("", Integer.class,
				Locale.getDefault());
		Assert.assertNull(convertToModel);
	}

	@Test (expected = ConversionException.class)
	public void noDigitsTest()
	{
		intervalConverter.convertToModel(":", Integer.class, Locale.getDefault());
	}

	@Test (expected = ConversionException.class)
	public void belowMinimumTest()
	{
		intervalConverter.convertToModel(":14", Integer.class, Locale.getDefault());
	}

	@Test (expected = ConversionException.class)
	public void aboveMaximumTest()
	{
		intervalConverter.convertToModel("99:01", Integer.class, Locale.getDefault());
	}

	@Test
	public void twoDigitMinuteTest()
	{
		Integer convertToModel = intervalConverter.convertToModel(":55", Integer.class,
				Locale.getDefault());
		Assert.assertEquals(new Integer(3300), convertToModel);
	}

	@Test
	public void oneDigitHourWithoutMinuteTest()
	{
		Integer convertToModel = intervalConverter.convertToModel("1", Integer.class,
				Locale.getDefault());
		Assert.assertEquals(new Integer(3600), convertToModel);
	}

	@Test
	public void oneDigitHourSemicolonTest()
	{
		Integer convertToModel = intervalConverter.convertToModel("1:", Integer.class,
				Locale.getDefault());
		Assert.assertEquals(new Integer(3600), convertToModel);
	}

	@Test
	public void oneDigitHourWihtOneDigitMinuteTest()
	{
		Integer convertToModel = intervalConverter.convertToModel("1:5", Integer.class,
				Locale.getDefault());
		Assert.assertEquals(new Integer(3900), convertToModel);
	}

	@Test
	public void oneDigitHourWithTwoDigitsMinuteTest()
	{
		Integer convertToModel = intervalConverter.convertToModel("1:55", Integer.class,
				Locale.getDefault());
		Assert.assertEquals(new Integer(6900), convertToModel);
	}

	@Test
	public void twoDigitsHourWithoutSemicolonTest()
	{
		Integer convertToModel = intervalConverter.convertToModel("01", Integer.class,
				Locale.getDefault());
		Assert.assertEquals(new Integer(3600), convertToModel);
	}

	@Test
	public void twoDigitsHourWithSemicolonTest()
	{
		Integer convertToModel = intervalConverter.convertToModel("01:", Integer.class,
				Locale.getDefault());
		Assert.assertEquals(new Integer(3600), convertToModel);
	}

	@Test
	public void twoDigitsHourWithOneDigitMinuteTest()
	{
		Integer convertToModel = intervalConverter.convertToModel("01:5", Integer.class,
				Locale.getDefault());
		Assert.assertEquals(new Integer(3900), convertToModel);
	}

	@Test
	public void twoDigitsHourWithTwoDigitMinuteTest()
	{
		Integer convertToModel = intervalConverter.convertToModel("01:55", Integer.class,
				Locale.getDefault());
		Assert.assertEquals(new Integer(6900), convertToModel);
	}

	@Test (expected = ConversionException.class)
	public void nonSenseTest()
	{
		intervalConverter.convertToModel("Hallo:Welt", Integer.class, Locale.getDefault());
	}

	@Test (expected = ConversionException.class)
	public void partialyNonSenseTest()
	{
		intervalConverter.convertToModel("01:Welt", Integer.class, Locale.getDefault());
	}

	@Test
	public void moreThanSixtyMinutesTest()
	{
		Integer convertToModel = intervalConverter.convertToModel("01:75", Integer.class,
				Locale.getDefault());
		Assert.assertEquals(new Integer(8100), convertToModel);
	}

	@Test (expected = ConversionException.class)
	public void negativeNumberTest()
	{
		intervalConverter.convertToModel("-1", Integer.class, Locale.getDefault());
	}

	@Test
	public void converttoPresentationTest()
	{
		String convertToPresentation = intervalConverter.convertToPresentation(25014, String.class,
				Locale.getDefault());
		Assert.assertEquals("06:56", convertToPresentation);
	}

	@Test
	public void converttoPresentationNullTest()
	{
		String convertToPresentation = intervalConverter.convertToPresentation(null, String.class,
				Locale.getDefault());
		Assert.assertEquals("", convertToPresentation);
	}
}
