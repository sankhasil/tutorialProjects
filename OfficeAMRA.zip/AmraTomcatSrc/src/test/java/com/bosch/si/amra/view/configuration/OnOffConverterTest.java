
package com.bosch.si.amra.view.configuration;

import java.util.Locale;

import org.junit.Assert;
import org.junit.Test;

import com.bosch.si.amra.constants.configuration.ConfigurationConstants;
import com.bosch.si.amra.view.configuration.converter.OnOffConverter;
import com.vaadin.data.util.converter.Converter.ConversionException;

public class OnOffConverterTest
{
	private OnOffConverter onOffConverter;

	@Test
	public void fromOnTest()
	{
		onOffConverter = new OnOffConverter();
		Boolean model = onOffConverter.convertToModel(ConfigurationConstants.ON, Boolean.class,
				Locale.getDefault());
		Assert.assertNotNull(model);
		Assert.assertEquals(true, model);
	}

	@Test
	public void fromOffTest()
	{
		onOffConverter = new OnOffConverter();
		Boolean model = onOffConverter.convertToModel(ConfigurationConstants.OFF, Boolean.class,
				Locale.getDefault());
		Assert.assertNotNull(model);
		Assert.assertEquals(false, model);
	}

	@Test (expected = ConversionException.class)
	public void fromBadStringTest()
	{
		onOffConverter = new OnOffConverter();
		onOffConverter.convertToModel("Blabla", Boolean.class, Locale.getDefault());
	}

	@Test (expected = ConversionException.class)
	public void fromNullTest()
	{
		onOffConverter = new OnOffConverter();
		onOffConverter.convertToModel(null, Boolean.class, Locale.getDefault());
	}

	@Test
	public void toOnTest()
	{
		onOffConverter = new OnOffConverter();
		String presentation = onOffConverter.convertToPresentation(true, String.class,
				Locale.getDefault());
		Assert.assertNotNull(presentation);
		Assert.assertEquals(ConfigurationConstants.ON, presentation);
	}

	@Test
	public void toOffTest()
	{
		onOffConverter = new OnOffConverter();
		String presentation = onOffConverter.convertToPresentation(false, String.class,
				Locale.getDefault());
		Assert.assertNotNull(presentation);
		Assert.assertEquals(ConfigurationConstants.OFF, presentation);
	}

	@Test (expected = ConversionException.class)
	public void toNullTest()
	{
		onOffConverter = new OnOffConverter();
		onOffConverter.convertToPresentation(null, String.class, Locale.getDefault());
	}
}
