
package com.bosch.si.amra.view.notification.filter;

import org.junit.Assert;
import org.junit.Test;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.notification.NotificationConstants;
import com.bosch.si.amra.entity.notification.Notification;
import com.vaadin.data.util.BeanItem;

import mockit.Expectations;
import mockit.Mocked;

public class ReasonFilterTest
{
	@Test
	public void reasonRuleNameFilterTest()
	{
		ReasonFilter filter = new ReasonFilter(NotificationConstants.REASON, "verlassen", true,
				false);
		Notification notification = getNotification();
		notification.setReason("Waiblingen verlassen");
		boolean passesFilter = filter.passesFilter(notification,
				new BeanItem<Notification>(notification));
		Assert.assertTrue(passesFilter);
	}

	@Test
	public void reasonRuleNamePartFilterTest()
	{
		ReasonFilter filter = new ReasonFilter(NotificationConstants.REASON, "Waiblingen", true,
				false);
		Notification notification = getNotification();
		notification.setReason("Waiblingen verlassen");
		boolean passesFilter = filter.passesFilter(notification,
				new BeanItem<Notification>(notification));
		Assert.assertTrue(passesFilter);
	}

	@Test
	public void shockRXFilterTest(@Mocked DashboardUI ui)
	{
		new Expectations()
		{
			{
				DashboardUI.getMessageSource()
						.getMessage("view.notification.reason.shunting_shock_detected_rx");
				returns("Sto\u00DF erkannt auf X-Achse");
			}
		};
		ReasonFilter filter = new ReasonFilter(NotificationConstants.REASON, "Stoß", true, false);
		Notification notification = getNotification();
		notification.setReason("SHUNTING_SHOCK_DETECTED_RX");
		boolean passesFilter = filter.passesFilter(notification,
				new BeanItem<Notification>(notification));
		Assert.assertTrue(passesFilter);
	}

	@Test
	public void shockRYFilterTest(@Mocked DashboardUI ui)
	{
		new Expectations()
		{
			{
				DashboardUI.getMessageSource()
						.getMessage("view.notification.reason.shunting_shock_detected_ry");
				returns("Sto\u00DF erkannt auf Y-Achse");
			}
		};
		ReasonFilter filter = new ReasonFilter(NotificationConstants.REASON, "y-achse", true,
				false);
		Notification notification = getNotification();
		notification.setReason("SHUNTING_SHOCK_DETECTED_RY");
		boolean passesFilter = filter.passesFilter(notification,
				new BeanItem<Notification>(notification));
		Assert.assertTrue(passesFilter);
	}

	@Test
	public void shockRZFilterTest(@Mocked DashboardUI ui)
	{
		new Expectations()
		{
			{
				DashboardUI.getMessageSource()
						.getMessage("view.notification.reason.shunting_shock_detected_rz");
				returns("Sto\u00DF erkannt auf Z-Achse");
			}
		};
		ReasonFilter filter = new ReasonFilter(NotificationConstants.REASON, "erkannt", true,
				false);
		Notification notification = getNotification();
		notification.setReason("SHUNTING_SHOCK_DETECTED_RZ");
		boolean passesFilter = filter.passesFilter(notification,
				new BeanItem<Notification>(notification));
		Assert.assertTrue(passesFilter);
	}

	@Test
	public void filterNotPassTest()
	{
		ReasonFilter filter = new ReasonFilter(NotificationConstants.REASON, "Germany", true,
				false);
		Notification notification = getNotification();
		notification.setReason("Waiblingen verlassen");
		boolean passesFilter = filter.passesFilter(notification,
				new BeanItem<Notification>(notification));
		Assert.assertFalse(passesFilter);
	}

	public Notification getNotification()
	{
		Notification notification = new Notification();
		return notification;
	}

}
