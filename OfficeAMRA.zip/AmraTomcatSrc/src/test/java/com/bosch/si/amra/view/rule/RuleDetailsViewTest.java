
package com.bosch.si.amra.view.rule;

import java.util.Arrays;
import java.util.Date;
import java.util.UUID;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.rule.RuleConstants;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.entity.geofence.Geofence;
import com.bosch.si.amra.entity.rule.Rule;
import com.bosch.si.amra.entity.rule.Rule.Severity;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.view.ruledetails.RuleDetailsView;
import com.vaadin.server.VaadinSession;
import com.vaadin.tapio.googlemaps.client.LatLon;
import com.vaadin.ui.Button;

import mockit.Expectations;
import mockit.Mocked;
import mockit.integration.junit4.JMockit;

@RunWith (JMockit.class)
public class RuleDetailsViewTest
{
	private RuleDetailsView		ruleDetailsView;

	@Mocked
	private VaadinSession		vaadinSession;

	@Mocked
	private DashboardUI			dashboardUI;

	@Mocked
	private DashboardEventBus	dashboardEventBust;

	@Before
	public void setup()
	{
		final User user = createUser();
		new Expectations()
		{
			{
				VaadinSession.getCurrent().getAttribute(User.class.getName());
				returns(user);
			}
		};
	}

	@Test
	public void displayRuleToBeCreatedTest()
	{
		ruleDetailsView = new RuleDetailsView(null, new Button());
		Rule rule = ruleDetailsView.getRule();
		Assert.assertNotNull(rule);
		Assert.assertEquals(new Integer(0), rule.getLimit());
		Assert.assertNull(rule.getCondition());
		Assert.assertNull(rule.getId());
		Assert.assertNull(rule.getName());
		Assert.assertNull(rule.getRuleType());
		Assert.assertNull(rule.getTenantId());
		Assert.assertNull(rule.getUnit());
		Assert.assertNull(rule.getActive());
		Assert.assertNull(rule.getGeofence());
		Assert.assertNull(rule.getSeverity());
		Assert.assertNull(rule.getTimestamp());
		Assert.assertTrue(rule.getWagons().isEmpty());
	}

	@Test
	public void displayExistingRuleTest()
	{
		Rule createdRule = createRule();
		ruleDetailsView = new RuleDetailsView(createdRule, new Button());
		Rule rule = ruleDetailsView.getRule();
		Assert.assertNotNull(rule);
		Assert.assertEquals(createdRule, rule);
	}

	@Test
	public void displayUpperBoundaryValueRuleTestForHT()
	{
		Rule createdRuleForUpperHT = createdRuleForHT('U');
		ruleDetailsView = new RuleDetailsView(createdRuleForUpperHT, new Button());
		Rule rule_upper = ruleDetailsView.getRule();
		Assert.assertNotNull(rule_upper);
		Assert.assertEquals(createdRuleForUpperHT, rule_upper);
	}

	@Test
	public void displayLowerBoundaryValueRuleTestForHT()
	{
		Rule createdRuleForLowerHT = createdRuleForHT('L');
		ruleDetailsView = new RuleDetailsView(createdRuleForLowerHT, new Button());
		Rule rule_lower = ruleDetailsView.getRule();
		Assert.assertNotNull(rule_lower);
		Assert.assertEquals(createdRuleForLowerHT, rule_lower);
	}

	@Test
	public void displayUpperBoundaryValueRuleTestForHM()
	{
		Rule createdRuleForUpperHM = createdRuleForHM('U');
		ruleDetailsView = new RuleDetailsView(createdRuleForUpperHM, new Button());
		Rule rule_upper = ruleDetailsView.getRule();
		Assert.assertNotNull(rule_upper);
		Assert.assertEquals(createdRuleForUpperHM, rule_upper);
	}

	@Test
	public void displayLowerBoundaryValueRuleTestForHM()
	{
		Rule createdRuleForLowerHM = createdRuleForHM('L');
		ruleDetailsView = new RuleDetailsView(createdRuleForLowerHM, new Button());
		Rule rule_lower = ruleDetailsView.getRule();
		Assert.assertNotNull(rule_lower);
		Assert.assertEquals(createdRuleForLowerHM, rule_lower);
	}

	@Test
	public void displayRangeValuesRuleTestForHTR()
	{
		Rule createdRuleForHTR = createRuleForHTR();
		ruleDetailsView = new RuleDetailsView(createdRuleForHTR, new Button());
		Rule rule_htr = ruleDetailsView.getRule();
		Assert.assertNotNull(rule_htr);
		Assert.assertEquals(createdRuleForHTR, rule_htr);
	}

	private User createUser()
	{
		User user = new User();
		user.setTenant("Bosch");
		return user;
	}

	private Rule createRule()
	{
		Rule rule = new Rule();
		rule.setActive(true);
		rule.setCondition("gt");
		Geofence geofence = new Geofence();
		geofence.setId(UUID.randomUUID().toString());
		geofence.setDescription("Test Geofence");
		geofence.setName("Test");
		geofence.setTimestamp(new Date());
		geofence.setTenantId("test");
		geofence.setPositions(Arrays.asList(new LatLon(50.0, 50.0)));
		rule.setGeofence(geofence);
		rule.setLimit(26);
		rule.setName("Regel");
		rule.setRuleType("HM");
		rule.setSeverity(Severity.RED);
		rule.setTenantId("test");
		rule.setTimestamp(new Date());
		rule.setUnit("°C");
		Wagon wagon = new Wagon();
		wagon.setInitial(false);
		rule.setWagons(Arrays.asList(wagon));
		return rule;
	}

	private Rule createdRuleForHT(char limit)
	{

		Rule rule = new Rule();
		rule.setActive(true);
		if (limit == 'U')
		{
			rule.setCondition("gt");
			rule.setLimit(65);
		}
		else if (limit == 'L')
		{
			rule.setCondition("lt");
			rule.setLimit(-39);
		}
		rule.setName("HT_CHECK");
		rule.setRuleType("HT");
		rule.setSeverity(Severity.RED);
		rule.setTenantId("test");
		rule.setTimestamp(new Date());
		rule.setUnit("°C");
		Wagon wagon = new Wagon();
		wagon.setInitial(false);
		rule.setWagons(Arrays.asList(wagon));
		return rule;

	}

	private Rule createdRuleForHM(char limit)
	{

		Rule rule = new Rule();
		rule.setActive(true);
		if (limit == 'U')
		{
			rule.setCondition("gt");
			rule.setLimit(105);
		}
		else if (limit == 'L')
		{
			rule.setCondition("lt");
			rule.setLimit(5);
		}
		rule.setName("HM_CHECK");
		rule.setRuleType("HM");
		rule.setSeverity(Severity.RED);
		rule.setTenantId("test");
		rule.setTimestamp(new Date());
		rule.setUnit("%");
		Wagon wagon = new Wagon();
		wagon.setInitial(false);
		rule.setWagons(Arrays.asList(wagon));
		return rule;

	}

	private Rule createRuleForHTR()
	{
		Rule rule = new Rule();
		rule.setActive(true);
		rule.setName("HTR_CHECK");
		rule.setRuleType(RuleConstants.HUMIDITY_TEMPERATURE_RANGE);
		rule.setSeverity(Severity.RED);
		rule.setTenantId("test");
		rule.setTimestamp(new Date());
		rule.setCondition(RuleConstants.OUT_RANGE);
		rule.setMaxRange(26);
		rule.setMinRange(-30);
		rule.setUnit("°C");
		Wagon wagon = new Wagon();
		wagon.setInitial(false);
		rule.setWagons(Arrays.asList(wagon));
		return rule;

	}
}
