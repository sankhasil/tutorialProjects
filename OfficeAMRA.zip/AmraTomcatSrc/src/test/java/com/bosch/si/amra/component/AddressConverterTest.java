
package com.bosch.si.amra.component;

import java.util.Locale;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.component.converter.AddressConverter;

import mockit.Expectations;
import mockit.Mocked;

public class AddressConverterTest
{
	AddressConverter addressConverter;

	@Before
	public void setup()
	{
		addressConverter = new AddressConverter();
	}

	@Test
	public void convertAddressToPresentationTest()
	{
		String convertedAddress = addressConverter.convertToPresentation(
				"Stuttgarter Straße 13,, 71332 Waiblingen", String.class, Locale.GERMAN);
		Assert.assertNotNull(convertedAddress);
		Assert.assertEquals("Stuttgarter Straße 13,, 71332 Waiblingen", convertedAddress);
	}

	@Test
	public void convertEmptyAddressToPresentationTest(@Mocked DashboardUI dashboardUI)
	{
		new Expectations()
		{
			{
				DashboardUI.getMessageSource().getMessage("not.available");
				returns("Nicht verfügbar");
			}
		};
		String convertedAddress = addressConverter.convertToPresentation("", String.class,
				Locale.GERMAN);
		Assert.assertNotNull(convertedAddress);
		Assert.assertEquals("Nicht verfügbar", convertedAddress);
	}

	@Test
	public void convertNullAddressToPresentationTest(@Mocked DashboardUI dashboardUI)
	{
		new Expectations()
		{
			{
				DashboardUI.getMessageSource().getMessage("not.available");
				returns("Nicht verfügbar");
			}
		};
		String convertedAddress = addressConverter.convertToPresentation(null, String.class,
				Locale.GERMAN);
		Assert.assertNotNull(convertedAddress);
		Assert.assertEquals("Nicht verfügbar", convertedAddress);
	}

	@Test
	public void convertAddressToModel()
	{
		String convertedAddressToModel = addressConverter.convertToModel(
				"Stuttgarter Straße 13,, 71332 Waiblingen", String.class, Locale.GERMAN);
		Assert.assertNull(convertedAddressToModel);
	}
}
