
package com.bosch.si.amra.view.notification;

import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;

import com.bosch.si.amra.entity.notification.Notification;
import com.vaadin.data.Container.Filterable;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.ui.Grid;
import com.vaadin.ui.MenuBar;
import com.vaadin.ui.MenuBar.MenuItem;

import mockit.Expectations;
import mockit.Mocked;

public class NotificationMapFilterCommandTest
{

	@Test
	public void menuSelectedTest(final @Mocked Grid grid, @Mocked NotificationView view)
	{
		final BeanItemContainer<Notification> container = new BeanItemContainer<>(
				Notification.class);
		new Expectations()
		{
			{
				grid.getContainerDataSource();
				returns(container);
			}
		};
		MenuBar menuBar = new MenuBar();
		Map<MenuItem, String> menuItems = new HashMap<>();
		MenuItem shockItem = menuBar.addItem("Shock", null, null);
		shockItem.setCheckable(true);
		shockItem.setChecked(true);
		menuItems.put(shockItem, "SHUNTING_SHOCK_DETECTED");
		MenuItem humidityItem = menuBar.addItem("Humidity", null, null);
		humidityItem.setCheckable(true);
		humidityItem.setChecked(true);
		menuItems.put(humidityItem, "HM");
		MenuItem humidityTemperature = menuBar.addItem("Humidity temperature", null, null);
		humidityTemperature.setCheckable(true);
		humidityTemperature.setChecked(true);
		menuItems.put(humidityTemperature, "HT");
		MenuItem deviceTemperature = menuBar.addItem("Device temperature", null, null);
		deviceTemperature.setCheckable(true);
		deviceTemperature.setChecked(true);
		menuItems.put(deviceTemperature, "DT");
		MenuItem mileageItem = menuBar.addItem("Mileage", null, null);
		mileageItem.setCheckable(true);
		mileageItem.setChecked(true);
		menuItems.put(mileageItem, "KM");
		MenuItem geofenceItem = menuBar.addItem("Geofence", null, null);
		geofenceItem.setCheckable(true);
		geofenceItem.setChecked(true);
		menuItems.put(geofenceItem, "GEOFENCE");
		MenuItem generalItem = menuBar.addItem("General", null, null);
		generalItem.setCheckable(true);
		generalItem.setChecked(true);
		menuItems.put(generalItem, "GENERAL_NOTIFICATION");
		NotificationMapFilterCommand command = new NotificationMapFilterCommand(menuItems, grid,
				view);
		for (MenuItem menuItem : menuItems.keySet())
		{
			menuItem.setCommand(command);
		}
		command.menuSelected(shockItem);
		Filterable data = (Filterable) grid.getContainerDataSource();
		Assert.assertEquals(1, data.getContainerFilters().size());
	}
}