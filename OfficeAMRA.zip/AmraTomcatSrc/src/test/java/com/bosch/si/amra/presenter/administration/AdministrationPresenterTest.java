
package com.bosch.si.amra.presenter.administration;

import java.io.IOException;
import java.io.InputStream;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.commons.io.IOUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.entity.WagonType;
import com.bosch.si.amra.event.DashboardEvent.CouplingEvent;
import com.bosch.si.amra.event.DashboardEvent.DecouplingEvent;
import com.bosch.si.amra.event.DashboardEvent.UpdateMeansOfTransportEvent;
import com.bosch.si.amra.event.DashboardEvent.WagonTypeDeleteEvent;
import com.bosch.si.amra.event.DashboardEvent.WagonTypeEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.provider.DataProviderInitializer;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.util.JSON;

import mockit.Expectations;
import mockit.Mocked;

@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (locations = "file:src/test/resources/spring-servlet.xml")
public class AdministrationPresenterTest
{
	private static final String		TENANT_ID_E9			= "1798c300-c27f-11e4-81a3-0050569350e9";

	private static final String		TENANT_ID_E8			= "1798c300-c27f-11e4-81a3-0050569350e8";

	private static final String		WAGON_TYPE_1020			= "WAGON_TYPE_1020";

	private static final String		EDITED_WAGON_TYPE_1020	= "EDITED_WAGON_TYPE_1020";

	private static final String		WAGON_ID				= "992d077f-460c-4038-9454-2bff56929a7e";

	@Autowired
	private AdministrationPresenter	presenter;

	@Mocked
	final DashboardEventBus			eventBus				= null;

	@Mocked
	final DashboardUI				dashboardUI				= null;

	@Value ("${MONGO_HOST}")
	public String					MONGO_HOST;

	@Value ("${MONGO_PORT}")
	public Integer					MONGO_PORT;

	@Value ("${MONGO_DATABASE}")
	public String					MONGO_DATABASE;

	@Value ("${MONGO_USERNAME}")
	public String					MONGO_USERNAME;

	@Value ("${MONGO_PASSWORD}")
	public String					MONGO_PASSWORD;

	@Value ("${EVENT_COLLECTION}")
	public String					EVENT_COLLECTION;

	@Value ("${MILEAGE_COLLECTION}")
	public String					MILEAGE_COLLECTION;

	@Value ("${ROUTING_COLLECTION}")
	public String					ROUTING_COLLECTION;

	@Value ("${CURRENT_COLLECTION}")
	public String					CURRENT_COLLECTION;

	@Value ("${WAGON_TYPE_COLLECTION}")
	public String					WAGON_TYPE_COLLECITON;

	@Value ("${WAGON_COLLECTION}")
	public String					WAGON_COLLECTION;

	@Value ("${CONFIGURATION_COLLECTION}")
	public String					CONFIGURATION_COLLECTION;

	@Value ("${MONGO_COLLECTION}")
	public String					MONGO_COLLECTION;

	@Value ("${NOTIFICATION_COLLECTION}")
	public String					NOTIFICATION_COLLECTION;

	private Wagon					wagonToSave;

	@Before
	public void setUp()
	{
		MockitoAnnotations.initMocks(this);
		wagonToSave = createWagon("NewWagon", TENANT_ID_E8);
	}

	private Expectations basicExpectation()
	{

		Expectations be = new Expectations()
		{
			{
				DashboardUI.getWagonCollection();
				returns(WAGON_COLLECTION);
				DashboardUI.getConfigurationCollection();
				returns(CONFIGURATION_COLLECTION);
				DashboardUI.getMongoCurrentCollection();
				returns(CURRENT_COLLECTION);
				DashboardUI.getEventCollection();
				returns(EVENT_COLLECTION);
				DashboardUI.getWagonTypeCollection();
				returns(WAGON_TYPE_COLLECITON);
				DashboardUI.getMongoMileageCollection();
				returns(MILEAGE_COLLECTION);
				DashboardUI.getMongoRoutingCollection();
				returns(ROUTING_COLLECTION);
				DashboardUI.getMongoCollection();
				returns(MONGO_COLLECTION);

			}
		};

		return be;
	}

	@After
	public void tearDown() throws UnknownHostException
	{

		new Expectations()
		{
			{
				DashboardUI.getWagonCollection();
				returns(WAGON_COLLECTION);
				DashboardUI.getConfigurationCollection();
				returns(CONFIGURATION_COLLECTION);
				DashboardUI.getMongoCurrentCollection();
				returns(CURRENT_COLLECTION);
				DashboardUI.getEventCollection();
				returns(EVENT_COLLECTION);
				DashboardUI.getWagonTypeCollection();
				returns(WAGON_TYPE_COLLECITON);
				DashboardUI.getMongoMileageCollection();
				returns(MILEAGE_COLLECTION);
				DashboardUI.getMongoRoutingCollection();
				returns(ROUTING_COLLECTION);
				DashboardUI.getMongoCollection();
				returns(MONGO_COLLECTION);
				DashboardUI.getNotificationCollection();
				returns(NOTIFICATION_COLLECTION);
			}
		};

		DBCollection collection = getCollection(DashboardUI.getWagonTypeCollection());
		collection.remove(new BasicDBObject());

		collection = getCollection(DashboardUI.getWagonCollection());
		collection.remove(new BasicDBObject());

		DBCollection configuration = getCollection(DashboardUI.getConfigurationCollection());
		configuration.remove(new BasicDBObject());

		DBCollection current = getCollection(DashboardUI.getMongoCurrentCollection());
		current.remove(new BasicDBObject());

		DBCollection telematic = getCollection(DashboardUI.getEventCollection());
		telematic.remove(new BasicDBObject());

		DBCollection mileage = getCollection(DashboardUI.getMongoMileageCollection());
		mileage.remove(new BasicDBObject());

		DBCollection routing = getCollection(DashboardUI.getMongoRoutingCollection());
		routing.remove(new BasicDBObject());

		DBCollection correlated = getCollection(DashboardUI.getMongoCollection());
		correlated.remove(new BasicDBObject());
		DBCollection notification = getCollection(DashboardUI.getNotificationCollection());
		notification.remove(new BasicDBObject());
	}

	/**
	 * No existing wagon in DB
	 *
	 * <ul>
	 * Wagon To save
	 * <li>tenantId : 1798c300-c27f-11e4-81a3-0050569350e8</li>
	 * <li>NewWagon</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * Result: Saving successful. One wagon in DB
	 *
	 * @throws UnknownHostException
	 */
	@Test
	public void createNewWagonTest() throws UnknownHostException
	{
		getMongoClient();
		basicExpectation();

		WagonType wagonType = createWagonType(WAGON_TYPE_1020, TENANT_ID_E8,
				UUID.randomUUID().toString());
		wagonToSave.setWagonType(wagonType);
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagonToSave, TENANT_ID_E8));

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject find = new BasicDBObject(MongoConstants.ALIAS, "NewWagon");
		find.put(MongoConstants.TENANT_ID, TENANT_ID_E8);
		DBCursor foundWagons = wagonCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertEquals(1, foundWagons.count());

		DBObject foundWagon = foundWagons.iterator().next();
		Assert.assertEquals("NewWagon", foundWagon.get(MongoConstants.ALIAS));
		Assert.assertEquals(TENANT_ID_E8, foundWagon.get(MongoConstants.TENANT_ID));
		DBObject wagonTypeObject = (DBObject) foundWagon.get(MongoConstants.WAGON_TYPE);
		Assert.assertEquals(WAGON_TYPE_1020, wagonTypeObject.get(MongoConstants.WAGON_TYPE_NAME));
	}

	/**
	 * <ul>
	 * Wagon in DB
	 * <li>tenantId : 1798c300-c27f-11e4-81a3-0050569350e8</li>
	 * <li>NewWagon</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * <ul>
	 * Wagon To save
	 * <li>tenantId : 1798c300-c27f-11e4-81a3-0050569350e8</li>
	 * <li>NewWagon</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * Result: Saving not successful due to duplicate key. One wagon in DB
	 *
	 * @throws UnknownHostException
	 */
	@Test
	public void createExistingWagonTest() throws UnknownHostException
	{
		getMongoClient();
		basicExpectation();

		final Wagon wagon = createWagon("NewWagon", TENANT_ID_E8);
		final WagonType wagonType = createWagonType(WAGON_TYPE_1020, TENANT_ID_E8,
				UUID.randomUUID().toString());
		wagon.setWagonType(wagonType);
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagon, TENANT_ID_E8));

		wagonToSave.setWagonType(wagonType);
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagonToSave, TENANT_ID_E8));

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject find = new BasicDBObject(MongoConstants.TENANT_ID, TENANT_ID_E8);
		DBCursor foundWagons = wagonCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertEquals(1, foundWagons.count());
	}

	@Test
	public void editWagonAndCheckForDisponentsTest() throws UnknownHostException
	{
		getMongoClient();
		basicExpectation();

		final Wagon wagon = createWagon("NewWagon", TENANT_ID_E8);

		final WagonType wagonType = createWagonType(WAGON_TYPE_1020, TENANT_ID_E8,
				UUID.randomUUID().toString());
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));

		final WagonType editedWagonType = createWagonType(EDITED_WAGON_TYPE_1020, TENANT_ID_E9,
				UUID.randomUUID().toString());

		wagon.setWagonType(wagonType);

		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagon, TENANT_ID_E8));
		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject find = new BasicDBObject(MongoConstants.TENANT_ID, TENANT_ID_E8);
		find.put(MongoConstants.ALIAS, "NewWagon");
		DBCursor foundWagons = wagonCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertEquals(1, foundWagons.count());

		assingnDisponents(wagon);
		wagon.setAlias("EditedNewWagon");
		wagon.setWagonType(editedWagonType);
		wagon.setId((String) foundWagons.next().get(MongoConstants.ID));

		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagon, TENANT_ID_E8));

		find = new BasicDBObject(MongoConstants.TENANT_ID, TENANT_ID_E8);
		find.put(MongoConstants.ALIAS, "EditedNewWagon");

		foundWagons = wagonCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertEquals(1, foundWagons.count());
		DBObject foundWagon = foundWagons.next();
		Assert.assertNotNull(foundWagon.get(MongoConstants.DISPONENTS));
		BasicDBList disponentsAssigned = (BasicDBList) foundWagon.get(MongoConstants.DISPONENTS);

		Assert.assertEquals(2, disponentsAssigned.size());

	}

	/**
	 * <ul>
	 * Wagon in DB
	 * <li>tenantId : 1798c300-c27f-11e4-81a3-0050569350e8</li>
	 * <li>newwagon</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * <ul>
	 * Wagon To save
	 * <li>tenantId : 1798c300-c27f-11e4-81a3-0050569350e8</li>
	 * <li>NewWagon</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * Result: Saving not successful due to duplicate key. One wagon in DB
	 *
	 * @throws UnknownHostException
	 */
	@Test
	public void createExistingWagonLowerCaseTest() throws UnknownHostException
	{
		getMongoClient();
		basicExpectation();

		final Wagon wagon = createWagon("newwagon", TENANT_ID_E8);
		final WagonType wagonType = createWagonType(WAGON_TYPE_1020, TENANT_ID_E8,
				UUID.randomUUID().toString());
		wagon.setWagonType(wagonType);
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagon, TENANT_ID_E8));

		wagonToSave.setWagonType(wagonType);
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagonToSave, TENANT_ID_E8));

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject find = new BasicDBObject(MongoConstants.TENANT_ID, TENANT_ID_E8);
		DBCursor foundWagons = wagonCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertEquals(1, foundWagons.count());
	}

	/**
	 * <ul>
	 * Wagon in DB
	 * <li>tenantId : cbeaa370-c11d-11e1-8ba8-d4bed92ae489</li>
	 * <li>NewWagon</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * <ul>
	 * Wagon To save
	 * <li>tenantId : 1798c300-c27f-11e4-81a3-0050569350e8</li>
	 * <li>NewWagon</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * Result: Saving successful. Same alias in different tenant. Two wagons in DB
	 *
	 * @throws UnknownHostException
	 */
	@Test
	public void createWagonWithSameAliasInDifferentTenantTest() throws UnknownHostException
	{
		getMongoClient();
		basicExpectation();

		final Wagon wagon = createWagon("NewWagon", "cbeaa370-c11d-11e1-8ba8-d4bed92ae489");
		WagonType wagonType = createWagonType(WAGON_TYPE_1020,
				"cbeaa370-c11d-11e1-8ba8-d4bed92ae489", UUID.randomUUID().toString());
		wagon.setWagonType(wagonType);
		presenter.saveWagonType(
				new WagonTypeEvent(wagonType, "cbeaa370-c11d-11e1-8ba8-d4bed92ae489"));
		presenter.saveWagon(
				new UpdateMeansOfTransportEvent(wagon, "cbeaa370-c11d-11e1-8ba8-d4bed92ae489"));

		wagonType = createWagonType(WAGON_TYPE_1020, TENANT_ID_E8, UUID.randomUUID().toString());
		wagonToSave.setWagonType(wagonType);
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagonToSave, TENANT_ID_E8));

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject find = new BasicDBObject(MongoConstants.ALIAS, "NewWagon");
		DBCursor foundWagons = wagonCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertEquals(2, foundWagons.count());

	}

	/**
	 * <ul>
	 * Wagon in DB
	 * <li>tenantId : 1798c300-c27f-11e4-81a3-0050569350e8</li>
	 * <li>OtherWagon</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * <ul>
	 * Wagon To save
	 * <li>tenantId : 1798c300-c27f-11e4-81a3-0050569350e8</li>
	 * <li>NewWagon</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * Result: Saving successful. Different alias in same tenant. Two wagons in DB
	 *
	 * @throws UnknownHostException
	 */
	@Test
	public void createWagonWithDifferentAliasInSameTenantTest() throws UnknownHostException
	{
		getMongoClient();
		basicExpectation();

		final Wagon wagon = createWagon("OtherWagon", TENANT_ID_E8);
		WagonType wagonType = createWagonType(WAGON_TYPE_1020, TENANT_ID_E8,
				UUID.randomUUID().toString());
		wagon.setWagonType(wagonType);
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagon, TENANT_ID_E8));

		wagonToSave.setWagonType(wagonType);
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagonToSave, TENANT_ID_E8));

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject find = new BasicDBObject(MongoConstants.TENANT_ID, TENANT_ID_E8);
		DBCursor foundWagons = wagonCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertEquals(2, foundWagons.count());
	}

	/**
	 * <ul>
	 * Wagon in DB
	 * <li>tenantId : cbeaa370-c11d-11e1-8ba8-d4bed92ae489</li>
	 * <li>OtherWagon</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * <ul>
	 * Wagon To save
	 * <li>tenantId : 1798c300-c27f-11e4-81a3-0050569350e8</li>
	 * <li>NewWagon</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * Result: Saving successful. Different alias in different tenant. Two wagons in DB. One in each
	 * tenant
	 *
	 * @throws UnknownHostException
	 */
	@Test
	public void createWagonWithDifferenAliasInDifferentTenantTest() throws UnknownHostException
	{
		getMongoClient();
		basicExpectation();

		final Wagon wagon = createWagon("TestWagon", "cbeaa370-c11d-11e1-8ba8-d4bed92ae489");
		WagonType wagonType = createWagonType(WAGON_TYPE_1020,
				"cbeaa370-c11d-11e1-8ba8-d4bed92ae489", UUID.randomUUID().toString());
		wagon.setWagonType(wagonType);
		presenter.saveWagonType(
				new WagonTypeEvent(wagonType, "cbeaa370-c11d-11e1-8ba8-d4bed92ae489"));
		presenter.saveWagon(
				new UpdateMeansOfTransportEvent(wagon, "cbeaa370-c11d-11e1-8ba8-d4bed92ae489"));

		wagonType = createWagonType(WAGON_TYPE_1020, TENANT_ID_E8, UUID.randomUUID().toString());
		wagonToSave.setWagonType(wagonType);
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagonToSave, TENANT_ID_E8));

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject find = new BasicDBObject(MongoConstants.TENANT_ID,
				"cbeaa370-c11d-11e1-8ba8-d4bed92ae489");
		DBCursor foundWagons = wagonCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertEquals(1, foundWagons.count());

		find = new BasicDBObject(MongoConstants.TENANT_ID, TENANT_ID_E8);
		foundWagons = wagonCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertEquals(1, foundWagons.count());
	}

	@Test (expected = IllegalArgumentException.class)
	public void createNullWagonTest()
	{
		presenter.saveWagon(new UpdateMeansOfTransportEvent(null, TENANT_ID_E8));
	}

	@Test (expected = IllegalArgumentException.class)
	public void createNullTenantWagonTest() throws UnknownHostException
	{
		getMongoClient();

		new Expectations()
		{
			{

				DashboardUI.getWagonTypeCollection();
				returns(WAGON_TYPE_COLLECITON);
			}
		};

		final Wagon wagon = createWagon("NewWagon", TENANT_ID_E8);
		final WagonType wagonType = createWagonType(WAGON_TYPE_1020, TENANT_ID_E8, TENANT_ID_E8);
		wagon.setWagonType(wagonType);
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagon, null));
	}

	@Test (expected = IllegalArgumentException.class)
	public void createEmptyTenantWagonTest() throws UnknownHostException
	{
		getMongoClient();
		new Expectations()
		{
			{

				DashboardUI.getWagonTypeCollection();
				returns(WAGON_TYPE_COLLECITON);
			}
		};

		final Wagon wagon = createWagon("NewWagon", TENANT_ID_E8);
		final WagonType wagonType = createWagonType(WAGON_TYPE_1020, TENANT_ID_E8,
				UUID.randomUUID().toString());
		wagon.setWagonType(wagonType);
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagon, ""));
	}

	@Test (expected = IllegalArgumentException.class)
	public void createNullTest()
	{
		presenter.saveWagon(new UpdateMeansOfTransportEvent(null, null));
	}

	/**
	 * <ul>
	 * Existing Wagon in DB
	 * <li>tenantId : cbeaa370-c11d-11e1-8ba8-d4bed92ae489</li>
	 * <li>NewWagon</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * <ul>
	 * Wagon to change
	 * <li>tenantId : 1798c300-c27f-11e4-81a3-0050569350e8</li>
	 * <li>NewWagon -> OtherWagon</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * Result: Updating successful
	 *
	 * @throws UnknownHostException
	 */
	@Test
	public void updateWagonToDifferentAliasWagonExistingInOtherTenantTest()
			throws UnknownHostException
	{
		getMongoClient();
		basicExpectation();

		final Wagon wagon = createWagon("NewWagon", "cbeaa370-c11d-11e1-8ba8-d4bed92ae489");
		WagonType wagonType = createWagonType(WAGON_TYPE_1020,
				"cbeaa370-c11d-11e1-8ba8-d4bed92ae489", UUID.randomUUID().toString());
		wagon.setWagonType(wagonType);
		presenter.saveWagonType(
				new WagonTypeEvent(wagonType, "cbeaa370-c11d-11e1-8ba8-d4bed92ae489"));
		presenter.saveWagon(
				new UpdateMeansOfTransportEvent(wagon, "cbeaa370-c11d-11e1-8ba8-d4bed92ae489"));

		wagonType = createWagonType(WAGON_TYPE_1020, TENANT_ID_E8, UUID.randomUUID().toString());
		wagonToSave.setWagonType(wagonType);
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagonToSave, TENANT_ID_E8));

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject find = new BasicDBObject(MongoConstants.ALIAS, "NewWagon");
		DBCursor foundWagons = wagonCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertEquals(2, foundWagons.count());

		find = new BasicDBObject(MongoConstants.TENANT_ID, TENANT_ID_E8);
		foundWagons = wagonCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertEquals(1, foundWagons.count());

		DBObject wagonToChange = foundWagons.iterator().next();
		Wagon dbObject2Wagon = Wagon.dbObject2Wagon(wagonToChange);
		dbObject2Wagon.setAlias("OtherWagon");
		presenter.saveWagon(new UpdateMeansOfTransportEvent(dbObject2Wagon, TENANT_ID_E8));

		find = new BasicDBObject(MongoConstants.ALIAS, "OtherWagon");
		foundWagons = wagonCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertEquals(1, foundWagons.count());
	}

	@Test
	public void updateRouting() throws UnknownHostException, IOException
	{
		getMongoClient();
		new Expectations()
		{
			{
				DashboardUI.getWagonCollection();
				returns(WAGON_COLLECTION);
				DashboardUI.getConfigurationCollection();
				returns(CONFIGURATION_COLLECTION);
				DashboardUI.getMongoCurrentCollection();
				returns(CURRENT_COLLECTION);
				DashboardUI.getEventCollection();
				returns(EVENT_COLLECTION);
				DashboardUI.getMongoMileageCollection();
				returns(MILEAGE_COLLECTION);
				DashboardUI.getMongoCollection();
				returns(MONGO_COLLECTION);
				DashboardUI.getMongoRoutingCollection();
				returns(ROUTING_COLLECTION);
			}
		};

		fillRouting();

		final Wagon wagon = createWagon("NewWagon", TENANT_ID_E8);
		wagon.setId("5a3e9bde-5bfe-4697-8929-f7dcd76c93ez");
		WagonType wagonType = createWagonType(WAGON_TYPE_1020,
				"cbeaa370-c11d-11e1-8ba8-d4bed92ae489", UUID.randomUUID().toString());
		wagon.setWagonType(wagonType);
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagon, TENANT_ID_E8));

		DBCollection routingCollection = getCollection(DashboardUI.getMongoRoutingCollection());
		DBObject find = new BasicDBObject(MongoConstants.ALIAS, "NewWagon");
		DBCursor foundWagons = routingCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertEquals(1, foundWagons.count());

	}

	@Test
	public void updateCorrelated() throws UnknownHostException, IOException
	{
		getMongoClient();
		new Expectations()
		{
			{
				DashboardUI.getWagonCollection();
				returns(WAGON_COLLECTION);
				DashboardUI.getConfigurationCollection();
				returns(CONFIGURATION_COLLECTION);
				DashboardUI.getMongoCurrentCollection();
				returns(CURRENT_COLLECTION);
				DashboardUI.getEventCollection();
				returns(EVENT_COLLECTION);
				DashboardUI.getMongoMileageCollection();
				returns(MILEAGE_COLLECTION);
				DashboardUI.getMongoCollection();
				returns(MONGO_COLLECTION);
				DashboardUI.getMongoRoutingCollection();
				returns(ROUTING_COLLECTION);
			}
		};

		fillCorrelated();

		final Wagon wagon = createWagon("NewWagon", TENANT_ID_E8);
		wagon.setId("5a3e9bde-5bfe-4697-8929-f7dcd76c93ez");
		WagonType wagonType = createWagonType(WAGON_TYPE_1020,
				"cbeaa370-c11d-11e1-8ba8-d4bed92ae489", UUID.randomUUID().toString());
		wagon.setWagonType(wagonType);
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagon, TENANT_ID_E8));

		DBCollection correlated = getCollection(DashboardUI.getMongoCollection());
		DBObject find = new BasicDBObject(MongoConstants.ALIAS, "NewWagon");
		DBCursor foundWagons = correlated.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertEquals(1, foundWagons.count());

	}

	/**
	 * <ul>
	 * Existing Wagon in DB
	 * <li>tenantId : 1798c300-c27f-11e4-81a3-0050569350e8</li>
	 * <li>OtherWagon</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * <ul>
	 * Wagon to change
	 * <li>tenantId : 1798c300-c27f-11e4-81a3-0050569350e8</li>
	 * <li>NewWagon -> OtherWagon</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * Result: Updating not successful due to duplicate key. A wagon with OtherWagon and NewWagon
	 * exist
	 *
	 * @throws UnknownHostException
	 */
	@Test
	public void updateWagonToSameAliasWagonExistingInSameTenantTest() throws UnknownHostException
	{
		getMongoClient();
		basicExpectation();

		final Wagon wagon = createWagon("OtherWagon", TENANT_ID_E8);
		WagonType wagonType = createWagonType(WAGON_TYPE_1020, TENANT_ID_E8,
				UUID.randomUUID().toString());
		wagon.setWagonType(wagonType);
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagon, TENANT_ID_E8));

		wagonToSave.setWagonType(wagonType);
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagonToSave, TENANT_ID_E8));

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject find = new BasicDBObject(MongoConstants.TENANT_ID, TENANT_ID_E8);
		DBCursor foundWagons = wagonCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertEquals(2, foundWagons.count());

		find = new BasicDBObject(MongoConstants.ALIAS, "NewWagon");
		foundWagons = wagonCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertEquals(1, foundWagons.size());

		DBObject wagonToChange = foundWagons.iterator().next();
		Wagon dbObject2Wagon = Wagon.dbObject2Wagon(wagonToChange);
		dbObject2Wagon.setAlias("OtherWagon");
		presenter.saveWagon(new UpdateMeansOfTransportEvent(dbObject2Wagon, TENANT_ID_E8));

		find = new BasicDBObject(MongoConstants.ALIAS, "OtherWagon");
		foundWagons = wagonCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertEquals(1, foundWagons.count());

		find = new BasicDBObject(MongoConstants.ALIAS, "NewWagon");
		foundWagons = wagonCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertEquals(1, foundWagons.size());
	}

	/**
	 * <ul>
	 * Existing Wagon in DB
	 * <li>tenantId : cbeaa370-c11d-11e1-8ba8-d4bed92ae489</li>
	 * <li>OtherWagon</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * <ul>
	 * Wagon to change
	 * <li>tenantId : 1798c300-c27f-11e4-81a3-0050569350e8</li>
	 * <li>NewWagon -> OtherWagon</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * Result: Updating not successful due to duplicate key. A wagon with OtherWagon and NewWagon
	 * exist
	 *
	 * @throws UnknownHostException
	 */
	@Test
	public void updateWagonToSameAliasWagonExistingInOtherTenantTest() throws UnknownHostException
	{
		getMongoClient();
		basicExpectation();

		final Wagon wagon = createWagon("OtherWagon", "cbeaa370-c11d-11e1-8ba8-d4bed92ae489");
		WagonType wagonType = createWagonType(WAGON_TYPE_1020,
				"cbeaa370-c11d-11e1-8ba8-d4bed92ae489", UUID.randomUUID().toString());
		wagon.setWagonType(wagonType);
		presenter.saveWagonType(
				new WagonTypeEvent(wagonType, "cbeaa370-c11d-11e1-8ba8-d4bed92ae489"));
		presenter.saveWagon(
				new UpdateMeansOfTransportEvent(wagon, "cbeaa370-c11d-11e1-8ba8-d4bed92ae489"));

		wagonType = createWagonType(WAGON_TYPE_1020, TENANT_ID_E8, UUID.randomUUID().toString());
		wagonToSave.setWagonType(wagonType);
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagonToSave, TENANT_ID_E8));

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject find = new BasicDBObject(MongoConstants.TENANT_ID, TENANT_ID_E8);
		DBCursor foundWagons = wagonCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertEquals(1, foundWagons.count());

		find = new BasicDBObject(MongoConstants.ALIAS, "NewWagon");
		foundWagons = wagonCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertEquals(1, foundWagons.count());

		DBObject wagonToChange = foundWagons.iterator().next();
		Wagon dbObject2Wagon = Wagon.dbObject2Wagon(wagonToChange);
		dbObject2Wagon.setAlias("OtherWagon");
		presenter.saveWagon(new UpdateMeansOfTransportEvent(dbObject2Wagon, TENANT_ID_E8));

		find = new BasicDBObject(MongoConstants.ALIAS, "OtherWagon");
		foundWagons = wagonCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertEquals(2, foundWagons.count());

		find = new BasicDBObject(MongoConstants.TENANT_ID, "cbeaa370-c11d-11e1-8ba8-d4bed92ae489");
		foundWagons = wagonCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertEquals(1, foundWagons.size());
	}

	@Test
	public void updateWagonCheckAliasTest() throws IOException
	{
		getMongoClient();
		basicExpectation();
		createWagonCollection("/testData/wagon/wagon2Save.json");
		fillTestDB();
		fillCorrelated();
		fillRouting();

		final Wagon wagonToSave = new Wagon();
		wagonToSave.setId("5a3e9bde-5bfe-4697-8929-f7dcd76c93ez");
		wagonToSave.setAlias("NewWagon");
		wagonToSave.setCreatedTs(new Date());
		wagonToSave.setTenantId(TENANT_ID_E8);

		WagonType wagonType = createWagonType(WAGON_TYPE_1020, TENANT_ID_E8,
				UUID.randomUUID().toString());
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));
		wagonToSave.setWagonType(wagonType);
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagonToSave, TENANT_ID_E8));

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject find = new BasicDBObject(MongoConstants.ALIAS, "NewWagon");
		DBObject wagonObject = wagonCollection.findOne(find);

		Assert.assertNotNull(wagonObject);

		// Update the alias
		Wagon dbObject2Wagon = Wagon.dbObject2Wagon(wagonObject);
		dbObject2Wagon.setAlias("OtherWagon");
		presenter.saveWagon(new UpdateMeansOfTransportEvent(dbObject2Wagon, TENANT_ID_E8));

		find = new BasicDBObject(MongoConstants.ALIAS, "OtherWagon");
		wagonObject = wagonCollection.findOne(find);

		Assert.assertNotNull(wagonObject);

		// Check current collection
		DBCollection currentCollection = getCollection(DashboardUI.getMongoCurrentCollection());

		// No NewWagon available
		DBObject match = new BasicDBObject(MongoConstants.ALIAS, "NewWagon");
		match.put(MongoConstants.TENANT_ID, TENANT_ID_E8);
		DBObject currentObject = currentCollection.findOne(match);
		Assert.assertNull(currentObject);

		// Check for updated alias
		match = new BasicDBObject(MongoConstants.TENANT_ID, TENANT_ID_E8);
		currentObject = currentCollection.findOne(match);
		Assert.assertNotNull(currentObject);
		Assert.assertEquals("OtherWagon", currentObject.get(MongoConstants.ALIAS));
		Assert.assertEquals("otherwagon", currentObject.get(MongoConstants.SORT));

		// Check telematic collection
		DBCollection telematicCollection = getCollection(DashboardUI.getEventCollection());

		// No NewWagon available
		match = new BasicDBObject(MongoConstants.ALIAS, "NewWagon");
		match.put(MongoConstants.TENANT_ID, TENANT_ID_E8);
		DBCursor telematicCursor = telematicCollection.find(match);
		Assert.assertNotNull(telematicCursor);
		Assert.assertEquals(0, telematicCursor.count());

		match = new BasicDBObject(MongoConstants.WAGON_ID, "5a3e9bde-5bfe-4697-8929-f7dcd76c93ez");
		DBObject telematicObject = telematicCollection.findOne(match);
		Assert.assertNotNull(telematicObject);
		Assert.assertEquals("OtherWagon", telematicObject.get(MongoConstants.ALIAS));
		Assert.assertEquals("otherwagon", telematicObject.get(MongoConstants.SORT));

		// Check correlated collection
		DBCollection correlatedCollection = getCollection(DashboardUI.getMongoCollection());

		// Check No NewWagon in correlated collection
		match = new BasicDBObject(MongoConstants.ALIAS, "NewWagon");
		match.put(MongoConstants.TENANT_ID, TENANT_ID_E8);
		DBObject correlatedObject = correlatedCollection.findOne(match);
		Assert.assertNull(correlatedObject);

		// Check for updated alias in correlated collection
		match = new BasicDBObject(MongoConstants.TENANT_ID, TENANT_ID_E8);
		correlatedObject = correlatedCollection.findOne(match);
		Assert.assertNotNull(correlatedObject);
		Assert.assertEquals("OtherWagon", correlatedObject.get(MongoConstants.ALIAS));
		Assert.assertEquals("otherwagon", correlatedObject.get(MongoConstants.SORT));

		// Check routing collection
		DBCollection routingCollection = getCollection(DashboardUI.getMongoRoutingCollection());

		// Check No NewWagon in routing collection
		match = new BasicDBObject(MongoConstants.ALIAS, "NewWagon");
		match.put(MongoConstants.TENANT_ID, TENANT_ID_E8);
		DBObject routingObject = routingCollection.findOne(match);
		Assert.assertNull(routingObject);

		// Check for updated alias in routing collection
		match = new BasicDBObject(MongoConstants.TENANT_ID, TENANT_ID_E8);
		routingObject = routingCollection.findOne(match);
		Assert.assertNotNull(routingObject);
		Assert.assertEquals("OtherWagon", routingObject.get(MongoConstants.ALIAS));
		Assert.assertEquals("otherwagon", routingObject.get(MongoConstants.SORT));

	}

	/**
	 * <ul>
	 * CoupleWagon
	 * <li>tenantId : 1798c300-c27f-11e4-81a3-0050569350e8</li>
	 * <li>boxId : 123456789012345L</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * Result: Coupling successful
	 *
	 * @throws UnknownHostException
	 */
	@Test
	public void coupleWagonTest() throws UnknownHostException
	{
		getMongoClient();
		basicExpectation();

		Wagon wagon = createWagon("CoupleWagon", TENANT_ID_E8);
		WagonType wagonType = createWagonType(WAGON_TYPE_1020, TENANT_ID_E8,
				UUID.randomUUID().toString());
		wagon.setWagonType(wagonType);
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagon, TENANT_ID_E8));

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject find = new BasicDBObject(MongoConstants.ALIAS, "CoupleWagon");
		find.put(MongoConstants.TENANT_ID, TENANT_ID_E8);
		DBCursor foundWagonsWithoutBoxId = wagonCollection.find(find);

		Assert.assertNotNull(foundWagonsWithoutBoxId);
		Assert.assertEquals(1, foundWagonsWithoutBoxId.count());

		DBObject foundWagonWithoutBoxId = foundWagonsWithoutBoxId.iterator().next();
		Assert.assertEquals("CoupleWagon", foundWagonWithoutBoxId.get(MongoConstants.ALIAS));
		Assert.assertNull(foundWagonWithoutBoxId.get(MongoConstants.BOX_ID));
		Assert.assertEquals(TENANT_ID_E8, foundWagonWithoutBoxId.get(MongoConstants.TENANT_ID));
		DBObject wagonTypeObject = (DBObject) foundWagonWithoutBoxId.get(MongoConstants.WAGON_TYPE);
		Assert.assertEquals(WAGON_TYPE_1020, wagonTypeObject.get(MongoConstants.WAGON_TYPE_NAME));

		Wagon dbObject2Wagon = Wagon.dbObject2Wagon(foundWagonWithoutBoxId);
		dbObject2Wagon.setBoxId(123456789012345L);
		presenter.coupleWagonWithBox(new CouplingEvent(dbObject2Wagon));

		find = new BasicDBObject(MongoConstants.ALIAS, "CoupleWagon");
		DBCursor foundWagonsWithBoxId = wagonCollection.find(find);

		Assert.assertNotNull(foundWagonsWithBoxId);
		Assert.assertEquals(1, foundWagonsWithBoxId.count());
		Assert.assertEquals(new Long(123456789012345L),
				foundWagonsWithBoxId.iterator().next().get(MongoConstants.BOX_ID));
	}

	/**
	 * <ul>
	 * NewWagon
	 * <li>tenantId : cbeaa370-c11d-11e1-8ba8-d4bed92ae489</li>
	 * <li>boxId : 123456789012345L</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * <ul>
	 * NewWagon (ToCouple)
	 * <li>tenantId : 1798c300-c27f-11e4-81a3-0050569350e8</li>
	 * <li>boxId : 123456789012345L</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * Result: No coupling of NewWagon due to existing box Id 123456789012345L
	 *
	 * @throws UnknownHostException
	 */
	@Test
	public void coupleWagonWithSameAliasInDifferentTenantExistingBoxIdTest()
			throws UnknownHostException
	{
		getMongoClient();
		basicExpectation();

		Wagon wagon = createWagon("NewWagon", "cbeaa370-c11d-11e1-8ba8-d4bed92ae489");
		wagon.setBoxId(123456789012345L);
		WagonType wagonType = createWagonType(WAGON_TYPE_1020,
				"cbeaa370-c11d-11e1-8ba8-d4bed92ae489", UUID.randomUUID().toString());
		wagon.setWagonType(wagonType);
		presenter.saveWagonType(
				new WagonTypeEvent(wagonType, "cbeaa370-c11d-11e1-8ba8-d4bed92ae489"));
		presenter.saveWagon(
				new UpdateMeansOfTransportEvent(wagon, "cbeaa370-c11d-11e1-8ba8-d4bed92ae489"));

		wagonType = createWagonType(WAGON_TYPE_1020, TENANT_ID_E8, UUID.randomUUID().toString());
		wagonToSave.setWagonType(wagonType);
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagonToSave, TENANT_ID_E8));

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBCursor foundWagonsWithBoxId = wagonCollection
				.find(new BasicDBObject(MongoConstants.ALIAS, "NewWagon"));

		Assert.assertNotNull(foundWagonsWithBoxId);
		Assert.assertEquals(2, foundWagonsWithBoxId.count());

		wagonToSave.setBoxId(123456789012345L);
		presenter.coupleWagonWithBox(new CouplingEvent(wagonToSave));

		DBObject findOne = wagonCollection
				.findOne(new BasicDBObject(MongoConstants.TENANT_ID, TENANT_ID_E8));
		Assert.assertNotNull(findOne);
		Assert.assertNull(findOne.get(MongoConstants.BOX_ID));
	}

	/**
	 * <ul>
	 * NewWagon
	 * <li>tenantId : cbeaa370-c11d-11e1-8ba8-d4bed92ae489</li>
	 * <li>boxId : 123456789012345L</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * <ul>
	 * NewWagon (ToCouple)
	 * <li>tenantId : 1798c300-c27f-11e4-81a3-0050569350e8</li>
	 * <li>boxId : 123456789012346L</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * Result: Coupling successfully
	 *
	 * @throws UnknownHostException
	 */
	@Test
	public void coupleWagonWithSameAliasInDifferentTenantDifferentBoxIdTest()
			throws UnknownHostException
	{
		getMongoClient();
		basicExpectation();

		Wagon wagon = createWagon("NewWagon", "cbeaa370-c11d-11e1-8ba8-d4bed92ae489");
		WagonType wagonType = createWagonType(WAGON_TYPE_1020,
				"cbeaa370-c11d-11e1-8ba8-d4bed92ae489", UUID.randomUUID().toString());
		wagon.setWagonType(wagonType);
		presenter.saveWagonType(
				new WagonTypeEvent(wagonType, "cbeaa370-c11d-11e1-8ba8-d4bed92ae489"));
		presenter.saveWagon(
				new UpdateMeansOfTransportEvent(wagon, "cbeaa370-c11d-11e1-8ba8-d4bed92ae489"));

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject find = new BasicDBObject(MongoConstants.ALIAS, "NewWagon");
		DBObject wagonObject = wagonCollection.findOne(find);

		Wagon dbObject2Wagon = Wagon.dbObject2Wagon(wagonObject);
		dbObject2Wagon.setBoxId(123456789012345L);
		presenter.coupleWagonWithBox(new CouplingEvent(dbObject2Wagon));

		wagonType = createWagonType(WAGON_TYPE_1020, TENANT_ID_E8, UUID.randomUUID().toString());
		wagonToSave.setWagonType(wagonType);
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagonToSave, TENANT_ID_E8));

		find = new BasicDBObject(MongoConstants.TENANT_ID, TENANT_ID_E8);
		DBCursor foundWagonsWithBoxId = wagonCollection.find(find);

		Assert.assertNotNull(foundWagonsWithBoxId);
		Assert.assertEquals(1, foundWagonsWithBoxId.count());

		DBObject wagonToCouple = foundWagonsWithBoxId.iterator().next();
		Wagon dbObject2Wagon2 = Wagon.dbObject2Wagon(wagonToCouple);
		dbObject2Wagon2.setBoxId(123456789012346L);
		presenter.coupleWagonWithBox(new CouplingEvent(dbObject2Wagon2));

		find = new BasicDBObject(MongoConstants.ALIAS, "NewWagon");
		foundWagonsWithBoxId = wagonCollection.find(find);

		Assert.assertNotNull(foundWagonsWithBoxId);
		Assert.assertEquals(2, foundWagonsWithBoxId.count());

		find = new BasicDBObject(MongoConstants.TENANT_ID, TENANT_ID_E8);
		foundWagonsWithBoxId = wagonCollection.find(find);

		Assert.assertNotNull(foundWagonsWithBoxId);
		Assert.assertEquals(1, foundWagonsWithBoxId.count());
		Assert.assertEquals(new Long(123456789012346L),
				foundWagonsWithBoxId.iterator().next().get(MongoConstants.BOX_ID));

		find = new BasicDBObject(MongoConstants.TENANT_ID, "cbeaa370-c11d-11e1-8ba8-d4bed92ae489");
		foundWagonsWithBoxId = wagonCollection.find(find);

		Assert.assertNotNull(foundWagonsWithBoxId);
		Assert.assertEquals(1, foundWagonsWithBoxId.count());
		Assert.assertEquals(new Long(123456789012345L),
				foundWagonsWithBoxId.iterator().next().get(MongoConstants.BOX_ID));
	}

	/**
	 * <ul>
	 * OtherWagon
	 * <li>tenantId : 1798c300-c27f-11e4-81a3-0050569350e8</li>
	 * <li>boxId : 123456789012345L</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * <ul>
	 * NewWagon (ToCouple)
	 * <li>tenantId : 1798c300-c27f-11e4-81a3-0050569350e8</li>
	 * <li>boxId : 123456789012345L</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * Result: Coupling not successful due to existing box Id 123456789012345L
	 *
	 * @throws UnknownHostException
	 */
	@Test
	public void coupleWagonWithDifferentAliasInSameTenantExistingBoxIdTest()
			throws UnknownHostException
	{
		getMongoClient();
		basicExpectation();

		Wagon wagon = createWagon("OtherWagon", TENANT_ID_E8);
		WagonType wagonType = createWagonType(WAGON_TYPE_1020, TENANT_ID_E8,
				UUID.randomUUID().toString());
		wagon.setWagonType(wagonType);
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagon, TENANT_ID_E8));

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject find = new BasicDBObject(MongoConstants.ALIAS, "OtherWagon");
		DBObject wagonObject = wagonCollection.findOne(find);

		Wagon dbObject2Wagon = Wagon.dbObject2Wagon(wagonObject);
		dbObject2Wagon.setBoxId(123456789012345L);
		presenter.coupleWagonWithBox(new CouplingEvent(dbObject2Wagon));

		wagonToSave.setWagonType(wagonType);
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagonToSave, TENANT_ID_E8));

		find = new BasicDBObject(MongoConstants.ALIAS, "NewWagon");
		wagonObject = wagonCollection.findOne(find);
		Assert.assertNotNull(wagonObject);

		dbObject2Wagon = Wagon.dbObject2Wagon(wagonObject);
		dbObject2Wagon.setBoxId(123456789012345L);
		presenter.coupleWagonWithBox(new CouplingEvent(dbObject2Wagon));

		find = new BasicDBObject(MongoConstants.TENANT_ID, TENANT_ID_E8);
		DBCursor foundWagonsWithBoxId = wagonCollection.find(find);

		Assert.assertNotNull(foundWagonsWithBoxId);
		Assert.assertEquals(2, foundWagonsWithBoxId.count());

		find = new BasicDBObject(MongoConstants.ALIAS, "OtherWagon");
		foundWagonsWithBoxId = wagonCollection.find(find);

		Assert.assertNotNull(foundWagonsWithBoxId);
		Assert.assertEquals(1, foundWagonsWithBoxId.count());
		Assert.assertEquals(new Long(123456789012345L),
				foundWagonsWithBoxId.iterator().next().get(MongoConstants.BOX_ID));

		find = new BasicDBObject(MongoConstants.ALIAS, "NewWagon");
		foundWagonsWithBoxId = wagonCollection.find(find);

		Assert.assertNotNull(foundWagonsWithBoxId);
		Assert.assertEquals(1, foundWagonsWithBoxId.count());
		Assert.assertNull(foundWagonsWithBoxId.iterator().next().get(MongoConstants.BOX_ID));
	}

	/**
	 * <ul>
	 * OtherWagon
	 * <li>tenantId : cbeaa370-c11d-11e1-8ba8-d4bed92ae489</li>
	 * <li>boxId : 123456789012345L</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * <ul>
	 * NewWagon (ToCouple)
	 * <li>tenantId : 1798c300-c27f-11e4-81a3-0050569350e8</li>
	 * <li>boxId : 123456789012345L</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * Result: Coupling not successful due to existing box Id 123456789012345L
	 *
	 * @throws UnknownHostException
	 */
	@Test
	public void coupleWagonWithDifferentAliasInDifferentTenantExistingBoxIdTest()
			throws UnknownHostException
	{
		getMongoClient();
		basicExpectation();

		Wagon wagon = createWagon("OtherWagon", "cbeaa370-c11d-11e1-8ba8-d4bed92ae489");
		WagonType wagonType = createWagonType(WAGON_TYPE_1020,
				"cbeaa370-c11d-11e1-8ba8-d4bed92ae489", UUID.randomUUID().toString());
		wagon.setWagonType(wagonType);
		presenter.saveWagonType(
				new WagonTypeEvent(wagonType, "cbeaa370-c11d-11e1-8ba8-d4bed92ae489"));
		presenter.saveWagon(
				new UpdateMeansOfTransportEvent(wagon, "cbeaa370-c11d-11e1-8ba8-d4bed92ae489"));

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject find = new BasicDBObject(MongoConstants.ALIAS, "OtherWagon");
		DBObject wagonObject = wagonCollection.findOne(find);

		Wagon dbObject2Wagon = Wagon.dbObject2Wagon(wagonObject);
		dbObject2Wagon.setBoxId(123456789012345L);
		presenter.coupleWagonWithBox(new CouplingEvent(dbObject2Wagon));

		wagonType = createWagonType(WAGON_TYPE_1020, TENANT_ID_E8, UUID.randomUUID().toString());
		wagonToSave.setWagonType(wagonType);
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagonToSave, TENANT_ID_E8));

		find = new BasicDBObject(MongoConstants.ALIAS, "NewWagon");
		wagonObject = wagonCollection.findOne(find);

		dbObject2Wagon = Wagon.dbObject2Wagon(wagonObject);
		Assert.assertNotNull(dbObject2Wagon);
		dbObject2Wagon.setBoxId(123456789012345L);
		presenter.coupleWagonWithBox(new CouplingEvent(dbObject2Wagon));

		find = new BasicDBObject(MongoConstants.TENANT_ID, TENANT_ID_E8);
		DBCursor foundWagonsWithBoxId = wagonCollection.find(find);

		Assert.assertNotNull(foundWagonsWithBoxId);
		Assert.assertEquals(1, foundWagonsWithBoxId.count());

		find = new BasicDBObject(MongoConstants.ALIAS, "OtherWagon");
		foundWagonsWithBoxId = wagonCollection.find(find);

		Assert.assertNotNull(foundWagonsWithBoxId);
		Assert.assertEquals(1, foundWagonsWithBoxId.count());
		Assert.assertEquals(new Long(123456789012345L),
				foundWagonsWithBoxId.iterator().next().get(MongoConstants.BOX_ID));

		find = new BasicDBObject(MongoConstants.ALIAS, "NewWagon");
		foundWagonsWithBoxId = wagonCollection.find(find);

		Assert.assertNotNull(foundWagonsWithBoxId);
		Assert.assertEquals(1, foundWagonsWithBoxId.size());
		Assert.assertNull(foundWagonsWithBoxId.iterator().next().get(MongoConstants.BOX_ID));
	}

	/**
	 * <ul>
	 * OtherWagon
	 * <li>tenantId : 1798c300-c27f-11e4-81a3-0050569350e8</li>
	 * <li>boxId : 123456789012345L</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * <ul>
	 * NewWagon (ToCouple)
	 * <li>tenantId : 1798c300-c27f-11e4-81a3-0050569350e8</li>
	 * <li>boxId : 123456789012346L</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * Result: Coupling successfully
	 *
	 * @throws UnknownHostException
	 */
	@Test
	public void coupleWagonWithDifferentAliasInSameTenantDifferentBoxIdTest()
			throws UnknownHostException
	{
		getMongoClient();
		basicExpectation();

		Wagon wagon = createWagon("OtherWagon", TENANT_ID_E8);
		WagonType wagonType = createWagonType(WAGON_TYPE_1020, TENANT_ID_E8,
				UUID.randomUUID().toString());
		wagon.setWagonType(wagonType);
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagon, TENANT_ID_E8));

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject find = new BasicDBObject(MongoConstants.ALIAS, "OtherWagon");
		DBObject wagonObject = wagonCollection.findOne(find);

		Wagon dbObject2Wagon = Wagon.dbObject2Wagon(wagonObject);
		dbObject2Wagon.setBoxId(123456789012345L);
		presenter.coupleWagonWithBox(new CouplingEvent(dbObject2Wagon));

		wagonToSave.setWagonType(wagonType);
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagonToSave, TENANT_ID_E8));

		find = new BasicDBObject(MongoConstants.ALIAS, "NewWagon");
		wagonObject = wagonCollection.findOne(find);
		Assert.assertNotNull(wagonObject);

		dbObject2Wagon = Wagon.dbObject2Wagon(wagonObject);
		dbObject2Wagon.setBoxId(123456789012346L);
		presenter.coupleWagonWithBox(new CouplingEvent(dbObject2Wagon));

		find = new BasicDBObject(MongoConstants.TENANT_ID, TENANT_ID_E8);
		DBCursor foundWagonsWithBoxId = wagonCollection.find(find);

		Assert.assertNotNull(foundWagonsWithBoxId);
		Assert.assertEquals(2, foundWagonsWithBoxId.count());

		find = new BasicDBObject(MongoConstants.ALIAS, "OtherWagon");
		foundWagonsWithBoxId = wagonCollection.find(find);

		Assert.assertNotNull(foundWagonsWithBoxId);
		Assert.assertEquals(1, foundWagonsWithBoxId.count());
		Assert.assertEquals(new Long(123456789012345L),
				foundWagonsWithBoxId.iterator().next().get(MongoConstants.BOX_ID));

		find = new BasicDBObject(MongoConstants.ALIAS, "NewWagon");
		foundWagonsWithBoxId = wagonCollection.find(find);

		Assert.assertNotNull(foundWagonsWithBoxId);
		Assert.assertEquals(1, foundWagonsWithBoxId.size());
		Assert.assertEquals(new Long(123456789012346L),
				foundWagonsWithBoxId.iterator().next().get(MongoConstants.BOX_ID));
	}

	/**
	 * <ul>
	 * OtherWagon
	 * <li>tenantId : cbeaa370-c11d-11e1-8ba8-d4bed92ae489</li>
	 * <li>boxId : 123456789012345L</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * <ul>
	 * NewWagon (ToCouple)
	 * <li>tenantId : 1798c300-c27f-11e4-81a3-0050569350e8</li>
	 * <li>boxId : 123456789012346L</li>
	 * <li>WagonType : WAGON_TYPE_1020</li>
	 * </ul>
	 *
	 * Result: Coupling successful
	 *
	 * @throws UnknownHostException
	 * @throws InterruptedException
	 */
	@Test
	public void coupleWagonWithDifferentAliasInDifferentTenantDifferentBoxIdTest()
			throws UnknownHostException, InterruptedException
	{
		getMongoClient();
		basicExpectation();

		Wagon wagon = createWagon("OtherWagon", "cbeaa370-c11d-11e1-8ba8-d4bed92ae489");
		WagonType wagonType = createWagonType(WAGON_TYPE_1020,
				"cbeaa370-c11d-11e1-8ba8-d4bed92ae489", UUID.randomUUID().toString());
		wagon.setWagonType(wagonType);
		presenter.saveWagonType(
				new WagonTypeEvent(wagonType, "cbeaa370-c11d-11e1-8ba8-d4bed92ae489"));
		presenter.saveWagon(
				new UpdateMeansOfTransportEvent(wagon, "cbeaa370-c11d-11e1-8ba8-d4bed92ae489"));

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject find = new BasicDBObject(MongoConstants.SORT, "otherwagon");
		DBCursor foundWagonsWithBoxId = wagonCollection.find(find);

		Assert.assertNotNull(foundWagonsWithBoxId);
		Assert.assertEquals(1, foundWagonsWithBoxId.count());

		DBObject wagonToCouple = foundWagonsWithBoxId.iterator().next();
		Wagon dbObject2Wagon = Wagon.dbObject2Wagon(wagonToCouple);
		dbObject2Wagon.setBoxId(123456789012345L);
		presenter.coupleWagonWithBox(new CouplingEvent(dbObject2Wagon));

		wagonType = createWagonType(WAGON_TYPE_1020, TENANT_ID_E8, UUID.randomUUID().toString());
		wagonToSave.setWagonType(wagonType);
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagonToSave, TENANT_ID_E8));

		find = new BasicDBObject(MongoConstants.SORT, "newwagon");
		foundWagonsWithBoxId = wagonCollection.find(find);

		Assert.assertNotNull(foundWagonsWithBoxId);
		Assert.assertEquals(1, foundWagonsWithBoxId.count());

		wagonToCouple = foundWagonsWithBoxId.iterator().next();
		dbObject2Wagon = Wagon.dbObject2Wagon(wagonToCouple);
		dbObject2Wagon.setBoxId(123456789012346L);
		presenter.coupleWagonWithBox(new CouplingEvent(dbObject2Wagon));

		find = new BasicDBObject(MongoConstants.SORT, "otherwagon");
		foundWagonsWithBoxId = wagonCollection.find(find);

		Assert.assertNotNull(foundWagonsWithBoxId);
		Assert.assertEquals(1, foundWagonsWithBoxId.size());
		Assert.assertEquals(new Long(123456789012345L),
				foundWagonsWithBoxId.iterator().next().get(MongoConstants.BOX_ID));

		find = new BasicDBObject(MongoConstants.ALIAS, "NewWagon");
		foundWagonsWithBoxId = wagonCollection.find(find);

		Assert.assertNotNull(foundWagonsWithBoxId);
		Assert.assertEquals(1, foundWagonsWithBoxId.size());
		Assert.assertEquals(new Long(123456789012346L),
				foundWagonsWithBoxId.iterator().next().get(MongoConstants.BOX_ID));
	}

	@Test
	public void coupleWagonUpdateConfigurationTest() throws IOException
	{
		getMongoClient();
		basicExpectation();
		createWagonCollection("/testData/wagon/wagon2Save.json");
		fillTestDB();

		final Wagon wagonToSave = new Wagon();
		wagonToSave.setId("5a3e9bde-5bfe-4697-8929-f7dcd76c93ez");
		wagonToSave.setAlias("NewWagon");
		wagonToSave.setCreatedTs(new Date());
		wagonToSave.setTenantId(TENANT_ID_E8);

		WagonType wagonType = createWagonType(WAGON_TYPE_1020, TENANT_ID_E8,
				UUID.randomUUID().toString());
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));
		wagonToSave.setWagonType(wagonType);
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagonToSave, TENANT_ID_E8));

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject find = new BasicDBObject(MongoConstants.ALIAS, "NewWagon");
		DBObject wagonObject = wagonCollection.findOne(find);

		Assert.assertNotNull(wagonObject);

		// Couple wagon
		Wagon dbObject2Wagon = Wagon.dbObject2Wagon(wagonObject);
		dbObject2Wagon.setBoxId(777777766666443l);
		presenter.coupleWagonWithBox(new CouplingEvent(dbObject2Wagon));

		DBCollection configurationCollection = getCollection(
				DashboardUI.getConfigurationCollection());
		String wagonId = dbObject2Wagon.getId();
		DBObject configurationObject = configurationCollection
				.findOne(new BasicDBObject(MongoConstants.WAGON_ID, wagonId));

		Assert.assertNotNull(configurationObject);
		Assert.assertEquals("NewWagon", configurationObject.get(MongoConstants.ALIAS));
		Assert.assertEquals("newwagon", configurationObject.get(MongoConstants.SORT));
		Assert.assertEquals(777777766666443l, configurationObject.get(MongoConstants.BOX_ID));
	}

	@Test
	public void decoupleTest() throws UnknownHostException
	{
		getMongoClient();
		basicExpectation();

		Wagon wagon = createWagon("DecoupleWagon", "cbeaa370-c11d-11e1-8ba8-d4bed92ae489");
		wagon.setBoxId(111111111111111l);
		WagonType wagonType = createWagonType(WAGON_TYPE_1020,
				"cbeaa370-c11d-11e1-8ba8-d4bed92ae489", UUID.randomUUID().toString());
		wagon.setWagonType(wagonType);
		presenter.saveWagonType(
				new WagonTypeEvent(wagonType, "cbeaa370-c11d-11e1-8ba8-d4bed92ae489"));
		presenter.saveWagon(
				new UpdateMeansOfTransportEvent(wagon, "cbeaa370-c11d-11e1-8ba8-d4bed92ae489"));

		DBCollection collection = getCollection(DashboardUI.getWagonCollection());
		DBObject find = new BasicDBObject(MongoConstants.ALIAS, "DecoupleWagon");
		DBObject wagonObject = collection.findOne(find);
		Wagon dbObject2Wagon = Wagon.dbObject2Wagon(wagonObject);

		presenter.decoupleWagonWithBox(new DecouplingEvent(dbObject2Wagon));

		find = new BasicDBObject(MongoConstants.ALIAS, "DecoupleWagon");
		wagonObject = collection.findOne(find);

		Assert.assertNotNull(wagonObject);
		Assert.assertNull(wagonObject.get(MongoConstants.BOX_ID));
	}

	/**
	 * This test checks whether after decoupling a wagon from a box the tag assignment is not
	 * affected by this action.
	 *
	 * @throws IOException
	 */
	@Test
	public void decoupleWagonWithAssignedTagsTest() throws IOException
	{
		getMongoClient();
		new Expectations()
		{
			{
				DashboardUI.getWagonCollection();
				returns(WAGON_COLLECTION);
				DashboardUI.getConfigurationCollection();
				returns(CONFIGURATION_COLLECTION);
				DashboardUI.getMongoCurrentCollection();
				returns(CURRENT_COLLECTION);
			}
		};
		createWagonCollection("/testData/wagon/wagonWithTags.json");

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject find = new BasicDBObject(MongoConstants.ID,
				"5a3e9bde-5bfe-4697-8929-f7dcd76c93ez");
		DBObject wagonObject = wagonCollection.findOne(find);

		Assert.assertNotNull(wagonObject);

		Wagon dbObject2Wagon = Wagon.dbObject2Wagon(wagonObject);

		// Decouple wagon
		presenter.decoupleWagonWithBox(new DecouplingEvent(dbObject2Wagon));

		String wagonId = dbObject2Wagon.getId();
		wagonObject = wagonCollection.findOne(new BasicDBObject(MongoConstants.ID, wagonId));

		Assert.assertNotNull(wagonObject);
		Assert.assertNull(wagonObject.get(MongoConstants.BOX_ID));
		BasicDBList tags = (BasicDBList) wagonObject.get(MongoConstants.WAGON_TAG);
		Assert.assertNotNull(tags);

		tags.forEach(eachTag -> {
			DBObject tagObject = (DBObject) eachTag;
			Assert.assertNotNull(tagObject.get(MongoConstants.ID));
			Assert.assertNotNull(tagObject.get(MongoConstants.TAG_NAME));
			Assert.assertNotNull(tagObject.get(MongoConstants.SORT));
		});
	}

	@Test
	public void decoupleUpdateConfigurationTest() throws IOException
	{
		getMongoClient();
		basicExpectation();
		createWagonCollection("/testData/wagon/wagon2Save.json");
		fillTestDB();

		final Wagon wagonToSave = new Wagon();
		wagonToSave.setId("5a3e9bde-5bfe-4697-8929-f7dcd76c93ez");
		wagonToSave.setAlias("NewWagon");
		wagonToSave.setCreatedTs(new Date());
		wagonToSave.setTenantId(TENANT_ID_E8);
		wagonToSave.setBoxId(777777766666444l);

		WagonType wagonType = createWagonType(WAGON_TYPE_1020, TENANT_ID_E8,
				UUID.randomUUID().toString());
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));
		wagonToSave.setWagonType(wagonType);
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagonToSave, TENANT_ID_E8));

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject find = new BasicDBObject(MongoConstants.ALIAS, "NewWagon");
		DBObject wagonObject = wagonCollection.findOne(find);

		Assert.assertNotNull(wagonObject);

		Wagon dbObject2Wagon = Wagon.dbObject2Wagon(wagonObject);

		// DeCouple wagon
		presenter.decoupleWagonWithBox(new DecouplingEvent(dbObject2Wagon));

		DBCollection configurationCollection = getCollection(
				DashboardUI.getConfigurationCollection());
		String wagonId = dbObject2Wagon.getId();
		DBObject configurationObject = configurationCollection
				.findOne(new BasicDBObject(MongoConstants.WAGON_ID, wagonId));

		Assert.assertNotNull(configurationObject);
		Assert.assertEquals("NewWagon", configurationObject.get(MongoConstants.ALIAS));
		Assert.assertEquals("newwagon", configurationObject.get(MongoConstants.SORT));
		Assert.assertNull(configurationObject.get(MongoConstants.BOX_ID));
	}

	@Test (expected = IllegalArgumentException.class)
	public void decoupleNullWagonTest()
	{
		presenter.decoupleWagonWithBox(new DecouplingEvent(null));
	}

	@Test (expected = IllegalArgumentException.class)
	public void createNullWagonCouplingTest()
	{
		presenter.coupleWagonWithBox(new CouplingEvent(null));
	}

	@Test (expected = IllegalArgumentException.class)
	public void updateNullWagonTest()
	{
		presenter.saveWagon(new UpdateMeansOfTransportEvent(null, null));
	}

	@Test
	public void saveWagonTypeTest() throws UnknownHostException
	{
		getMongoClient();
		new Expectations()
		{
			{

				DashboardUI.getWagonTypeCollection();
				returns(WAGON_TYPE_COLLECITON);
			}
		};

		final WagonType wagonType = new WagonType();
		wagonType.setTypeName("Test");
		wagonType.setTenantId(TENANT_ID_E8);
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));

		DBCollection wagonTypeCollection = getCollection(DashboardUI.getWagonTypeCollection());
		DBObject find = new BasicDBObject(MongoConstants.WAGON_TYPE_NAME, "Test");
		find.put(MongoConstants.TENANT_ID, TENANT_ID_E8);
		DBCursor foundWagonTypes = wagonTypeCollection.find(find);

		Assert.assertNotNull(foundWagonTypes);
		Assert.assertEquals(1, foundWagonTypes.count());

		DBObject foundWagonType = foundWagonTypes.iterator().next();
		Assert.assertEquals("Test", foundWagonType.get(MongoConstants.WAGON_TYPE_NAME));
		Assert.assertEquals(TENANT_ID_E8, foundWagonType.get(MongoConstants.TENANT_ID));
	}

	@Test
	public void wagonTresholdTest() throws UnknownHostException
	{

		Wagon wagon = createWagon("OtherWagon", "cbeaa370-c11d-11e1-8ba8-d4bed92ae489");

		wagon.setHumidityTemperature(20);
		Assert.assertEquals(new Integer(20), wagon.getHumidityTemperature());
		wagon.setHumidityTemperature(-40);
		Assert.assertNull(wagon.getHumidityTemperature());
		wagon.setHumidityTemperature(66);
		Assert.assertNull(wagon.getHumidityTemperature());

		wagon.setHumidity(12);
		Assert.assertEquals(new Integer(12), wagon.getHumidity());
		wagon.setHumidity(1);
		Assert.assertNull(wagon.getHumidity());
		wagon.setHumidity(107);
		Assert.assertNull(wagon.getHumidity());

		wagon.setT1Temperature(17);
		Assert.assertEquals(new Integer(17), wagon.getT1Temperature());
		wagon.setT1Temperature(-41);
		Assert.assertNull(wagon.getT1Temperature());
		wagon.setT1Temperature(101);
		Assert.assertNull(wagon.getT1Temperature());
	}

	@Test
	public void saveAlreadyExistingWagonTypeTest() throws UnknownHostException
	{
		getMongoClient();
		new Expectations()
		{
			{

				DashboardUI.getWagonTypeCollection();
				returns(WAGON_TYPE_COLLECITON);
			}
		};

		final WagonType wagonType = new WagonType();
		wagonType.setTypeName("ExistingWagonType");
		wagonType.setTenantId(TENANT_ID_E8);
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));

		final WagonType wagonType1 = new WagonType();
		wagonType1.setTypeName("ExistingWagonType");
		wagonType1.setTenantId(TENANT_ID_E8);
		presenter.saveWagonType(new WagonTypeEvent(wagonType1, TENANT_ID_E8));

		DBCollection wagonTypeCollection = getCollection(DashboardUI.getWagonTypeCollection());
		int wagonTypeCount = wagonTypeCollection
				.find(new BasicDBObject(MongoConstants.TENANT_ID, TENANT_ID_E8)).count();
		Assert.assertEquals(1, wagonTypeCount);
	}

	@Test (expected = IllegalArgumentException.class)
	public void nullTest()
	{
		presenter.saveWagonType(new WagonTypeEvent(null, null));
	}

	@Test (expected = IllegalArgumentException.class)
	public void nullWagonTypeTest()
	{
		presenter.saveWagonType(new WagonTypeEvent(null, TENANT_ID_E8));
	}

	@Test (expected = IllegalArgumentException.class)
	public void nullTenantTest()
	{
		final WagonType wagonType = new WagonType();
		wagonType.setTypeName("ExistingWagonType");
		wagonType.setTenantId(TENANT_ID_E8);
		presenter.saveWagonType(new WagonTypeEvent(wagonType, null));
	}

	@Test (expected = IllegalArgumentException.class)
	public void emptyTenantTest()
	{
		final WagonType wagonType = new WagonType();
		wagonType.setTypeName("ExistingWagonType");
		wagonType.setTenantId(TENANT_ID_E8);
		presenter.saveWagonType(new WagonTypeEvent(wagonType, ""));
	}

	/**
	 * Creates and updates a wagon (alias and wagon type). Then check if in current collection a new
	 * document is created and updated
	 *
	 * @throws IOException
	 */
	@Test
	public void createAndUpdateAliasAndWagonTypeNameInCurrentTest() throws IOException
	{
		getMongoClient();
		basicExpectation();

		final Wagon wagonToSave = new Wagon();
		wagonToSave.setAlias("NewWagon");
		wagonToSave.setCreatedTs(new Date());
		wagonToSave.setTenantId(TENANT_ID_E8);

		WagonType wagonType = createWagonType(WAGON_TYPE_1020, TENANT_ID_E8,
				UUID.randomUUID().toString());
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));
		wagonToSave.setWagonType(wagonType);
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagonToSave, TENANT_ID_E8));

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject find = new BasicDBObject(MongoConstants.ALIAS, "NewWagon");
		DBObject wagonObject = wagonCollection.findOne(find);

		Assert.assertNotNull(wagonObject);
		String wagonId = (String) wagonObject.get(MongoConstants.ID);

		// Check current collection
		DBCollection currentCollection = getCollection(DashboardUI.getMongoCurrentCollection());

		DBObject match = new BasicDBObject(MongoConstants.ID, wagonId);
		match.put(MongoConstants.TENANT_ID, TENANT_ID_E8);
		DBCursor currentCursor = currentCollection.find(match);
		Assert.assertNotNull(currentCursor);
		Assert.assertEquals(1, currentCursor.count());

		DBObject currentObject = currentCursor.next();
		Assert.assertNotNull(currentObject);
		Assert.assertEquals(TENANT_ID_E8, currentObject.get(MongoConstants.TENANT_ID));
		Assert.assertNull(currentObject.get(MongoConstants.BOX_ID));
		Assert.assertNotNull(currentObject.get(MongoConstants.DATA_ELEMENT));
		Assert.assertEquals("NewWagon", currentObject.get(MongoConstants.ALIAS));
		Assert.assertEquals("newwagon", currentObject.get(MongoConstants.SORT));
		DBObject wagonTypeObject = (DBObject) currentObject.get(MongoConstants.WAGON_TYPE);
		Assert.assertEquals("WAGON_TYPE_1020", wagonTypeObject.get(MongoConstants.WAGON_TYPE_NAME));
		Assert.assertEquals("wagon_type_1020", wagonTypeObject.get(MongoConstants.SORT));
		Assert.assertNotNull(currentObject.get(MongoConstants.ADDRESS));

		// Update the alias
		Wagon dbObject2Wagon = Wagon.dbObject2Wagon(wagonObject);
		dbObject2Wagon.setAlias("OtherWagon");
		presenter.saveWagon(new UpdateMeansOfTransportEvent(dbObject2Wagon, TENANT_ID_E8));

		match = new BasicDBObject(MongoConstants.ID, wagonId);
		match.put(MongoConstants.TENANT_ID, TENANT_ID_E8);
		currentObject = currentCollection.findOne(match);

		Assert.assertNotNull(currentObject);
		Assert.assertEquals("OtherWagon", currentObject.get(MongoConstants.ALIAS));
		Assert.assertEquals("otherwagon", currentObject.get(MongoConstants.SORT));

		// Update wagon type name
		dbObject2Wagon = Wagon.dbObject2Wagon(wagonObject);
		dbObject2Wagon.getWagonType().setTypeName("OtherType");
		presenter.saveWagon(new UpdateMeansOfTransportEvent(dbObject2Wagon, TENANT_ID_E8));

		match = new BasicDBObject(MongoConstants.ID, wagonId);
		match.put(MongoConstants.TENANT_ID, TENANT_ID_E8);
		currentObject = currentCollection.findOne(match);

		Assert.assertNotNull(currentObject);
		wagonTypeObject = (DBObject) currentObject.get(MongoConstants.WAGON_TYPE);
		Assert.assertEquals("OtherType", wagonTypeObject.get(MongoConstants.WAGON_TYPE_NAME));
		Assert.assertEquals("othertype", wagonTypeObject.get(MongoConstants.SORT));
	}

	/**
	 * For this test we have to fill in a telematic document and update the wagon id of the document
	 * because we don't know the wagon id at the beginning of the test. After updating the wagon id
	 * the presenter is able to update the telematic document according to the new alias and wagon
	 * type name
	 *
	 * @throws IOException
	 */
	@Test
	public void createAndUpdateAliasAndWagonTypeNameInTelematicTest() throws IOException
	{
		getMongoClient();
		basicExpectation();

		final Wagon wagonToSave = new Wagon();
		wagonToSave.setAlias("NewWagon");
		wagonToSave.setCreatedTs(new Date());
		wagonToSave.setTenantId(TENANT_ID_E8);

		WagonType wagonType = createWagonType(WAGON_TYPE_1020, TENANT_ID_E8,
				UUID.randomUUID().toString());
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));
		wagonToSave.setWagonType(wagonType);
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagonToSave, TENANT_ID_E8));

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject find = new BasicDBObject(MongoConstants.ALIAS, "NewWagon");
		DBObject wagonObject = wagonCollection.findOne(find);

		Assert.assertNotNull(wagonObject);
		String wagonId = (String) wagonObject.get(MongoConstants.ID);

		fillTelematic();
		DBCollection telematicCollection = getCollection(DashboardUI.getEventCollection());
		telematicCollection.update(new BasicDBObject(MongoConstants.ALIAS, "NewWagon"),
				new BasicDBObject("$set", new BasicDBObject(MongoConstants.WAGON_ID, wagonId)));

		// Update the alias
		Wagon dbObject2Wagon = Wagon.dbObject2Wagon(wagonObject);
		dbObject2Wagon.setAlias("OtherWagon");
		presenter.saveWagon(new UpdateMeansOfTransportEvent(dbObject2Wagon, TENANT_ID_E8));

		DBObject match = new BasicDBObject(MongoConstants.WAGON_ID, wagonId);
		match.put(MongoConstants.TENANT_ID, TENANT_ID_E8);
		DBObject telematicObject = telematicCollection.findOne(match);

		Assert.assertNotNull(telematicObject);
		Assert.assertEquals("OtherWagon", telematicObject.get(MongoConstants.ALIAS));
		Assert.assertEquals("otherwagon", telematicObject.get(MongoConstants.SORT));

		// Update wagon type name
		dbObject2Wagon = Wagon.dbObject2Wagon(wagonObject);
		dbObject2Wagon.getWagonType().setTypeName("OtherType");
		presenter.saveWagon(new UpdateMeansOfTransportEvent(dbObject2Wagon, TENANT_ID_E8));

		match = new BasicDBObject(MongoConstants.WAGON_ID, wagonId);
		match.put(MongoConstants.TENANT_ID, TENANT_ID_E8);
		telematicObject = telematicCollection.findOne(match);

		Assert.assertNotNull(telematicObject);
		DBObject wagonTypeObject = (DBObject) telematicObject.get(MongoConstants.WAGON_TYPE);
		Assert.assertEquals("OtherType", wagonTypeObject.get(MongoConstants.WAGON_TYPE_NAME));
		Assert.assertEquals("othertype", wagonTypeObject.get(MongoConstants.SORT));
	}

	/**
	 * A wagon with alias Wagon1 is created and also six entries for mileage with this alias are
	 * created.
	 * After updating the alias from Wagon1 to NewWagon there must not be an entry in the mileage
	 * and wagon collection with an alias Wagon1.
	 * The six entries from the mileage collection must have NewWagon as alias
	 *
	 * @throws IOException
	 */
	@Test
	public void createAndUpdateAliasInMileageTest() throws IOException
	{
		getMongoClient();
		new Expectations()
		{
			{
				DashboardUI.getWagonCollection();
				returns(WAGON_COLLECTION);
				DashboardUI.getConfigurationCollection();
				returns(CONFIGURATION_COLLECTION);
				DashboardUI.getMongoCurrentCollection();
				returns(CURRENT_COLLECTION);
				DashboardUI.getEventCollection();
				returns(EVENT_COLLECTION);
				DashboardUI.getMongoMileageCollection();
				returns(MILEAGE_COLLECTION);
				DashboardUI.getMongoCollection();
				returns(MONGO_COLLECTION);
				DashboardUI.getMongoRoutingCollection();
				returns(ROUTING_COLLECTION);
			}
		};

		fillTestDB();
		fillMileage();
		fillWagon();

		final Wagon wagonToSave = new Wagon();
		wagonToSave.setId("5a3e9bde-5bfe-4697-8929-f7dcd76c93ec");
		wagonToSave.setAlias("NewWagon");
		wagonToSave.setCreatedTs(new Date());
		wagonToSave.setBoxId(777777777777777l);
		wagonToSave.setTenantId("cbeaa370-c11d-11e1-8ba8-d4bed92ae488");
		WagonType wagonType = createWagonType("Test", "cbeaa370-c11d-11e1-8ba8-d4bed92ae488",
				"dc8cdf67-818a-4641-b0fc-da6b533787ee");
		wagonToSave.setWagonType(wagonType);
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagonToSave,
				"cbeaa370-c11d-11e1-8ba8-d4bed92ae488"));

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject find = new BasicDBObject(MongoConstants.ALIAS, "NewWagon");
		Assert.assertEquals(1, wagonCollection.count(find));

		find = new BasicDBObject(MongoConstants.ALIAS, "Wagon1");
		Assert.assertEquals(0, wagonCollection.count(find));

		DBCollection mileageCollection = getCollection(DashboardUI.getMongoMileageCollection());
		find = new BasicDBObject(MongoConstants.ALIAS, "NewWagon");
		Assert.assertEquals(6, mileageCollection.count(find));

		mileageCollection = getCollection(DashboardUI.getMongoMileageCollection());
		find = new BasicDBObject(MongoConstants.ALIAS, "Wagon1");
		Assert.assertEquals(0, mileageCollection.count(find));
	}

	/**
	 * Creates a new wagon -> a new current document is created
	 * Couples the wagon -> BoxId is updated in current
	 * Decouples the wagon -> BoxId is unset in current
	 *
	 * @throws UnknownHostException
	 */
	@Test
	public void coupleAndDecoupleWagonUpdateBoxIdInCurrentTest() throws UnknownHostException
	{
		getMongoClient();
		basicExpectation();

		Wagon wagon = createWagon("CoupleWagon", TENANT_ID_E8);
		WagonType wagonType = createWagonType(WAGON_TYPE_1020, TENANT_ID_E8,
				UUID.randomUUID().toString());
		wagon.setWagonType(wagonType);
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagon, TENANT_ID_E8));

		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBObject find = new BasicDBObject(MongoConstants.ALIAS, "CoupleWagon");
		find.put(MongoConstants.TENANT_ID, TENANT_ID_E8);
		DBObject foundWagonWithoutBoxId = wagonCollection.findOne(find);

		Assert.assertNotNull(foundWagonWithoutBoxId);
		String wagonId = (String) foundWagonWithoutBoxId.get(MongoConstants.ID);

		DBCollection currentCollection = getCollection(DashboardUI.getMongoCurrentCollection());
		find = new BasicDBObject(MongoConstants.ID, wagonId);
		DBObject currentObject = currentCollection.findOne(find);
		Assert.assertNotNull(currentObject);
		Assert.assertNull(currentObject.get(MongoConstants.BOX_ID));

		Wagon dbObject2Wagon = Wagon.dbObject2Wagon(foundWagonWithoutBoxId);
		dbObject2Wagon.setBoxId(123456789012345L);
		presenter.coupleWagonWithBox(new CouplingEvent(dbObject2Wagon));

		currentObject = currentCollection.findOne(find);
		Assert.assertNotNull(currentObject);
		Assert.assertEquals(new Long(123456789012345L), currentObject.get(MongoConstants.BOX_ID));

		dbObject2Wagon = Wagon.dbObject2Wagon(foundWagonWithoutBoxId);

		presenter.decoupleWagonWithBox(new DecouplingEvent(dbObject2Wagon));

		currentObject = currentCollection.findOne(find);
		Assert.assertNotNull(currentObject);
		Assert.assertNull(currentObject.get(MongoConstants.BOX_ID));
	}

	/**
	 * Tries to delete wagon type not used by any wagon.
	 * The wagon type has specific tenant.
	 *
	 * Result: Removal successful.
	 *
	 * @throws UnknownHostException
	 */
	@Test
	public void deleteNotUsedWagonType() throws UnknownHostException
	{
		getMongoClient();
		basicExpectation();

		// preparation with creation the wagon type to be removed later
		WagonType wagonType1 = createWagonType(WAGON_TYPE_1020, TENANT_ID_E8,
				UUID.randomUUID().toString());
		presenter.saveWagonType(new WagonTypeEvent(wagonType1, TENANT_ID_E8));

		// preparation with creation an other wagon type with different tenant
		WagonType wagonType2 = createWagonType(WAGON_TYPE_1020, TENANT_ID_E9,
				UUID.randomUUID().toString());
		presenter.saveWagonType(new WagonTypeEvent(wagonType2, TENANT_ID_E9));

		// preparation with creation the wagon that uses wagon type2
		wagonToSave.setWagonType(wagonType2);
		wagonToSave.setTenantId(TENANT_ID_E9);
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagonToSave, TENANT_ID_E9));

		DBCollection wagonTypeCollection = getCollection(DashboardUI.getWagonTypeCollection());
		DBObject find = new BasicDBObject(MongoConstants.WAGON_TYPE_NAME, WAGON_TYPE_1020);
		find.put(MongoConstants.TENANT_ID, TENANT_ID_E8);
		DBCursor foundWagons = wagonTypeCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertEquals(1, foundWagons.count());

		// actual test with the removal
		presenter.deleteWagonType(new WagonTypeDeleteEvent(wagonType1, TENANT_ID_E8));

		wagonTypeCollection = getCollection(DashboardUI.getWagonTypeCollection());
		foundWagons = wagonTypeCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertEquals(0, foundWagons.count());
	}

	/**
	 * Tries to delete wagon type used by a wagon.
	 * The wagon type has specific tenant.
	 *
	 * Result: Removal is not successful as the wagon type is used.
	 *
	 * @throws UnknownHostException
	 */
	@Test
	public void deleteUsedWagonType() throws UnknownHostException
	{
		getMongoClient();
		basicExpectation();

		// preparation with creation the wagon type
		WagonType wagonType = createWagonType(WAGON_TYPE_1020, TENANT_ID_E8,
				UUID.randomUUID().toString());
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));

		// preparation with creation the wagon that uses the wagon type
		wagonToSave.setWagonType(wagonType);
		wagonToSave.setTenantId(TENANT_ID_E8);
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagonToSave, TENANT_ID_E8));

		DBCollection wagonTypeCollection = getCollection(DashboardUI.getWagonTypeCollection());
		DBObject find = new BasicDBObject(MongoConstants.WAGON_TYPE_NAME, WAGON_TYPE_1020);
		find.put(MongoConstants.TENANT_ID, TENANT_ID_E8);
		DBCursor foundWagons = wagonTypeCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertEquals(1, foundWagons.count());

		// actual test with the removal
		presenter.deleteWagonType(new WagonTypeDeleteEvent(wagonType, TENANT_ID_E8));
		wagonTypeCollection = getCollection(DashboardUI.getWagonTypeCollection());
		foundWagons = wagonTypeCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertEquals(1, foundWagons.count());
	}

	@Test
	public void checkNotificationRuleAliveStatus() throws IOException
	{
		getMongoClient();
		new Expectations()
		{
			{
				DashboardUI.getWagonCollection();
				returns(WAGON_COLLECTION);
				DashboardUI.getConfigurationCollection();
				returns(CONFIGURATION_COLLECTION);
				DashboardUI.getMongoCurrentCollection();
				returns(CURRENT_COLLECTION);
				DashboardUI.getEventCollection();
				returns(EVENT_COLLECTION);
				DashboardUI.getWagonTypeCollection();
				returns(WAGON_TYPE_COLLECITON);
				DashboardUI.getMongoMileageCollection();
				returns(MILEAGE_COLLECTION);
				DashboardUI.getMongoRoutingCollection();
				returns(ROUTING_COLLECTION);
				DashboardUI.getMongoCollection();
				returns(MONGO_COLLECTION);
				DashboardUI.getNotificationCollection();
				minTimes = 1;
				returns(NOTIFICATION_COLLECTION);
			}
		};
		fillNotificationCollection();
		wagonToSave.setId(WAGON_ID);
		wagonToSave.setTenantId(TENANT_ID_E8);
		WagonType wagonType = createWagonType(WAGON_TYPE_1020, TENANT_ID_E8,
				UUID.randomUUID().toString());
		presenter.saveWagonType(new WagonTypeEvent(wagonType, TENANT_ID_E8));
		// preparation with creation the wagon that uses the wagon type
		wagonToSave.setWagonType(wagonType);
		wagonToSave.setOldMileageOffset(null);
		wagonToSave.setMileageOffset(20);
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagonToSave, TENANT_ID_E8));
		checkNotificationCollection();
		DBCollection notificationCollection = getCollection(
				DashboardUI.getNotificationCollection());
		notificationCollection.remove(new BasicDBObject());
		fillNotificationCollection();
		wagonToSave.setOldMileageOffset(50);
		wagonToSave.setMileageOffset(70);
		presenter.saveWagon(new UpdateMeansOfTransportEvent(wagonToSave, TENANT_ID_E8));
		checkNotificationCollection();

	}

	private MongoClient getMongoClient() throws UnknownHostException
	{
		new Expectations()
		{
			{
				DashboardUI.getMongoUsername();
				returns(MONGO_USERNAME);
				DashboardUI.getMongoPassword();
				returns(MONGO_PASSWORD);
				DashboardUI.getMongoDatabase();
				returns(MONGO_DATABASE);
				DashboardUI.getMongoHost();
				returns(MONGO_HOST);
				DashboardUI.getMongoPort();
				returns(MONGO_PORT);
			}
		};
		DataProviderInitializer.createMongoClient();
		return DataProviderInitializer.getMongoClient();
	}

	private Wagon createWagon(String alias, String tenantId)
	{
		final Wagon wagon = new Wagon();
		wagon.setAlias(alias);
		wagon.setCreatedTs(new Date());
		wagon.setTenantId(tenantId);
		return wagon;
	}

	private void assingnDisponents(Wagon wagon) throws UnknownHostException
	{
		BasicDBList disponents2Assign = new BasicDBList();
		DBObject value = new BasicDBObject(MongoConstants.ID,
				"956f2c40-6e44-11e4-8035-0050569350e8");
		value.put(MongoConstants.ALIAS, "sample disponent one");
		disponents2Assign.add(value);
		value = new BasicDBObject(MongoConstants.ID, "956f2c40-6e44-11e4-8035-0050569350e9");
		value.put(MongoConstants.ALIAS, "sample disponent two");
		disponents2Assign.add(value);
		DBObject update = new BasicDBObject(MongoConstants.DISPONENTS, disponents2Assign);

		DBObject set = new BasicDBObject("$set", update);

		DBObject match = new BasicDBObject(MongoConstants.ALIAS, wagon.getAlias());
		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		wagonCollection.update(match, set, false, false);

	}

	private WagonType createWagonType(String typeName, String tenantId, String uuid)
	{
		final WagonType wagonType = new WagonType();
		wagonType.setId(uuid);
		wagonType.setTypeName(typeName);
		wagonType.setTenantId(tenantId);
		return wagonType;
	}

	private void fillTestDB() throws IOException
	{
		// Fill current collection
		DBCollection collection = getCollection(DashboardUI.getMongoCurrentCollection());
		InputStream testMessage = AdministrationPresenterTest.class
				.getResourceAsStream("/testData/current/updateAliasInCurrent.json");

		String message = IOUtils.toString(testMessage, "UTF-8");
		Object parse = JSON.parse(message);
		DBObject objectToSave = (DBObject) parse;
		collection.save(objectToSave);

		// Fill telematic collection
		collection = getCollection(DashboardUI.getEventCollection());
		testMessage = AdministrationPresenterTest.class
				.getResourceAsStream("/testData/telematic/updateAliasInTelematic.json");

		message = IOUtils.toString(testMessage, "UTF-8");
		parse = JSON.parse(message);
		objectToSave = (DBObject) parse;
		collection.save(objectToSave);

		// Fill configurations collection
		collection = getCollection(DashboardUI.getConfigurationCollection());
		testMessage = AdministrationPresenterTest.class
				.getResourceAsStream("/testData/configurations/updateAliasInConfiguration.json");

		message = IOUtils.toString(testMessage, "UTF-8");
		parse = JSON.parse(message);
		objectToSave = (DBObject) parse;
		collection.save(objectToSave);

		collection = getCollection(DashboardUI.getConfigurationCollection());
		testMessage = AdministrationPresenterTest.class.getResourceAsStream(
				"/testData/configurations/updateAliasWithBoxIdInConfiguration.json");

		message = IOUtils.toString(testMessage, "UTF-8");
		parse = JSON.parse(message);
		objectToSave = (DBObject) parse;
		collection.save(objectToSave);
	}

	private void fillMileage() throws IOException
	{
		// Fill mileage collection
		DBCollection collection = getCollection(DashboardUI.getMongoMileageCollection());
		InputStream testMessage = AdministrationPresenterTest.class
				.getResourceAsStream("/testData/mileage/updateAliasInMileage.json");

		String message = IOUtils.toString(testMessage, "UTF-8");
		Object parse = JSON.parse(message);
		List<DBObject> listToSave = (List<DBObject>) parse;
		collection.insert(listToSave);
	}

	private void createWagonCollection(String testDataFileName) throws IOException
	{
		DBCollection collection = getCollection(DashboardUI.getWagonCollection());
		InputStream testMessage = AdministrationPresenterTest.class
				.getResourceAsStream(testDataFileName);

		String message = IOUtils.toString(testMessage, "UTF-8");
		Object parse = JSON.parse(message);
		DBObject objectToSave = (DBObject) parse;
		collection.save(objectToSave);
	}

	private void fillTelematic() throws IOException
	{

		DBCollection collection = getCollection(DashboardUI.getEventCollection());
		InputStream testMessage = AdministrationPresenterTest.class
				.getResourceAsStream("/testData/telematic/updateAliasInTelematic.json");

		String message = IOUtils.toString(testMessage, "UTF-8");
		Object parse = JSON.parse(message);
		DBObject objectToSave = (DBObject) parse;
		collection.save(objectToSave);
	}

	private void fillWagon() throws IOException
	{
		DBCollection collection = getCollection(DashboardUI.getWagonCollection());
		InputStream testMessage = AdministrationPresenterTest.class
				.getResourceAsStream("/testData/wagon/wagonUpdate.json");

		String message = IOUtils.toString(testMessage, "UTF-8");
		Object parse = JSON.parse(message);
		DBObject objectToSave = (DBObject) parse;
		collection.save(objectToSave);
	}

	private void fillRouting() throws IOException
	{

		DBCollection collection = getCollection(DashboardUI.getMongoRoutingCollection());
		InputStream testMessage = this.getClass()
				.getResourceAsStream("/testData/routing/routing.json");
		String routing = IOUtils.toString(testMessage, "UTF-8");

		Object parse = JSON.parse(routing);
		List<DBObject> objectListToSave = (List<DBObject>) parse;
		collection.insert(objectListToSave);

	}

	private void fillCorrelated() throws IOException
	{

		DBCollection collection = getCollection(DashboardUI.getMongoCollection());
		InputStream testMessage = this.getClass()
				.getResourceAsStream("/testData/correlated/correlated.json");
		String correlated = IOUtils.toString(testMessage, "UTF-8");

		Object parse = JSON.parse(correlated);
		List<DBObject> objectListToSave = (List<DBObject>) parse;
		collection.insert(objectListToSave);

	}

	private void fillNotificationCollection() throws IOException
	{

		DBCollection collection = getCollection(DashboardUI.getNotificationCollection());
		InputStream testMessage = this.getClass()
				.getResourceAsStream("/testData/notification/notificationsForOffset.json");
		String notification = IOUtils.toString(testMessage, "UTF-8");

		Object parse = JSON.parse(notification);
		List<DBObject> objectListToSave = (List<DBObject>) parse;
		collection.insert(objectListToSave);

	}

	private void checkNotificationCollection() throws UnknownHostException
	{
		DBCollection notificationCollection = getCollection(
				DashboardUI.getNotificationCollection());
		DBObject find = new BasicDBObject(MongoConstants.WAGON_ID, WAGON_ID);
		find.put(MongoConstants.TENANT_ID, TENANT_ID_E8);
		DBCursor foundWagons = notificationCollection.find(find);
		Assert.assertNotNull(foundWagons);
		Assert.assertEquals(2, foundWagons.count());
		for (DBObject dbObject : foundWagons)
		{

			Boolean AliveStatus = (Boolean) ((DBObject) dbObject.get(MongoConstants.RULE))
					.get(MongoConstants.ALARM_ALIVE);
			Assert.assertEquals(AliveStatus, false);
		}
	}

	private DBCollection getCollection(String collectionName) throws UnknownHostException
	{
		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		return db.getCollection(collectionName);
	}

}
