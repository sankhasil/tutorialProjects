
package com.bosch.si.amra.component;

import java.util.Date;
import java.util.Locale;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.component.converter.TimestampConverter;

import mockit.Expectations;
import mockit.Mocked;

public class TimestampConverterTest
{
	private TimestampConverter timestampConverter;

	@Before
	public void setup()
	{
		timestampConverter = new TimestampConverter();
	}

	@Test
	public void convertGermanTimestampTest(@Mocked DashboardUI dashboardUI)
	{
		new Expectations()
		{
			{
				DashboardUI.getMessageSource().getMessage("date.format");
				returns("dd.MM.yyyy HH:mm:ss");
			}
		};
		// 2016/03/03 12:00:00 UTC
		Date date = new Date(1457006400000L);
		String convertedDateToPresentation = timestampConverter.convertToPresentation(date,
				String.class, Locale.GERMAN);
		Assert.assertNotNull(convertedDateToPresentation);
		Assert.assertEquals("03.03.2016 12:00:00", convertedDateToPresentation);
	}

	@Test
	public void convertEnglishTimestampTest(@Mocked DashboardUI dashboardUI)
	{
		new Expectations()
		{
			{
				DashboardUI.getMessageSource().getMessage("date.format");
				returns("yyyy/MM/dd HH:mm:ss");
			}
		};
		// 2016/03/03 12:00:00 UTC
		Date date = new Date(1457006400000L);
		String convertedDateToPresentation = timestampConverter.convertToPresentation(date,
				String.class, Locale.ENGLISH);
		Assert.assertNotNull(convertedDateToPresentation);
		Assert.assertEquals("2016/03/03 12:00:00", convertedDateToPresentation);
	}

	@Test
	public void convertGermanTimestampToModel(@Mocked DashboardUI dashboardUI)
	{
		new Expectations()
		{
			{
				DashboardUI.getMessageSource().getMessage("date.format");
				returns("dd.MM.yyyy HH:mm:ss");
			}
		};
		// 2016/03/03 12:00:00 UTC == 2016/03/03 13:00:00 GMT
		String formattedDate = "03.03.2016 13:00:00";
		Date convertedDateToModel = timestampConverter.convertToModel(formattedDate, Date.class,
				Locale.GERMAN);
		Assert.assertNotNull(convertedDateToModel);
		Assert.assertEquals(new Date(1457006400000L), convertedDateToModel);
	}

	@Test
	public void convertEnglishTimestampToModel(@Mocked DashboardUI dashboardUI)
	{
		new Expectations()
		{
			{
				DashboardUI.getMessageSource().getMessage("date.format");
				returns("yyyy/MM/dd HH:mm:ss");
			}
		};
		// 2016/03/03 12:00:00 UTC == 2016/03/03 13:00:00 GMT
		String formattedDate = "2016/03/03 13:00:00";
		Date convertedDateToModel = timestampConverter.convertToModel(formattedDate, Date.class,
				Locale.ENGLISH);
		Assert.assertNotNull(convertedDateToModel);
		Assert.assertEquals(new Date(1457006400000L), convertedDateToModel);
	}
}
