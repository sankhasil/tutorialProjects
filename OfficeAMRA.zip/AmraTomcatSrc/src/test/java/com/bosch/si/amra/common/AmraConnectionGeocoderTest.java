
package com.bosch.si.amra.common;

import java.util.Collection;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestClientException;
import org.vaadin.addons.locationtextfield.GeocodedLocation;
import org.vaadin.addons.locationtextfield.GeocodingException;
import org.vaadin.addons.locationtextfield.LocationType;

import com.bosch.si.amra.DashboardUI;

import mockit.Expectations;
import mockit.Mocked;

@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (locations = "file:src/test/resources/spring-servlet.xml")
public class AmraConnectionGeocoderTest
{

	@Value ("${USE_PROXY}")
	public String								USE_PROXY;

	@Value ("${HOST}")
	public String								HOST;

	@Value ("${PORT}")
	public Integer								PORT;

	@Mocked
	DashboardUI									dashboardUi;

	AmraConnectionGeocoder<GeocodedLocation>	testable;

	@Test
	public void testGeocodeForward() throws GeocodingException
	{
		new Expectations()
		{
			{
				DashboardUI.isProxyUsed();
				returns(USE_PROXY);
				DashboardUI.getHost();
				returns(HOST);
				DashboardUI.getPort();
				returns(PORT);
			}
		};
		testable = new AmraConnectionGeocoder<>()
				.setUseProxy(Boolean.valueOf(DashboardUI.isProxyUsed()))
				.setHost(DashboardUI.getHost()).setPort(DashboardUI.getPort())
				.setUrl("https://api.opencagedata.com/geocode/v1/json")
				.setApiKey("00a7e862dcf18039aa26f219b573f796");
		testable.setLimit(15);

		Collection<GeocodedLocation> geocodes = testable
				.geocode("Stuttgarter Straße 130, Waiblingen");
		Assert.assertNotNull(geocodes);
		Assert.assertEquals(2, geocodes.size());
		geocodes.forEach(geocode -> {
			Assert.assertNotNull(geocode);
			if (geocode.getType() != null && geocode.getType().equals(LocationType.ROUTE))
			{
				Assert.assertEquals(
						"Bosch Software Innovations GmbH, Stuttgarter Straße 130, 71332 Waiblingen, Germany",
						geocode.getGeocodedAddress());
				Assert.assertEquals("Baden-Württemberg", geocode.getAdministrativeAreaLevel1());
				Assert.assertEquals("Rems-Murr-Kreis", geocode.getAdministrativeAreaLevel2());
				Assert.assertEquals("Germany", geocode.getCountry());
				Assert.assertEquals("Waiblingen", geocode.getLocality());
				Assert.assertEquals(48.82304000854492, geocode.getLat(), 0);
				Assert.assertEquals(9.295439720153809, geocode.getLon(), 0);
				Assert.assertEquals("Stuttgarter Straße 130, Waiblingen",
						geocode.getOriginalAddress());
				Assert.assertEquals("71332", geocode.getPostalCode());
				Assert.assertEquals("Stuttgarter Straße", geocode.getRoute());
				Assert.assertEquals("130", geocode.getStreetNumber());
			}
		});
	}

	@Test (expected = RestClientException.class)
	public void testWithWrongProxySettings() throws GeocodingException
	{
		testable = new AmraConnectionGeocoder<>().setUseProxy(true).setHost("wrong.proxy.de")
				.setPort(1234).setUrl("https://api.opencagedata.com/geocode/v1/json")
				.setApiKey("00a7e862dcf18039aa26f219b573f796");
		testable.setLimit(15);

		testable.geocode("Stuttgarter Straße 130, Waiblingen");
	}
}
