
package com.bosch.si.amra.provider;

import java.io.IOException;
import java.io.InputStream;
import java.net.UnknownHostException;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.geofence.Geofence;
import com.bosch.si.amra.provider.geofence.GeofenceDataProvider;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.util.JSON;

import mockit.Expectations;
import mockit.Mocked;

@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (locations = "file:src/test/resources/spring-servlet.xml")
public class GeofenecDataProviderTest
{
	@Autowired
	private GeofenceDataProvider	geofenceDataProvider;

	@Value ("${MONGO_HOST}")
	public String					MONGO_HOST;

	@Value ("${MONGO_PORT}")
	public Integer					MONGO_PORT;

	@Value ("${MONGO_DATABASE}")
	public String					MONGO_DATABASE;

	@Value ("${MONGO_USERNAME}")
	public String					MONGO_USERNAME;

	@Value ("${MONGO_PASSWORD}")
	public String					MONGO_PASSWORD;

	@Value ("${GEOFENCE_COLLECTION}")
	public String					GEOFENCE_COLLECTION;

	@Value ("${USE_PROXY}")
	public String					PROXY;

	@Mocked
	DashboardUI						dashboardUi;

	@Before
	public void setup() throws IOException
	{
		fillTestDB();
	}

	@After
	public void tearDown() throws IOException
	{
		deleteTestDB();
	}

	@Test
	public void getGeofenceTest()
	{
		initMongoDB();
		List<Geofence> geofences = geofenceDataProvider
				.getGeofencesForDisplaying("1798c300-c27f-11e4-81a3-0050569350e8");
		Assert.assertNotNull(geofences);
		Assert.assertEquals(8, geofences.size());
		for (Geofence geofence : geofences)
		{
			Assert.assertNotNull("Geofence must not be null", geofence);
			Assert.assertNotNull("Geofence name must not be null", geofence.getName());
			Assert.assertNotNull("Geofence id must not be null", geofence.getId());
		}
	}

	@Test (expected = IllegalArgumentException.class)
	public void getGeofenecsNullTenantTest()
	{
		geofenceDataProvider.getGeofencesForDisplaying(null);
	}

	@Test (expected = IllegalArgumentException.class)
	public void getGeofenecsEmptyTenantTest()
	{
		geofenceDataProvider.getGeofencesForDisplaying("");
	}

	@Test
	public void getGeofencesNotExistingTenantTest()
	{
		initMongoDB();
		List<Geofence> geofences = geofenceDataProvider
				.getGeofencesForDisplaying("notExistingTenant");
		Assert.assertNotNull(geofences);
		Assert.assertEquals(0, geofences.size());
	}

	private void initMongoDB()
	{
		new Expectations()
		{
			{
				DashboardUI.getMongoUsername();
				returns(MONGO_USERNAME);
				DashboardUI.getMongoPassword();
				returns(MONGO_PASSWORD);
				DashboardUI.getMongoDatabase();
				returns(MONGO_DATABASE);
				DashboardUI.getMongoHost();
				returns(MONGO_HOST);
				DashboardUI.getMongoPort();
				returns(MONGO_PORT);
				DashboardUI.getGeofenceCollection();
				returns(GEOFENCE_COLLECTION);
			}
		};
		try
		{
			DataProviderInitializer.createMongoClient();
		}
		catch (UnknownHostException e)
		{
			e.printStackTrace();
		}
	}

	@SuppressWarnings ("unchecked")
	private void fillTestDB() throws IOException
	{
		new Expectations()
		{
			{
				DashboardUI.getGeofenceCollection();
				returns(GEOFENCE_COLLECTION);
			}
		};

		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection collection = db.getCollection(DashboardUI.getGeofenceCollection());
		InputStream testMessage = GeofenecDataProviderTest.class
				.getResourceAsStream("/testData/geofence/geofenceData.json");
		String message = IOUtils.toString(testMessage, "UTF-8");

		Object parse = JSON.parse(message);
		List<DBObject> objectToSave = (List<DBObject>) parse;
		collection.insert(objectToSave);
	}

	private void deleteTestDB() throws IOException
	{
		new Expectations()
		{
			{
				DashboardUI.getGeofenceCollection();
				returns(GEOFENCE_COLLECTION);
			}
		};

		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection collection = db.getCollection(DashboardUI.getGeofenceCollection());
		collection.remove(new BasicDBObject());

	}

	private MongoClient getMongoClient() throws UnknownHostException
	{
		new Expectations()
		{
			{
				DashboardUI.getMongoUsername();
				returns(MONGO_USERNAME);
				DashboardUI.getMongoPassword();
				returns(MONGO_PASSWORD);
				DashboardUI.getMongoDatabase();
				returns(MONGO_DATABASE);
				DashboardUI.getMongoHost();
				returns(MONGO_HOST);
				DashboardUI.getMongoPort();
				returns(MONGO_PORT);
			}
		};
		DataProviderInitializer.createMongoClient();
		return DataProviderInitializer.getMongoClient();
	}
}
