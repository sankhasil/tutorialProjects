
package com.bosch.si.amra.view.notification;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.notification.Address;
import com.bosch.si.amra.entity.notification.Notification;
import com.bosch.si.amra.entity.notification.Notification.Priority;
import com.bosch.si.amra.entity.rule.Rule;
import com.vaadin.tapio.googlemaps.client.LatLon;
import com.vaadin.tapio.googlemaps.client.overlays.GoogleMapInfoWindow;
import com.vaadin.tapio.googlemaps.client.overlays.GoogleMapMarker;
import com.vaadin.ui.Label;
import com.vaadin.ui.MenuBar;
import com.vaadin.ui.MenuBar.MenuItem;

import mockit.Expectations;
import mockit.Mocked;

public class NotificationViewMapTest
{
	private NotificationViewMap viewMap;

	@Before
	public void setup()
	{
		viewMap = new NotificationViewMap();
	}

	@Test
	public void buildToolbar(@Mocked MenuBar menuBar)
	{
		Map<MenuItem, String> buildToolbar = viewMap.buildToolbar(menuBar);
		Assert.assertEquals(10, buildToolbar.keySet().size());
	}

	@Test
	public void buildCaption(@Mocked DashboardUI ui)
	{
		new Expectations()
		{
			{
				DashboardUI.getMessageSource().getMessage("view.notification.map");
				returns("Karte");
			}
		};
		Label buildCaptionLabel = viewMap.buildCaptionLabel();
		Assert.assertEquals("Karte", buildCaptionLabel.getValue());
	}

	@Test
	public void buildGoogleMapMarker()
	{
		Notification notification = new Notification();
		notification.setAlias("TestMarker");
		notification.setLatitude(48.8231635);
		notification.setLongitude(9.2936913);
		notification.setGpsFixed(true);
		Rule rule = new Rule();
		rule.setRuleType("HM");
		notification.setRule(rule);
		GoogleMapMarker notificationMarker = viewMap.buildNotificationMarker(notification);
		Assert.assertNotNull(notificationMarker);
		Assert.assertEquals("VAADIN/themes/dashboard/img/notification/hm.png",
				notificationMarker.getIconUrl());
		Assert.assertEquals("TestMarker", notificationMarker.getCaption());
		Assert.assertEquals(0, notificationMarker.getzIndex());
		Assert.assertNotNull(notificationMarker.getPosition());
		LatLon position = notificationMarker.getPosition();
		Assert.assertEquals(48.8231635, position.getLat(), 0);
		Assert.assertEquals(9.2936913, position.getLon(), 0);
	}

	@Test
	public void buildGoogleMapMarkerInfoWindow(@Mocked DashboardUI ui,
			final @Mocked SimpleDateFormat format)
	{
		final Calendar calendar = Calendar.getInstance();
		calendar.set(2015, 04, 10, 13, 25, 14);
		new Expectations()
		{
			{
				DashboardUI.getMessageSource().getMessage("view.notification.reason.hm");
				returns("Relative Luftfeuchtigkeit");
				DashboardUI.getMessageSource().getMessage("view.notification.priority.yellow");
				returns("Mittel");
				DashboardUI.getMessageSource().getMessage("date.format");
				returns("dd.MM.yyyy HH:mm:ss");
				format.format(calendar.getTime());
				returns("10.05.2015 13:25:14");
			}
		};
		Notification notification = new Notification();
		notification.setAlias("TestMarker");
		notification.setLatitude(48.8231635);
		notification.setLongitude(9.2936913);
		notification.setTimestamp(calendar.getTime());
		Address address = new Address();
		address.setFormattedAddress("Stuttgarter Straße 130, Waiblingen");
		notification.setAddress(address);
		Rule rule = new Rule();
		rule.setRuleType("HM");
		notification.setRule(rule);
		notification.setPriority(Priority.YELLOW);
		GoogleMapMarker notificationMarker = viewMap.buildNotificationMarker(notification);
		GoogleMapInfoWindow notificationWindow = viewMap
				.buildNotificationMarkerWindow(notificationMarker, notification);
		Assert.assertNotNull(notificationWindow);
		Assert.assertEquals(notificationMarker, notificationWindow.getAnchorMarker());
		Assert.assertEquals("100%", notificationWindow.getHeight());
		Assert.assertEquals("100%", notificationWindow.getWidth());
		Assert.assertNull(notificationWindow.getPosition());
		Assert.assertEquals(
				"<h5>TestMarker</h5><p style=\"color: orange\">Mittel</p>Relative Luftfeuchtigkeit</br>Stuttgarter Straße 130, Waiblingen</br>10.05.2015 13:25:14",
				notificationWindow.getContent());
	}
}
