
package com.bosch.si.amra.provider;

import java.io.IOException;
import java.io.InputStream;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.component.grid.OverviewGrid;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.constants.overview.OverviewConstants;
import com.bosch.si.amra.entity.ColumnConfiguration;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.UserSettingsConfiguration;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.util.JSON;
import com.vaadin.data.sort.SortOrder;
import com.vaadin.shared.data.sort.SortDirection;

import mockit.Expectations;
import mockit.Mocked;

@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (locations = "file:src/test/resources/spring-servlet.xml")
public class UserSessionDataProviderTest
{
	@Autowired
	private UserSessionDataProvider	userSessionDataProvider;

	@Value ("${MONGO_HOST}")
	public String					MONGO_HOST;

	@Value ("${MONGO_PORT}")
	public Integer					MONGO_PORT;

	@Value ("${MONGO_DATABASE}")
	public String					MONGO_DATABASE;

	@Value ("${MONGO_USERNAME}")
	public String					MONGO_USERNAME;

	@Value ("${MONGO_PASSWORD}")
	public String					MONGO_PASSWORD;

	@Value ("${USERSESSION_COLLECTION}")
	public String					USERSESSION_COLLECTION;

	@Value ("${USE_PROXY}")
	public String					PROXY;

	@Mocked
	DashboardUI						dashboardUi;

	@After
	@Before
	public void tearDown() throws UnknownHostException
	{
		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection collection = db.getCollection(DashboardUI.getMongoUserSessionCollection());
		collection.remove(new BasicDBObject());
	}

	@Test
	public void checkNoUserSettingsTest() throws UnknownHostException
	{
		getMongoClient();
		User user = createUser();
		DBObject userSettings = userSessionDataProvider.getUserSettings(user);
		UserSettingsConfiguration overViewConfiguration = userSessionDataProvider
				.fetchCurrentUserSettings(userSettings, MongoConstants.OVERVIEW_PAGE);
		Assert.assertNull("The overview page configurations should be null", overViewConfiguration);
	}

	@Test
	public void updateUserSettingsTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		User user = createUser();
		UserSettingsConfiguration configuration = new UserSettingsConfiguration();
		ArrayList<ColumnConfiguration> userSettingsColumnConfigurations = createSampleConfiguration();
		Map<String, String> filterMap = createSamplefilterMap();
		SortOrder sortedGridColumnConfigurations = createSampleSortOrder();
		configuration.setUserSettingsColumnConfigurations(userSettingsColumnConfigurations);
		configuration.setFilterMap(filterMap);
		configuration.setSortedGridColumnConfigurations(sortedGridColumnConfigurations);
		userSessionDataProvider.updateUserSettings(user, configuration,
				MongoConstants.OVERVIEW_PAGE);
		userSessionDataProvider.updateUserSettings(user, configuration,
				MongoConstants.DISPONENT_PAGE);
		DBCollection collection = getCollection(DashboardUI.getMongoUserSessionCollection());
		DBObject find = new BasicDBObject(MongoConstants.ID,
				"b144b8e0-6e44-11e4-8035-0050569350e8");
		DBObject result = collection.findOne(find);
		Assert.assertNotNull(result);
		Assert.assertTrue(result.containsField(MongoConstants.OVERVIEW_PAGE));
		Assert.assertTrue(result.containsField(MongoConstants.DISPONENT_PAGE));
		DBObject userSettingsConfiguration = (DBObject) result.get(MongoConstants.OVERVIEW_PAGE);
		BasicDBList columnConfiguration = (BasicDBList) userSettingsConfiguration
				.get(MongoConstants.COLUMN_CONFIGURATION);
		Assert.assertNotNull(columnConfiguration);
		Assert.assertEquals(columnConfiguration.size(), OverviewGrid.getColumnIds(user).length);
		BasicDBList filterSettings = (BasicDBList) userSettingsConfiguration
				.get(MongoConstants.FILTERS);
		Assert.assertNotNull(filterSettings);
		Assert.assertEquals(filterSettings.size(), 2);
		DBObject sortColumnConfiguration = (DBObject) userSettingsConfiguration
				.get(MongoConstants.SORTED_ORDER);
		Assert.assertNotNull(sortColumnConfiguration);
		Assert.assertTrue(sortColumnConfiguration.containsField(MongoConstants.ALIAS));
		Assert.assertEquals(sortColumnConfiguration.get(MongoConstants.ALIAS), false);
		DBObject disponentConfiguration = (DBObject) result.get(MongoConstants.DISPONENT_PAGE);
		BasicDBList disponentColumnConfiguration = (BasicDBList) disponentConfiguration
				.get(MongoConstants.COLUMN_CONFIGURATION);
		Assert.assertNotNull(disponentColumnConfiguration);
		Assert.assertEquals(disponentColumnConfiguration.size(),
				OverviewGrid.getColumnIds(user).length);
		filterSettings = (BasicDBList) disponentConfiguration.get(MongoConstants.FILTERS);
		Assert.assertNotNull(filterSettings);
		Assert.assertEquals(filterSettings.size(), 2);
		DBObject disponentSort = (DBObject) disponentConfiguration.get(MongoConstants.SORTED_ORDER);
		Assert.assertNotNull(disponentSort);
		Assert.assertTrue(disponentSort.containsField(MongoConstants.ALIAS));
		Assert.assertEquals(disponentSort.get(MongoConstants.ALIAS), false);
	}

	@Test
	public void fetchCurrentUserSettingsTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		User user = createUser();
		DBObject userSettings = userSessionDataProvider.getUserSettings(user);
		UserSettingsConfiguration userSettingsConfiguration = userSessionDataProvider
				.fetchCurrentUserSettings(userSettings, MongoConstants.OVERVIEW_PAGE);
		Assert.assertNotNull("The overview page configurations should not be null",
				userSettingsConfiguration);
		ArrayList<ColumnConfiguration> userSettingsColumnConfigurations = userSettingsConfiguration
				.getUserSettingsColumnConfigurations();
		Assert.assertNotNull("The column settings should not be null",
				userSettingsColumnConfigurations);
		Assert.assertEquals(userSettingsColumnConfigurations.size(), 2);
		Map<String, String> filterMap = userSettingsConfiguration.getFilterMap();
		Assert.assertNotNull("The filter map should not be null", filterMap);
		Assert.assertEquals("The size of filter map should be 3", 3, filterMap.size());
		SortOrder sortedGridColumnConfigurations = userSettingsConfiguration
				.getSortedGridColumnConfigurations();
		Assert.assertNotNull("The sorted column settings should not be null",
				sortedGridColumnConfigurations);
		Assert.assertEquals(sortedGridColumnConfigurations.getPropertyId(), "alias");
		Assert.assertEquals(sortedGridColumnConfigurations.getDirection(), SortDirection.ASCENDING);

		UserSettingsConfiguration disponentConfiguration = userSessionDataProvider
				.fetchCurrentUserSettings(userSettings, MongoConstants.DISPONENT_PAGE);
		Assert.assertNotNull("The disponent page configurations should not be null",
				disponentConfiguration);
		ArrayList<ColumnConfiguration> disponentColumnConfiguration = disponentConfiguration
				.getUserSettingsColumnConfigurations();
		Assert.assertNotNull("The column settings should not be null",
				disponentColumnConfiguration);
		Assert.assertEquals(disponentColumnConfiguration.size(), 2);
		filterMap = disponentConfiguration.getFilterMap();
		Assert.assertNotNull("The filter map should not be null", filterMap);
		Assert.assertEquals("The size of filter map should be 2", 2, filterMap.size());
		SortOrder disponentSort = disponentConfiguration.getSortedGridColumnConfigurations();
		Assert.assertNotNull("The sorted column settings should not be null", disponentSort);
		Assert.assertEquals(disponentSort.getPropertyId(), "address.country");
		Assert.assertEquals(disponentSort.getDirection(), SortDirection.ASCENDING);
	}

	private MongoClient getMongoClient() throws UnknownHostException
	{
		new Expectations()
		{
			{

				DashboardUI.getMongoUsername();
				returns(MONGO_USERNAME);
				DashboardUI.getMongoPassword();
				returns(MONGO_PASSWORD);
				DashboardUI.getMongoDatabase();
				returns(MONGO_DATABASE);
				DashboardUI.getMongoHost();
				returns(MONGO_HOST);
				DashboardUI.getMongoPort();
				returns(MONGO_PORT);
				DashboardUI.getMongoUserSessionCollection();
				minTimes = 0;
				returns(USERSESSION_COLLECTION);
			}
		};
		DataProviderInitializer.createMongoClient();
		return DataProviderInitializer.getMongoClient();
	}

	@SuppressWarnings ("unchecked")
	private void fillTestDB() throws IOException
	{
		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection collection = db.getCollection(DashboardUI.getMongoUserSessionCollection());
		InputStream testMessage = UserSessionDataProviderTest.class
				.getResourceAsStream("/testData/userSession/userSetting.json");
		String message = IOUtils.toString(testMessage, "UTF-8");
		Object parse = JSON.parse(message);
		List<DBObject> objectListToSave = (List<DBObject>) parse;
		collection.insert(objectListToSave);
	}

	private User createUser()
	{
		User user = new User();
		user.setTenant("cbeaa370-c11d-11e1-8ba8-d4bed92ae488");
		user.setId("b144b8e0-6e44-11e4-8035-0050569350e8");
		return user;
	}

	private ArrayList<ColumnConfiguration> createSampleConfiguration()
	{
		ArrayList<ColumnConfiguration> sampleConfigurations = new ArrayList<ColumnConfiguration>();
		Arrays.asList(OverviewConstants.DEFAULT_PROPERTY_IDS).stream().forEach(propertyId -> {

			ColumnConfiguration columnConfiguration = new ColumnConfiguration();
			columnConfiguration.setPropertyId(propertyId.toString());
			columnConfiguration.setWidth(50.0);
			sampleConfigurations.add(columnConfiguration);
		});
		return sampleConfigurations;
	}

	private Map<String, String> createSamplefilterMap()
	{
		Map<String, String> filterMap = new HashMap<String, String>();
		filterMap.put("alias", "amra");
		filterMap.put("tags", "banana");
		return filterMap;
	}

	private SortOrder createSampleSortOrder()
	{
		SortOrder sortOrder = new SortOrder(OverviewConstants.ALIAS, SortDirection.DESCENDING);
		return sortOrder;
	}

	private DBCollection getCollection(String collectionName) throws UnknownHostException
	{
		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		return db.getCollection(collectionName);
	}
}
