
package com.bosch.si.amra.presenter.overview;

import java.io.IOException;
import java.io.InputStream;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.io.IOUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.entity.Tag;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.event.DashboardEvent.DeleteTagEvent;
import com.bosch.si.amra.event.DashboardEvent.TagAssignChangeEvent;
import com.bosch.si.amra.event.DashboardEvent.TagCreateOrUpdateEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.provider.DataProviderInitializer;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.util.JSON;

import mockit.Expectations;
import mockit.Mocked;

@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (locations = "file:src/test/resources/spring-servlet.xml")
@PrepareForTest ({ DashboardUI.class })
public class OverviewPresenterTest
{
	@Autowired
	OverviewPresenter			overviewPresenter;

	final private static String	TI			= "cbeaa370-c11d-11e1-8ba8-d4bed92ae488";

	@Mocked
	final DashboardEventBus		eventBus	= null;

	@Mocked
	DashboardUI					dashboardUi;

	@Value ("${MONGO_HOST}")
	public String				MONGO_HOST;

	@Value ("${MONGO_PORT}")
	public Integer				MONGO_PORT;

	@Value ("${MONGO_DATABASE}")
	public String				MONGO_DATABASE;

	@Value ("${MONGO_USERNAME}")
	public String				MONGO_USERNAME;

	@Value ("${MONGO_PASSWORD}")
	public String				MONGO_PASSWORD;

	@Value ("${CURRENT_COLLECTION}")
	public String				CURRENT_COLLECTION;

	@Value ("${WAGON_COLLECTION}")
	public String				WAGON_COLLECTION;

	@Value ("${TAG_COLLECTION}")
	public String				TAG_COLLECTION;

	@After
	public void tearDown() throws UnknownHostException
	{
		getTestExpectations();
		DBCollection collection = getCollection(DashboardUI.getMongoCurrentCollection());
		BasicDBObject empty = new BasicDBObject();
		collection.remove(empty);
		collection = getCollection(DashboardUI.getWagonCollection());
		collection.remove(empty);
		collection = getCollection(DashboardUI.getMongoTagCollection());
		collection.remove(empty);
	}

	@Test
	public void createTagTest() throws IOException
	{
		getTagTestExcpectations();

		Tag tag = new Tag();
		tag.setTagName("Test Tag");
		tag.setTenantId(TI);
		tag.setCreatedBy("tester");
		tag.setCreatedServerTimestamp(System.currentTimeMillis());
		tag.setAssigned(false);
		overviewPresenter.createOrUpdateTag(new TagCreateOrUpdateEvent(TI, tag));

		DBCollection collection = getCollection(DashboardUI.getMongoTagCollection());
		BasicDBObject findQuery = new BasicDBObject(MongoConstants.TENANT_ID, TI);
		findQuery.put(MongoConstants.SORT, tag.getTagName().toLowerCase());

		DBCursor find = collection.find(findQuery);

		Assert.assertNotNull(find);
		Assert.assertTrue(find.count() == 1);
	}

	@Test
	public void createDuplicateTagTest() throws IOException
	{
		getTagTestExcpectations();
		String tagName = "Test Tag";
		Tag tag = new Tag();
		tag.setTagName(tagName);
		tag.setTenantId(TI);
		tag.setCreatedBy("tester");
		tag.setCreatedServerTimestamp(System.currentTimeMillis());
		tag.setAssigned(false);
		overviewPresenter.createOrUpdateTag(new TagCreateOrUpdateEvent(TI, tag));

		Tag dupTag = new Tag();
		dupTag.setTagName(tagName.toLowerCase());
		dupTag.setTenantId(TI);
		dupTag.setCreatedBy("tester");
		dupTag.setCreatedServerTimestamp(System.currentTimeMillis());
		dupTag.setAssigned(false);
		overviewPresenter.createOrUpdateTag(new TagCreateOrUpdateEvent(TI, dupTag));

		DBCollection collection = getCollection(DashboardUI.getMongoTagCollection());
		BasicDBObject findQuery = new BasicDBObject(MongoConstants.TENANT_ID, TI);
		findQuery.put(MongoConstants.SORT, dupTag.getTagName());

		DBCursor find = collection.find(findQuery);

		Assert.assertEquals(1, find.count());
	}

	@Test
	public void assignSingleTagToSingleWagonTest() throws IOException
	{
		getTestExpectations();
		createCurrentcollection();
		List<Tag> tagsToBeAssigned = createTagCollection();
		List<Wagon> wagonsToBeUsed = createWagonCollection();
		overviewPresenter.changeTagAssignmentToWagon(
				new TagAssignChangeEvent((List<Wagon>) Arrays.asList(wagonsToBeUsed.get(0)),
						(List<Tag>) Arrays.asList(tagsToBeAssigned.get(0)), true));
		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBCollection currentCollection = getCollection(DashboardUI.getMongoCurrentCollection());
		DBObject find = new BasicDBObject(MongoConstants.TENANT_ID, TI);
		find.put(MongoConstants.WAGON_TAG + "." + MongoConstants.SORT,
				tagsToBeAssigned.get(0).getTagName().toLowerCase());

		DBCursor foundWagons = wagonCollection.find(find);
		DBCursor foundCurrentWagons = currentCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertNotNull(foundCurrentWagons);
		Assert.assertEquals(1, foundWagons.count());
		Assert.assertEquals(1, foundCurrentWagons.count());
	}

	@Test
	public void assignSingleTagToMultipleWagonTest() throws IOException
	{
		getTestExpectations();
		createCurrentcollection();
		List<Tag> tagsToBeAssigned = createTagCollection();
		List<Wagon> wagonsToBeUsed = createWagonCollection();
		overviewPresenter.changeTagAssignmentToWagon(new TagAssignChangeEvent(wagonsToBeUsed,
				(List<Tag>) Arrays.asList(tagsToBeAssigned.get(0)), true));
		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBCollection currentCollection = getCollection(DashboardUI.getMongoCurrentCollection());
		DBObject find = new BasicDBObject(MongoConstants.TENANT_ID, TI);
		find.put(MongoConstants.WAGON_TAG + "." + MongoConstants.SORT,
				tagsToBeAssigned.get(0).getTagName().toLowerCase());

		DBCursor foundWagons = wagonCollection.find(find);
		DBCursor foundCurrentWagons = currentCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertNotNull(foundCurrentWagons);
		Assert.assertEquals(5, foundWagons.count());
		Assert.assertEquals(5, foundCurrentWagons.count());
	}

	@Test
	public void assignMultipleTagToSingleWagonTest() throws IOException
	{
		getTestExpectations();
		createCurrentcollection();
		List<Tag> tagsToBeAssigned = createTagCollection();
		List<Wagon> wagonsToBeUsed = createWagonCollection();
		overviewPresenter.changeTagAssignmentToWagon(new TagAssignChangeEvent(
				(List<Wagon>) Arrays.asList(wagonsToBeUsed.get(0)), tagsToBeAssigned, true));
		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBCollection currentCollection = getCollection(DashboardUI.getMongoCurrentCollection());
		DBObject find = new BasicDBObject(MongoConstants.TENANT_ID, TI);
		BasicDBList tagSortNameList = tagsToBeAssigned.stream()
				.map(tag -> tag.getTagName().toLowerCase())
				.collect(Collectors.toCollection(BasicDBList::new));
		find.put(MongoConstants.WAGON_TAG + "." + MongoConstants.SORT,
				new BasicDBObject("$in", tagSortNameList));

		DBCursor foundWagons = wagonCollection.find(find);
		DBCursor foundCurrentWagons = currentCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertNotNull(foundCurrentWagons);
		Assert.assertEquals(1, foundWagons.count());
		Assert.assertEquals(1, foundCurrentWagons.count());
	}

	@Test
	public void assignMultipleTagToMultipleWagonTest() throws IOException
	{
		getTestExpectations();
		createCurrentcollection();
		List<Tag> tagsToBeAssigned = createTagCollection();
		List<Wagon> WagonToBeUsed = createWagonCollection();
		overviewPresenter.changeTagAssignmentToWagon(
				new TagAssignChangeEvent(WagonToBeUsed, tagsToBeAssigned, true));
		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBCollection currentCollection = getCollection(DashboardUI.getMongoCurrentCollection());
		DBObject find = new BasicDBObject(MongoConstants.TENANT_ID, TI);
		BasicDBList tagSortNameList = tagsToBeAssigned.stream()
				.map(tag -> tag.getTagName().toLowerCase())
				.collect(Collectors.toCollection(BasicDBList::new));
		find.put(MongoConstants.WAGON_TAG + "." + MongoConstants.SORT,
				new BasicDBObject("$in", tagSortNameList));

		DBCursor foundWagons = wagonCollection.find(find);
		DBCursor foundCurrentWagons = currentCollection.find(find);

		Assert.assertNotNull(foundWagons);
		Assert.assertNotNull(foundCurrentWagons);
		Assert.assertEquals(5, foundWagons.count());
		Assert.assertEquals(5, foundCurrentWagons.count());
	}

	@Test
	public void unAssignSingleTagFromSingleWagonTest() throws IOException
	{
		getTestExpectations();
		createCurrentcollection();
		List<Tag> tagsToBeAssigned = createTagCollection();
		List<Wagon> WagonToBeUsed = createWagonCollection();
		overviewPresenter.changeTagAssignmentToWagon(
				new TagAssignChangeEvent(WagonToBeUsed, tagsToBeAssigned, true));
		tagsToBeAssigned.forEach(tag -> tag.setAssigned(true));
		WagonToBeUsed.forEach(wagon -> wagon.setTags(tagsToBeAssigned));
		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBCollection currentCollection = getCollection(DashboardUI.getMongoCurrentCollection());
		Wagon wagonFromTagToBeUnAssigned = WagonToBeUsed.get(0);
		DBObject find = new BasicDBObject(MongoConstants.ID, wagonFromTagToBeUnAssigned.getId());

		Tag tagToBeUnAssigned = tagsToBeAssigned.get(0);
		find.put(MongoConstants.WAGON_TAG + "." + MongoConstants.SORT,
				tagToBeUnAssigned.getTagName().toLowerCase());

		overviewPresenter.changeTagAssignmentToWagon(
				new TagAssignChangeEvent((List<Wagon>) Arrays.asList(wagonFromTagToBeUnAssigned),
						(List<Tag>) Arrays.asList(tagToBeUnAssigned), false));

		DBCursor foundWagons = wagonCollection.find(find);
		DBCursor foundCurrentWagons = currentCollection.find(find);
		Assert.assertEquals(0, foundWagons.count());
		Assert.assertEquals(0, foundCurrentWagons.count());
	}

	@Test
	public void unAssignSingleTagFromMultipleWagonTest() throws IOException
	{
		getTestExpectations();
		createCurrentcollection();
		List<Tag> tagsToBeAssigned = createTagCollection();
		List<Wagon> WagonToBeUsed = createWagonCollection();
		overviewPresenter.changeTagAssignmentToWagon(
				new TagAssignChangeEvent(WagonToBeUsed, tagsToBeAssigned, true));
		tagsToBeAssigned.forEach(tag -> tag.setAssigned(true));
		WagonToBeUsed.forEach(wagon -> wagon.setTags(tagsToBeAssigned));
		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBCollection currentCollection = getCollection(DashboardUI.getMongoCurrentCollection());
		DBObject find = new BasicDBObject(MongoConstants.TENANT_ID, TI);

		Tag tagToBeUnAssigned = tagsToBeAssigned.get(0);
		find.put(MongoConstants.WAGON_TAG + "." + MongoConstants.SORT,
				tagToBeUnAssigned.getTagName().toLowerCase());

		overviewPresenter.changeTagAssignmentToWagon(new TagAssignChangeEvent(WagonToBeUsed,
				(List<Tag>) Arrays.asList(tagToBeUnAssigned), false));

		DBCursor foundWagons = wagonCollection.find(find);
		DBCursor foundCurrentWagons = currentCollection.find(find);
		Assert.assertEquals(0, foundWagons.count());
		Assert.assertEquals(0, foundCurrentWagons.count());
	}

	@Test
	public void unAssignMultipleTagFromMultipleWagonTest() throws IOException
	{
		getTestExpectations();
		createCurrentcollection();
		List<Tag> tagsToBeUnAssigned = createTagCollection();
		List<Wagon> WagonToBeUsed = createWagonCollection();
		overviewPresenter.changeTagAssignmentToWagon(
				new TagAssignChangeEvent(WagonToBeUsed, tagsToBeUnAssigned, true));
		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBCollection currentCollection = getCollection(DashboardUI.getMongoCurrentCollection());
		DBObject find = new BasicDBObject(MongoConstants.TENANT_ID, TI);

		BasicDBList tagSortNameList = tagsToBeUnAssigned.stream()
				.map(tag -> tag.getTagName().toLowerCase())
				.collect(Collectors.toCollection(BasicDBList::new));
		find.put(MongoConstants.WAGON_TAG + "." + MongoConstants.SORT,
				new BasicDBObject("$in", tagSortNameList));

		tagsToBeUnAssigned.forEach(tag -> tag.setAssigned(true));
		WagonToBeUsed.forEach(wagon -> wagon.setTags(tagsToBeUnAssigned));
		overviewPresenter.changeTagAssignmentToWagon(
				new TagAssignChangeEvent(WagonToBeUsed, tagsToBeUnAssigned, false));

		DBCursor foundWagons = wagonCollection.find(find);
		DBCursor foundCurrentWagons = currentCollection.find(find);
		Assert.assertEquals(0, foundWagons.count());
		Assert.assertEquals(0, foundCurrentWagons.count());
	}

	@Test
	public void editTagTest() throws IOException
	{
		getTestExpectations();
		createCurrentcollection();
		List<Tag> tagsToBeAssigned = createTagCollection();
		List<Wagon> WagonToBeUsed = createWagonCollection();
		overviewPresenter.changeTagAssignmentToWagon(
				new TagAssignChangeEvent(WagonToBeUsed, tagsToBeAssigned, true));
		DBCollection wagonCollection = getCollection(DashboardUI.getWagonCollection());
		DBCollection currentCollection = getCollection(DashboardUI.getMongoCurrentCollection());
		DBObject find = new BasicDBObject(MongoConstants.TENANT_ID, TI);

		Tag tagToBeEdited = tagsToBeAssigned.get(0);
		tagToBeEdited.setTagName("Fruit");
		tagToBeEdited.setAssigned(true);

		overviewPresenter.createOrUpdateTag(new TagCreateOrUpdateEvent(TI, tagToBeEdited));
		find.put(MongoConstants.WAGON_TAG + "." + MongoConstants.SORT,
				tagToBeEdited.getTagName().toLowerCase());

		DBCursor foundWagons = wagonCollection.find(find);
		DBCursor foundCurrentWagons = currentCollection.find(find);
		Assert.assertEquals(5, foundWagons.count());
		Assert.assertEquals(5, foundCurrentWagons.count());
	}

	@Test
	public void editDuplicateTagTest() throws IOException
	{
		getTagTestExcpectations();
		List<Tag> tagsToBeAssigned = createTagCollection();

		Tag tagToBeEdited = tagsToBeAssigned.get(0);
		tagToBeEdited.setTagName(tagsToBeAssigned.get(1).getTagName().toLowerCase());

		overviewPresenter.createOrUpdateTag(new TagCreateOrUpdateEvent(TI, tagToBeEdited));

		DBCollection tagCollection = getCollection(DashboardUI.getMongoTagCollection());
		DBObject find = new BasicDBObject(MongoConstants.TENANT_ID, TI);
		find.put(MongoConstants.SORT, tagToBeEdited.getTagName().toLowerCase());

		DBCursor foundTags = tagCollection.find(find);

		Assert.assertEquals(1, foundTags.count());
	}

	@Test
	public void deleteMultipleTagTest() throws IOException
	{
		getTagTestExcpectations();
		List<Tag> tagListToDelete = createTagCollection();
		overviewPresenter.deleteTags(new DeleteTagEvent(tagListToDelete));
		DBCollection tagCollection = getCollection(DashboardUI.getMongoTagCollection());
		Assert.assertEquals(0, tagCollection.count());
	}

	@Test
	public void deleteAssignedTagsTest() throws IOException
	{
		getTestExpectations();
		createCurrentcollection();
		List<Tag> tagsToBeAssigned = createTagCollection();
		List<Wagon> WagonToBeUsed = createWagonCollection();
		overviewPresenter.changeTagAssignmentToWagon(
				new TagAssignChangeEvent(WagonToBeUsed, tagsToBeAssigned, true));
		tagsToBeAssigned.forEach(tag -> tag.setAssigned(true));
		DBCollection tagCollection = getCollection(DashboardUI.getMongoTagCollection());

		DBObject find = new BasicDBObject(MongoConstants.TENANT_ID, TI);
		overviewPresenter.deleteTags(new DeleteTagEvent(new ArrayList<Tag>()));
		DBCursor tagsFound = tagCollection.find(find);

		Assert.assertEquals(3, tagsFound.count());
	}

	@Test
	public void deleteMixedTagsTest() throws IOException
	{
		getTestExpectations();
		createCurrentcollection();
		List<Tag> tags = createTagCollection();
		List<Wagon> WagonToBeUsed = createWagonCollection();
		List<Tag> tagsToBeAssigned = tags.subList(1, 3);
		overviewPresenter.changeTagAssignmentToWagon(
				new TagAssignChangeEvent(WagonToBeUsed, tagsToBeAssigned, true));
		tagsToBeAssigned.forEach(tag -> tag.setAssigned(true));
		DBCollection tagCollection = getCollection(DashboardUI.getMongoTagCollection());

		DBObject find = new BasicDBObject(MongoConstants.TENANT_ID, TI);
		overviewPresenter.deleteTags(new DeleteTagEvent(tags.subList(0, 1)));
		DBCursor tagsFound = tagCollection.find(find);

		Assert.assertEquals(2, tagsFound.count());
	}

	private MongoClient getMongoClient() throws UnknownHostException
	{
		new Expectations()
		{
			{
				DashboardUI.getMongoUsername();
				returns(MONGO_USERNAME);
				DashboardUI.getMongoPassword();
				returns(MONGO_PASSWORD);
				DashboardUI.getMongoDatabase();
				returns(MONGO_DATABASE);
				DashboardUI.getMongoHost();
				returns(MONGO_HOST);
				DashboardUI.getMongoPort();
				returns(MONGO_PORT);
			}
		};
		DataProviderInitializer.createMongoClient();
		return DataProviderInitializer.getMongoClient();
	}

	private DBCollection getCollection(String collectionName) throws UnknownHostException
	{
		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		return db.getCollection(collectionName);
	}

	private List<Tag> createTagCollection() throws IOException
	{
		DBCollection collection = getCollection(DashboardUI.getMongoTagCollection());
		InputStream testMessage = this.getClass()
				.getResourceAsStream("/testData/tags/tagsData.json");
		String tags = IOUtils.toString(testMessage, "UTF-8");

		Object parse = JSON.parse(tags);
		List<DBObject> objectListToSave = (List<DBObject>) parse;
		collection.insert(objectListToSave);
		List<Tag> tagList = new ArrayList<>();

		objectListToSave.forEach(dbMaper -> {
			dbMaper.put("STU", Long.parseLong(dbMaper.get("STU").toString()));
			tagList.add(Tag.dbObject2Tag(dbMaper));
		});
		return tagList;
	}

	private List<Wagon> createWagonCollection() throws IOException
	{
		DBCollection collection = getCollection(DashboardUI.getWagonCollection());
		InputStream testMessage = this.getClass().getResourceAsStream("/testData/wagon/wagon.json");
		String wagons = IOUtils.toString(testMessage, "UTF-8");

		Object parse = JSON.parse(wagons);
		List<DBObject> objectListToSave = (List<DBObject>) parse;
		collection.insert(objectListToSave);
		List<Wagon> wagonsList = new ArrayList<>();
		objectListToSave.forEach(dbMaper -> wagonsList.add(Wagon.dbObject2Wagon(dbMaper)));
		return wagonsList;
	}

	private void createCurrentcollection() throws IOException
	{
		DBCollection collection = getCollection(DashboardUI.getMongoCurrentCollection());
		InputStream testMessage = this.getClass()
				.getResourceAsStream("/testData/current/current.json");
		String current = IOUtils.toString(testMessage, "UTF-8");

		Object parse = JSON.parse(current);
		List<DBObject> objectListToSave = (List<DBObject>) parse;
		collection.insert(objectListToSave);
	}

	private void getTestExpectations()
	{
		new Expectations()
		{
			{
				DashboardUI.getMongoUsername();
				returns(MONGO_USERNAME);
				DashboardUI.getMongoPassword();
				returns(MONGO_PASSWORD);
				DashboardUI.getMongoDatabase();
				returns(MONGO_DATABASE);
				DashboardUI.getMongoHost();
				returns(MONGO_HOST);
				DashboardUI.getMongoPort();
				returns(MONGO_PORT);
				DashboardUI.getMongoTagCollection();
				returns(TAG_COLLECTION);
				DashboardUI.getWagonCollection();
				returns(WAGON_COLLECTION);
				DashboardUI.getMongoCurrentCollection();
				returns(CURRENT_COLLECTION);
			}
		};
	}

	private void getTagTestExcpectations()
	{
		new Expectations()
		{
			{
				DashboardUI.getMongoUsername();
				returns(MONGO_USERNAME);
				DashboardUI.getMongoPassword();
				returns(MONGO_PASSWORD);
				DashboardUI.getMongoDatabase();
				returns(MONGO_DATABASE);
				DashboardUI.getMongoHost();
				returns(MONGO_HOST);
				DashboardUI.getMongoPort();
				returns(MONGO_PORT);
				DashboardUI.getMongoTagCollection();
				minTimes = 2;
				returns(TAG_COLLECTION);
			}
		};
	}
}
