
package com.bosch.si.amra.view.configuration;

import java.util.Locale;

import org.junit.Assert;
import org.junit.Test;

import com.bosch.si.amra.view.configuration.converter.FirmwareConverter;
import com.vaadin.data.util.converter.Converter.ConversionException;

public class FirmwareConverterTest
{
	private FirmwareConverter firmwareAndStatusConverter;

	@Test
	public void firmwareTest()
	{
		firmwareAndStatusConverter = new FirmwareConverter(0, 999999);
		Integer convertToModel = firmwareAndStatusConverter.convertToModel("100100", Integer.class,
				Locale.getDefault());
		Assert.assertNotNull(convertToModel);
		Assert.assertEquals(new Integer(100100), convertToModel);
	}

	@Test
	public void firmwareZeroTest()
	{
		firmwareAndStatusConverter = new FirmwareConverter(0, 999999);
		Integer convertToModel = firmwareAndStatusConverter.convertToModel("0", Integer.class,
				Locale.getDefault());
		Assert.assertNotNull(convertToModel);
		Assert.assertEquals(new Integer(0), convertToModel);
	}

	@Test
	public void firmware999999Test()
	{
		firmwareAndStatusConverter = new FirmwareConverter(0, 999999);
		Integer convertToModel = firmwareAndStatusConverter.convertToModel("999999", Integer.class,
				Locale.getDefault());
		Assert.assertNotNull(convertToModel);
		Assert.assertEquals(new Integer(999999), convertToModel);
	}

	@Test
	public void firmwareNegativeTest()
	{
		firmwareAndStatusConverter = new FirmwareConverter(0, 999999);
		Integer convertToModel = firmwareAndStatusConverter.convertToModel("-1", Integer.class,
				Locale.getDefault());
		Assert.assertNotNull(convertToModel);
		Assert.assertEquals(new Integer(0), convertToModel);
	}

	@Test
	public void firmware1000000Test()
	{
		firmwareAndStatusConverter = new FirmwareConverter(0, 999999);
		Integer convertToModel = firmwareAndStatusConverter.convertToModel("1000000", Integer.class,
				Locale.getDefault());
		Assert.assertNotNull(convertToModel);
		Assert.assertEquals(new Integer(999999), convertToModel);
	}

	@Test (expected = ConversionException.class)
	public void firmwareStringTest()
	{
		firmwareAndStatusConverter = new FirmwareConverter(0, 999999);
		firmwareAndStatusConverter.convertToModel("Hallo", Integer.class, Locale.getDefault());
	}

	@Test
	public void firmwareEmptyTest()
	{
		firmwareAndStatusConverter = new FirmwareConverter(0, 999999);
		Assert.assertNull(
				firmwareAndStatusConverter.convertToModel("", Integer.class, Locale.getDefault()));
	}

	@Test
	public void firmwareNullTest()
	{
		firmwareAndStatusConverter = new FirmwareConverter(0, 999999);
		Assert.assertNull(firmwareAndStatusConverter.convertToModel(null, Integer.class,
				Locale.getDefault()));

	}

	@Test
	public void statusTest()
	{
		firmwareAndStatusConverter = new FirmwareConverter(0, 999999);
		Integer convertToModel = firmwareAndStatusConverter.convertToModel("1", Integer.class,
				Locale.getDefault());
		Assert.assertNotNull(convertToModel);
		Assert.assertEquals(new Integer(1), convertToModel);
	}

	@Test
	public void statusZeroTest()
	{
		firmwareAndStatusConverter = new FirmwareConverter(0, Integer.MAX_VALUE);
		Integer convertToModel = firmwareAndStatusConverter.convertToModel("0", Integer.class,
				Locale.getDefault());
		Assert.assertNotNull(convertToModel);
		Assert.assertEquals(new Integer(0), convertToModel);
	}

	@Test
	public void statusMaxTest()
	{
		firmwareAndStatusConverter = new FirmwareConverter(0, Integer.MAX_VALUE);
		Integer convertToModel = firmwareAndStatusConverter.convertToModel("2147483647",
				Integer.class, Locale.getDefault());
		Assert.assertNotNull(convertToModel);
		Assert.assertEquals(new Integer(2147483647), convertToModel);
	}

	@Test
	public void statusNegativeTest()
	{
		firmwareAndStatusConverter = new FirmwareConverter(0, Integer.MAX_VALUE);
		Integer convertToModel = firmwareAndStatusConverter.convertToModel("-1", Integer.class,
				Locale.getDefault());
		Assert.assertNotNull(convertToModel);
		Assert.assertEquals(new Integer(0), convertToModel);
	}

	@Test (expected = ConversionException.class)
	public void statusOverMaxTest()
	{
		firmwareAndStatusConverter = new FirmwareConverter(0, Integer.MAX_VALUE);
		firmwareAndStatusConverter.convertToModel("2147483648", Integer.class, Locale.getDefault());
	}

	@Test (expected = ConversionException.class)
	public void statusStringTest()
	{
		firmwareAndStatusConverter = new FirmwareConverter(0, Integer.MAX_VALUE);
		firmwareAndStatusConverter.convertToModel("Hallo", Integer.class, Locale.getDefault());
	}

	@Test
	public void statusEmptyTest()
	{
		firmwareAndStatusConverter = new FirmwareConverter(0, Integer.MAX_VALUE);
		Assert.assertNull(
				firmwareAndStatusConverter.convertToModel("", Integer.class, Locale.getDefault()));
	}

	@Test
	public void statusNullTest()
	{
		firmwareAndStatusConverter = new FirmwareConverter(0, Integer.MAX_VALUE);
		Assert.assertNull(firmwareAndStatusConverter.convertToModel(null, Integer.class,
				Locale.getDefault()));
	}
}
