
package com.bosch.si.amra.presenter.fleetbalancing;

import static com.bosch.si.amra.constants.MongoConstants.ALIAS;
import static com.bosch.si.amra.constants.MongoConstants.DATE;
import static com.bosch.si.amra.constants.MongoConstants.DIVIDE;
import static com.bosch.si.amra.constants.MongoConstants.FIRST;
import static com.bosch.si.amra.constants.MongoConstants.GREATER_THAN_EQUALS;
import static com.bosch.si.amra.constants.MongoConstants.GROUP;
import static com.bosch.si.amra.constants.MongoConstants.ID;
import static com.bosch.si.amra.constants.MongoConstants.IN;
import static com.bosch.si.amra.constants.MongoConstants.LESS_THAN_EQUALS;
import static com.bosch.si.amra.constants.MongoConstants.MATCH;
import static com.bosch.si.amra.constants.MongoConstants.MILEAGE;
import static com.bosch.si.amra.constants.MongoConstants.PROJECT;
import static com.bosch.si.amra.constants.MongoConstants.SORT;
import static com.bosch.si.amra.constants.MongoConstants.SUBTRACT;
import static com.bosch.si.amra.constants.MongoConstants.SUM;
import static com.bosch.si.amra.constants.MongoConstants.TENANT_ID;
import static com.bosch.si.amra.constants.MongoConstants.WAGON_ID;
import static com.bosch.si.amra.constants.fleetbalancing.FleetBalancingConstants.DEVIATION;
import static com.bosch.si.amra.constants.fleetbalancing.FleetBalancingConstants.MILEAGE_SUM;
import static com.bosch.si.amra.constants.fleetbalancing.FleetBalancingConstants.TOTAL_MILEAGE;

import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.bosch.si.amra.entity.Wagon;
import com.mongodb.BasicDBList;
import com.mongodb.DBObject;

public class FleetBalancingMongoQueryFactoryTest
{
	private static final int DESCENDING_ORDER = -1;
	private static final String T_ID = "cbeaa370-c11d-11e1-8ba8-d4bed92ae488";

	@Test
	public void matchTest()
	{
		String startDate = "16-03-22";
		String endDate = "16-07-15";
		DBObject match = FleetBalancingMongoQueryFactory.match(T_ID, createWagons(), startDate,
				endDate);
		Assert.assertNotNull(match);
		Assert.assertTrue(match.containsField(MATCH));
		DBObject matchObject = (DBObject) match.get(MATCH);
		Assert.assertEquals(3, matchObject.toMap().size());
		Assert.assertTrue(matchObject.containsField(DATE));
		DBObject dateObject = (DBObject) matchObject.get(DATE);
		Assert.assertTrue(dateObject.containsField("$" + GREATER_THAN_EQUALS));
		Assert.assertEquals(startDate, dateObject.get("$" + GREATER_THAN_EQUALS));
		Assert.assertTrue(dateObject.containsField("$" + LESS_THAN_EQUALS));
		Assert.assertEquals(endDate, dateObject.get("$" + LESS_THAN_EQUALS));
		Assert.assertTrue(matchObject.containsField(TENANT_ID));
		Assert.assertEquals(T_ID, matchObject.get(TENANT_ID));
		Assert.assertTrue(matchObject.containsField(WAGON_ID));
		DBObject wagonsObject = (DBObject) matchObject.get(WAGON_ID);
		Assert.assertTrue(wagonsObject.containsField("$" + IN));
		BasicDBList wagonIds = (BasicDBList) wagonsObject.get("$" + IN);
		Assert.assertEquals(3, wagonIds.size());
	}

	@Test
	public void groupMileageTest()
	{
		DBObject groupMileageSum = FleetBalancingMongoQueryFactory.groupMileageSum();
		Assert.assertNotNull(groupMileageSum);
		Assert.assertTrue(groupMileageSum.containsField(GROUP));
		DBObject groupObject = (DBObject) groupMileageSum.get(GROUP);
		Assert.assertEquals(2, groupObject.toMap().size());
		Assert.assertTrue(groupObject.containsField(ID));
		Assert.assertEquals("$" + TENANT_ID, groupObject.get(ID));
		Assert.assertTrue(groupObject.containsField(MILEAGE_SUM));
		DBObject sumMileageObject = (DBObject) groupObject.get(MILEAGE_SUM);
		Assert.assertEquals("$" + MILEAGE, sumMileageObject.get("$" + SUM));
	}

	@Test
	public void projectTotalSum()
	{
		DBObject totalSum = FleetBalancingMongoQueryFactory.projectTotalSum(4);
		Assert.assertNotNull(totalSum);
		Assert.assertTrue(totalSum.containsField(PROJECT));
		DBObject project = (DBObject) totalSum.get(PROJECT);
		Assert.assertEquals(1, project.toMap().size());
		Assert.assertTrue(project.containsField(TOTAL_MILEAGE));
		DBObject totalSumObject = (DBObject) project.get(TOTAL_MILEAGE);
		Assert.assertTrue(totalSumObject.containsField(DIVIDE));
		BasicDBList divide = (BasicDBList) totalSumObject.get(DIVIDE);
		Assert.assertEquals(2, divide.size());
	}

	@Test
	public void groupDeviationMileage()
	{
		DBObject groupDeviationMileage = FleetBalancingMongoQueryFactory.groupDeviationMileage();
		Assert.assertNotNull(groupDeviationMileage);
		Assert.assertTrue(groupDeviationMileage.containsField(GROUP));
		DBObject groupObject = (DBObject) groupDeviationMileage.get(GROUP);
		Assert.assertEquals(3, groupObject.toMap().size());
		Assert.assertTrue(groupObject.containsField(ID));
		Assert.assertEquals("$" + WAGON_ID, groupObject.get(ID));
		Assert.assertTrue(groupObject.containsField(MILEAGE_SUM));
		DBObject sumMileageObject = (DBObject) groupObject.get(MILEAGE_SUM);
		Assert.assertEquals("$" + MILEAGE, sumMileageObject.get("$" + SUM));
		Assert.assertTrue(groupObject.containsField(ALIAS));
		DBObject aliasObject = (DBObject) groupObject.get(ALIAS);
		Assert.assertEquals("$" + ALIAS, aliasObject.get("$" + FIRST));
	}

	@Test
	public void projectDeviationMileage()
	{
		DBObject deviationMileage = FleetBalancingMongoQueryFactory.projectDeviationMileage(749);
		Assert.assertNotNull(deviationMileage);
		Assert.assertTrue(deviationMileage.containsField(PROJECT));
		DBObject project = (DBObject) deviationMileage.get(PROJECT);
		Assert.assertEquals(2, project.toMap().size());
		Assert.assertTrue(project.containsField(ALIAS));
		Assert.assertEquals("$" + ALIAS, project.get(ALIAS));
		Assert.assertTrue(project.containsField(DEVIATION));
		DBObject deviation = (DBObject) project.get(DEVIATION);
		Assert.assertTrue(deviation.containsField(SUBTRACT));
		BasicDBList subtract = (BasicDBList) deviation.get(SUBTRACT);
		Assert.assertEquals(2, subtract.size());
	}

	@Test
	public void sortDeviationMileage()
	{
		DBObject sortMileage = FleetBalancingMongoQueryFactory.sortDeviationMileage();
		Assert.assertNotNull(sortMileage);
		Assert.assertTrue(sortMileage.containsField("$" + SORT));
		DBObject sort = (DBObject) sortMileage.get("$" + SORT);
		Assert.assertEquals(1, sort.toMap().size());
		Assert.assertTrue(sort.containsField(DEVIATION));
		Assert.assertEquals(DESCENDING_ORDER, sort.get(DEVIATION));
	}

	private List<Wagon> createWagons()
	{
		Wagon wagon1 = new Wagon();
		wagon1.setId("f9c36cc8-0c71-4c9f-a0e5-3e59758fa3bb");
		wagon1.setAlias("INST353816054766557");
		Wagon wagon2 = new Wagon();
		wagon2.setId("f46c9397-3879-44f0-877f-1d8678ad0ceb");
		wagon2.setAlias("TestWagon");
		Wagon wagon3 = new Wagon();
		wagon3.setId("91b7a464-6573-48a1-a0d2-95c0cf0b4a5d");
		wagon3.setAlias("Wagen 0815");
		return Arrays.asList(wagon1, wagon2, wagon3);
	}
}
