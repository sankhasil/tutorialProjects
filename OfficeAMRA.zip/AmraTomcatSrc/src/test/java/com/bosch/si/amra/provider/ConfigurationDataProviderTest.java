
package com.bosch.si.amra.provider;

import java.io.IOException;
import java.io.InputStream;
import java.net.UnknownHostException;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.configuration.Configuration;
import com.bosch.si.amra.provider.configuration.ConfigurationDataProvider;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.util.JSON;

import mockit.Expectations;
import mockit.Mocked;

@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (locations = "file:src/test/resources/spring-servlet.xml")
public class ConfigurationDataProviderTest
{
	@Autowired
	private ConfigurationDataProvider	configurationDataProvider;

	@Value ("${MONGO_HOST}")
	public String						MONGO_HOST;

	@Value ("${MONGO_PORT}")
	public Integer						MONGO_PORT;

	@Value ("${MONGO_DATABASE}")
	public String						MONGO_DATABASE;

	@Value ("${MONGO_USERNAME}")
	public String						MONGO_USERNAME;

	@Value ("${MONGO_PASSWORD}")
	public String						MONGO_PASSWORD;

	@Value ("${MONGO_COLLECTION}")
	public String						MONGO_COLLECTION;

	@Value ("${MILEAGE_COLLECTION}")
	public String						MILEAGE_COLLECTION;

	@Value ("${EVENT_COLLECTION}")
	public String						EVENT_COLLECTION;

	@Value ("${ROUTING_COLLECTION}")
	public String						ROUTING_COLLECTION;

	@Value ("${CURRENT_COLLECTION}")
	public String						CURRENT_COLLECTION;

	@Value ("${WAGON_COLLECTION}")
	public String						WAGON_COLLECTION;

	@Value ("${USE_PROXY}")
	public String						PROXY;

	@Value ("${CONFIGURATION_COLLECTION}")
	public String						CONFIGURATION_COLLECTION;

	@Mocked
	DashboardUI							dashboardUi;

	@After
	public void tearDown() throws UnknownHostException
	{
		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection collection = db.getCollection(DashboardUI.getConfigurationCollection());
		collection.remove(new BasicDBObject());
	}

	@Test
	public void getConfigurationsTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		List<Configuration> configurations = configurationDataProvider
				.getConfigurations("1798c300-c27f-11e4-81a3-0050569350e8");
		Assert.assertNotNull(configurations);
		Assert.assertTrue(configurations.size() == 11);
	}

	@Test (expected = IllegalArgumentException.class)
	public void getConfigurationsNullTenantTest()
	{
		configurationDataProvider.getConfigurations(null);
	}

	@Test (expected = IllegalArgumentException.class)
	public void getConfigurationsEmptyTenantTest()
	{
		configurationDataProvider.getConfigurations("");
	}

	@Test
	public void getConfigurationsNotExistingTenantTest() throws UnknownHostException
	{
		getMongoClient();
		List<Configuration> configurations = configurationDataProvider.getConfigurations("0");
		Assert.assertNotNull(configurations);
		Assert.assertTrue(configurations.size() == 0);
	}

	@Test
	public void configTest(@Mocked DBCursor cursor)
	{
		List<Configuration> createConfigurationsList = configurationDataProvider
				.createConfigurationsList(cursor);
		Assert.assertNotNull(createConfigurationsList);
		Assert.assertTrue(createConfigurationsList.size() == 0);
	}

	private MongoClient getMongoClient() throws UnknownHostException
	{
		new Expectations()
		{
			{
				DashboardUI.getMongoUsername();
				returns(MONGO_USERNAME);
				DashboardUI.getMongoPassword();
				returns(MONGO_PASSWORD);
				DashboardUI.getMongoDatabase();
				returns(MONGO_DATABASE);
				DashboardUI.getMongoHost();
				returns(MONGO_HOST);
				DashboardUI.getMongoPort();
				returns(MONGO_PORT);
				DashboardUI.getConfigurationCollection();
				returns(CONFIGURATION_COLLECTION);
			}
		};
		DataProviderInitializer.createMongoClient();
		return DataProviderInitializer.getMongoClient();
	}

	@SuppressWarnings ("unchecked")
	private void fillTestDB() throws IOException
	{

		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());

		// Fill configuration collection
		DBCollection collection = db.getCollection(DashboardUI.getConfigurationCollection());
		InputStream testMessage = ConfigurationDataProviderTest.class
				.getResourceAsStream("/testData/configurations/configurations.json");

		String message = IOUtils.toString(testMessage, "UTF-8");
		Object parse = JSON.parse(message);
		List<DBObject> objectToSave = (List<DBObject>) parse;
		collection.insert(objectToSave);
	}
}
