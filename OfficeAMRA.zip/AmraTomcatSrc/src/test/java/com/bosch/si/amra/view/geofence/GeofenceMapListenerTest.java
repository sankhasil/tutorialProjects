
package com.bosch.si.amra.view.geofence;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.vaadin.tapio.googlemaps.GoogleMap;
import com.vaadin.tapio.googlemaps.client.LatLon;
import com.vaadin.tapio.googlemaps.client.overlays.GoogleMapMarker;

public class GeofenceMapListenerTest
{
	private GeofenceMapListener		geofenceMapListener;

	private List<GoogleMapMarker>	markers;

	private List<LatLon>			positions;

	private GoogleMap				googleMap;

	@Before
	public void setup()
	{
		positions = createPositions();
		markers = createMarkers(positions);
		googleMap = new GoogleMap("test", "", "");
	}

	/**
	 * Clicking on a marker must remove the clicked marker and the size of the list decreases
	 */
	@Test
	public void markerClickedTest()
	{
		geofenceMapListener = new GeofenceMapListener(googleMap, positions, markers);
		Assert.assertEquals(10, geofenceMapListener.getGeofenceCoordinates().size());
		Assert.assertEquals(10, geofenceMapListener.getGeofenceMarkers().size());
		geofenceMapListener.markerClicked(markers.get(0));
		Assert.assertEquals(9, geofenceMapListener.getGeofenceCoordinates().size());
		Assert.assertEquals(9, geofenceMapListener.getGeofenceMarkers().size());
	}

	/**
	 * Simulating a double click by passing a null reference in the method. So we can check that
	 * nothing when a marker is null
	 */
	@Test
	public void markerDoubleClickedTest()
	{
		geofenceMapListener = new GeofenceMapListener(googleMap, positions, markers);
		Assert.assertEquals(10, geofenceMapListener.getGeofenceCoordinates().size());
		Assert.assertEquals(10, geofenceMapListener.getGeofenceMarkers().size());
		geofenceMapListener.markerClicked(markers.get(0));
		Assert.assertEquals(9, geofenceMapListener.getGeofenceCoordinates().size());
		Assert.assertEquals(9, geofenceMapListener.getGeofenceMarkers().size());
		geofenceMapListener.markerClicked(null);
		Assert.assertEquals(9, geofenceMapListener.getGeofenceCoordinates().size());
		Assert.assertEquals(9, geofenceMapListener.getGeofenceMarkers().size());
	}

	/**
	 * An existing marker is dragged. Therefore we have to simulate the situation that the marker to
	 * be dragged gets a new position. The old position of the marker is used for the method to
	 * identify which position is to be removed. The positions list must not contain the old
	 * position but the new position after the marker was dragged
	 */
	@Test
	public void markerDraggedTest()
	{
		geofenceMapListener = new GeofenceMapListener(googleMap, positions, markers);
		GoogleMapMarker draggedMarker = markers.get(0);
		LatLon oldPosition = draggedMarker.getPosition();
		draggedMarker.setPosition(new LatLon(50, 50));
		Assert.assertEquals(10, geofenceMapListener.getGeofenceCoordinates().size());
		Assert.assertEquals(10, geofenceMapListener.getGeofenceMarkers().size());
		Assert.assertTrue(positions.contains(oldPosition));
		geofenceMapListener.markerDragged(draggedMarker, oldPosition);
		Assert.assertEquals(10, geofenceMapListener.getGeofenceCoordinates().size());
		Assert.assertEquals(10, geofenceMapListener.getGeofenceMarkers().size());
		Assert.assertFalse(positions.contains(oldPosition));
		Assert.assertTrue(positions.contains(draggedMarker.getPosition()));
	}

	/**
	 * Tests if a null marker can be dragged. Nothing should happen. The old position still is
	 * available and the new position is not added to the list
	 */
	@Test
	public void markerDraggedNullMarkerTest()
	{
		geofenceMapListener = new GeofenceMapListener(googleMap, positions, markers);
		GoogleMapMarker draggedMarker = markers.get(0);
		LatLon oldPosition = draggedMarker.getPosition();
		LatLon newPosition = new LatLon(50, 50);
		draggedMarker.setPosition(newPosition);
		Assert.assertEquals(10, geofenceMapListener.getGeofenceCoordinates().size());
		Assert.assertEquals(10, geofenceMapListener.getGeofenceMarkers().size());
		Assert.assertTrue(positions.contains(oldPosition));
		geofenceMapListener.markerDragged(null, oldPosition);
		Assert.assertEquals(10, geofenceMapListener.getGeofenceCoordinates().size());
		Assert.assertEquals(10, geofenceMapListener.getGeofenceMarkers().size());
		Assert.assertTrue(positions.contains(oldPosition));
		Assert.assertFalse(positions.contains(newPosition));
	}

	/**
	 * Tests if a marker with a null old position can be dragged. Nothing should happen.
	 */
	@Test
	public void markerDraggedNulOldPositionTest()
	{
		geofenceMapListener = new GeofenceMapListener(googleMap, positions, markers);
		GoogleMapMarker draggedMarker = markers.get(0);
		LatLon oldPosition = null;
		LatLon newPosition = new LatLon(50, 50);
		draggedMarker.setPosition(newPosition);
		Assert.assertEquals(10, geofenceMapListener.getGeofenceCoordinates().size());
		Assert.assertEquals(10, geofenceMapListener.getGeofenceMarkers().size());
		geofenceMapListener.markerDragged(draggedMarker, oldPosition);
		Assert.assertEquals(10, geofenceMapListener.getGeofenceCoordinates().size());
		Assert.assertEquals(10, geofenceMapListener.getGeofenceMarkers().size());
		Assert.assertFalse(positions.contains(newPosition));
	}

	/**
	 * Adding a marker to the map. Checking if all lists are refreshed and if the map contains the
	 * newly added marker
	 */
	@Test
	public void markerAddTest()
	{
		List<LatLon> positions = new ArrayList<>();
		List<GoogleMapMarker> markers = new ArrayList<>();
		LatLon position = new LatLon(50, 50);
		geofenceMapListener = new GeofenceMapListener(googleMap, positions, markers);
		Assert.assertEquals(0, geofenceMapListener.getGeofenceCoordinates().size());
		Assert.assertEquals(0, geofenceMapListener.getGeofenceMarkers().size());
		geofenceMapListener.mapClicked(position);
		Assert.assertEquals(1, geofenceMapListener.getGeofenceCoordinates().size());
		Assert.assertEquals(1, geofenceMapListener.getGeofenceMarkers().size());
		Assert.assertEquals(1, googleMap.getMarkers().size());
		GoogleMapMarker addedMarker = geofenceMapListener.getGeofenceMarkers().get(0);
		Assert.assertEquals("VAADIN/themes/dashboard/img/thumb-tack.png", addedMarker.getIconUrl());
		Assert.assertEquals("", addedMarker.getCaption());
		Assert.assertEquals(position, addedMarker.getPosition());
		Assert.assertEquals(true, addedMarker.isDraggable());
	}

	/**
	 * Adds a null position marker. Nothing should happen
	 */
	@Test
	public void markerAddNullPositionTest()
	{
		List<LatLon> positions = new ArrayList<>();
		List<GoogleMapMarker> markers = new ArrayList<>();
		LatLon position = null;
		geofenceMapListener = new GeofenceMapListener(googleMap, positions, markers);
		Assert.assertEquals(0, geofenceMapListener.getGeofenceCoordinates().size());
		Assert.assertEquals(0, geofenceMapListener.getGeofenceMarkers().size());
		geofenceMapListener.mapClicked(position);
		Assert.assertEquals(0, geofenceMapListener.getGeofenceCoordinates().size());
		Assert.assertEquals(0, geofenceMapListener.getGeofenceMarkers().size());
		Assert.assertEquals(0, googleMap.getMarkers().size());
	}

	private List<LatLon> createPositions()
	{
		List<LatLon> positions = new ArrayList<>();
		for (int i = 0; i < 10; i++)
		{
			LatLon position = new LatLon(i - 1, i + 1);
			positions.add(position);
		}

		return positions;
	}

	private List<GoogleMapMarker> createMarkers(List<LatLon> positions)
	{
		List<GoogleMapMarker> markers = new ArrayList<>();
		for (LatLon position : positions)
		{
			GoogleMapMarker marker = new GoogleMapMarker(("Test" + String.valueOf(position)),
					position, false);
			markers.add(marker);
		}
		return markers;
	}
}
