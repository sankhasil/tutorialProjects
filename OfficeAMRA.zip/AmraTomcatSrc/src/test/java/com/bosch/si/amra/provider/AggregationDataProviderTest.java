
package com.bosch.si.amra.provider;

import java.io.IOException;
import java.io.InputStream;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.apache.commons.io.IOUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.entity.report.MileageValue;
import com.bosch.si.amra.entity.report.SensorValue;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.util.JSON;

import mockit.Expectations;
import mockit.Mocked;

@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (locations = "file:src/test/resources/spring-servlet.xml")
public class AggregationDataProviderTest
{
	private static final TimeZone	TIME_ZONE_UTC	= TimeZone.getTimeZone("UTC");

	@Autowired
	private AggregationDataProvider	aggregationDataProvider;

	@Value ("${MONGO_HOST}")
	public String					MONGO_HOST;

	@Value ("${MONGO_PORT}")
	public Integer					MONGO_PORT;

	@Value ("${MONGO_DATABASE}")
	public String					MONGO_DATABASE;

	@Value ("${MONGO_USERNAME}")
	public String					MONGO_USERNAME;

	@Value ("${MONGO_PASSWORD}")
	public String					MONGO_PASSWORD;

	@Value ("${MONGO_COLLECTION}")
	public String					MONGO_COLLECTION;

	@Value ("${MILEAGE_COLLECTION}")
	public String					MILEAGE_COLLECTION;

	@Value ("${EVENT_COLLECTION}")
	public String					EVENT_COLLECTION;

	@Value ("${ROUTING_COLLECTION}")
	public String					ROUTING_COLLECTION;

	@Value ("${CURRENT_COLLECTION}")
	public String					CURRENT_COLLECTION;

	@Value ("${WAGON_COLLECTION}")
	public String					WAGON_COLLECTION;

	@Mocked
	DashboardUI						dashboardUi;

	@After
	public void tearDown() throws UnknownHostException
	{
		getMongoClient();
		additionalCollectionExpectation();
		DBCollection collection = getCollection(DashboardUI.getWagonCollection());
		collection.remove(new BasicDBObject());
		collection = getCollection(DashboardUI.getMongoCurrentCollection());
		collection.remove(new BasicDBObject());
		collection = getCollection(DashboardUI.getMongoMileageCollection());
		collection.remove(new BasicDBObject());
		collection = getCollection(DashboardUI.getEventCollection());
		collection.remove(new BasicDBObject());
	}

	@Test
	public void getTopFiveMileageTest() throws IOException
	{
		getMongoClient();
		additionalCollectionExpectation();
		fillTestDB();
		List<Wagon> topFiveMileage = aggregationDataProvider.getTopFiveMileage(createUser());
		Assert.assertNotNull(topFiveMileage);
		Assert.assertTrue(topFiveMileage.size() >= 4);
		Assert.assertEquals(new Integer(1962), topFiveMileage.get(0).getMileage());
	}

	@Test
	public void getTopFiveMileageWithPositiveOffsetTest() throws IOException
	{
		getMongoClient();
		additionalCollectionExpectation();
		fillTestDB("/testData/wagon/wagonWithPositiveOffset.json");
		List<Wagon> topFiveMileage = aggregationDataProvider.getTopFiveMileage(createUser());
		Assert.assertNotNull(topFiveMileage);
		Assert.assertTrue(topFiveMileage.size() >= 4);
		Assert.assertEquals(new Integer(2000), topFiveMileage.get(0).getMileage());
	}

	@Test
	public void getTopFiveMileageWithNegativeOffsetTest() throws IOException
	{
		getMongoClient();
		additionalCollectionExpectation();
		fillTestDB("/testData/wagon/wagonWithNegativeOffset.json");
		List<Wagon> topFiveMileage = aggregationDataProvider.getTopFiveMileage(createUser());
		Assert.assertNotNull(topFiveMileage);
		Assert.assertTrue(topFiveMileage.size() >= 4);
		Assert.assertEquals(new Integer(1962), topFiveMileage.get(0).getMileage());
		Assert.assertEquals(new Integer(800), topFiveMileage.get(1).getMileage());
		Assert.assertEquals(new Integer(682), topFiveMileage.get(2).getMileage());
		Assert.assertEquals(new Integer(234), topFiveMileage.get(3).getMileage());
	}

	@Test
	public void getTopFiveMileageForDisponentTest() throws IOException
	{
		getMongoClient();
		additionalCollectionExpectation();
		fillTestDB();
		User disponent = createUser();
		disponent.setAdmin(false);
		disponent.setId("7523a8e0-6e39-11e4-8035-0050569350e8");
		List<Wagon> topFiveMileage = aggregationDataProvider.getTopFiveMileage(disponent);
		Assert.assertNotNull(topFiveMileage);
		Assert.assertEquals(2, topFiveMileage.size());
		for (Wagon wagon : topFiveMileage)
		{
			if (wagon.getAlias().equals("TestWagon2"))
				Assert.assertEquals(new Integer(254), wagon.getMileage());
			if (wagon.getAlias().equals("TestWagon1"))
				Assert.assertEquals(new Integer(880), wagon.getMileage());
		}
	}

	@Test (expected = IllegalArgumentException.class)
	public void getTopFiveMileageNullTenantTest()
	{
		aggregationDataProvider.getTopFiveMileage(null);
	}

	@Test (expected = IllegalArgumentException.class)
	public void getTopFiveMileageEmptyTenantTest()
	{
		User user = createUser();
		user.setTenant("");
		aggregationDataProvider.getTopFiveMileage(user);
	}

	@Test
	public void getTopFiveMileageNotExistentTenantTest() throws IOException
	{
		getMongoClient();
		additionalCollectionExpectation();
		fillTestDB();
		User user = createUser();
		user.setTenant("12345");
		List<Wagon> topFiveMileage = aggregationDataProvider.getTopFiveMileage(user);
		Assert.assertNotNull(topFiveMileage);
		Assert.assertTrue(topFiveMileage.size() == 0);
	}

	@Test
	public void getMileageReport() throws IOException
	{
		getMongoClient();
		additionalCollectionExpectation();
		fillTestDB();

		Calendar calendar = getCalendar();
		Map<String, List<MileageValue>> mileage = aggregationDataProvider.getMileage(
				"cbeaa370-c11d-11e1-8ba8-d4bed92ae488",
				Arrays.asList("5a3e9bde-5bfe-4697-8929-f7dcd76c93eb",
						"5a3e9bde-5bfe-4697-8929-f7dcd76c93ec"),
				calendar.getTime());
		Assert.assertNotNull(mileage);
		Assert.assertTrue(mileage.values().size() == 2);
		Assert.assertTrue(mileage.keySet().size() == 2);
		Assert.assertTrue(mileage.containsKey("TestWagon1"));
		Assert.assertTrue(mileage.containsKey("TestWagon2"));
		List<MileageValue> list = mileage.get("TestWagon1");
		Assert.assertNotNull(list);
		Assert.assertTrue(list.size() == 1);
		MileageValue mileageValue = list.get(0);
		Assert.assertEquals(880, mileageValue.getMileage().intValue());
		list = mileage.get("TestWagon2");
		Assert.assertNotNull(list);
		Assert.assertTrue(list.size() == 1);
		mileageValue = list.get(0);
		Assert.assertEquals(254, mileageValue.getMileage().intValue());

		Calendar actual = Calendar.getInstance(TIME_ZONE_UTC);
		actual.setTime(mileageValue.getDate());
		actual.set(Calendar.MILLISECOND, 0);
		calendar.set(Calendar.YEAR, 2014);
		calendar.set(Calendar.MONTH, 10);
		calendar.set(Calendar.DATE, 10);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		Assert.assertEquals(calendar.getTime(), actual.getTime());
	}

	@Test (expected = IllegalArgumentException.class)
	public void getMileageReportNullTenant()
	{
		aggregationDataProvider.getMileage(null,
				Arrays.asList("5a3e9bde-5bfe-4697-8929-f7dcd76c93eb",
						"5a3e9bde-5bfe-4697-8929-f7dcd76c93ec"),
				getCalendar().getTime());
	}

	@Test (expected = IllegalArgumentException.class)
	public void getMileageReportEmptyTenant()
	{
		aggregationDataProvider.getMileage("", Arrays.asList("5a3e9bde-5bfe-4697-8929-f7dcd76c93eb",
				"5a3e9bde-5bfe-4697-8929-f7dcd76c93ec"), getCalendar().getTime());
	}

	@Test (expected = IllegalArgumentException.class)
	public void getMileageReportNullBoxIds()
	{
		aggregationDataProvider.getMileage("cbeaa370-c11d-11e1-8ba8-d4bed92ae488", null,
				getCalendar().getTime());
	}

	@SuppressWarnings ("unchecked")
	@Test (expected = IllegalArgumentException.class)
	public void getMileageReportEmptylBoxIds()
	{
		aggregationDataProvider.getMileage("cbeaa370-c11d-11e1-8ba8-d4bed92ae488",
				Collections.EMPTY_LIST, getCalendar().getTime());
	}

	@Test (expected = IllegalArgumentException.class)
	public void getMileageReportNullCalendar()
	{
		aggregationDataProvider.getMileage("cbeaa370-c11d-11e1-8ba8-d4bed92ae488",
				Arrays.asList("5a3e9bde-5bfe-4697-8929-f7dcd76c93eb",
						"5a3e9bde-5bfe-4697-8929-f7dcd76c93ec"),
				null);
	}

	@Test
	public void getSensorReport() throws IOException
	{
		Calendar calendar = getCalendar();
		getMongoClient();
		additionalCollectionExpectation();
		fillTestDB();

		Map<String, List<SensorValue>> sensor = aggregationDataProvider.getSensorValues(
				"cbeaa370-c11d-11e1-8ba8-d4bed92ae488",
				Arrays.asList("5a3e9bde-5bfe-4697-8929-f7dcd76c93ec"), calendar.getTime());
		Assert.assertNotNull(sensor);
		Assert.assertTrue(sensor.values().size() == 1);
		Assert.assertTrue(sensor.keySet().size() == 1);
		Assert.assertTrue(sensor.containsKey("Wagon"));
		List<SensorValue> list = sensor.get("Wagon");
		Assert.assertNotNull(list);
		Assert.assertTrue(list.size() == 5);

		for (SensorValue sensorValue : list)
		{
			if ("Waiblingen".equalsIgnoreCase(sensorValue.getCity()))
			{
				Assert.assertEquals("Waiblingen", sensorValue.getCity());
				Assert.assertNull(sensorValue.getHumidity());
				Assert.assertEquals(1, sensorValue.getTemperature().intValue());

				Calendar actual = Calendar.getInstance(TIME_ZONE_UTC);
				actual.setTime(sensorValue.getTimestamp());
				actual.set(Calendar.MILLISECOND, 0);

				calendar.set(Calendar.YEAR, 2014);
				calendar.set(Calendar.MONTH, 11);
				calendar.set(Calendar.DATE, 11);
				calendar.set(Calendar.HOUR_OF_DAY, 9);
				calendar.set(Calendar.MINUTE, 38);
				calendar.set(Calendar.SECOND, 31);
				calendar.set(Calendar.MILLISECOND, 0);
				Assert.assertEquals(calendar.getTime(), actual.getTime());
			}
			calendar.set(Calendar.YEAR, 2014);
			calendar.set(Calendar.MONTH, 11);
			calendar.set(Calendar.DATE, 10);
			calendar.set(Calendar.HOUR_OF_DAY, 10);
			calendar.set(Calendar.MINUTE, 38);
			calendar.set(Calendar.SECOND, 31);
			calendar.set(Calendar.MILLISECOND, 0);
			Calendar sensorTimestamp = Calendar.getInstance(TIME_ZONE_UTC);
			sensorTimestamp.setTime(sensorValue.getTimestamp());
			sensorTimestamp.set(Calendar.MILLISECOND, 0);
			if (calendar.getTime().compareTo(sensorTimestamp.getTime()) == 0)
			{
				Assert.assertNull(sensorValue.getTemperature());
			}
		}

	}

	@Test (expected = IllegalArgumentException.class)
	public void getSensorReportNullTenant()
	{
		aggregationDataProvider.getSensorValues(null,
				Arrays.asList("5a3e9bde-5bfe-4697-8929-f7dcd76c93eb"), getCalendar().getTime());
	}

	@Test (expected = IllegalArgumentException.class)
	public void getSensorReportEmptyTenant()
	{
		aggregationDataProvider.getSensorValues("",
				Arrays.asList("5a3e9bde-5bfe-4697-8929-f7dcd76c93eb"), getCalendar().getTime());
	}

	@Test (expected = IllegalArgumentException.class)
	public void getSensorReportNullBoxIds()
	{
		aggregationDataProvider.getSensorValues("cbeaa370-c11d-11e1-8ba8-d4bed92ae488", null,
				getCalendar().getTime());
	}

	@SuppressWarnings ("unchecked")
	@Test (expected = IllegalArgumentException.class)
	public void getSensorReportEmptylBoxIds()
	{
		aggregationDataProvider.getSensorValues("cbeaa370-c11d-11e1-8ba8-d4bed92ae488",
				Collections.EMPTY_LIST, getCalendar().getTime());
	}

	@Test (expected = IllegalArgumentException.class)
	public void getSensorReportNullCalendar()
	{
		aggregationDataProvider.getSensorValues("cbeaa370-c11d-11e1-8ba8-d4bed92ae488",
				Arrays.asList("5a3e9bde-5bfe-4697-8929-f7dcd76c93eb"), null);
	}

	@Test
	public void getMaximumHumidityTest() throws IOException
	{
		getMongoClient();
		additionalCollectionExpectation();
		fillTestDB();

		Wagon wagon = aggregationDataProvider.getMaximumHumidity(createUser());
		Assert.assertEquals(new Integer(90), wagon.getHumidity());
	}

	@Test
	public void getMaximumHumidityForDisponentTest() throws IOException
	{
		getMongoClient();
		additionalCollectionExpectation();
		fillTestDB();
		User disponent = createUser();
		disponent.setAdmin(false);
		disponent.setId("7523a8e0-6e39-11e4-8035-0050569350e8");
		Wagon wagon = aggregationDataProvider.getMaximumHumidity(disponent);
		Assert.assertEquals(new Integer(49), wagon.getHumidity());
	}

	@Test
	public void getMaximumHumidityNoDataTest() throws IOException
	{
		getMongoClient();
		User user = createUser();
		user.setTenant("notExistingTenant");
		Wagon wagon = aggregationDataProvider.getMaximumHumidity(user);

		Assert.assertNull(wagon);
	}

	@Test
	public void getMaximumAmbientTemperatureTest() throws IOException
	{
		getMongoClient();
		additionalCollectionExpectation();
		fillTestDB();

		Wagon wagon = aggregationDataProvider.getMaximumAmbientTemperature(createUser());
		Assert.assertEquals(new Integer(26), wagon.getTemperature());
	}

	@Test
	public void getMaximumAmbientTemperatureForDisponentTest() throws IOException
	{
		getMongoClient();
		additionalCollectionExpectation();
		fillTestDB();
		User disponent = createUser();
		disponent.setAdmin(false);
		disponent.setId("7523a8e0-6e39-11e4-8035-0050569350e8");
		Wagon wagon = aggregationDataProvider.getMaximumAmbientTemperature(disponent);
		Assert.assertEquals(new Integer(10), wagon.getTemperature());
	}

	@Test
	public void getMaximumAmbientTemperatureNoDataTest() throws IOException
	{
		getMongoClient();
		User user = createUser();
		user.setTenant("notExistingTenant");
		Wagon wagon = aggregationDataProvider.getMaximumAmbientTemperature(user);
		Assert.assertNull(wagon);
	}

	@Test
	public void getMaximumPayloadTemperatureTest() throws IOException
	{
		getMongoClient();
		additionalCollectionExpectation();
		fillTestDB();

		Wagon wagon = aggregationDataProvider.getMaximumPayloadTemperature(createUser());
		Assert.assertEquals(new Integer(58), wagon.getHumidityTemperature());
	}

	@Test
	public void getMaximumPayloadTemperatureForDisponentTest() throws IOException
	{
		getMongoClient();
		additionalCollectionExpectation();
		fillTestDB();
		User disponent = createUser();
		disponent.setAdmin(false);
		disponent.setId("7523a8e0-6e39-11e4-8035-0050569350e8");
		Wagon wagon = aggregationDataProvider.getMaximumPayloadTemperature(disponent);
		Assert.assertEquals(new Integer(31), wagon.getHumidityTemperature());
	}

	@Test
	public void getMaximumPayloadTemperatureNoDataTest() throws IOException
	{
		getMongoClient();
		User user = createUser();
		user.setTenant("notExistingTenant");
		Wagon wagon = aggregationDataProvider.getMaximumPayloadTemperature(user);
		Assert.assertNull(wagon);
	}

	private MongoClient getMongoClient() throws UnknownHostException
	{
		new Expectations()
		{
			{
				DashboardUI.getMongoUsername();
				returns(MONGO_USERNAME);
				DashboardUI.getMongoPassword();
				returns(MONGO_PASSWORD);
				DashboardUI.getMongoDatabase();
				returns(MONGO_DATABASE);
				DashboardUI.getMongoHost();
				returns(MONGO_HOST);
				DashboardUI.getMongoPort();
				returns(MONGO_PORT);
				DashboardUI.getMongoCurrentCollection();
				returns(CURRENT_COLLECTION);
			}
		};
		DataProviderInitializer.createMongoClient();
		return DataProviderInitializer.getMongoClient();
	}

	private void additionalCollectionExpectation()
	{
		new Expectations()
		{
			{
				DashboardUI.getWagonCollection();
				returns(WAGON_COLLECTION);
				DashboardUI.getMongoMileageCollection();
				returns(MILEAGE_COLLECTION);
				DashboardUI.getEventCollection();
				returns(EVENT_COLLECTION);
			}
		};
	}

	private Calendar getCalendar()
	{
		Calendar calendar = Calendar.getInstance(TIME_ZONE_UTC);
		calendar.set(Calendar.YEAR, 2014);
		calendar.set(Calendar.MONTH, 9);
		return calendar;
	}

	@SuppressWarnings ("unchecked")
	private void fillTestDB(String... values) throws IOException
	{

		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection collection = db.getCollection(DashboardUI.getMongoCurrentCollection());
		InputStream testMessage = AggregationDataProviderTest.class
				.getResourceAsStream("/testData/current/current.json");
		String message = IOUtils.toString(testMessage, "UTF-8");

		Object parse = JSON.parse(message);
		List<DBObject> objectToSave = (List<DBObject>) parse;
		collection.insert(objectToSave);

		collection = db.getCollection(DashboardUI.getMongoMileageCollection());
		testMessage = this.getClass().getResourceAsStream("/testData/mileage/mileage.json");
		message = IOUtils.toString(testMessage, "UTF-8");

		parse = JSON.parse(message);
		objectToSave = (List<DBObject>) parse;
		collection.insert(objectToSave);

		collection = db.getCollection(DashboardUI.getEventCollection());
		testMessage = this.getClass().getResourceAsStream("/testData/telematic/mainTelematic.json");
		message = IOUtils.toString(testMessage, "UTF-8");

		parse = JSON.parse(message);
		objectToSave = (List<DBObject>) parse;
		collection.insert(objectToSave);

		collection = db.getCollection(DashboardUI.getWagonCollection());
		String wagonResourcePath = (values.length == 0 ? "/testData/wagon/wagon.json" : values[0]);
		testMessage = this.getClass().getResourceAsStream(wagonResourcePath);
		String wagon = IOUtils.toString(testMessage, "UTF-8");

		parse = JSON.parse(wagon);
		objectToSave = (List<DBObject>) parse;
		collection.insert(objectToSave);
	}

	private DBCollection getCollection(String collectionName) throws UnknownHostException
	{
		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		return db.getCollection(collectionName);
	}

	private User createUser()
	{
		User user = new User();
		user.setTenant("cbeaa370-c11d-11e1-8ba8-d4bed92ae488");
		user.setAdmin(true);
		return user;
	}
}
