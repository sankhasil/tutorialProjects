
package com.bosch.si.amra.provider;

import java.io.IOException;
import java.io.InputStream;
import java.net.UnknownHostException;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;
import java.util.stream.Collectors;

import org.apache.commons.io.IOUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.entity.notification.Address;
import com.bosch.si.amra.provider.details.DetailsDataProvider;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.util.JSON;

import mockit.Expectations;
import mockit.Mocked;

@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (locations = "file:src/test/resources/spring-servlet.xml")
public class DetailsDataProviderTest
{
	private static final TimeZone	TIME_ZONE_UTC			= TimeZone.getTimeZone("UTC");

	private static final String		WAGON_ID_E8BE7ECF_8F	= "e8be7ecf-eef0-4fdc-9dc6-3003f1f95c8f";

	private static final String		WAGON_ID_E9A664E9_3C	= "e9a664e9-18e6-4ac5-b40f-ee7f55a7903c";

	private static final String		WAGON_ID_A08F633D_9F	= "a08f633d-3742-4d53-8e7b-94188f965e9f";

	private static final String		WAGON_ID_2C9D33F9_4E	= "2c9d33f9-3f24-4bc5-8cfa-7266e32aa64e";

	private static final String		WAGON_ID_5A3E9BDE_EC	= "5a3e9bde-5bfe-4697-8929-f7dcd76c93ec";

	@Autowired
	private DetailsDataProvider		detailsDataProvider;

	@Value ("${MONGO_HOST}")
	public String					MONGO_HOST;

	@Value ("${MONGO_PORT}")
	public Integer					MONGO_PORT;

	@Value ("${MONGO_DATABASE}")
	public String					MONGO_DATABASE;

	@Value ("${MONGO_USERNAME}")
	public String					MONGO_USERNAME;

	@Value ("${MONGO_PASSWORD}")
	public String					MONGO_PASSWORD;

	@Value ("${TELEMATIC_UNWIND_COLLECTION}")
	public String					TELEMATIC_UNWIND_COLLECTION;

	@Mocked
	DashboardUI						dashboardUi;

	@After
	public void tearDown() throws UnknownHostException
	{
		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		DBCollection collection = db.getCollection(DashboardUI.getTelematicUnwind());
		collection.remove(new BasicDBObject());
		mongoClient.close();
	}

	@Test
	public void getWagonsTest() throws IOException
	{
		getMongoClient();
		fillTestDB("mainTelematic.json");
		List<Wagon> wagons = detailsDataProvider.getTelematicDataForWagon(WAGON_ID_5A3E9BDE_EC);
		Assert.assertNotNull(wagons);
		Assert.assertEquals(5, wagons.size());
		wagons.forEach(wagon -> {
			Assert.assertNull(wagon.getBatteryLevel());
			Assert.assertNull(wagon.getBatterySeverity());
			Assert.assertNull(wagon.getHumidity());
			Assert.assertNull(wagon.getHumidityTemperature());
			Assert.assertNull(wagon.getMileage());
			Assert.assertNull(wagon.getT1Temperature());
			Assert.assertNull(wagon.getTemperature());
			Assert.assertNull(wagon.getWagonType());
			Assert.assertNull(wagon.getAlias());
			Assert.assertNull(wagon.getTenantId());
			Assert.assertNull(wagon.getBoxId());
			Assert.assertNotNull(wagon.getTimestamp());
			Assert.assertNotNull(wagon.getAddress());
			Assert.assertNotNull(wagon.getId());
			Assert.assertNotNull(wagon.getLatLong());
			if (wagon.getId().equals(WAGON_ID_2C9D33F9_4E))
			{
				Calendar expectedDate = Calendar.getInstance(TIME_ZONE_UTC);
				expectedDate.set(2014, 11, 11, 9, 38, 31);
				expectedDate.set(Calendar.MILLISECOND, 0);
				Calendar actualDate = Calendar.getInstance(TIME_ZONE_UTC);
				actualDate.setTime(wagon.getTimestamp());
				actualDate.set(Calendar.MILLISECOND, 0);
				Assert.assertEquals(expectedDate.getTime(), actualDate.getTime());
				Address address = wagon.getAddress();
				Assert.assertEquals("Stuttgarter Str. 130, 71332 Waiblingen, Deutschland",
						address.getFormattedAddress());
				Assert.assertEquals("Stuttgarter Straße 130", address.getStreet());
				Assert.assertEquals("71332 Waiblingen", address.getCity());
				Assert.assertEquals("Deutschland", address.getCountry());
				Assert.assertEquals(Double.valueOf(48.8231635),
						(Double) wagon.getLatLong().getLat());
				Assert.assertEquals(Double.valueOf(9.2936913),
						(Double) wagon.getLatLong().getLng());
			}
		});
	}

	/**
	 * Tests if mixed data, documents with GF = 3 and GF != 3 are retrieved properly. In this case 5
	 * documents are stored and those documents with GF != 3 contain a trip started or trip ended
	 * key with a TU greater than 01.01.2016. So we are expecting to retrieve 5 documents
	 *
	 * @throws IOException
	 *             - If the json file could not be found
	 */
	@Test
	public void getWagonsMixedGF3AndGFNotEqual3Test() throws IOException
	{
		getMongoClient();
		fillTestDB("historyMixed.json");
		List<Wagon> wagons = detailsDataProvider.getTelematicDataForWagon(WAGON_ID_5A3E9BDE_EC);
		Assert.assertNotNull(wagons);
		Assert.assertEquals(5, wagons.size());
		wagons.forEach(wagon -> {
			if (wagon.getId().equals(WAGON_ID_A08F633D_9F))
			{
				Calendar expectedDate = Calendar.getInstance(TIME_ZONE_UTC);
				expectedDate.set(2016, 1, 11, 10, 38, 31);
				expectedDate.set(Calendar.MILLISECOND, 0);
				Calendar actualDate = Calendar.getInstance(TIME_ZONE_UTC);
				actualDate.setTime(wagon.getTimestamp());
				actualDate.set(Calendar.MILLISECOND, 0);
				Assert.assertEquals(expectedDate.getTime(), actualDate.getTime());
				Assert.assertEquals(new Integer(4), wagon.getCollectCause());
			}
			if (wagon.getId().equals(WAGON_ID_E9A664E9_3C))
			{
				Calendar expectedDate = Calendar.getInstance(TIME_ZONE_UTC);
				expectedDate.set(2016, 1, 11, 12, 38, 31);
				expectedDate.set(Calendar.MILLISECOND, 0);
				Calendar actualDate = Calendar.getInstance(TIME_ZONE_UTC);
				actualDate.setTime(wagon.getTimestamp());
				actualDate.set(Calendar.MILLISECOND, 0);
				Assert.assertEquals(expectedDate.getTime(), actualDate.getTime());
				Assert.assertEquals(new Integer(16), wagon.getCollectCause());
			}
		});
	}

	/**
	 * We have a mixed history with GF = 3 and GF != 3 but the TU contains data before 2016. So they
	 * should not be considered in the retrieved wagon history list
	 *
	 * @throws IOException
	 *             - If the json file could not be found
	 */
	@Test
	public void getWagonsMixedGF3AndGFNotEqual3LessThan2016Test() throws IOException
	{
		getMongoClient();
		fillTestDB("historyMixedWithTULessThan2016.json");
		List<Wagon> wagons = detailsDataProvider.getTelematicDataForWagon(WAGON_ID_5A3E9BDE_EC);
		Assert.assertNotNull(wagons);
		Assert.assertEquals(4, wagons.size());
	}

	/**
	 * Only documents with GF != 3 are provided. Three of the five documents contain a trip started
	 * or trip ended flag with a TU greater than 2016. Therefore we expect three documents to be
	 * returned
	 *
	 * @throws IOException
	 *             - If the json file could not be found
	 */
	@Test
	public void getWagonsOnlyGFNotEqual3Test() throws IOException
	{
		getMongoClient();
		fillTestDB("historyOnlyTU.json");
		List<Wagon> wagons = detailsDataProvider.getTelematicDataForWagon(WAGON_ID_5A3E9BDE_EC);
		Assert.assertNotNull(wagons);
		Assert.assertEquals(3, wagons.size());
		wagons.forEach(wagon -> {
			if (wagon.getId().equals(WAGON_ID_A08F633D_9F))
			{
				checkData(wagon, 10, 4);
			}
			if (wagon.getId().equals(WAGON_ID_E9A664E9_3C))
			{
				checkData(wagon, 12, 16);
			}
			if (wagon.getId().equals(WAGON_ID_E8BE7ECF_8F))
			{
				checkData(wagon, 13, 15);
			}
		});
	}

	/**
	 * Tests what wagons are retrieved after specific activation date, all are 5 but the first is
	 * out of range.
	 */
	@Test
	public void getWagonsAfterActivationDateTest() throws IOException
	{
		getMongoClient();
		fillTestDB("mainTelematic.json");
		Calendar activationDate = Calendar.getInstance(TIME_ZONE_UTC);
		activationDate.set(2014, 11, 11, 9, 38, 31);
		activationDate.set(Calendar.MILLISECOND, 0);
		List<Wagon> wagons = detailsDataProvider.getTelematicDataForWagon(WAGON_ID_5A3E9BDE_EC)
				.stream().filter(telematicWagon -> telematicWagon.getTimestamp()
						.after(activationDate.getTime()))
				.collect(Collectors.toList());

		Assert.assertNotNull(wagons);
		Assert.assertEquals(4, wagons.size());
	}

	private void checkData(Wagon wagon, int hour, int collectCause)
	{
		Calendar expectedDate = Calendar.getInstance(TIME_ZONE_UTC);
		expectedDate.set(2016, 1, 11, hour, 38, 31);
		expectedDate.set(Calendar.MILLISECOND, 0);
		Calendar actualDate = Calendar.getInstance(TIME_ZONE_UTC);
		actualDate.setTime(wagon.getTimestamp());
		actualDate.set(Calendar.MILLISECOND, 0);
		Assert.assertEquals(expectedDate.getTime(), actualDate.getTime());
		Assert.assertEquals(new Integer(collectCause), wagon.getCollectCause());
	}

	@Test (expected = IllegalArgumentException.class)
	public void getWagonsNullTest() throws IOException
	{
		getMongoClient();
		fillTestDB("mainTelematic.json");
		detailsDataProvider.getTelematicDataForWagon(null);
	}

	@Test (expected = IllegalArgumentException.class)
	public void getWagonsEmpyTest() throws IOException
	{
		getMongoClient();
		fillTestDB("mainTelematic.json");
		detailsDataProvider.getTelematicDataForWagon("");
	}

	private MongoClient getMongoClient() throws UnknownHostException
	{
		new Expectations()
		{
			{
				DashboardUI.getMongoUsername();
				returns(MONGO_USERNAME);
				DashboardUI.getMongoPassword();
				returns(MONGO_PASSWORD);
				DashboardUI.getMongoDatabase();
				returns(MONGO_DATABASE);
				DashboardUI.getMongoHost();
				returns(MONGO_HOST);
				DashboardUI.getMongoPort();
				returns(MONGO_PORT);
				DashboardUI.getTelematicUnwind();
				returns(TELEMATIC_UNWIND_COLLECTION);
			}
		};
		DataProviderInitializer.createMongoClient();
		return DataProviderInitializer.getMongoClient();
	}

	@SuppressWarnings ("unchecked")
	private void fillTestDB(String fileName) throws IOException
	{
		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection collection = db.getCollection(DashboardUI.getTelematicUnwind());
		InputStream testMessage = AggregationDataProviderTest.class
				.getResourceAsStream("/testData/telematic/" + fileName);
		String message = IOUtils.toString(testMessage, "UTF-8");

		Object parse = JSON.parse(message);
		List<DBObject> objectListToSave = (List<DBObject>) parse;
		collection.insert(objectListToSave);
	}
}
