
package com.bosch.si.amra.view.overview;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.verifyStatic;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.event.DashboardEvent.WagonDetailsEvent;
import com.bosch.si.amra.event.DashboardEvent.WagonSelectedEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.provider.NewDataProvider;
import com.bosch.si.amra.view.AmraView;
import com.bosch.si.fleet.common.internationalization.I18n;
import com.vaadin.server.VaadinSession;
import com.vaadin.ui.Table;
import com.vaadin.ui.UI;

import ru.xpoft.vaadin.DiscoveryNavigator;

@RunWith (PowerMockRunner.class)
@PrepareForTest ({ DashboardUI.class, DashboardEventBus.class, UI.class, VaadinSession.class,
		Table.class })
@Ignore
public class OverviewViewTest
{

	private OverviewView	overview;

	DiscoveryNavigator		navigator;

	List<Wagon>				wagons;

	@Before
	public void setUp()
	{
		wagons = buildList();
		mockStatic(DashboardEventBus.class);
		mockStatic(DashboardUI.class);

		User userMock = mock(User.class);
		VaadinSession sessionMock = mock(VaadinSession.class);
		DashboardUI dashboardUIMock = mock(DashboardUI.class);
		I18n i18nMock = mock(I18n.class);
		NewDataProvider provider = mock(NewDataProvider.class);
		navigator = mock(DiscoveryNavigator.class);

		VaadinSession.setCurrent(sessionMock);
		DashboardUI.setCurrent(dashboardUIMock);

		when(VaadinSession.getCurrent().getAttribute(User.class.getName())).thenReturn(userMock);
		when(DashboardUI.getMessageSource()).thenReturn(i18nMock);
		when(i18nMock.getMessage("view.overview.caption")).thenReturn("Overview");
		when(DashboardUI.getDataProvider()).thenReturn(provider);
		when(provider.getWagons(userMock)).thenReturn(wagons);
		when(DashboardUI.getCurrent().getNavigator()).thenReturn(navigator);

		overview = new OverviewView();
	}

	@Test
	public void showDetailsTest()
	{
		overview.showDetailsForSelection(new ArrayList<Wagon>());

		verify(navigator, times(1)).navigateTo(AmraView.DETAILS.getViewName());
		verifyStatic(times(1));
		DashboardEventBus.post(new WagonDetailsEvent(Mockito.anyListOf(Wagon.class)));
	}

	@Test
	@Ignore
	public void editSelectedWagonTest()
	{
		overview.editSelectedWagon();

		verify(navigator, times(1)).navigateTo(AmraView.ADMINISTRATION.getViewName());
		verifyStatic(times(1));
		DashboardEventBus.post(new WagonSelectedEvent(Mockito.any(Wagon.class)));
	}

	private List<Wagon> buildList()
	{
		List<Wagon> wagonList = new ArrayList<>();
		wagonList.add(new Wagon());
		return wagonList;
	}
}
