
package com.bosch.si.amra.presenter.export;

import java.io.IOException;
import java.io.InputStream;
import java.net.UnknownHostException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.apache.commons.io.IOUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.MongoConstants;
import com.bosch.si.amra.entity.Wagon;
import com.bosch.si.amra.event.DashboardEvent.ExportGenerationEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.provider.DataProviderInitializer;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.util.JSON;
import com.vaadin.server.VaadinSession;
import com.vaadin.ui.UI;

import mockit.Expectations;
import mockit.Mocked;

@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (locations = "file:src/test/resources/spring-servlet.xml")
@PrepareForTest ({ DashboardUI.class })
public class ExportPresenterTest
{

	@Autowired
	private ExportPresenter	exportPresenter;

	@Mocked
	final DashboardEventBus	eventBus	= null;

	@Mocked
	DashboardUI				dashboardUi;

	@Mocked
	UI						ui;

	@Mocked
	VaadinSession			vaadinSession;

	@Value ("${MONGO_HOST}")
	public String			MONGO_HOST;

	@Value ("${MONGO_PORT}")
	public Integer			MONGO_PORT;

	@Value ("${MONGO_DATABASE}")
	public String			MONGO_DATABASE;

	@Value ("${MONGO_USERNAME}")
	public String			MONGO_USERNAME;

	@Value ("${MONGO_PASSWORD}")
	public String			MONGO_PASSWORD;

	@Value ("${EVENT_COLLECTION}")
	public String			EVENT_COLLECTION;

	@Value ("${MILEAGE_COLLECTION}")
	public String			MILEAGE_COLLECTION;

	@Value ("${ROUTING_COLLECTION}")
	public String			ROUTING_COLLECTION;

	@Value ("${CURRENT_COLLECTION}")
	public String			CURRENT_COLLECTION;

	@Value ("${WAGON_COLLECTION}")
	public String			WAGON_COLLECTION;

	@Value ("${WAGON_TYPE_COLLECTION}")
	public String			WAGON_TYPE_COLLECITON;

	@Value ("${CONFIGURATION_COLLECTION}")
	public String			CONFIGURATION_COLLECTION;

	@Before
	public void setUp() throws IOException
	{
		MockitoAnnotations.initMocks(this);
		fillTestDB();

	}

	@After
	public void tearDown() throws UnknownHostException
	{
		new Expectations()
		{
			{
				DashboardUI.getEventCollection();
				returns(EVENT_COLLECTION);
			}
		};
		MongoClient mongoClient = getMongoClient();
		if (mongoClient != null)
		{
			DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
			DBCollection collection = db.getCollection(DashboardUI.getEventCollection());
			collection.remove(new BasicDBObject());

			DBCollection mileageCollection = db
					.getCollection(DashboardUI.getMongoMileageCollection());
			mileageCollection.remove(new BasicDBObject());

		}
		mongoClient.close();
	}

	@Test
	public void onlyLongitudeSelectedTest() throws UnknownHostException
	{
		new Expectations()
		{

			{
				DashboardUI.getMongoUsername();
				returns(MONGO_USERNAME);
				DashboardUI.getMongoPassword();
				returns(MONGO_PASSWORD);
				DashboardUI.getMongoDatabase();
				returns(MONGO_DATABASE);
				DashboardUI.getMongoHost();
				returns(MONGO_HOST);
				DashboardUI.getMongoPort();
				returns(MONGO_PORT);
				DashboardUI.getEventCollection();
				returns(EVENT_COLLECTION);
				DashboardUI.getMessageSource().getMessage("date.format");
				returns("dd.MM.yyyy HH:mm:ss");

				DashboardUI.getMessageSource()
						.getMessage("vaadin.presenter.export.csv.language.locale");
				returns("en_GB");
				DashboardUI.getMessageSource()
						.getMessage("vaadin.presenter.export.csv.separator.decimal");
				returns(".");
				DashboardUI.getMessageSource()
						.getMessage("vaadin.presenter.export.csv.separator.group");
				returns(",");
			}
		};
		DataProviderInitializer.createMongoClient();
		Calendar calendar = Calendar.getInstance();
		calendar.set(2014, 8, 8);
		SimpleDateFormat dateFormatUTC = new SimpleDateFormat("yy-MM-dd HH:mm:ss");
		dateFormatUTC.setTimeZone(TimeZone.getTimeZone("UTC"));

		Date startDate = null;
		Date endDate = null;
		try
		{
			startDate = dateFormatUTC.parse("15-01-01 12:33:23");
			endDate = dateFormatUTC.parse("15-11-11 12:33:23");
		}
		catch (ParseException e)
		{
			Assert.fail("Could not parse message");
		}

		DBCursor cursor = exportPresenter
				.generateCSVExport(new ExportGenerationEvent("cbeaa370-c11d-11e1-8ba8-d4bed92atest",
						getWagonList(), getSelectedFields(), startDate, endDate));

		Iterator<DBObject> d = cursor.iterator();
		Double longitude = null;
		Double latitude = null;

		DBObject next = d.next();
		DBObject telematicData = (DBObject) next.get("D");

		longitude = (Double) telematicData.get("LO");
		latitude = (Double) telematicData.get("LA");

		Assert.assertEquals(new Double(8.87), longitude);
		Assert.assertNull(latitude);

	}

	@Test
	public void allDataSelectedTest() throws UnknownHostException
	{
		new Expectations()
		{

			{
				DashboardUI.getMongoUsername();
				returns(MONGO_USERNAME);
				DashboardUI.getMongoPassword();
				returns(MONGO_PASSWORD);
				DashboardUI.getMongoDatabase();
				returns(MONGO_DATABASE);
				DashboardUI.getMongoHost();
				returns(MONGO_HOST);
				DashboardUI.getMongoPort();
				returns(MONGO_PORT);
				DashboardUI.getEventCollection();
				returns(EVENT_COLLECTION);
				DashboardUI.getMessageSource().getMessage("date.format");
				returns("dd.MM.yyyy HH:mm:ss");
				DashboardUI.getMessageSource()
						.getMessage("vaadin.presenter.export.csv.language.locale");
				returns("en_GB");
				DashboardUI.getMessageSource()
						.getMessage("vaadin.presenter.export.csv.separator.decimal");
				returns(".");
				DashboardUI.getMessageSource()
						.getMessage("vaadin.presenter.export.csv.separator.group");
				returns(",");

				DashboardUI.getMongoMileageCollection();
				returns(MILEAGE_COLLECTION);

			}
		};
		DataProviderInitializer.createMongoClient();
		Calendar calendar = Calendar.getInstance();
		calendar.set(2014, 8, 8);
		SimpleDateFormat dateFormatUTC = new SimpleDateFormat("yy-MM-dd HH:mm:ss");
		dateFormatUTC.setTimeZone(TimeZone.getTimeZone("UTC"));

		Date startDate = null;
		Date endDate = null;
		try
		{
			startDate = dateFormatUTC.parse("15-01-01 12:33:23");
			endDate = dateFormatUTC.parse("15-11-11 12:33:23");
		}
		catch (ParseException e)
		{
			Assert.fail("Could not parse message");
		}

		Map<String, Boolean> selectedFields = getSelectedFields();
		selectedFields.put(MongoConstants.LATITUDE, true);
		selectedFields.put(MongoConstants.ALTITUDE, true);
		selectedFields.put(MongoConstants.HUMIDITY, true);
		selectedFields.put(MongoConstants.DEVICE_TEMPERATURE, true);
		selectedFields.put(MongoConstants.HUMIDITY_TEMPERATURE, true);
		selectedFields.put(MongoConstants.SHOCK, true);

		DBCursor cursor = exportPresenter
				.generateCSVExport(new ExportGenerationEvent("cbeaa370-c11d-11e1-8ba8-d4bed92atest",
						getWagonList(), selectedFields, startDate, endDate));

		Iterator<DBObject> d = cursor.iterator();
		Double longitude = null;
		Double latitude = null;
		Double altitude = null;
		Double humidity = null;
		Integer deviceTemp = null;
		Double humidityTemp = null;
		Integer shock = null;
		Integer mileage = null;

		DBObject next = d.next();
		DBObject telematicData = (DBObject) next.get("D");

		longitude = (Double) telematicData.get("LO");
		latitude = (Double) telematicData.get("LA");

		altitude = (Double) telematicData.get("AL");
		humidity = (Double) telematicData.get("HM");
		deviceTemp = (Integer) telematicData.get("DT");
		humidityTemp = (Double) telematicData.get("HT");
		shock = (Integer) telematicData.get("RX");

		// for mileage
		Iterator<DBObject> mileageData = exportPresenter
				.aggregateMileage(telematicData.get("DA").toString(), next.get("WI").toString())
				.results().iterator();
		if (mileageData.hasNext())
			mileage = (Integer) mileageData.next().get(MongoConstants.MILEAGE);
		else
			mileage = 0;

		Assert.assertEquals(new Double(8.87), longitude);
		Assert.assertEquals(new Double(46.398678), latitude);
		Assert.assertEquals(new Double(393.2), altitude);
		Assert.assertEquals(new Double(48.828125), humidity);
		Assert.assertEquals(new Integer(4), deviceTemp);
		Assert.assertEquals(new Double(14.199219), humidityTemp);
		Assert.assertEquals(new Integer(1), shock);
		Assert.assertEquals(new Integer(2), mileage);

	}

	@Test
	public void outofTimIntevallTest() throws UnknownHostException
	{
		new Expectations()
		{

			{
				DashboardUI.getMongoUsername();
				returns(MONGO_USERNAME);
				DashboardUI.getMongoPassword();
				returns(MONGO_PASSWORD);
				DashboardUI.getMongoDatabase();
				returns(MONGO_DATABASE);
				DashboardUI.getMongoHost();
				returns(MONGO_HOST);
				DashboardUI.getMongoPort();
				returns(MONGO_PORT);
				DashboardUI.getEventCollection();
				returns(EVENT_COLLECTION);

			}
		};
		DataProviderInitializer.createMongoClient();
		Calendar calendar = Calendar.getInstance();
		calendar.set(2014, 8, 8);
		SimpleDateFormat dateFormatUTC = new SimpleDateFormat("yy-MM-dd HH:mm:ss");
		dateFormatUTC.setTimeZone(TimeZone.getTimeZone("UTC"));

		Date startDate = null;
		Date endDate = null;
		try
		{
			startDate = dateFormatUTC.parse("12-01-01 12:33:23");
			endDate = dateFormatUTC.parse("11-11-11 12:33:23");
		}
		catch (ParseException e)
		{
			Assert.fail("Could not parse message");
		}

		Map<String, Boolean> selectedFields = getSelectedFields();
		selectedFields.put(MongoConstants.LATITUDE, true);
		selectedFields.put(MongoConstants.ALTITUDE, true);
		selectedFields.put(MongoConstants.HUMIDITY, true);
		selectedFields.put(MongoConstants.DEVICE_TEMPERATURE, true);
		selectedFields.put(MongoConstants.HUMIDITY_TEMPERATURE, true);
		selectedFields.put(MongoConstants.SHOCK, true);

		DBCursor cursor = exportPresenter
				.generateCSVExport(new ExportGenerationEvent("cbeaa370-c11d-11e1-8ba8-d4bed92atest",
						getWagonList(), selectedFields, startDate, endDate));

		Iterator<DBObject> d = cursor.iterator();

		boolean nextBool = d.hasNext();

		Assert.assertFalse(nextBool);

	}

	private MongoClient getMongoClient() throws UnknownHostException
	{
		new Expectations()
		{
			{
				DashboardUI.getMongoUsername();
				returns(MONGO_USERNAME);
				DashboardUI.getMongoPassword();
				returns(MONGO_PASSWORD);
				DashboardUI.getMongoDatabase();
				returns(MONGO_DATABASE);
				DashboardUI.getMongoHost();
				returns(MONGO_HOST);
				DashboardUI.getMongoPort();
				returns(MONGO_PORT);
				DashboardUI.getMongoMileageCollection();
				returns(MILEAGE_COLLECTION);
			}
		};
		DataProviderInitializer.createMongoClient();
		return DataProviderInitializer.getMongoClient();
	}

	@SuppressWarnings ("unchecked")
	private void fillTestDB() throws IOException
	{
		new Expectations()
		{
			{
				DashboardUI.getEventCollection();
				returns(EVENT_COLLECTION);
			}
		};
		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection collection = db.getCollection(DashboardUI.getEventCollection());
		InputStream testMessage = this.getClass()
				.getResourceAsStream("/testData/telematic/telematic.json");
		String message = IOUtils.toString(testMessage, "UTF-8");

		Object parse = JSON.parse(message);
		List<DBObject> objectListToSave = (List<DBObject>) parse;
		collection.insert(objectListToSave);

		DBCollection mileageCollection = db.getCollection(DashboardUI.getMongoMileageCollection());
		InputStream testMileageMessage = this.getClass()
				.getResourceAsStream("/testData/telematic/mileage.json");
		String mileageMessage = IOUtils.toString(testMileageMessage, "UTF-8");

		Object mileageParse = JSON.parse(mileageMessage);
		List<DBObject> mileageListToSave = (List<DBObject>) mileageParse;
		mileageCollection.insert(mileageListToSave);

	}

	private List<Wagon> getWagonList()
	{

		List<Wagon> wagonList = new ArrayList<Wagon>();

		Wagon wagon = new Wagon();
		wagon.setId("bc93643f-1743-40e8-ab73-0c52c5ctest4");
		wagon.setAlias("Tester");
		wagon.setCreatedTs(new Date());
		wagon.setBoxId(123456789012345L);
		wagon.setTenantId("cbeaa370-c11d-11e1-8ba8-d4bed92atest");

		wagonList.add(wagon);

		return wagonList;
	}

	private Map<String, Boolean> getSelectedFields()
	{

		Map<String, Boolean> selectedFields = new HashMap<String, Boolean>();

		selectedFields.put(MongoConstants.DATE, true);
		selectedFields.put(MongoConstants.TIME, true);
		selectedFields.put(MongoConstants.LONGITUDE, true);

		return selectedFields;
	}

}
