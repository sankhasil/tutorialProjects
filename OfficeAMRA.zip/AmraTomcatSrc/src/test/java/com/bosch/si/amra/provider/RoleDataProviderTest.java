
package com.bosch.si.amra.provider;

import java.io.IOException;
import java.io.InputStream;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.WagonUser;
import com.bosch.si.amra.entity.WagonUsers;
import com.bosch.si.amra.provider.role.RoleDataProvider;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.util.JSON;

import mockit.Expectations;
import mockit.Mocked;

@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (locations = "file:src/test/resources/spring-servlet.xml")
public class RoleDataProviderTest
{
	private static final String	TENANT_ID_CBEAA370_88			= "cbeaa370-c11d-11e1-8ba8-d4bed92ae488";

	private static final String	USERNAME_BEG					= "beg";

	private static final String	USERNAME_TEST2					= "test2";

	private static final String	USERNAME_AE_BETH2				= "ae-beth2";

	private static final String	USERNAME_ALEKS2					= "Aleks2";

	private static final String	USERNAME_INST_KRMA				= "inst-krma";

	private static final String	USERNAME_AE_BETH				= "ae-beth";

	private static final String	USERNAME_ALEKS					= "Aleks";

	private static final String	USER_ID_15FB7B90_F8				= "15fb7b90-6b3c-11e4-87b1-0050569350f8";

	private static final String	USER_ID_01F95B30_E9				= "01f95b30-717d-11e4-90de-0050569350e9";

	private static final String	USER_ID_00F95B30_E9				= "00f95b30-717d-11e4-90de-0050569350e9";

	private static final String	USER_ID_7523A8E0_E9				= "7523a8e0-6e39-11e4-8035-0050569350e9";

	private static final String	USER_ID_15FB7B90_E8				= "15fb7b90-6b3c-11e4-87b1-0050569350e8";

	private static final String	USER_ID_00F95B30_E8				= "00f95b30-717d-11e4-90de-0050569350e8";

	private static final String	USER_ID_7523A8E0_E8				= "7523a8e0-6e39-11e4-8035-0050569350e8";

	private static final String	WAGON_ID_6FF79722_6E			= "6ff79722-f6ab-4514-9702-94cfa5d5846e";

	private static final String	WAGON_ID_6FF79722_5E			= "6ff79722-f6ab-4515-9702-95cfa5d5845e";

	private static final String	WAGON_TYPE_1060					= "WAGON_TYPE_1060";

	private static final String	WAGON_ALIAS_TEST2				= "Test2";

	private static final Date	EXPECTED_DATE_1469057868395L	= new Date(1469057868395L);

	private static final Date	EXPECTED_DATE_1469057868396		= new Date(1469057868396L);

	@Autowired
	private RoleDataProvider	roleDataProvider;

	@Value ("${MONGO_HOST}")
	public String				MONGO_HOST;

	@Value ("${MONGO_PORT}")
	public Integer				MONGO_PORT;

	@Value ("${MONGO_DATABASE}")
	public String				MONGO_DATABASE;

	@Value ("${MONGO_USERNAME}")
	public String				MONGO_USERNAME;

	@Value ("${MONGO_PASSWORD}")
	public String				MONGO_PASSWORD;

	@Value ("${WAGON_COLLECTION}")
	public String				WAGON_COLLECTION;

	@Mocked
	DashboardUI					dashboardUi;

	@After
	public void tearDown() throws UnknownHostException
	{
		getMongoClient();
		new Expectations()
		{
			{
				DashboardUI.getWagonCollection();
				returns(WAGON_COLLECTION);
			}
		};
		DBCollection collection = getCollection(DashboardUI.getWagonCollection());
		collection.remove(new BasicDBObject());
	}

	@Test
	public void getAssignedDispo4SpecificWagonTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		List<WagonUser> assignedDisponentsForWagon = roleDataProvider
				.getAssignedDisponentsForWagon(TENANT_ID_CBEAA370_88, WAGON_ID_6FF79722_6E);
		Assert.assertNotNull(assignedDisponentsForWagon);
		Assert.assertEquals(3, assignedDisponentsForWagon.size());
		for (WagonUser dispo2Wagon : assignedDisponentsForWagon)
		{
			if (dispo2Wagon.getUserId().equals(USER_ID_7523A8E0_E8))
				Assert.assertEquals(USERNAME_ALEKS, dispo2Wagon.getUserName());
			if (dispo2Wagon.getUserId().equals(USER_ID_00F95B30_E8))
				Assert.assertEquals(USERNAME_AE_BETH, dispo2Wagon.getUserName());
			if (dispo2Wagon.getUserId().equals(USER_ID_15FB7B90_E8))
				Assert.assertEquals(USERNAME_INST_KRMA, dispo2Wagon.getUserName());
		}
	}

	@Test
	public void getAssignedEndCustomers4SpecificWagonTest() throws IOException
	{
		getMongoClient();
		fillTestDB();
		List<WagonUser> assignedEndCustomersForWagon = roleDataProvider
				.getAssignedEndCustomersForWagon(TENANT_ID_CBEAA370_88, WAGON_ID_6FF79722_6E);
		Assert.assertNotNull(assignedEndCustomersForWagon);
		Assert.assertEquals(2, assignedEndCustomersForWagon.size());
		for (WagonUser dispo2Wagon : assignedEndCustomersForWagon)
		{
			if (dispo2Wagon.getUserId().equals(USER_ID_7523A8E0_E9))
			{
				Assert.assertEquals(USERNAME_ALEKS2, dispo2Wagon.getUserName());
				Assert.assertEquals(EXPECTED_DATE_1469057868395L, dispo2Wagon.getActivationTime());
			}
			if (dispo2Wagon.getUserId().equals(USER_ID_00F95B30_E9))
			{
				Assert.assertEquals(USERNAME_AE_BETH2, dispo2Wagon.getUserName());
				Assert.assertEquals(EXPECTED_DATE_1469057868396, dispo2Wagon.getActivationTime());
			}
		}
	}

	@Test (expected = IllegalArgumentException.class)
	public void getAssignedDispo4SpecificWagonNullTenantTest() throws IOException
	{
		roleDataProvider.getAssignedDisponentsForWagon(null, WAGON_ID_6FF79722_6E);
	}

	@Test (expected = IllegalArgumentException.class)
	public void getAssignedEndCustomers4SpecificWagonNullTenantTest() throws IOException
	{
		roleDataProvider.getAssignedEndCustomersForWagon(null, WAGON_ID_6FF79722_6E);
	}

	@Test (expected = IllegalArgumentException.class)
	public void getAssignedDispo4SpecificWagonEmptyTenantTest() throws IOException
	{
		roleDataProvider.getAssignedDisponentsForWagon("", WAGON_ID_6FF79722_6E);
	}

	@Test (expected = IllegalArgumentException.class)
	public void getAssignedEndCustomers4SpecificWagonEmptyTenantTest() throws IOException
	{
		roleDataProvider.getAssignedEndCustomersForWagon("", WAGON_ID_6FF79722_6E);
	}

	@Test (expected = IllegalArgumentException.class)
	public void getAssignedDispo4SpecificWagonNullWagonIdTest() throws IOException
	{
		roleDataProvider.getAssignedDisponentsForWagon(TENANT_ID_CBEAA370_88, null);
	}

	@Test (expected = IllegalArgumentException.class)
	public void getAssignedEndCustomers4SpecificWagonNullWagonIdTest() throws IOException
	{
		roleDataProvider.getAssignedEndCustomersForWagon(TENANT_ID_CBEAA370_88, null);
	}

	@Test (expected = IllegalArgumentException.class)
	public void getAssignedDispo4SpecificWagonEmptyWagonIdTest() throws IOException
	{
		roleDataProvider.getAssignedDisponentsForWagon(TENANT_ID_CBEAA370_88, "");
	}

	@Test (expected = IllegalArgumentException.class)
	public void getAssignedEndCustomers4SpecificWagonEmptyWagonIdTest() throws IOException
	{
		roleDataProvider.getAssignedEndCustomersForWagon(TENANT_ID_CBEAA370_88, "");
	}

	@Test
	public void getUsers2WagonAssignments() throws IOException
	{
		getMongoClient();
		fillTestDB();
		List<WagonUsers> users2WagonAssignment = roleDataProvider
				.getUsers2WagonAssignment(TENANT_ID_CBEAA370_88);
		Assert.assertNotNull(users2WagonAssignment);
		Assert.assertEquals(4, users2WagonAssignment.size());
		for (WagonUsers wagonUsers : users2WagonAssignment)
		{
			if (wagonUsers.getId().equals(WAGON_ID_6FF79722_5E))
			{
				Assert.assertEquals(WAGON_ALIAS_TEST2, wagonUsers.getAlias());
				Assert.assertEquals(WAGON_TYPE_1060, wagonUsers.getTypeName());
				Assert.assertNotNull(wagonUsers.getDisponents());
				Assert.assertEquals(2, wagonUsers.getDisponents().size());
				for (WagonUser dispo2Wagon : wagonUsers.getDisponents())
				{
					if (dispo2Wagon.getUserId().equals(USER_ID_01F95B30_E9))
						Assert.assertEquals(USERNAME_TEST2, dispo2Wagon.getUserName());
					if (dispo2Wagon.getUserId().equals(USER_ID_15FB7B90_F8))
						Assert.assertEquals(USERNAME_BEG, dispo2Wagon.getUserName());
				}

				Assert.assertNotNull(wagonUsers.getEndcustomers());
				Assert.assertEquals(1, wagonUsers.getEndcustomers().size());
				for (WagonUser endCustomer2Wagon : wagonUsers.getEndcustomers())
				{
					if (endCustomer2Wagon.getUserId().equals(USER_ID_7523A8E0_E9))
					{
						Assert.assertEquals(USERNAME_ALEKS2, endCustomer2Wagon.getUserName());
						Assert.assertEquals(EXPECTED_DATE_1469057868395L,
								endCustomer2Wagon.getActivationTime());
					}
				}
			}
		}
	}

	@Test (expected = IllegalArgumentException.class)
	public void getUsers2WagonAssignmentsNullTenantTest() throws IOException
	{
		roleDataProvider.getUsers2WagonAssignment(null);
	}

	@Test (expected = IllegalArgumentException.class)
	public void getUsers2WagonAssignmentsEmptyTenantTest() throws IOException
	{
		roleDataProvider.getUsers2WagonAssignment("");
	}

	private MongoClient getMongoClient() throws UnknownHostException
	{
		new Expectations()
		{
			{
				DashboardUI.getMongoUsername();
				returns(MONGO_USERNAME);
				DashboardUI.getMongoPassword();
				returns(MONGO_PASSWORD);
				DashboardUI.getMongoDatabase();
				returns(MONGO_DATABASE);
				DashboardUI.getMongoHost();
				returns(MONGO_HOST);
				DashboardUI.getMongoPort();
				returns(MONGO_PORT);
				DashboardUI.getWagonCollection();
				returns(WAGON_COLLECTION);
			}
		};
		DataProviderInitializer.createMongoClient();
		return DataProviderInitializer.getMongoClient();
	}

	@SuppressWarnings ("unchecked")
	private void fillTestDB() throws IOException
	{

		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());

		DBCollection collection = db.getCollection(DashboardUI.getWagonCollection());
		InputStream testMessage = AggregationDataProviderTest.class
				.getResourceAsStream("/testData/wagon/wagonUsers.json");
		String message = IOUtils.toString(testMessage, "UTF-8");

		Object parse = JSON.parse(message);
		List<DBObject> objectToSave = (List<DBObject>) parse;
		collection.insert(objectToSave);
	}

	private DBCollection getCollection(String collectionName) throws UnknownHostException
	{
		MongoClient mongoClient = getMongoClient();
		DB db = mongoClient.getDB(DashboardUI.getMongoDatabase());
		return db.getCollection(collectionName);
	}
}
