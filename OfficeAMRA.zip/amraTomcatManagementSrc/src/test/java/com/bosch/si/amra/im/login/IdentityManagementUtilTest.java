
package com.bosch.si.amra.im.login;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bosch.im.command.ICommandExecutor;
import com.bosch.im.command.ICommandFactory;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.event.DashboardEvent.ChangePasswordEvent;
import com.bosch.si.amra.event.DashboardEvent.ResetPasswordEvent;
import com.bosch.si.amra.event.DashboardEventBus;

import mockit.Mocked;
import mockit.Verifications;

@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (locations = "file:src/test/resources/spring-servlet.xml")
public class IdentityManagementUtilTest
{
	@Autowired
	private IdentityManagementUtil	idmUtil;

	@Mocked
	final DashboardEventBus			eventBus	= null;

	@Mocked
	ICommandFactory					commandFactory;

	@Mocked
	ICommandExecutor				commandExecutor;

	@Before
	public void setUp()
	{
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void changePasswordTest()
	{
		User user = new User();
		user.setTechnialName("NoExistingUser");
		user.setTenantName("DEFAULT");
		idmUtil.changePassword(new ChangePasswordEvent(user, "oldPassword", "newPassword"));
		new Verifications()
		{
			{
				DashboardEventBus.post(any);
				times = 1;
			}
		};
	}

	@Test (expected = NullPointerException.class)
	public void changePasswordNullTechnicalNameTest()
	{
		User user = new User();
		user.setTechnialName(null);
		user.setTenantName("DEFAULT");
		idmUtil.changePassword(new ChangePasswordEvent(user, "oldPassword", "newPassword"));
	}

	@Test (expected = NullPointerException.class)
	public void changePasswordNullTenantNameTest()
	{
		User user = new User();
		user.setTechnialName("NoExistingUser");
		user.setTenantName(null);
		idmUtil.changePassword(new ChangePasswordEvent(user, "oldPassword", "newPassword"));
	}

	@Test (expected = NullPointerException.class)
	public void changePasswordNullOldPasswordTest()
	{
		User user = new User();
		user.setTechnialName("NoExistingUser");
		user.setTenantName("DEFAULT");
		idmUtil.changePassword(new ChangePasswordEvent(user, null, "newPassword"));
	}

	@Test (expected = NullPointerException.class)
	public void changePasswordNullNewPasswordTest()
	{
		User user = new User();
		user.setTechnialName("NoExistingUser");
		user.setTenantName("DEFAULT");
		idmUtil.changePassword(new ChangePasswordEvent(user, "oldPassword", null));
	}

	@Test
	public void resetPasswordTest()
	{
		User user = new User();
		user.setTechnialName("NoExistingUser");
		user.setTenantName("DEFAULT");
		idmUtil.resetPassword(new ResetPasswordEvent(user));
		new Verifications()
		{
			{
				DashboardEventBus.post(any);
				times = 1;
			}
		};
	}

	@Test (expected = IllegalArgumentException.class)
	public void resetPasswordNullTechnicalNameTest()
	{
		User user = new User();
		user.setTechnialName(null);
		user.setTenantName("DEFAULT");
		idmUtil.resetPassword(new ResetPasswordEvent(user));
	}

	@Test (expected = IllegalArgumentException.class)
	public void resetPasswordNullTenantNameTest()
	{
		User user = new User();
		user.setTechnialName("NoExistingUser");
		user.setTenantName(null);
		idmUtil.resetPassword(new ResetPasswordEvent(user));
	}

	@Test (expected = NullPointerException.class)
	public void resetPasswordNullUserTest()
	{
		idmUtil.resetPassword(new ResetPasswordEvent(null));
	}
}
