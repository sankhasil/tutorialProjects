
package com.bosch.si.amra;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.vaadin.server.Page;

import mockit.Expectations;
import mockit.Mocked;
import mockit.integration.junit4.JMockit;

@RunWith (JMockit.class)
public class DashboardUITest
{
	@Mocked
	private Page				page;

	private SimpleDateFormat	dataDateFormat	= new SimpleDateFormat("yy-MM-dd HH:mm:ss");

	@Before
	public void setup()
	{
		dataDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
	}

	/**
	 * Tests if a given date (31.01.2015 10:23:00 UTC is displayed correctly for a user located in a
	 * timezone with UTC+1 and enabled DST. Expected behavior is to display the date 31.01.2015
	 * 11:23:00 CET. It does not matter if we are currently in summer or winter
	 *
	 * @throws ParseException
	 */
	@Test
	public void geofixInWinterInStuttgartTest() throws ParseException
	{
		new Expectations()
		{
			{
				Page.getCurrent().getWebBrowser().getRawTimezoneOffset();
				returns(3600000);
				Page.getCurrent().getWebBrowser().getDSTSavings();
				returns(3600000);
			}
		};

		Date parse = dataDateFormat.parse("15-01-31 10:23:00");

		TimeZone userTimeZone = DashboardUI.getUserTimeZone();
		SimpleDateFormat displayFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
		displayFormat.setTimeZone(userTimeZone);
		String format = displayFormat.format(parse);
		Assert.assertEquals("31.01.2015 11:23:00", format);
	}

	@Test
	public void geofixInSummerInStuttgartTest() throws ParseException
	{
		new Expectations()
		{
			{
				Page.getCurrent().getWebBrowser().getRawTimezoneOffset();
				returns(3600000);
				Page.getCurrent().getWebBrowser().getDSTSavings();
				returns(3600000);
			}
		};

		Date parse = dataDateFormat.parse("15-05-31 10:23:00");

		TimeZone userTimeZone = DashboardUI.getUserTimeZone();
		SimpleDateFormat displayFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
		displayFormat.setTimeZone(userTimeZone);
		String format = displayFormat.format(parse);
		Assert.assertEquals("31.05.2015 12:23:00", format);
	}

	/**
	 * Algier has the same timezone as Stuttgart but with DST = 0
	 *
	 * @throws ParseException
	 */
	@Test
	public void geofixInWinterInAglierTest() throws ParseException
	{
		new Expectations()
		{
			{
				Page.getCurrent().getWebBrowser().getRawTimezoneOffset();
				returns(3600000);
				Page.getCurrent().getWebBrowser().getDSTSavings();
				returns(0);
			}
		};

		Date parse = dataDateFormat.parse("15-01-31 10:23:00");

		TimeZone userTimeZone = DashboardUI.getUserTimeZone();
		SimpleDateFormat displayFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
		displayFormat.setTimeZone(userTimeZone);
		String format = displayFormat.format(parse);
		Assert.assertEquals("31.01.2015 11:23:00", format);
	}

	/**
	 * Algier has the same timezone as Stuttgart but with DST = 0
	 *
	 * @throws ParseException
	 */
	@Test
	public void geofixInSummerInAlgierTest() throws ParseException
	{
		new Expectations()
		{
			{
				Page.getCurrent().getWebBrowser().getRawTimezoneOffset();
				returns(3600000);
				Page.getCurrent().getWebBrowser().getDSTSavings();
				returns(0);
			}
		};

		Date parse = dataDateFormat.parse("15-05-31 10:23:00");

		TimeZone userTimeZone = DashboardUI.getUserTimeZone();
		SimpleDateFormat displayFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
		displayFormat.setTimeZone(userTimeZone);
		String format = displayFormat.format(parse);
		Assert.assertEquals("31.05.2015 11:23:00", format);
	}

	@Test
	public void geofixInWinterInLondonTest() throws ParseException
	{
		new Expectations()
		{
			{
				Page.getCurrent().getWebBrowser().getRawTimezoneOffset();
				returns(0);
				Page.getCurrent().getWebBrowser().getDSTSavings();
				returns(3600000);
			}
		};

		Date parse = dataDateFormat.parse("15-01-31 10:23:00");

		TimeZone userTimeZone = DashboardUI.getUserTimeZone();
		SimpleDateFormat displayFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
		displayFormat.setTimeZone(userTimeZone);
		String format = displayFormat.format(parse);
		Assert.assertEquals("31.01.2015 10:23:00", format);
	}

	@Test
	public void geofixInSummerInLondonTest() throws ParseException
	{
		new Expectations()
		{
			{
				Page.getCurrent().getWebBrowser().getRawTimezoneOffset();
				returns(0);
				Page.getCurrent().getWebBrowser().getDSTSavings();
				returns(3600000);
			}
		};

		Date parse = dataDateFormat.parse("15-05-31 10:23:00");

		TimeZone userTimeZone = DashboardUI.getUserTimeZone();
		SimpleDateFormat displayFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
		displayFormat.setTimeZone(userTimeZone);
		String format = displayFormat.format(parse);
		Assert.assertEquals("31.05.2015 11:23:00", format);
	}

	@Test
	public void geofixInWinterInAthensTest() throws ParseException
	{
		new Expectations()
		{
			{
				Page.getCurrent().getWebBrowser().getRawTimezoneOffset();
				returns(7200000);
				Page.getCurrent().getWebBrowser().getDSTSavings();
				returns(3600000);
			}
		};

		Date parse = dataDateFormat.parse("15-01-31 10:23:00");

		TimeZone userTimeZone = DashboardUI.getUserTimeZone();
		SimpleDateFormat displayFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
		displayFormat.setTimeZone(userTimeZone);
		String format = displayFormat.format(parse);
		Assert.assertEquals("31.01.2015 12:23:00", format);
	}

	@Test
	public void geofixInSummerInAthensTest() throws ParseException
	{
		new Expectations()
		{
			{
				Page.getCurrent().getWebBrowser().getRawTimezoneOffset();
				returns(7200000);
				Page.getCurrent().getWebBrowser().getDSTSavings();
				returns(3600000);
			}
		};

		Date parse = dataDateFormat.parse("15-05-31 10:23:00");

		TimeZone userTimeZone = DashboardUI.getUserTimeZone();
		SimpleDateFormat displayFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
		displayFormat.setTimeZone(userTimeZone);
		String format = displayFormat.format(parse);
		Assert.assertEquals("31.05.2015 13:23:00", format);
	}

	/**
	 * Geofix recorded in winter in Adelaide (Australia). Adelaide has the timezone UTC+9,5 and
	 * because australia is in the southern hemisphere in january the DST is enabled. At this time
	 * it is summer in australia
	 *
	 * @throws ParseException
	 */
	@Test
	public void geofixInWinterInAdelaideTest() throws ParseException
	{
		new Expectations()
		{
			{
				Page.getCurrent().getWebBrowser().getRawTimezoneOffset();
				returns(34200000);
				Page.getCurrent().getWebBrowser().getDSTSavings();
				returns(3600000);
			}
		};

		Date parse = dataDateFormat.parse("15-01-31 10:23:00");

		TimeZone userTimeZone = DashboardUI.getUserTimeZone();
		SimpleDateFormat displayFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
		displayFormat.setTimeZone(userTimeZone);
		String format = displayFormat.format(parse);
		Assert.assertEquals("31.01.2015 20:53:00", format);
	}

	/**
	 * Geofix recorded in winter in Adelaide (Australia). Adelaide has the timezone UTC+9,5 and
	 * because australia is in the southern hemisphere in may the DST is not enabled. At this time
	 * it is winter in australia
	 *
	 * @throws ParseException
	 */
	@Test
	public void geofixInSummerInAdelaideTest() throws ParseException
	{
		new Expectations()
		{
			{
				Page.getCurrent().getWebBrowser().getRawTimezoneOffset();
				returns(34200000);
				Page.getCurrent().getWebBrowser().getDSTSavings();
				returns(3600000);
			}
		};

		Date parse = dataDateFormat.parse("15-05-31 10:23:00");

		TimeZone userTimeZone = DashboardUI.getUserTimeZone();
		SimpleDateFormat displayFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
		displayFormat.setTimeZone(userTimeZone);
		String format = displayFormat.format(parse);
		Assert.assertEquals("31.05.2015 19:53:00", format);
	}

	/**
	 * Geofix recorded in winter in HongKong (China). Hongkong has the timezone UTC+8 and DST = 0
	 *
	 * @throws ParseException
	 */
	@Test
	public void geofixInWinterInHongkongTest() throws ParseException
	{
		new Expectations()
		{
			{
				Page.getCurrent().getWebBrowser().getRawTimezoneOffset();
				returns(28800000);
				Page.getCurrent().getWebBrowser().getDSTSavings();
				returns(0);
			}
		};

		Date parse = dataDateFormat.parse("15-01-31 10:23:00");

		TimeZone userTimeZone = DashboardUI.getUserTimeZone();
		SimpleDateFormat displayFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
		displayFormat.setTimeZone(userTimeZone);
		String format = displayFormat.format(parse);
		Assert.assertEquals("31.01.2015 18:23:00", format);
	}

	/**
	 * Geofix recorded in winter in HongKong (China). Hongkong has the timezone UTC+8 and DST = 0
	 *
	 * @throws ParseException
	 */
	@Test
	public void geofixInSummerInHongkongTest() throws ParseException
	{
		new Expectations()
		{
			{
				Page.getCurrent().getWebBrowser().getRawTimezoneOffset();
				returns(28800000);
				Page.getCurrent().getWebBrowser().getDSTSavings();
				returns(0);
			}
		};

		Date parse = dataDateFormat.parse("15-05-31 10:23:00");

		TimeZone userTimeZone = DashboardUI.getUserTimeZone();
		SimpleDateFormat displayFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
		displayFormat.setTimeZone(userTimeZone);
		String format = displayFormat.format(parse);
		Assert.assertEquals("31.05.2015 18:23:00", format);
	}
}
