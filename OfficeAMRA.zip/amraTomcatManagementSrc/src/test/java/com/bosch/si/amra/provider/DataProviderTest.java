
package com.bosch.si.amra.provider;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.AmraManagementRESTConstants;
import com.bosch.si.amra.entity.DeviceManagement;
import com.fasterxml.jackson.jaxrs.json.JacksonJsonProvider;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.GenericType;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.client.apache4.ApacheHttpClient4;
import com.sun.jersey.client.apache4.config.DefaultApacheHttpClient4Config;
import com.sun.jersey.core.util.Base64;

import mockit.Expectations;
import mockit.Mocked;

@Ignore
@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (locations = "file:src/test/resources/spring-servlet.xml")
public class DataProviderTest
{
	private static final Logger	_log		= LoggerFactory.getLogger(DataProviderTest.class);

	@Mocked
	final DashboardUI			dashboardUI	= null;

	@Value ("${AMRA_MANAGEMENT_REST_SERVER}")
	public String				AMRA_MANAGEMENT_REST_SERVER;

	private static ClientConfig getClientConfig()
	{
		ClientConfig config = new DefaultClientConfig();

		config.getProperties().put(DefaultApacheHttpClient4Config.PROPERTY_CHUNKED_ENCODING_SIZE,
				0);

		config.getClasses().add(JacksonJsonProvider.class);
		return config;
	}

	private static String getAuthenticationHeader()
	{
		String auth = new String(Base64.encode(
				AmraManagementRESTConstants.tenant + "/" + AmraManagementRESTConstants.username
						+ ":" + AmraManagementRESTConstants.password));
		return auth;
	}

	public static WebResource getWebResource(String uri)
	{
		Client client = ApacheHttpClient4.create(getClientConfig());

		String url = DashboardUI.getArmaManagementRestServer() + "/" + uri;
		WebResource webResource = client.resource(url);
		return webResource;
	}

	/**
	 * Returns an HTTP Web Target that points to the REST Server
	 * along with the authentication credentials required for the Interface
	 *
	 * @param uri
	 *            the REST URI
	 * @return {@link ClientResponse}
	 */
	public static ClientResponse getHttpResponse(String uri)
	{

		String auth = getAuthenticationHeader();

		WebResource webResource = getWebResource(uri);

		ClientResponse clientResponse = webResource.header("Authorization", "Basic " + auth)
				.header("Transfer-Encoding", "chunked").get(ClientResponse.class);

		return clientResponse;

	}

	/**
	 * Returns an HTTP Web Target that points to the REST Server
	 * along with the authentication credentials required for the Interface
	 *
	 * @param uri
	 *            the REST URI
	 * @param requestBody
	 *            the response
	 * @return {@link ClientResponse}
	 */
	public static ClientResponse postHttpRequest(String uri, String requestBody)
	{

		String auth = getAuthenticationHeader();

		WebResource webResource = getWebResource(uri);

		ClientResponse clientResponse = webResource.header("Authorization", "Basic " + auth)
				.post(ClientResponse.class, requestBody);

		return clientResponse;

	}

	@Before
	public void setUp()
	{
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getDevicesTest()
	{
		List<DeviceManagement> devices = new ArrayList<DeviceManagement>();

		ClientResponse clientResponse = getHttpResponse(AmraManagementRESTConstants.URI_DEVICE_ALL);

		devices = clientResponse.getEntity(new GenericType<ArrayList<DeviceManagement>>()
		{
		});

		_log.debug("Device Count:" + devices.size());

		Assert.assertEquals(3, devices.size());

	}

	@Test
	public void updateDevicesTest()
	{

		String requestBody = "[{\"BI\": 777777777777788,\"IIC\": 123456789012370,\"SIM\": 123456789012355,\"HW\": 22}]";
		new Expectations()
		{
			{
				DashboardUI.getArmaManagementRestServer();
				returns(AMRA_MANAGEMENT_REST_SERVER);

			}
		};
		ClientResponse clientResponse = postHttpRequest(AmraManagementRESTConstants.URI_DEVICE_ALL,
				requestBody);

		_log.debug("response status:" + clientResponse.getStatus());

		Assert.assertEquals(200, clientResponse.getStatus());

	}
}
