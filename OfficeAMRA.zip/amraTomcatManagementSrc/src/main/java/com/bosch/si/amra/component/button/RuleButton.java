
package com.bosch.si.amra.component.button;

import com.bosch.si.amra.DashboardUI;
import com.vaadin.server.Resource;
import com.vaadin.ui.Button;
import com.vaadin.ui.themes.ValoTheme;

public class RuleButton extends Button
{
	/**
	 * Serial version uid
	 */
	private static final long serialVersionUID = -1312553560705980305L;

	public RuleButton(String tooltip, Resource icon, boolean enabled, ClickListener listener)
	{
		setDescription(DashboardUI.getMessageSource().getMessage(tooltip));
		setIcon(icon);
		addStyleName(ValoTheme.BUTTON_ICON_ONLY);
		setEnabled(enabled);
		addClickListener(listener);
	}
}
