
package com.bosch.si.amra.view.message;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.messages.MessagesConstants;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.messages.Message;
import com.bosch.si.amra.event.DashboardEvent.MessageAcknowledgementEvent;
import com.bosch.si.amra.event.DashboardEvent.MessageCountUpdatedEvent;
import com.bosch.si.amra.event.DashboardEvent.MessageSetEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.im.login.Role;
import com.bosch.si.amra.im.login.Role.Roles;
import com.bosch.si.amra.provider.MessageDataProvider;
import com.bosch.si.amra.view.message.MessagesGridFilterComponent.CreatedReadFilter;
import com.bosch.si.amra.view.message.MessagesGridFilterComponent.MessageFilter;
import com.bosch.si.amra.view.message.MessagesGridFilterComponent.SeverityFilter;
import com.google.common.eventbus.Subscribe;
import com.vaadin.data.Container.Filter;
import com.vaadin.data.Container.Filterable;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.data.util.filter.Compare;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.event.ShortcutListener;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Responsive;
import com.vaadin.server.ThemeResource;
import com.vaadin.server.VaadinSession;
import com.vaadin.ui.AbstractComponent;
import com.vaadin.ui.Button;
import com.vaadin.ui.CheckBox;
import com.vaadin.ui.Component;
import com.vaadin.ui.DateField;
import com.vaadin.ui.Grid;
import com.vaadin.ui.Grid.HeaderCell;
import com.vaadin.ui.Grid.HeaderRow;
import com.vaadin.ui.Grid.SelectionMode;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Notification.Type;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.renderers.DateRenderer;
import com.vaadin.ui.themes.ValoTheme;

@Role ({ Roles.USER, Roles.FLEETADMIN, Roles.SYSTEMADMIN })
@SuppressWarnings ("serial")
public class MessageView extends VerticalLayout implements View
{
	private Grid							grid;

	private HorizontalLayout				tools;

	private Button							approveMessages;

	private CheckBox						checkBox;

	private final Filter					acknowledgedFilter;

	private Object[]						propertyIds			= new Object[] {
			MessagesConstants.SEVERITY, MessagesConstants.BOX_ID, MessagesConstants.ALIAS,
			MessagesConstants.TENANT_ID, MessagesConstants.CREATED_TIME,
			MessagesConstants.READ_TIME, MessagesConstants.TYPE, MessagesConstants.TEXT };

	private Map<AbstractComponent, Object>	componentToPidMap	= new HashMap<>();

	public MessageView()
	{
		acknowledgedFilter = new Compare.Equal(MessagesConstants.ACKNOWLEDGE, false);

		setSizeFull();
		addStyleName("message");
		DashboardEventBus.register(this);

		addComponent(buildToolbar());

		grid = buildGrid();
		addComponent(grid);
		setExpandRatio(grid, 1);

		addShortcutListener(new ShortcutListener("Clear", KeyCode.ESCAPE, null)
		{
			@SuppressWarnings ("unchecked")
			@Override
			public void handleAction(Object sender, Object target)
			{
				BeanItemContainer<Message> container = (BeanItemContainer<Message>) grid
						.getContainerDataSource();
				if (target != null && target instanceof MessageFilter)
					((MessageFilter) target).setValue(null);
				else if (target != null && target instanceof CreatedReadFilter)
					((DateField) target).setValue(null);
				else if (target != null && target instanceof SeverityFilter)
					((SeverityFilter) target).setValue(null);
				Object pid = componentToPidMap.get(target);
				container.removeContainerFilters(pid);
			}
		});
	}

	@Override
	public void detach()
	{
		super.detach();
		DashboardEventBus.unregister(this);
	}

	private Component buildToolbar()
	{
		HorizontalLayout header = new HorizontalLayout();
		header.addStyleName("viewheader");
		header.setSpacing(true);
		Responsive.makeResponsive(header);

		Label title = new Label(DashboardUI.getMessageSource().getMessage("view.messages.caption"));
		title.setSizeUndefined();
		title.addStyleName(ValoTheme.LABEL_H1);
		title.addStyleName(ValoTheme.LABEL_NO_MARGIN);
		header.addComponent(title);

		approveMessages = buildApproveMessage();
		checkBox = buildShowAllNotAcknowledgedMessages();
		tools = new HorizontalLayout(approveMessages, checkBox);
		tools.setSpacing(true);
		tools.addStyleName("toolbar");
		header.addComponent(tools);

		return header;
	}

	private Button buildApproveMessage()
	{
		final Button approveNotificationButton = buildButton(null,
				"view.messages.button.approve.tooltip");
		approveNotificationButton.setIcon(new ThemeResource("img/notification/done2.png"));
		approveNotificationButton.setEnabled(false);

		approveNotificationButton.addClickListener(clickEvent -> {
			List<Object> selectedRows = (List<Object>) grid.getSelectedRows();
			User user = (User) VaadinSession.getCurrent().getAttribute(User.class.getName());
			List<Message> selectedMessages = new ArrayList<Message>();

			for (Object row : selectedRows)
			{
				Message mes = (Message) row;
				selectedMessages.add(mes);

			}
			DashboardEventBus.post(new MessageAcknowledgementEvent(selectedMessages, user));
			DashboardEventBus.post(new MessageCountUpdatedEvent());
		});
		return approveNotificationButton;
	}

	private Button buildButton(FontAwesome icon, String description)
	{
		final Button button = new Button(icon);
		button.setDescription(DashboardUI.getMessageSource().getMessage(description));
		button.addStyleName(ValoTheme.BUTTON_ICON_ONLY);
		return button;
	}

	private CheckBox buildShowAllNotAcknowledgedMessages()
	{
		final CheckBox checkBox = new CheckBox();
		checkBox.setValue(false);
		checkBox.addStyleName(ValoTheme.BUTTON_ICON_ONLY);
		checkBox.setImmediate(true);
		checkBox.setDescription(
				DashboardUI.getMessageSource().getMessage("view.messages.checkbox.tooltip.notack"));
		checkBox.addStyleName("checkBox");
		checkBox.setValue(true);
		checkBox.addValueChangeListener(event -> {

			Filterable data = (Filterable) grid.getContainerDataSource();
			if ((boolean) event.getProperty().getValue())
				data.addContainerFilter(acknowledgedFilter);
			else
				data.removeContainerFilter(acknowledgedFilter);
		});

		return checkBox;
	}

	private Grid buildGrid()
	{
		grid = new Grid();
		List<Message> messages = getMessages();
		if (messages != null)
			configureGrid(messages);
		else
			Notification.show(DashboardUI.getMessageSource().getMessage("view.message.empty"),
					Type.WARNING_MESSAGE);
		return grid;
	}

	private List<Message> getMessages()
	{
		MessageDataProvider messageProvider = new MessageDataProvider();
		return messageProvider.getMessages(true);
	}

	private void configureGrid(List<Message> messages)
	{
		grid.setContainerDataSource(createContainer(messages));
		grid.setSizeFull();
		grid.removeAllColumns();
		grid.setEditorEnabled(false);
		Arrays.asList(propertyIds).stream().forEach(action -> {
			grid.addColumn(action.toString());
			grid.getColumn(action).setHeaderCaption(DashboardUI.getMessageSource()
					.getMessage("view.message.columnheader." + action.toString().toLowerCase()));
		});
		grid.setColumnOrder(propertyIds);
		grid.setSelectionMode(SelectionMode.MULTI);
		grid.addSelectionListener(
				listner -> approveMessages.setEnabled(listner.getSelected().size() > 0));
		grid.addItemClickListener(new MessagesItemClickListener());
		grid.setRowStyleGenerator(new MessagesStyleGenerator.MessagesRowStyleGenerator());
		grid.setCellStyleGenerator(new MessagesStyleGenerator.MessagesCellStyleGenerator());
		Filterable data = (Filterable) grid.getContainerDataSource();
		data.addContainerFilter(acknowledgedFilter);

		addFilterRow();
		setPresentationForColumns();
	}

	private BeanItemContainer<Message> createContainer(List<Message> messages)
	{
		final BeanItemContainer<Message> beanContainer = new BeanItemContainer<Message>(
				Message.class, messages);
		beanContainer.addNestedContainerProperty(MessagesConstants.ALIAS);
		beanContainer.addNestedContainerProperty(MessagesConstants.SEVERITY);
		beanContainer.addNestedContainerProperty(MessagesConstants.CREATED_TIME);
		beanContainer.addNestedContainerProperty(MessagesConstants.READ_TIME);
		beanContainer.addNestedContainerProperty(MessagesConstants.TYPE);
		beanContainer.addNestedContainerProperty(MessagesConstants.TEXT);
		beanContainer.addNestedContainerProperty(MessagesConstants.ACKNOWLEDGE);
		return beanContainer;
	}

	@SuppressWarnings ("unchecked")
	private void addFilterRow()
	{
		BeanItemContainer<Message> container = (BeanItemContainer<Message>) grid
				.getContainerDataSource();
		HeaderRow filterRow = grid.appendHeaderRow();
		for (Object pid : propertyIds)
		{
			HeaderCell cell = filterRow.getCell(pid);

			AbstractComponent filterField;

			if (pid.equals(MessagesConstants.SEVERITY))
			{
				filterField = new SeverityFilter(pid, container);
			}
			else if (pid.equals(MessagesConstants.CREATED_TIME)
					|| pid.equals(MessagesConstants.READ_TIME))
			{
				filterField = new CreatedReadFilter(pid, container);
			}
			else
			{
				filterField = new MessageFilter(pid, container, acknowledgedFilter);
			}
			componentToPidMap.put(filterField, pid);

			cell.setComponent(filterField);
		}
	}

	private void setPresentationForColumns()
	{
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(
				DashboardUI.getMessageSource().getMessage("date.format"));
		simpleDateFormat.setTimeZone(DashboardUI.getUserTimeZone());
		grid.getColumn(MessagesConstants.CREATED_TIME)
				.setRenderer(new DateRenderer(simpleDateFormat));
		grid.getColumn(MessagesConstants.READ_TIME).setRenderer(new DateRenderer(simpleDateFormat));
		grid.getColumn(MessagesConstants.SEVERITY).setConverter(new EnumToStringConverter());
	}

	@Override
	public void enter(ViewChangeEvent event)
	{

	}

	@Subscribe
	public void setMessageList(MessageSetEvent event)
	{
		List<Message> messages = event.getMessages();
		grid.getContainerDataSource().removeAllItems();
		if (messages.size() > 0)
		{
			grid.setContainerDataSource(createContainer(messages));
			Filterable data = (Filterable) grid.getContainerDataSource();
			data.removeContainerFilter(acknowledgedFilter);
			data.addContainerFilter(acknowledgedFilter);
		}
	}
}
