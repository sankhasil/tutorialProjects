
package com.bosch.si.amra;

import java.net.UnknownHostException;

import org.jsoup.nodes.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bosch.im.context.IdentityContextHolder;
import com.bosch.si.amra.provider.DataProviderInitializer;
import com.vaadin.server.BootstrapFragmentResponse;
import com.vaadin.server.BootstrapListener;
import com.vaadin.server.BootstrapPageResponse;
import com.vaadin.server.ServiceException;
import com.vaadin.server.SessionDestroyEvent;
import com.vaadin.server.SessionDestroyListener;
import com.vaadin.server.SessionInitEvent;
import com.vaadin.server.SessionInitListener;

public class DashboardSessionInitListener implements SessionInitListener, SessionDestroyListener
{

	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= -5995644757269613725L;

	private static final Logger	logger				= LoggerFactory
			.getLogger(DashboardSessionInitListener.class);

	public DashboardSessionInitListener()
	{
		try
		{
			if (DataProviderInitializer.getMongoClient() == null)
			{
				DataProviderInitializer.createMongoClient();
			}
		}
		catch (UnknownHostException e)
		{
			logger.error("Could not find host", e);
		}
	}

	@SuppressWarnings ("serial")
	@Override
	public void sessionInit(final SessionInitEvent event) throws ServiceException
	{
		event.getSession().addBootstrapListener(new BootstrapListener()
		{

			@Override
			public void modifyBootstrapPage(final BootstrapPageResponse response)
			{
				final Element head = response.getDocument().head();
				head.appendElement("meta").attr("name", "viewport").attr("content",
						"width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no");
				head.appendElement("meta").attr("name", "apple-mobile-web-app-capable")
						.attr("content", "yes");
				head.appendElement("meta").attr("name", "apple-mobile-web-app-status-bar-style")
						.attr("content", "black-translucent");

				String contextPath = response.getRequest().getContextPath();
				head.appendElement("link").attr("rel", "apple-touch-icon").attr("href",
						contextPath + "/VAADIN/themes/dashboard/img/app-icon.png");

			}

			@Override
			public void modifyBootstrapFragment(final BootstrapFragmentResponse response)
			{
			}
		});
	}

	@Override
	public void sessionDestroy(SessionDestroyEvent event)
	{
		DataProviderInitializer.closeMongoClient();
		IdentityContextHolder.clear();
	}

}
