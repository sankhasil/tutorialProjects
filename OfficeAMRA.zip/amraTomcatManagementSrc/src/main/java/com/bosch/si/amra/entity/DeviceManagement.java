
package com.bosch.si.amra.entity;

import java.io.Serializable;
import java.time.Instant;
import java.util.Date;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude (Include.NON_NULL)
@JsonIgnoreProperties (ignoreUnknown = true)
public class DeviceManagement implements Serializable
{

	/**
	 * 
	 */
	private static final long	serialVersionUID	= 3241795908259156955L;

	@JsonProperty ("_id")
	private String				id;

	@JsonProperty ("BI")
	private Long				imei;

	private Long				iic;

	private Long				sim;

	@JsonProperty ("MI")
	private Long				mi;

	@JsonProperty ("CON")
	public void setCon(Map<String, Object> con)
	{
		this.iic = con.get("IIC") == null ? null : Long.parseLong(con.get("IIC").toString());
		this.sim = con.get("SIM") == null ? null : Long.parseLong(con.get("SIM").toString());
	}

	private String alias;

	@JsonProperty ("WN")
	public void setWagon(Map<String, Object> wagon)
	{
		this.alias = (String) wagon.get("alias");
	}

	@JsonProperty ("IV")
	private Long	initialVersion;

	@JsonProperty ("V")
	private Long	version;

	@JsonProperty ("HW")
	private Long	hwVersion;

	private Date	lastPost;

	@JsonProperty ("STU")
	public void setStu(Long unixTime)
	{
		Instant fromUnixTimestamp = Instant.ofEpochMilli(unixTime);
		this.lastPost = Date.from(fromUnixTimestamp);
	}

	public Long getImei()
	{
		return imei;
	}

	public Long getIic()
	{
		return iic;
	}

	public void setIic(Long iic)
	{
		this.iic = iic;
	}

	public Long getSim()
	{
		return sim;
	}

	public void setSim(Long sim)
	{
		this.sim = sim;
	}

	public String getAlias()
	{
		return alias;
	}

	private String	tenantId;

	private String	tenant;

	private String	tenantSort;

	@JsonProperty ("TN")
	public void setTenant(Map<String, Object> tenant)
	{
		this.tenantId = (String) tenant.get("TI");
		this.tenant = (String) tenant.get("name");
		this.tenantSort = (String) tenant.get("sort");
	}

	public Long getInitialVersion()
	{
		return initialVersion;
	}

	public void setInitialVersion(Long initialVersion)
	{
		this.initialVersion = initialVersion;
	}

	public Long getVersion()
	{
		return version;
	}

	public void setVersion(Long version)
	{
		this.version = version;
	}

	public Long getHwVersion()
	{
		return hwVersion;
	}

	public void setHwVersion(Long hwVersion)
	{
		this.hwVersion = hwVersion;
	}

	public Date getLastPost()
	{
		return lastPost;
	}

	public String getTenant()
	{
		return tenant;
	}

	public String getTenantSort()
	{
		return tenantSort;
	}

	public String getTenantId()
	{
		return tenantId;
	}

	public Long getMi()
	{
		return mi;
	}

	public void setMi(Long mi)
	{
		this.mi = mi;
	}

}
