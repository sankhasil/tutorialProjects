
package com.bosch.si.amra;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

import com.vaadin.spring.annotation.EnableVaadin;

@EnableVaadin
@Configuration
@ImportResource ("**/spring-servlet.xml")
public class AmraConfiguration
{

}
