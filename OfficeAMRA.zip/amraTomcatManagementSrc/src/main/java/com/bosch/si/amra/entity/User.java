
package com.bosch.si.amra.entity;

import java.io.Serializable;

public class User implements Serializable
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= 6644648085770637210L;

	private String				id;

	private String				role;

	private String				firstName;

	private String				lastName;

	private String				technialName;

	private String				email;

	private String				tenant;

	private String				tenantName;

	private boolean				admin				= false;

	private boolean				superAdmin			= false;

	private String				identityContextId;

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public String getRole()
	{
		return role;
	}

	public void setRole(String role)
	{
		this.role = role;
	}

	public String getFirstName()
	{
		return firstName;
	}

	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	public String getLastName()
	{
		return lastName;
	}

	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}

	public String getTechnialName()
	{
		return technialName;
	}

	public void setTechnialName(String technialName)
	{
		this.technialName = technialName;
	}

	public String getEmail()
	{
		return email;
	}

	public void setEmail(String email)
	{
		this.email = email;
	}

	public String getTenant()
	{
		return tenant;
	}

	public void setTenant(String tenant)
	{
		this.tenant = tenant;
	}

	public String getTenantName()
	{
		return tenantName;
	}

	public void setTenantName(String tenantName)
	{
		this.tenantName = tenantName;
	}

	public boolean isAdmin()
	{
		return admin;
	}

	public void setAdmin(boolean admin)
	{
		this.admin = admin;
	}

	public boolean isSuperAdmin()
	{
		return superAdmin;
	}

	public void setSuperAdmin(boolean superAdmin)
	{
		this.superAdmin = superAdmin;
	}

	public String getIdentityContextId()
	{
		return identityContextId;
	}

	public void setIdentityContextId(String identityContextId)
	{
		this.identityContextId = identityContextId;
	}
}
