
package com.bosch.si.amra.view.message;

import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.time.DateUtils;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.messages.Message;
import com.bosch.si.amra.entity.messages.MessageInfo.Severity;
import com.vaadin.data.Container.Filter;
import com.vaadin.data.Item;
import com.vaadin.data.Property;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.data.util.filter.SimpleStringFilter;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.DateField;
import com.vaadin.ui.TextField;

public class MessagesGridFilterComponent
{
	public static class SeverityFilter extends ComboBox
	{
		/**
		 * Serial version uid
		 */
		private static final long serialVersionUID = 7408529949272361694L;

		public SeverityFilter(Object pid, BeanItemContainer<Message> container)
		{
			List<Severity> severityValues = Arrays.asList(Severity.values());
			addItems(severityValues);
			setWidth("100%");
			setHeight("75%");
			setItemCaptionMode(ItemCaptionMode.EXPLICIT);
			setNullSelectionAllowed(true);
			severityValues.forEach(severity -> setItemCaption(severity, DashboardUI
					.getMessageSource().getMessage(severity.propertyKey().toLowerCase().trim())));
			addValueChangeListener(event -> {
				container.removeContainerFilters(pid);
				if (event.getProperty().getValue() != null)
					container.addContainerFilter(new SimpleStringFilter(pid,
							event.getProperty().getValue().toString(), true, false));
			});
		}
	}

	public static class MessageFilter extends TextField
	{
		/**
		 * Serial version uid
		 */
		private static final long serialVersionUID = 2925008614554210480L;

		public MessageFilter(Object pid, BeanItemContainer<Message> container,
				Filter acknowledgedFilter)
		{
			setWidth("100%");
			setHeight("75%");
			setNullRepresentation("");
			setNullSettingAllowed(true);
			addTextChangeListener(change -> {
				container.removeContainerFilters(pid);
				if (!change.getText().isEmpty())
					container.addContainerFilter(
							new SimpleStringFilter(pid, change.getText(), true, false));
			});
		}
	}

	public static class CreatedReadFilter extends DateField
	{
		/**
		 * Serial version uid
		 */
		private static final long serialVersionUID = -4496673311407673250L;

		public CreatedReadFilter(Object pid, BeanItemContainer<Message> container)
		{
			setWidth("100%");
			setHeight("75%");
			setDateFormat(DashboardUI.getMessageSource().getMessage("date.format.picker"));
			addValueChangeListener(event -> {
				container.removeContainerFilters(pid);
				if (event.getProperty().getValue() != null)
					container.addContainerFilter(
							new DateFilter(pid, (Date) event.getProperty().getValue()));
			});
		}
	}

	private static final class DateFilter implements Filter
	{
		/**
		 * Serial version uid
		 */
		private static final long	serialVersionUID	= -6164661003076759509L;

		private final Object		propertyId;

		private final Date			filterDate;

		public DateFilter(Object propertyId, Date filterDate)
		{
			this.propertyId = propertyId;
			this.filterDate = filterDate;
		}

		@Override
		public boolean passesFilter(Object itemId, Item item) throws UnsupportedOperationException
		{
			final Property<?> p = item.getItemProperty(propertyId);
			if (p == null)
			{
				return false;
			}
			Object propertyValue = p.getValue();
			if (propertyValue == null || !p.getType().equals(Date.class))
			{
				return false;
			}

			Date value = (Date) p.getValue();
			Calendar dateCalendar = Calendar.getInstance();
			dateCalendar.setTime(value);

			Calendar filterCalendar = Calendar.getInstance();
			filterCalendar.setTime(filterDate);

			return DateUtils.isSameDay(dateCalendar, filterCalendar);
		}

		@Override
		public boolean appliesToProperty(Object propertyId)
		{
			return propertyId != null && propertyId.equals(this.propertyId);
		}
	}
}
