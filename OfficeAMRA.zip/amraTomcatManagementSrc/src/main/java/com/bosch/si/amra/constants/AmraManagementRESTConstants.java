
package com.bosch.si.amra.constants;

public class AmraManagementRESTConstants
{
	public static final String	tenant				= "DEFAULT";

	public static final String	username			= "test";

	public static final String	password			= "t35t-us3r";

	public static final String	URI_DEVICE_ALL		= "admin/devices";

	public static final String	URI_MESSAGES_ALL	= "admin/messages";

	public static final String	URI_DEVICE_GET		= "devices?boxId=<boxId>";

}
