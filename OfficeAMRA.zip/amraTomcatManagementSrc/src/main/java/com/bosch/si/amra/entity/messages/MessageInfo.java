
package com.bosch.si.amra.entity.messages;

import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.bosch.si.amra.DashboardUI;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonInclude (Include.NON_NULL)
@JsonIgnoreProperties (ignoreUnknown = true)
public class MessageInfo implements Serializable
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= -1003593107894236027L;

	@JsonProperty ("createdTime")
	private Date				createdTime;

	@JsonProperty ("acknowledge")
	private boolean				acknowledge;

	@JsonProperty ("type")
	private String				type;

	@JsonProperty ("text")
	private String				text;

	@JsonProperty ("severity")
	private Severity			severity;

	@JsonProperty ("readTime")
	private Date				readTime;

	public enum Severity
	{
		HIGH(30, "high"), MEDIUM(20, "medium"), LOW(10, "low");

		private final int severity;

		private final String propertyKey;

		Severity(int severity, String propertyKey)
		{
			this.severity = severity;
			this.propertyKey = propertyKey;
		}

		public int severity()
		{
			return severity;
		}

		public String propertyKey()
		{
			return propertyKey;
		}
	}

	public Date getCreatedTime()
	{
		return createdTime;
	}

	public void setCreatedTime(Date createdTime)
	{
		this.createdTime = createdTime;
	}

	public boolean isAcknowledge()
	{
		return acknowledge;
	}

	public void setAcknowledge(boolean acknowledge)
	{
		this.acknowledge = acknowledge;
	}

	public String getType()
	{
		return type;
	}

	public void setType(String type)
	{
		this.type = type;
	}

	public String getText()
	{
		return text;
	}

	@JsonDeserialize (using = JsonStringDeserializer.class)
	public void setText(String text)
	{
		this.text = text;
	}

	public Severity getSeverity()
	{
		return severity;
	}

	@JsonDeserialize (using = JsonEnumDeserializer.class)
	public void setSeverity(Severity severity)
	{
		this.severity = severity;
	}

	public Date getReadTime()
	{
		return readTime;
	}

	public void setReadTime(Date readTime)
	{
		this.readTime = readTime;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + (acknowledge ? 1231 : 1237);
		result = prime * result + ((createdTime == null) ? 0 : createdTime.hashCode());
		result = prime * result + ((readTime == null) ? 0 : readTime.hashCode());
		result = prime * result + ((severity == null) ? 0 : severity.hashCode());
		result = prime * result + ((text == null) ? 0 : text.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MessageInfo other = (MessageInfo) obj;
		if (acknowledge != other.acknowledge)
			return false;
		if (createdTime == null)
		{
			if (other.createdTime != null)
				return false;
		}
		else if (!createdTime.equals(other.createdTime))
			return false;
		if (readTime == null)
		{
			if (other.readTime != null)
				return false;
		}
		else if (!readTime.equals(other.readTime))
			return false;
		if (severity != other.severity)
			return false;
		if (text == null)
		{
			if (other.text != null)
				return false;
		}
		else if (!text.equals(other.text))
			return false;
		if (type == null)
		{
			if (other.type != null)
				return false;
		}
		else if (!type.equals(other.type))
			return false;
		return true;
	}

	private static class JsonDateSerializer extends JsonSerializer<Date>
	{
		private static final SimpleDateFormat dateFormat = new SimpleDateFormat(
				DashboardUI.getMessageSource().getMessage("date.format"));

		@Override
		public void serialize(Date date, JsonGenerator gen, SerializerProvider provider)
				throws IOException, JsonProcessingException
		{
			gen.writeString(dateFormat.format(date));
		}
	}

	private static class JsonStringDeserializer extends JsonDeserializer<String>
	{
		@Override
		public String deserialize(JsonParser arg0, DeserializationContext arg1)
				throws IOException, JsonProcessingException
		{
			return DashboardUI.getMessageSource().getMessage(arg0.getText().toLowerCase().trim());
		}
	}

	private static class JsonEnumDeserializer extends JsonDeserializer<Severity>
	{
		@Override
		public Severity deserialize(JsonParser arg0, DeserializationContext arg1)
				throws IOException, JsonProcessingException
		{
			return Severity.valueOf(arg0.getText().toUpperCase());
		}
	}
}
