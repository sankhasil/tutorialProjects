
package com.bosch.si.amra.provider;

import java.net.UnknownHostException;
import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bosch.si.amra.DashboardUI;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;

public class DataProviderInitializer
{
	private static final Logger	logger	= LoggerFactory.getLogger(DataProviderInitializer.class);

	private static MongoClient	mongoClient;

	public static void createMongoClient() throws UnknownHostException
	{
		MongoCredential credential = MongoCredential.createMongoCRCredential(
				DashboardUI.getMongoUsername(), DashboardUI.getMongoDatabase(),
				DashboardUI.getMongoPassword().toCharArray());
		mongoClient = new MongoClient(
				new ServerAddress(DashboardUI.getMongoHost(), DashboardUI.getMongoPort()),
				Arrays.asList(credential));
	}

	public static void closeMongoClient()
	{
		if (mongoClient != null)
		{
			mongoClient.close();
			mongoClient = null;
		}
	}

	public static MongoClient getMongoClient()
	{
		if (mongoClient == null)
		{
			try
			{
				createMongoClient();
			}
			catch (UnknownHostException e)
			{
				logger.error("Could not find host", e);
			}
		}

		return mongoClient;
	}
}
