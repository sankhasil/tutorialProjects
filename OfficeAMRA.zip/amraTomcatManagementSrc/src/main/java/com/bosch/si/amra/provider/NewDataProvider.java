
package com.bosch.si.amra.provider;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.bosch.si.amra.constants.AmraManagementRESTConstants;
import com.bosch.si.amra.entity.DeviceManagement;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.GenericType;

/**
 * DataProvider which fetches Data from the Amra Management REST Service and makes them available
 * for UI
 *
 * @author pay2abt
 *
 */
@Component
public class NewDataProvider
{
	private static final Logger _log = LoggerFactory.getLogger(NewDataProvider.class);

	/**
	 * A list of AMRA devices
	 *
	 * @return a list of DeviceManagement objects
	 */
	public List<DeviceManagement> getDevices()
	{
		List<DeviceManagement> devices = new ArrayList<DeviceManagement>();

		ClientResponse clientResponse = AmraManagementRESTClient
				.getHttpRequest(AmraManagementRESTConstants.URI_DEVICE_ALL);
		devices = clientResponse.getEntity(new GenericType<ArrayList<DeviceManagement>>()
		{
		});

		return devices;
	}

	public DeviceManagement getDeviceByBoxId(Long boxId)
	{
		DeviceManagement device = new DeviceManagement();
		ClientResponse clientResponse = AmraManagementRESTClient
				.getHttpRequest(AmraManagementRESTConstants.URI_DEVICE_GET + boxId);

		device = clientResponse.getEntity(new GenericType<DeviceManagement>()
		{
		});
		return device;

	}

	/**
	 * POSTs list of devices to device-management
	 *
	 * @param devices
	 *            A list of AMRA devices
	 * @throws JsonProcessingException
	 *             throws JsonProcessingException
	 * @throws IOException
	 *             throws IOException
	 */
	public void postDevices(List<DeviceManagement> devices)
			throws JsonProcessingException, IOException
	{
		String requestBody = getDevicesJsonString(devices);

		_log.debug("requestBody:" + requestBody);

		ClientResponse clientResponse = AmraManagementRESTClient
				.postHttpRequest(AmraManagementRESTConstants.URI_DEVICE_ALL, requestBody);
		_log.debug("HTTP Status:" + clientResponse.getStatus());

	}

	private String getDevicesJsonString(List<DeviceManagement> devices)
			throws IOException, JsonProcessingException
	{
		// Create the node factory that gives us nodes.
		JsonNodeFactory factory = new JsonNodeFactory(false);

		// create a json factory to write the treenode as json. for the example
		// we just write to console
		JsonFactory jsonFactory = new JsonFactory();
		JsonGenerator generator = jsonFactory.createGenerator(System.out);

		// the root node - album
		ArrayNode devicesJsonArray = factory.arrayNode();

		for (int i = 0; i < devices.size(); i++)
		{
			ObjectNode device = factory.objectNode();

			device.put("BI", devices.get(i).getImei());
			device.put("IIC", devices.get(i).getIic());
			device.put("SIM", devices.get(i).getSim());
			device.put("HW", devices.get(i).getHwVersion());
			device.put("IV", devices.get(i).getInitialVersion());
			device.put("V", devices.get(i).getVersion());

			devicesJsonArray.add(device);
		}

		ObjectMapper mapper = new ObjectMapper();

		String devicesJsonArrayString = mapper.writeValueAsString(devicesJsonArray);

		return devicesJsonArrayString;
	}
}
