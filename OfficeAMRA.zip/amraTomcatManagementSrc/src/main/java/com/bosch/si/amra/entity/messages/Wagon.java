
package com.bosch.si.amra.entity.messages;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude (Include.NON_NULL)
@JsonIgnoreProperties (ignoreUnknown = true)
public class Wagon implements Serializable
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= 3114283081015478570L;

	@JsonProperty ("WI")
	private String				wagonId;

	@JsonProperty ("alias")
	private String				alias;

	@JsonProperty ("sort")
	private String				sort;

	public String getWagonId()
	{
		return wagonId;
	}

	public void setWagonId(String wagonId)
	{
		this.wagonId = wagonId;
	}

	public String getAlias()
	{
		return alias;
	}

	public void setAlias(String alias)
	{
		this.alias = alias;
	}

	public String getSort()
	{
		return sort;
	}

	public void setSort(String sort)
	{
		this.sort = sort;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((alias == null) ? 0 : alias.hashCode());
		result = prime * result + ((sort == null) ? 0 : sort.hashCode());
		result = prime * result + ((wagonId == null) ? 0 : wagonId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Wagon other = (Wagon) obj;
		if (alias == null)
		{
			if (other.alias != null)
				return false;
		}
		else if (!alias.equals(other.alias))
			return false;
		if (sort == null)
		{
			if (other.sort != null)
				return false;
		}
		else if (!sort.equals(other.sort))
			return false;
		if (wagonId == null)
		{
			if (other.wagonId != null)
				return false;
		}
		else if (!wagonId.equals(other.wagonId))
			return false;
		return true;
	}
}
