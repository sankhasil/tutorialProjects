
package com.bosch.si.amra.component.button;

import com.vaadin.server.Resource;
import com.vaadin.ui.Button;
import com.vaadin.ui.themes.ValoTheme;

public class OverviewButton extends Button
{
	/**
	 * Serial version uid
	 */
	private static final long serialVersionUID = 7920681744326941755L;

	public OverviewButton(String caption, String tooltip, Resource icon, ClickListener listener)
	{
		setCaption(caption);
		setDescription(tooltip);
		setIcon(icon);
		addStyleName(ValoTheme.BUTTON_ICON_ONLY);
		addClickListener(listener);
		setEnabled(false);
	}
}
