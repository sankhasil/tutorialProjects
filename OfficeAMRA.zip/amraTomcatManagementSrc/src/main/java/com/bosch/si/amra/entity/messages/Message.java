
package com.bosch.si.amra.entity.messages;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude (Include.NON_NULL)
@JsonIgnoreProperties (ignoreUnknown = true)
public class Message implements Serializable
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= 4672467587125643795L;

	@JsonProperty ("_id")
	private String				id;

	@JsonProperty ("BI")
	private String				boxId;

	@JsonProperty ("MI")
	private Long				messageId;

	@JsonProperty ("WN")
	private Wagon				wagon;

	@JsonProperty ("TI")
	private String				tenantId;

	@JsonProperty ("message")
	private MessageInfo			message;

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public String getBoxID()
	{
		return boxId;
	}

	public void setBoxID(String boxId)
	{
		this.boxId = boxId;
	}

	public Long getMessageId()
	{
		return messageId;
	}

	public void setMessageId(Long messageId)
	{
		this.messageId = messageId;
	}

	public String getTenantId()
	{
		return tenantId;
	}

	public void setTenantId(String tenantId)
	{
		this.tenantId = tenantId;
	}

	public String getBoxId()
	{
		return boxId;
	}

	public void setBoxId(String boxId)
	{
		this.boxId = boxId;
	}

	public Wagon getWagon()
	{
		return wagon;
	}

	public void setWagon(Wagon wagon)
	{
		this.wagon = wagon;
	}

	public MessageInfo getMessage()
	{
		return message;
	}

	public void setMessage(MessageInfo message)
	{
		this.message = message;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((boxId == null) ? 0 : boxId.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((message == null) ? 0 : message.hashCode());
		result = prime * result + ((messageId == null) ? 0 : messageId.hashCode());
		result = prime * result + ((tenantId == null) ? 0 : tenantId.hashCode());
		result = prime * result + ((wagon == null) ? 0 : wagon.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Message other = (Message) obj;
		if (boxId == null)
		{
			if (other.boxId != null)
				return false;
		}
		else if (!boxId.equals(other.boxId))
			return false;
		if (id == null)
		{
			if (other.id != null)
				return false;
		}
		else if (!id.equals(other.id))
			return false;
		if (message == null)
		{
			if (other.message != null)
				return false;
		}
		else if (!message.equals(other.message))
			return false;
		if (messageId == null)
		{
			if (other.messageId != null)
				return false;
		}
		else if (!messageId.equals(other.messageId))
			return false;
		if (tenantId == null)
		{
			if (other.tenantId != null)
				return false;
		}
		else if (!tenantId.equals(other.tenantId))
			return false;
		if (wagon == null)
		{
			if (other.wagon != null)
				return false;
		}
		else if (!wagon.equals(other.wagon))
			return false;
		return true;
	}
}
