
package com.bosch.si.amra.provider;

import java.util.List;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.AmraManagementRESTConstants;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.client.apache4.ApacheHttpClient4;
import com.sun.jersey.client.apache4.config.DefaultApacheHttpClient4Config;
import com.sun.jersey.core.util.Base64;
import com.sun.jersey.core.util.MultivaluedMapImpl;

public class AmraManagementRESTClient
{
	private static final String PATCH = "PATCH";

	/*
	 * Returns an HTTP Web Target that points to the REST Server
	 * along with the authentication credentials required for the Interface
	 */
	public static ClientResponse getHttpRequest(String uri)
	{
		String auth = getAuthenticationHeader();

		WebResource webResource = getWebResource(uri);

		ClientResponse clientResponse = webResource.accept(MediaType.APPLICATION_JSON_TYPE)
				.header("Authorization", "Basic " + auth).get(ClientResponse.class);

		return clientResponse;
	}

	/*
	 * Returns an HTTP Web Target that points to the REST Server
	 * along with the authentication credentials required for the Interface
	 */
	public static ClientResponse postHttpRequest(String uri, String requestBody)
	{
		String auth = getAuthenticationHeader();

		WebResource webResource = getWebResource(uri);

		ClientResponse clientResponse = webResource.header("Authorization", "Basic " + auth)
				.post(ClientResponse.class, requestBody);

		return clientResponse;
	}

	/**
	 * Send a HTTP patch request to the server
	 *
	 * @param uri
	 *            - The uri of the server
	 * @param messageIds
	 *            - The body with update information
	 * @return - The response after the server processed the request
	 */
	public static ClientResponse patchHttpRequest(String uri, List<String> messageIds)
	{
		String auth = getAuthenticationHeader();

		WebResource webResource = getWebResource(uri);

		MultivaluedMap<String, String> params = new MultivaluedMapImpl();
		params.add("messageIds",
				messageIds.toString().substring(1, messageIds.toString().length() - 1).trim());

		ClientResponse clientResponse = webResource.queryParams(params)
				.header("Authorization", "Basic " + auth).method(PATCH, ClientResponse.class);

		return clientResponse;
	}

	private static String getAuthenticationHeader()
	{
		String auth = new String(Base64.encode(
				AmraManagementRESTConstants.tenant + "/" + AmraManagementRESTConstants.username
						+ ":" + AmraManagementRESTConstants.password));
		return auth;
	}

	private static WebResource getWebResource(String uri)
	{
		Client client = ApacheHttpClient4.create(new DefaultApacheHttpClient4Config());

		String url = DashboardUI.getArmaManagementRestServer() + "/" + uri;
		WebResource webResource = client.resource(url);
		return webResource;
	}
}
