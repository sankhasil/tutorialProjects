
package com.bosch.si.amra.view;

import com.bosch.si.amra.view.devicemanagement.DeviceManagementView;
import com.bosch.si.amra.view.message.MessageView;
import com.vaadin.navigator.View;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Resource;

public enum AmraView
{
	DEVICEMANAGMENT("devicemanagement", DeviceManagementView.class, FontAwesome.MEDKIT, false), DEVICEMESSAGE(
			"messages", MessageView.class, FontAwesome.BELL, false);
	private final String				viewName;

	private final Class<? extends View>	viewClass;

	private final Resource				icon;

	private final boolean				stateful;

	private AmraView(String viewName, Class<? extends View> viewClass, Resource icon,
			boolean stateful)
	{
		this.viewName = viewName;
		this.viewClass = viewClass;
		this.icon = icon;
		this.stateful = stateful;
	}

	public boolean isStateful()
	{
		return stateful;
	}

	public String getViewName()
	{
		return viewName;
	}

	public Class<? extends View> getViewClass()
	{
		return viewClass;
	}

	public Resource getIcon()
	{
		return icon;
	}

}
