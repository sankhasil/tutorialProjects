
package com.bosch.si.amra.view;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.component.ForgotPasswordWindow;
import com.bosch.si.amra.event.DashboardEvent.CommunicationProblemEvent;
import com.bosch.si.amra.event.DashboardEvent.PasswordResetEvent;
import com.bosch.si.amra.event.DashboardEvent.UserLoginRequestedEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.google.common.eventbus.Subscribe;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.server.ExternalResource;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Responsive;
import com.vaadin.server.VaadinSession;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;
import com.vaadin.ui.Component;
import com.vaadin.ui.CssLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Link;
import com.vaadin.ui.PasswordField;
import com.vaadin.ui.PopupView;
import com.vaadin.ui.PopupView.PopupVisibilityEvent;
import com.vaadin.ui.PopupView.PopupVisibilityListener;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

@SuppressWarnings ("serial")
public class LoginView extends VerticalLayout
{
	private PopupView resetPassword;

	public LoginView()
	{
		DashboardEventBus.register(this);

		setSizeFull();

		Component loginForm = buildLoginForm();
		Component dataPolicy = buildDataPolicy();
		addComponents(loginForm, dataPolicy);
		setComponentAlignment(loginForm, Alignment.BOTTOM_CENTER);
		setComponentAlignment(dataPolicy, Alignment.BOTTOM_LEFT);
	}

	private Component buildLoginForm()
	{
		final VerticalLayout loginPanel = new VerticalLayout();
		loginPanel.setSizeUndefined();
		loginPanel.setSpacing(true);
		Responsive.makeResponsive(loginPanel);
		loginPanel.addStyleName("login-panel");

		loginPanel.addComponent(buildLabels());
		loginPanel.addComponent(buildFields());
		return loginPanel;
	}

	private Component buildLabels()
	{
		CssLayout labels = new CssLayout();
		labels.addStyleName("labels");

		Label welcome = new Label(DashboardUI.getMessageSource().getMessage("view.login.welcome"));
		welcome.setSizeUndefined();
		welcome.addStyleName(ValoTheme.LABEL_H4);
		welcome.addStyleName(ValoTheme.LABEL_COLORED);
		labels.addComponent(welcome);

		Label title = new Label(DashboardUI.getMessageSource().getMessage("view.login.dashboard"));
		title.setSizeUndefined();
		title.addStyleName(ValoTheme.LABEL_H3);
		title.addStyleName(ValoTheme.LABEL_LIGHT);
		labels.addComponent(title);
		return labels;
	}

	private Component buildFields()
	{
		VerticalLayout layout = new VerticalLayout();
		layout.setSpacing(true);

		HorizontalLayout fields = new HorizontalLayout();
		fields.setSpacing(true);
		fields.addStyleName("fields");

		final TextField tenant = new TextField(
				DashboardUI.getMessageSource().getMessage("view.login.tenant"));
		tenant.setIcon(FontAwesome.HOME);
		tenant.addStyleName(ValoTheme.TEXTFIELD_INLINE_ICON);
		tenant.setId("tenant");
		tenant.focus();

		final TextField username = new TextField(
				DashboardUI.getMessageSource().getMessage("view.login.username"));
		username.setIcon(FontAwesome.USER);
		username.addStyleName(ValoTheme.TEXTFIELD_INLINE_ICON);
		username.setId("username");

		final PasswordField password = new PasswordField(
				DashboardUI.getMessageSource().getMessage("view.login.password"));
		password.setIcon(FontAwesome.LOCK);
		password.addStyleName(ValoTheme.TEXTFIELD_INLINE_ICON);
		password.setId("password");

		final Button signin = new Button(
				DashboardUI.getMessageSource().getMessage("view.login.signin"));
		signin.addStyleName(ValoTheme.BUTTON_PRIMARY);
		signin.setClickShortcut(KeyCode.ENTER);
		signin.setId("signin");

		fields.addComponents(tenant, username, password, signin);
		fields.setComponentAlignment(signin, Alignment.BOTTOM_LEFT);

		signin.addClickListener(new ClickListener()
		{
			@Override
			public void buttonClick(ClickEvent event)
			{
				DashboardEventBus.post(new UserLoginRequestedEvent(username.getValue(),
						password.getValue(), tenant.getValue()));
			}
		});

		resetPassword = buildResetPasswordPopup();

		layout.addComponents(fields, resetPassword);
		return layout;
	}

	private PopupView buildResetPasswordPopup()
	{
		final ForgotPasswordWindow forgotPasswordWindow = new ForgotPasswordWindow();
		final PopupView resetPassword = new PopupView(
				DashboardUI.getMessageSource().getMessage("view.reset.password"),
				forgotPasswordWindow);
		resetPassword.setHideOnMouseOut(false);
		resetPassword.addPopupVisibilityListener(new PopupVisibilityListener()
		{
			@Override
			public void popupVisibilityChange(PopupVisibilityEvent event)
			{
				if (event.isPopupVisible())
					forgotPasswordWindow.discardChanges();
			}
		});
		forgotPasswordWindow.getCancel().addClickListener(new ClickListener()
		{

			@Override
			public void buttonClick(ClickEvent event)
			{
				resetPassword.setPopupVisible(false);
			}
		});
		return resetPassword;
	}

	private Component buildDataPolicy()
	{
		String country = VaadinSession.getCurrent().getLocale().getLanguage();

		HorizontalLayout layout = new HorizontalLayout();
		layout.setWidth("99%");

		HorizontalLayout dataPolicy = new HorizontalLayout();
		dataPolicy.setSpacing(true);

		final Link imprint = new Link(
				DashboardUI.getMessageSource().getMessage("view.login.imprint"),
				new ExternalResource("http://www.bosch.de/imprint/" + country + "/imprints.php"));
		imprint.setTargetName("_blank");
		imprint.setId("imprint");

		final Link privacyPolicy = new Link(
				DashboardUI.getMessageSource().getMessage("view.login.privacy"),
				new ExternalResource(
						"http://www.bosch.de/imprint/" + country + "/imprints.php?tab=3"));
		privacyPolicy.setTargetName("_blank");
		privacyPolicy.setId("privacy");

		final Link legalInfo = new Link(
				DashboardUI.getMessageSource().getMessage("view.login.legal"), new ExternalResource(
						"http://www.bosch.de/imprint/" + country + "/imprints.php?tab=2"));
		legalInfo.setTargetName("_blank");
		legalInfo.setId("legal");

		HorizontalLayout labelLayout = new HorizontalLayout();
		Label label = new Label("@ Bosch Software Innovations GmbH");
		label.setWidth(null);
		labelLayout.addComponent(label);

		dataPolicy.addComponents(imprint, privacyPolicy, legalInfo);
		layout.addComponents(dataPolicy, labelLayout);
		layout.setComponentAlignment(labelLayout, Alignment.BOTTOM_RIGHT);

		return layout;
	}

	@Subscribe
	public void communicationProblems(CommunicationProblemEvent event)
	{
		new UserNotification(event.getMessageCode(), 1000, false);
	}

	@Subscribe
	public void passwordResetInitiated(PasswordResetEvent event)
	{
		resetPassword.setPopupVisible(false);
		new UserNotification("view.reset.password.initiated", 1000, true);
	}
}
