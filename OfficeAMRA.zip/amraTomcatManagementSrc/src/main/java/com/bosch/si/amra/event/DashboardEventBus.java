
package com.bosch.si.amra.event;

import java.io.Serializable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bosch.si.amra.DashboardUI;
import com.google.common.eventbus.EventBus;
import com.google.common.eventbus.SubscriberExceptionContext;
import com.google.common.eventbus.SubscriberExceptionHandler;
import com.vaadin.ui.UI;

public class DashboardEventBus implements SubscriberExceptionHandler, Serializable
{
	/**
	 * Serial version uid
	 */
	private static final long			serialVersionUID	= -8738852948222851555L;

	private static final Logger			logger				= LoggerFactory
																	.getLogger(DashboardEventBus.class);

	private transient final EventBus	eventBus			= new EventBus(this);

	public static void post(Object event)
	{
		getEventBus().post(event);
	}

	public static void register(Object object)
	{
		getEventBus().register(object);
	}

	public static void unregister(Object object)
	{
		getEventBus().unregister(object);
	}

	private static EventBus getEventBus()
	{
		return ((DashboardUI) UI.getCurrent()).dashboardEventbus.eventBus;
	}

	@Override
	public void handleException(Throwable exception, SubscriberExceptionContext context)
	{
		logger.error("Event handling not successful", exception);
	}
}
