
package com.bosch.si.amra;

import java.lang.annotation.Annotation;
import java.util.Arrays;
import java.util.List;

import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.event.DashboardEvent.BrowserResizeEvent;
import com.bosch.si.amra.event.DashboardEvent.CloseOpenWindowsEvent;
import com.bosch.si.amra.event.DashboardEvent.PostViewChangeEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.im.login.Role;
import com.bosch.si.amra.im.login.Role.Roles;
import com.bosch.si.amra.view.AmraView;
import com.vaadin.navigator.Navigator;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener;
import com.vaadin.navigator.ViewProvider;
import com.vaadin.server.VaadinSession;
import com.vaadin.ui.ComponentContainer;
import com.vaadin.ui.UI;

@SuppressWarnings ("serial")
public class DashboardNavigator extends Navigator
{

	private final static AmraView	ERROR_VIEW	= AmraView.DEVICEMANAGMENT;

	private ViewProvider			errorViewProvider;

	public DashboardNavigator(ComponentContainer container)
	{
		super(UI.getCurrent(), container);

		initViewChangeListener();
		initViewProviders();

	}

	private void initViewChangeListener()
	{
		addViewChangeListener(new ViewChangeListener()
		{

			@Override
			public boolean beforeViewChange(ViewChangeEvent event)
			{
				return true;
			}

			@Override
			public void afterViewChange(ViewChangeEvent event)
			{
				for (AmraView view : AmraView.values())
				{
					if (view.getViewName().equals(event.getViewName()))
					{
						DashboardEventBus.post(new PostViewChangeEvent(view));
						DashboardEventBus.post(new BrowserResizeEvent());
						DashboardEventBus.post(new CloseOpenWindowsEvent());
						break;
					}
				}
			}
		});
	}

	private void initViewProviders()
	{
		User user = (User) VaadinSession.getCurrent().getAttribute(User.class.getName());
		for (final AmraView view : AmraView.values())
		{
			Annotation annotation = view.getViewClass().getAnnotation(Role.class);
			Role role = (Role) annotation;
			List<Roles> roles = Arrays.asList(role.value());
			if (roles.contains(Roles.USER) || (roles.contains(Roles.FLEETADMIN) && user.isAdmin())
					|| (roles.contains(Roles.SYSTEMADMIN) && user.isSuperAdmin()))
			{
				ViewProvider viewProvider = new ClassBasedViewProvider(view.getViewName(),
						view.getViewClass())
				{
					private View	cachedInstance;

					@Override
					public View getView(String viewName)
					{
						View result = null;
						if (view.getViewName().equals(viewName))
						{
							if (view.isStateful())
							{
								// Stateful views get lazily instantiated
								if (cachedInstance == null)
								{
									cachedInstance = super.getView(view.getViewName());
								}
								result = cachedInstance;
							}
							else
							{
								// Non-stateful views get instantiated every time
								// they're navigated to
								result = super.getView(view.getViewName());
							}
						}
						return result;
					}
				};

				if (view == ERROR_VIEW)
				{
					errorViewProvider = viewProvider;
				}

				addProvider(viewProvider);
			}

			setErrorProvider(new ViewProvider()
			{
				@Override
				public String getViewName(String viewAndParameters)
				{
					return ERROR_VIEW.getViewName();
				}

				@Override
				public View getView(String viewName)
				{
					return errorViewProvider.getView(ERROR_VIEW.getViewName());
				}
			});
		}
	}
}
