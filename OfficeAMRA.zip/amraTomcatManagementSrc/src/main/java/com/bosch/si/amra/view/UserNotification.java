
package com.bosch.si.amra.view;

import com.bosch.si.amra.DashboardUI;
import com.vaadin.server.Page;
import com.vaadin.shared.Position;
import com.vaadin.ui.Notification;

/**
 * Represents a simple user notification with a caption and a delay and if it is successful or not
 *
 * @author toa1wa3
 *
 */
public class UserNotification extends Notification
{
	/**
	 * Serial version uid
	 */
	private static final long serialVersionUID = 6709824081130408059L;

	public UserNotification(String caption, int delay, boolean successful)
	{
		super(DashboardUI.getMessageSource().getMessage(caption));
		setDelayMsec(delay);
		setStyleName(successful ? "success " : "failure " + "big");
		setPosition(Position.MIDDLE_CENTER);
		show(Page.getCurrent());
	}
}
