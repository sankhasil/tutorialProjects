
package com.bosch.si.amra.entity;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;

public class DeviceManagementDeserializer extends JsonDeserializer
{
	@Override
	public DeviceManagement deserialize(JsonParser jsonParser,
			DeserializationContext deserializationContext) throws IOException
	{
		ObjectCodec oc = jsonParser.getCodec();
		JsonNode node = oc.readTree(jsonParser);
		DeviceManagement devMgmt = new DeviceManagement();

		return devMgmt;
	}
}