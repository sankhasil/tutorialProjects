
package com.bosch.si.amra.view.message;

import java.util.Locale;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.entity.messages.MessageInfo.Severity;
import com.vaadin.data.util.converter.Converter;

/**
 * Converter for displaying enums in several languages
 *
 * @author toa1wa3
 *
 */
public class EnumToStringConverter implements Converter<String, Severity>
{
	/**
	 * Serial version uid
	 */
	private static final long serialVersionUID = -296113742660933803L;

	@Override
	public Severity convertToModel(String value, Class<? extends Severity> targetType,
			Locale locale) throws com.vaadin.data.util.converter.Converter.ConversionException
	{
		return Severity.valueOf(value.toUpperCase());
	}

	@Override
	public String convertToPresentation(Severity value, Class<? extends String> targetType,
			Locale locale) throws com.vaadin.data.util.converter.Converter.ConversionException
	{
		return DashboardUI.getMessageSource().getMessage(value.propertyKey());
	}

	@Override
	public Class<Severity> getModelType()
	{
		return Severity.class;
	}

	@Override
	public Class<String> getPresentationType()
	{
		return String.class;
	}

}
