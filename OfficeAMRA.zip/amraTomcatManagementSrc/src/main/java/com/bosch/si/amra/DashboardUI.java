
package com.bosch.si.amra;

import java.util.TimeZone;

import javax.servlet.annotation.WebListener;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.web.context.ContextLoaderListener;

import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.event.DashboardEvent.BrowserResizeEvent;
import com.bosch.si.amra.event.DashboardEvent.ClearValueEvent;
import com.bosch.si.amra.event.DashboardEvent.CloseOpenWindowsEvent;
import com.bosch.si.amra.event.DashboardEvent.CommunicationProblemEvent;
import com.bosch.si.amra.event.DashboardEvent.LoginFailedEvent;
import com.bosch.si.amra.event.DashboardEvent.UserLoggedInEvent;
import com.bosch.si.amra.event.DashboardEvent.UserLoggedOutEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.im.login.IdentityManagementUtil;
import com.bosch.si.amra.presenter.MessagePresenter;
import com.bosch.si.amra.provider.MessageDataProvider;
import com.bosch.si.amra.view.AmraView;
import com.bosch.si.amra.view.LoginView;
import com.bosch.si.amra.view.MainView;
import com.bosch.si.amra.view.UserNotification;
import com.bosch.si.fleet.common.error.GeneralErrorHandler;
import com.bosch.si.fleet.common.internationalization.I18n;
import com.google.common.eventbus.Subscribe;
import com.vaadin.annotations.Theme;
import com.vaadin.annotations.Title;
import com.vaadin.annotations.Widgetset;
import com.vaadin.server.Page;
import com.vaadin.server.Page.BrowserWindowResizeEvent;
import com.vaadin.server.Page.BrowserWindowResizeListener;
import com.vaadin.server.Responsive;
import com.vaadin.server.VaadinRequest;
import com.vaadin.server.VaadinService;
import com.vaadin.server.VaadinSession;
import com.vaadin.spring.annotation.SpringUI;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Notification.Type;
import com.vaadin.ui.UI;
import com.vaadin.ui.Window;

@SpringUI
@Scope ("prototype")
@Theme ("dashboard")
@Widgetset ("com.bosch.si.amra.AmraWidgetSet")
@Title ("AMRA Management")
@SuppressWarnings ("serial")
public class DashboardUI extends UI
{
	@WebListener
	public static class AmraContextLoaderListener extends ContextLoaderListener
	{

	}

	public transient DashboardEventBus			dashboardEventbus	= new DashboardEventBus();

	@Autowired
	private I18n								i18n;

	@Autowired
	private transient IdentityManagementUtil	util;

	@Autowired
	private transient MessageDataProvider		messageDataProvider;

	@Autowired
	private MessagePresenter					messagePresenter;

	@Autowired
	private GeneralErrorHandler					errorHandler;

	@Value ("${GOOGLE_API_KEY_OR_CLIENT_ID}")
	public String								GOOGLE_API_KEY_OR_CLIENT_ID;

	@Value ("${USE_PROXY}")
	public String								PROXY;

	@Value ("${MONGO_HOST}")
	public String								MONGO_HOST;

	@Value ("${MONGO_PORT}")
	public Integer								MONGO_PORT;

	@Value ("${MONGO_DATABASE}")
	public String								MONGO_DATABASE;

	@Value ("${MONGO_USERNAME}")
	public String								MONGO_USERNAME;

	@Value ("${MONGO_PASSWORD}")
	public String								MONGO_PASSWORD;

	@Value ("${AMRA_MANAGEMENT_REST_SERVER}")
	public String								AMRA_MANAGEMENT_REST_SERVER;

	@Value ("${MESSAGE_COLLECTION}")
	private String								MESSAGE_COLLECTION;

	@Override
	protected void init(VaadinRequest request)
	{
		setWebAppSettings(request);
		registerEventBusListener();

		Responsive.makeResponsive(this);

		updateContent();

		addWindowResizeListener();

	}

	private void setWebAppSettings(VaadinRequest request)
	{
		DashboardSessionInitListener dashboardSessionInitListener = new DashboardSessionInitListener();
		VaadinService.getCurrent().addSessionInitListener(dashboardSessionInitListener);
		VaadinService.getCurrent().addSessionDestroyListener(dashboardSessionInitListener);

		VaadinSession.getCurrent().setErrorHandler(errorHandler);
		VaadinSession.getCurrent().setLocale(request.getLocale());
	}

	private void registerEventBusListener()
	{
		DashboardEventBus.register(this);
		DashboardEventBus.register(util);
		DashboardEventBus.register(messagePresenter);
	}

	private void unregisterEventBusListener()
	{
		DashboardEventBus.unregister(this);
		DashboardEventBus.unregister(util);
		DashboardEventBus.unregister(messagePresenter);
	}

	private void updateContent()
	{
		User user = (User) VaadinSession.getCurrent().getAttribute(User.class.getName());
		if (user != null)
		{
			// Authenticated user
			setContent(new MainView());
			removeStyleName("loginview");
			String viewState = getNavigator().getState() == ""
					? AmraView.DEVICEMANAGMENT.getViewName() : getNavigator().getState();

			getNavigator().navigateTo(viewState);
		}
		else
		{
			setContent(new LoginView());
			addStyleName("loginview");
		}
	}

	private void addWindowResizeListener()
	{
		Page.getCurrent().addBrowserWindowResizeListener(new BrowserWindowResizeListener()
		{
			@Override
			public void browserWindowResized(BrowserWindowResizeEvent event)
			{
				DashboardEventBus.post(new BrowserResizeEvent());
			}
		});
	}

	@Subscribe
	public void userLoggedIn(UserLoggedInEvent event)
	{
		VaadinSession.getCurrent().setAttribute(User.class.getName(), event.getUser());
		updateContent();
	}

	@Subscribe
	public void userLoggedOut(UserLoggedOutEvent event)
	{
		unregisterEventBusListener();
		VaadinSession.getCurrent().close();
		Page.getCurrent().reload();
	}

	@Subscribe
	public void loginFailed(LoginFailedEvent event)
	{
		updateContent();
		Notification.show(DashboardUI.getMessageSource().getMessage("login.failed"),
				Type.HUMANIZED_MESSAGE);
	}

	@Subscribe
	public void communicationProblems(CommunicationProblemEvent event)
	{
		new UserNotification(event.getMessageCode(), 1000, false);
	}

	@Subscribe
	public void closeOpenWindows(CloseOpenWindowsEvent event)
	{
		for (Window window : getWindows())
		{
			window.close();
		}
	}

	@Subscribe
	public void updateValues(ClearValueEvent event)
	{
		// TODO: Remove when all administration panels are separated
		DashboardUI.getCurrent().getNavigator()
				.navigateTo(DashboardUI.getCurrent().getNavigator().getState());
	}

	public static TimeZone getUserTimeZone()
	{
		int rawOffset = Page.getCurrent().getWebBrowser().getRawTimezoneOffset();
		int dstSavings = Page.getCurrent().getWebBrowser().getDSTSavings();

		String[] availableIDs = TimeZone.getAvailableIDs(rawOffset);
		for (String id : availableIDs)
		{
			TimeZone timeZone = TimeZone.getTimeZone(id);
			if (dstSavings == timeZone.getDSTSavings())
			{
				return timeZone;
			}
		}
		return TimeZone.getDefault();
	}

	public static I18n getMessageSource()
	{
		return ((DashboardUI) getCurrent()).i18n;
	}

	public static String getGoogleAPIKey()
	{
		return ((DashboardUI) getCurrent()).GOOGLE_API_KEY_OR_CLIENT_ID;
	}

	public static String getMongoHost()
	{
		return ((DashboardUI) getCurrent()).MONGO_HOST;
	}

	public static Integer getMongoPort()
	{
		return ((DashboardUI) getCurrent()).MONGO_PORT;
	}

	public static String getMongoDatabase()
	{
		return ((DashboardUI) getCurrent()).MONGO_DATABASE;
	}

	public static String getMongoUsername()
	{
		return ((DashboardUI) getCurrent()).MONGO_USERNAME;
	}

	public static String getMongoPassword()
	{
		return ((DashboardUI) getCurrent()).MONGO_PASSWORD;
	}

	public static String isProxyUsed()
	{
		return ((DashboardUI) getCurrent()).PROXY;
	}

	public static String getArmaManagementRestServer()
	{
		return ((DashboardUI) getCurrent()).AMRA_MANAGEMENT_REST_SERVER;
	}

	public static String getMessageCollection()
	{
		return ((DashboardUI) getCurrent()).MESSAGE_COLLECTION;
	}

	public static MessageDataProvider getMessageDataProvider()
	{
		return ((DashboardUI) getCurrent()).messageDataProvider;
	}
}
