
package com.bosch.si.amra.view.message;

import java.util.ArrayList;
import java.util.List;

import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.messages.Message;
import com.bosch.si.amra.event.DashboardEvent.MessageAcknowledgementEvent;
import com.bosch.si.amra.event.DashboardEvent.MessageCountUpdatedEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.view.UserNotification;
import com.vaadin.event.ItemClickEvent;
import com.vaadin.event.ItemClickEvent.ItemClickListener;
import com.vaadin.server.VaadinSession;

/**
 * Item click listener which reacts on double click and acknowledges the selected item
 *
 * @author toa1wa3
 *
 */
public class MessagesItemClickListener implements ItemClickListener
{
	/**
	 * Serial version uid
	 */
	private static final long serialVersionUID = -6633707746145706890L;

	@Override
	public void itemClick(ItemClickEvent event)
	{
		if (event.isDoubleClick())
		{
			Message message = (Message) event.getItemId();
			if (message.getMessage().isAcknowledge())
			{
				new UserNotification("view.message.read", 500, false);
			}
			else
			{
				User user = (User) VaadinSession.getCurrent().getAttribute(User.class.getName());
				List<Message> selectedMessages = new ArrayList<Message>();
				selectedMessages.add(message);
				DashboardEventBus.post(new MessageAcknowledgementEvent(selectedMessages, user));
				DashboardEventBus.post(new MessageCountUpdatedEvent());
			}
		}
	}
}
