
package com.bosch.si.amra.presenter;

import java.io.Serializable;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.constants.UIConstants;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.messages.Message;
import com.bosch.si.amra.event.DashboardEvent;
import com.bosch.si.amra.event.DashboardEvent.MessageAcknowledgementEvent;
import com.bosch.si.amra.event.DashboardEventBus;

@Component
public class MessagePresenterImpl implements Serializable, MessagePresenter
{
	private static final Logger	logger				= LoggerFactory
			.getLogger(MessagePresenterImpl.class);

	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= -2486697362649941698L;

	@Override
	public void acknowledgeMessage(MessageAcknowledgementEvent event)
	{
		List<Message> messageList = event.getMessages();
		User user = event.getUser();
		if (user == null)
			throw new IllegalArgumentException(UIConstants.USER_MUST_NOT_BE_NULL);
		if (messageList == null)
			throw new IllegalArgumentException("Messages must not be null");

		List<String> messageIds = messageList.stream().map(mapper -> mapper.getId())
				.collect(Collectors.toList());
		DashboardUI.getMessageDataProvider().acknowledgeMessage(messageIds);

		List<Message> allMessageList = DashboardUI.getMessageDataProvider().getMessages(true);
		DashboardEventBus.post(new DashboardEvent.MessageSetEvent(allMessageList));
		logger.debug("Acknowledged Message");
	}
}
