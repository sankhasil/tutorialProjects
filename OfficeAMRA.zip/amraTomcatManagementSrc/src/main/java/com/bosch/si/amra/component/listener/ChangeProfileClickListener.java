
package com.bosch.si.amra.component.listener;

import com.bosch.si.amra.component.ProfilePreferencesWindow;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.event.DashboardEvent.ChangePasswordEvent;
import com.bosch.si.amra.event.DashboardEvent.ProfileUpdateEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.view.UserNotification;
import com.vaadin.data.Item;
import com.vaadin.data.fieldgroup.FieldGroup.CommitException;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;
import com.vaadin.ui.TabSheet;

public class ChangeProfileClickListener implements ClickListener
{
	private static final String				NEW					= "new";

	private static final String				OLD					= "old";

	private static final String				FIRST_NAME			= "firstName";

	private static final String				LAST_NAME			= "lastName";

	private static final String				EMAIL				= "email";

	/**
	 * Serial version uid
	 */
	private static final long				serialVersionUID	= 8901437231209874861L;

	private final User						user;

	private final ProfilePreferencesWindow	window;

	public ChangeProfileClickListener(User user, ProfilePreferencesWindow window)
	{
		this.user = user;
		this.window = window;
	}

	@Override
	public void buttonClick(ClickEvent event)
	{

		TabSheet tabSheet = window.getTabSheet();
		if (tabSheet.getSelectedTab().equals(tabSheet.getTab(1).getComponent()))
		{
			try
			{
				window.getPasswordFieldGroup().commit();
				Item passwordItem = window.getPasswordFieldGroup().getItemDataSource();
				String oldPassword = (String) passwordItem.getItemProperty(OLD).getValue();
				String newPassword = (String) passwordItem.getItemProperty(NEW).getValue();
				DashboardEventBus.post(new ChangePasswordEvent(user, oldPassword, newPassword));
			}
			catch (CommitException e)
			{
				new UserNotification("view.profile.wrong.password.group", 2000, false);
			}
		}
		else
		{
			try
			{
				window.getUserProfileFieldGroup().commit();
				Item userProfileItems = window.getUserProfileFieldGroup().getItemDataSource();
				String firstName = (String) userProfileItems.getItemProperty(FIRST_NAME).getValue();
				String lastName = (String) userProfileItems.getItemProperty(LAST_NAME).getValue();
				String email = (String) userProfileItems.getItemProperty(EMAIL).getValue();

				DashboardEventBus.post(new ProfileUpdateEvent(user, firstName, lastName, email));
			}
			catch (CommitException e)
			{
				new UserNotification("view.profile.wrong.profile.group", 2000, false);
			}
		}
	}
}
