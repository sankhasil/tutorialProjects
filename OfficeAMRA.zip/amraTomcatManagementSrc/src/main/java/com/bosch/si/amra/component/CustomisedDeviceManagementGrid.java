
package com.bosch.si.amra.component;

import java.util.Arrays;

import com.vaadin.ui.Grid;

public class CustomisedDeviceManagementGrid extends Grid
{

	private static final long	serialVersionUID	= -2856817047074562373L;

	private Object[]			propertyIds;

	private static final String	IMEI				= "imei";

	public CustomisedDeviceManagementGrid(Object[] propIds)
	{
		this.propertyIds = propIds;

	}

	@Override
	protected void doCancelEditor()
	{
		Arrays.asList(propertyIds).forEach(propertyId -> {
			if (!IMEI.equals(propertyId.toString()))
				this.getColumn(propertyId).setHidable(true);

		});

		super.doCancelEditor();
	}

}
