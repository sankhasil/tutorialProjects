
package com.bosch.si.amra.constants;

public class UIConstants
{
	public static final String	USER_MUST_NOT_BE_NULL			= "User must not be null";

	public static final String	TENANT_ID_MUST_NOT_BE_NULL		= "Tenant id must not be null";

	public static final String	GEOFENCE_ID_MUST_NOT_BE_NULL	= "Geofence id must not be null";

	public static final String	ID_MUST_NOT_BE_NULL				= "Id must not be null";

	public static final String	LIST_MUST_NOT_BE_NULL			= "List must not be null";

	public static final String	PROPERTY_MUST_NOT_BE_NULL		= "The property to be sort must not be null";

	public static final int		LOWERLIMIT_HUMIDITY				= 2;

	public static final int		UPPERLIMIT_HUMIDITY				= 100;

	public static final int		LOWERLIMIT_HUMIDITYTEMPERATURE	= -38;

	public static final int		UPPERLIMIT_HUMIDITYTEMPERATURE	= 60;

	public static final int		LOWERLIMIT_T1TEMPERATURE		= -40;

	public static final int		UPPERLIMIT_T1TEMPERATURE		= 100;

}
