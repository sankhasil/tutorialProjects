
package com.bosch.si.amra.component;

import java.util.Collection;

import com.bosch.si.amra.DashboardUI;
import com.vaadin.data.util.IndexedContainer;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.server.FontAwesome;
import com.vaadin.shared.ui.window.WindowMode;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.Component;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.TwinColSelect;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.Window;

public class TenantToDeviceAssignment extends Window
{
	/**
	 * Serial version uid
	 */
	private static final long	serialVersionUID	= 3171386869696873733L;

	private TwinColSelect		tenant2DeviceAssignment;

	public TenantToDeviceAssignment()
	{
		center();
		setClosable(true);
		setCloseShortcut(KeyCode.ESCAPE);
		setResizable(false);
		setWindowMode(WindowMode.NORMAL);
		setModal(true);
		VerticalLayout verticalLayout = new VerticalLayout();
		verticalLayout.setSpacing(true);
		verticalLayout.setMargin(true);
		setContent(verticalLayout);
		verticalLayout.addComponents(createTwinColSelect(), createButton());
	}

	private Component createTwinColSelect()
	{
		tenant2DeviceAssignment = new TwinColSelect(
				DashboardUI.getMessageSource().getMessage("view.devicemanagement.assign.caption"));
		tenant2DeviceAssignment.setRows(10);
		tenant2DeviceAssignment.setMultiSelect(true);
		tenant2DeviceAssignment.setImmediate(true);
		tenant2DeviceAssignment.setLeftColumnCaption(DashboardUI.getMessageSource()
				.getMessage("view.devicemanagement.assign.left.caption"));
		tenant2DeviceAssignment.setRightColumnCaption(DashboardUI.getMessageSource()
				.getMessage("view.devicemanagement.assign.right.caption"));
		return tenant2DeviceAssignment;
	}

	private Component createButton()
	{
		HorizontalLayout buttonLayout = new HorizontalLayout();
		buttonLayout.setWidth("99%");
		buttonLayout.setSpacing(true);
		Button okButton = new Button(FontAwesome.SAVE);
		okButton.setDescription(DashboardUI.getMessageSource()
				.getMessage("view.disponents.assign.save.button.tooltip"));
		okButton.addClickListener(listener -> {

			close();
		});
		buttonLayout.addComponent(okButton);
		buttonLayout.setComponentAlignment(okButton, Alignment.BOTTOM_RIGHT);
		return buttonLayout;
	}

	public void showTenants(Collection<String> tenants)
	{
		tenant2DeviceAssignment.setContainerDataSource(new IndexedContainer(tenants));
	}
}
