/**
 *
 */

package com.bosch.si.amra.provider;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.bosch.si.amra.constants.AmraManagementRESTConstants;
import com.bosch.si.amra.entity.messages.Message;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.GenericType;

/**
 * @author ILS5KOR
 *
 */
@Component
public class MessageDataProvider
{
	public List<Message> getMessages(boolean acknowledged)
	{
		List<Message> messages = new ArrayList<Message>();

		ClientResponse clientResponse = AmraManagementRESTClient
				.getHttpRequest(AmraManagementRESTConstants.URI_MESSAGES_ALL);
		messages = clientResponse.getEntity(new GenericType<ArrayList<Message>>()
		{
		});

		return messages;
	}

	/**
	 * Call the REST api to acknowledge a message for a given message id and returns the response
	 * code
	 *
	 * @param messageIds
	 *            - Message to be acknowledged
	 * @return - If successful return 200, otherwise the status code of the error is returned
	 */
	public int acknowledgeMessage(List<String> messageIds)
	{
		ClientResponse clientResponse = AmraManagementRESTClient
				.patchHttpRequest(AmraManagementRESTConstants.URI_MESSAGES_ALL, messageIds);
		return clientResponse.getStatus();
	}
}
