
package com.bosch.si.amra.component;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.component.listener.ChangeProfileClickListener;
import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.event.DashboardEvent.CloseOpenWindowsEvent;
import com.bosch.si.amra.event.DashboardEvent.PasswordChangedEvent;
import com.bosch.si.amra.event.DashboardEvent.ProfileUpdatedEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.view.UserNotification;
import com.google.common.eventbus.Subscribe;
import com.vaadin.data.Validator;
import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.vaadin.data.fieldgroup.FieldGroup;
import com.vaadin.data.fieldgroup.PropertyId;
import com.vaadin.data.util.ObjectProperty;
import com.vaadin.data.util.PropertysetItem;
import com.vaadin.data.validator.StringLengthValidator;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.server.FontAwesome;
import com.vaadin.server.Responsive;
import com.vaadin.server.ThemeResource;
import com.vaadin.shared.ui.MarginInfo;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;
import com.vaadin.ui.CheckBox;
import com.vaadin.ui.Component;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Image;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.PasswordField;
import com.vaadin.ui.TabSheet;
import com.vaadin.ui.TextField;
import com.vaadin.ui.UI;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.Window;
import com.vaadin.ui.themes.ValoTheme;

@SuppressWarnings ("serial")
public class ProfilePreferencesWindow extends Window
{
	public static final String			ID	= "profilepreferenceswindow";

	private final TabSheet				detailsWrapper;

	private final BeanFieldGroup<User>	fieldGroup;

	private FieldGroup					passwordFieldGroup;

	@PropertyId ("firstName")
	private TextField					firstNameField;

	@PropertyId ("lastName")
	private TextField					lastNameField;

	@PropertyId ("role")
	private TextField					roleField;

	@PropertyId ("email")
	private TextField					emailField;

	@PropertyId ("tenantName")
	private TextField					tenantNameField;

	@PropertyId ("admin")
	private CheckBox					isFleetAdmin;

	@PropertyId ("superAdmin")
	private CheckBox					isSuperAdmin;

	@PropertyId ("old")
	private PasswordField				oldPassword;

	@PropertyId ("new")
	private PasswordField				newPassword;

	@PropertyId ("retype")
	private PasswordField				retypePassword;

	private Button						ok;

	private final User					user;

	private final PropertysetItem		passwordItem;

	public ProfilePreferencesWindow(User user, boolean preferencesTabOpen)
	{
		DashboardEventBus.register(this);

		this.user = user;

		this.passwordItem = new PropertysetItem();
		passwordItem.addItemProperty("old", new ObjectProperty<String>(""));
		passwordItem.addItemProperty("new", new ObjectProperty<String>(""));
		passwordItem.addItemProperty("retype", new ObjectProperty<String>(""));

		addStyleName("profile-window");
		setId(ID);
		Responsive.makeResponsive(this);

		setModal(true);
		setCloseShortcut(KeyCode.ESCAPE, null);
		setResizable(false);
		setClosable(true);
		setHeight(90.0f, Unit.PERCENTAGE);

		VerticalLayout content = new VerticalLayout();
		content.setSizeFull();
		content.setMargin(new MarginInfo(true, false, false, false));
		setContent(content);

		detailsWrapper = new TabSheet();
		detailsWrapper.setSizeFull();
		detailsWrapper.addStyleName(ValoTheme.TABSHEET_PADDED_TABBAR);
		detailsWrapper.addStyleName(ValoTheme.TABSHEET_ICONS_ON_TOP);
		detailsWrapper.addStyleName(ValoTheme.TABSHEET_CENTERED_TABS);
		content.addComponent(detailsWrapper);
		content.setExpandRatio(detailsWrapper, 1f);

		detailsWrapper.addTab(buildProfileTab());
		detailsWrapper.addTab(buildChangePasswordTab());

		content.addComponent(buildFooter());
		if (preferencesTabOpen)
		{
			detailsWrapper.setSelectedTab(1);
		}

		fieldGroup = new BeanFieldGroup<User>(User.class);
		fieldGroup.bindMemberFields(this);
		fieldGroup.setItemDataSource(user);
		setFieldsReadOnly();
	}

	private Component buildProfileTab()
	{
		HorizontalLayout root = new HorizontalLayout();

		root.setCaption(DashboardUI.getMessageSource().getMessage("view.profile.pofile"));
		root.setIcon(FontAwesome.USER);
		root.setWidth(100.0f, Unit.PERCENTAGE);
		root.setSpacing(true);
		root.setMargin(true);
		root.addStyleName("profile-form");

		VerticalLayout pic = new VerticalLayout();
		pic.setSizeUndefined();
		pic.setSpacing(true);
		Image profilePic = new Image(null, new ThemeResource("img/profile-pic-300px.jpg"));
		profilePic.setWidth(100.0f, Unit.PIXELS);
		pic.addComponent(profilePic);

		Button upload = new Button("Change…", new ClickListener()
		{
			@Override
			public void buttonClick(ClickEvent event)
			{
				Notification.show("Not implemented in this demo");
			}
		});
		upload.addStyleName(ValoTheme.BUTTON_TINY);
		pic.addComponent(upload);

		root.addComponent(pic);

		FormLayout details = new FormLayout();
		details.addStyleName(ValoTheme.FORMLAYOUT_LIGHT);
		root.addComponent(details);
		root.setExpandRatio(details, 1);

		firstNameField = new TextField(
				DashboardUI.getMessageSource().getMessage("view.profile.firstname"));
		firstNameField.setRequired(true);
		firstNameField.setRequiredError(
				DashboardUI.getMessageSource().getMessage("view.profile.empty.firstname"));
		details.addComponent(firstNameField);

		lastNameField = new TextField(
				DashboardUI.getMessageSource().getMessage("view.profile.lastname"));
		lastNameField.setRequired(true);
		lastNameField.setRequiredError(
				DashboardUI.getMessageSource().getMessage("view.profile.empty.lastname"));
		details.addComponent(lastNameField);

		Label section = new Label(
				DashboardUI.getMessageSource().getMessage("view.profile.contact"));
		section.addStyleName(ValoTheme.LABEL_H4);
		section.addStyleName(ValoTheme.LABEL_COLORED);
		details.addComponent(section);

		emailField = new TextField(DashboardUI.getMessageSource().getMessage("view.profile.email"));
		emailField.setWidth("100%");
		emailField.setRequired(true);
		emailField.setRequiredError(
				DashboardUI.getMessageSource().getMessage("view.profile.empty.email"));
		emailField.setNullRepresentation("");
		emailField.setInputPrompt(
				DashboardUI.getMessageSource().getMessage("view.profile.panel.email.input"));
		emailField.addValidator(new com.vaadin.data.validator.EmailValidator(
				DashboardUI.getMessageSource().getMessage("view.profile.validation.email.error")));

		details.addComponent(emailField);

		section = new Label(DashboardUI.getMessageSource().getMessage("view.profile.additional"));
		section.addStyleName(ValoTheme.LABEL_H4);
		section.addStyleName(ValoTheme.LABEL_COLORED);
		details.addComponent(section);

		tenantNameField = new TextField(
				DashboardUI.getMessageSource().getMessage("view.profile.tenant"));
		tenantNameField.setWidth("100%");
		tenantNameField.setNullRepresentation("");
		details.addComponent(tenantNameField);

		isFleetAdmin = new CheckBox(
				DashboardUI.getMessageSource().getMessage("view.profile.fleetadmin"));
		isFleetAdmin.setWidth("100%");
		details.addComponent(isFleetAdmin);

		isSuperAdmin = new CheckBox(
				DashboardUI.getMessageSource().getMessage("view.profile.superadmin"));
		isSuperAdmin.setWidth("100%");
		details.addComponent(isSuperAdmin);

		return root;
	}

	private Component buildChangePasswordTab()
	{
		HorizontalLayout root = new HorizontalLayout();
		root.setCaption(DashboardUI.getMessageSource().getMessage("view.profile.change.password"));
		root.setIcon(FontAwesome.LOCK);
		root.setWidth(100.0f, Unit.PERCENTAGE);
		root.setSpacing(true);
		root.setMargin(true);
		root.addStyleName("profile-form");

		FormLayout passwordChange = new FormLayout();
		passwordChange.addStyleName(ValoTheme.FORMLAYOUT_LIGHT);
		root.addComponent(passwordChange);
		root.setExpandRatio(passwordChange, 1);

		oldPassword = new PasswordField(
				DashboardUI.getMessageSource().getMessage("view.profile.old.password"));
		oldPassword.setImmediate(true);
		oldPassword.setRequired(true);
		oldPassword.setRequiredError(
				DashboardUI.getMessageSource().getMessage("view.profile.empty.old.password"));
		passwordChange.addComponent(oldPassword);

		newPassword = new PasswordField(
				DashboardUI.getMessageSource().getMessage("view.profile.new.password"));
		newPassword.setImmediate(true);
		newPassword.setRequired(true);
		newPassword.setRequiredError(
				DashboardUI.getMessageSource().getMessage("view.profile.empty.new.password"));
		newPassword.addValidator(new StringLengthValidator(
				DashboardUI.getMessageSource().getMessage("view.profile.password.length"), 8, null,
				false));
		passwordChange.addComponent(newPassword);

		retypePassword = new PasswordField(
				DashboardUI.getMessageSource().getMessage("view.profile.retype.password"));
		retypePassword.setImmediate(true);
		retypePassword.setRequired(true);
		retypePassword.setRequiredError(
				DashboardUI.getMessageSource().getMessage("view.profile.empty.retype.password"));
		retypePassword.addValidator(new RetypeValidator());
		passwordChange.addComponent(retypePassword);

		passwordFieldGroup = new FieldGroup(passwordItem);
		passwordFieldGroup.bindMemberFields(this);

		return root;
	}

	private Component buildFooter()
	{
		HorizontalLayout footer = new HorizontalLayout();
		footer.addStyleName(ValoTheme.WINDOW_BOTTOM_TOOLBAR);
		footer.setWidth(100.0f, Unit.PERCENTAGE);

		ok = new Button(DashboardUI.getMessageSource().getMessage("view.profile.ok"));
		ok.addStyleName(ValoTheme.BUTTON_PRIMARY);
		ok.addClickListener(new ChangeProfileClickListener(user, this));
		ok.focus();
		footer.addComponent(ok);
		footer.setComponentAlignment(ok, Alignment.TOP_RIGHT);
		return footer;
	}

	private void setFieldsReadOnly()
	{
		fieldGroup.getField("superAdmin").setReadOnly(true);
		fieldGroup.getField("admin").setReadOnly(true);
		fieldGroup.getField("tenantName").setReadOnly(true);
	}

	public static void open(User user, boolean preferencesTabActive)
	{
		DashboardEventBus.post(new CloseOpenWindowsEvent());
		Window w = new ProfilePreferencesWindow(user, preferencesTabActive);
		UI.getCurrent().addWindow(w);
		w.focus();
	}

	public TabSheet getTabSheet()
	{
		return detailsWrapper;
	}

	public FieldGroup getPasswordFieldGroup()
	{
		return passwordFieldGroup;
	}

	public BeanFieldGroup<User> getUserProfileFieldGroup()
	{
		return fieldGroup;
	}

	@Subscribe
	public void passwordSuccessfullyChanged(PasswordChangedEvent event)
	{
		new UserNotification("view.profile.password.change.successful", 1000, true);
		this.close();
	}

	@Subscribe
	public void profileSuccessfullyUpdated(ProfileUpdatedEvent event)
	{
		new UserNotification("view.profile.contact.change.successful", 1000, true);
		this.close();
	}

	private class RetypeValidator implements Validator
	{
		@Override
		public void validate(Object value) throws InvalidValueException
		{
			if (!(value instanceof String && ((String) value).equals(newPassword.getValue())))
				throw new InvalidValueException(DashboardUI.getMessageSource()
						.getMessage("view.profile.wrong.retype.password"));
		}
	}
}