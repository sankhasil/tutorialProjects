
package com.bosch.si.amra.event;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.bosch.si.amra.entity.User;
import com.bosch.si.amra.entity.messages.Message;
import com.bosch.si.amra.view.AmraView;
import com.vaadin.ui.Component;

public class DashboardEvent implements Serializable
{

	/**
	 * Serial version uid
	 */
	private static final long serialVersionUID = 965359953980722507L;

	public static class UserLoginRequestedEvent
	{
		private final String userName, password, tenant;

		public UserLoginRequestedEvent(String userName, String password, String tenant)
		{
			this.userName = userName;
			this.password = password;
			this.tenant = tenant;
		}

		public String getUserName()
		{
			return userName;
		}

		public String getPassword()
		{
			return password;
		}

		public String getTenant()
		{
			return tenant;
		}

	}

	public static class TenantEvent
	{
		private final String tenantId;

		public String getTenantId()
		{
			return tenantId;
		}

		public TenantEvent(String tenantId)
		{
			this.tenantId = tenantId;
		}
	}

	public static class UserLoggedInEvent
	{
		private final User user;

		public UserLoggedInEvent(User user)
		{
			this.user = user;
		}

		public User getUser()
		{
			return user;
		}
	}

	public static class GetAllTenantsEvent
	{
		private final User			user;

		private final List<Object>	selectedDevice;

		public GetAllTenantsEvent(User user, List<Object> selectedDevice)
		{
			this.user = user;
			this.selectedDevice = selectedDevice;
		}

		public User getUser()
		{
			return user;
		}

		public List<Object> getSelectedDevice()
		{
			return selectedDevice;
		}
	}

	public static class ReceivedAllTenantsEvent
	{
		private final Map<String, String>	tenants;

		private final List<Object>			selectedDevice;

		public ReceivedAllTenantsEvent(Map<String, String> tenants, List<Object> selectedDevice)
		{
			this.tenants = tenants;
			this.selectedDevice = selectedDevice;
		}

		public Map<String, String> getTenants()
		{
			return tenants;
		}

		public List<Object> getSelectedDevice()
		{
			return selectedDevice;
		}
	}

	public static class BrowserResizeEvent
	{

	}

	public static class UserLoggedOutEvent
	{

	}

	public static class LoginFailedEvent
	{

	}

	public static class CommunicationProblemEvent
	{
		private final String messageCode;

		public CommunicationProblemEvent(String messageCode)
		{
			this.messageCode = messageCode;
		}

		public String getMessageCode()
		{
			return messageCode;
		}
	}

	public static class CloseOpenWindowsEvent
	{
	}

	public static class ProfileUpdateEvent
	{

		private final User	user;

		private String		firstName;

		private String		lastName;

		private String		email;

		public ProfileUpdateEvent(User user, String firstName, String lastName, String email)
		{
			this.user = user;
			this.setFirstName(firstName);
			this.setLastName(lastName);
			this.setEmail(email);
		}

		public User getUser()
		{
			return user;
		}

		public String getFirstName()
		{
			return firstName;
		}

		public void setFirstName(String firstName)
		{
			this.firstName = firstName;
		}

		public String getLastName()
		{
			return lastName;
		}

		public void setLastName(String lastName)
		{
			this.lastName = lastName;
		}

		public String getEmail()
		{
			return email;
		}

		public void setEmail(String email)
		{
			this.email = email;
		}

	}

	public static class PostViewChangeEvent
	{
		private final AmraView view;

		public PostViewChangeEvent(AmraView view)
		{
			this.view = view;
		}

		public AmraView getView()
		{
			return view;
		}
	}

	public static class ProfileUpdatedEvent
	{

	}

	public static class ChangePasswordEvent
	{
		private final User		user;

		private final String	oldPassword;

		private final String	newPassword;

		public ChangePasswordEvent(User user, String oldPassword, String newPassword)
		{
			this.user = user;
			this.oldPassword = oldPassword;
			this.newPassword = newPassword;
		}

		public User getUser()
		{
			return user;
		}

		public String getOldPassword()
		{
			return oldPassword;
		}

		public String getNewPassword()
		{
			return newPassword;
		}
	}

	public static class PasswordChangedEvent
	{

	}

	public static class ResetPasswordEvent
	{
		private final User user;

		public ResetPasswordEvent(User user)
		{
			this.user = user;
		}

		public User getUser()
		{
			return user;
		}
	}

	public static class PasswordResetEvent
	{

	}

	public static class MaximizeDashboardPanelEvent
	{
		private final Component panel;

		public MaximizeDashboardPanelEvent(Component panel)
		{
			this.panel = panel;
		}

		public Component getPanel()
		{
			return panel;
		}
	}

	public static class MinimizeDashboardPanelEvent
	{
		private final Component panel;

		public MinimizeDashboardPanelEvent(Component panel)
		{
			this.panel = panel;
		}

		public Component getPanel()
		{
			return panel;
		}
	}

	public static class ClearValueEvent
	{

	}

	public static class MessageAcknowledgementEvent
	{
		private final List<Message>	messages;

		private final User			user;

		public MessageAcknowledgementEvent(List<Message> messages, User user)
		{
			this.messages = messages;
			this.user = user;
		}

		public List<Message> getMessages()
		{
			return messages;
		}

		public User getUser()
		{
			return user;
		}
	}

	public static class MessageCountUpdatedEvent
	{
	}

	public static class MessageSetEvent
	{
		private final List<Message> messageList;

		public MessageSetEvent(List<Message> messageList)
		{
			this.messageList = messageList;
		}

		public List<Message> getMessages()
		{
			return messageList;
		}
	}
}
