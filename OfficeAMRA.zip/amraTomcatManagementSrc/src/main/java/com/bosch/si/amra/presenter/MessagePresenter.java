
package com.bosch.si.amra.presenter;

import com.bosch.si.amra.event.DashboardEvent.MessageAcknowledgementEvent;
import com.google.common.eventbus.Subscribe;

public interface MessagePresenter
{
	@Subscribe
	public void acknowledgeMessage(MessageAcknowledgementEvent event);
}
