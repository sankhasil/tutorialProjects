
package com.bosch.si.amra.view.message;

import com.bosch.si.amra.constants.messages.MessagesConstants;
import com.bosch.si.amra.entity.messages.Message;
import com.bosch.si.amra.entity.messages.MessageInfo;
import com.bosch.si.amra.entity.messages.MessageInfo.Severity;
import com.vaadin.data.util.BeanItem;
import com.vaadin.ui.Grid.CellReference;
import com.vaadin.ui.Grid.CellStyleGenerator;
import com.vaadin.ui.Grid.RowReference;
import com.vaadin.ui.Grid.RowStyleGenerator;

/**
 * Messages grid style generator provides row style and cell style generator
 *
 * @author toa1wa3
 *
 */
public class MessagesStyleGenerator
{
	/**
	 * Row is displayed in bold font when message is not acknowledged
	 *
	 * @author toa1wa3
	 *
	 */
	public static final class MessagesRowStyleGenerator implements RowStyleGenerator
	{
		/**
		 * Serial version uid
		 */
		private static final long serialVersionUID = -697951961036737451L;

		@SuppressWarnings ("unchecked")
		@Override
		public String getStyle(RowReference rowReference)
		{
			Message message = ((BeanItem<Message>) rowReference.getItem()).getBean();
			if (message.getMessage() != null && !message.getMessage().isAcknowledge())
			{
				return "acknowledge";
			}
			return null;
		}
	}

	public static final class MessagesCellStyleGenerator implements CellStyleGenerator
	{
		/**
		 * Serial version uid
		 */
		private static final long serialVersionUID = 5063665639104082025L;

		@Override
		public String getStyle(CellReference cellReference)
		{
			if (cellReference.getPropertyId().equals(MessagesConstants.SEVERITY))
			{
				switch ((Severity) cellReference.getValue())
				{
					case HIGH:
						return "red";
					case MEDIUM:
						return "yellow";
					case LOW:
						return "green";
					default:
						return null;
				}
			}
			return null;
		}
	}
}
