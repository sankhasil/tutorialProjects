
package com.bosch.si.amra.constants;

public class MongoConstants
{
	public static final String	ID							= "_id";

	public static final String	WAGON_ID					= "WI";

	public static final String	SORT						= "sort";

	public static final String	DISPONENTS					= "disponents";

	public static final String	BOX_ID						= "BI";

	public static final String	MESSAGE_ID					= "MI";

	public static final String	WAGON_TYPE					= "wagonType";

	public static final String	WAGON_TYPE_NAME				= "typeName";

	public static final String	SENSORVALUES_ELEMENT		= "sensorvalues";

	public static final String	DATA_ELEMENT				= "D";

	public static final String	LATITUDE					= "LA";

	public static final String	LONGITUDE					= "LO";

	public static final String	ALTITUDE					= "AL";

	public static final String	DATE						= "DA";

	public static final String	TIME						= "TM";

	public static final String	FLASH_DATA					= "F";

	public static final String	STATUS						= "S";

	public static final String	HUMIDITY					= "HM";

	public static final String	HUMIDITY_TEMPERATURE		= "HT";

	public static final String	TEMPERATURE					= "T1";

	public static final String	DEVICE_TEMPERATURE			= "DT";

	public static final String	SHOCK						= "RX";

	public static final String	SHOCK_X						= "SX";

	public static final String	SHOCK_Y						= "SY";

	public static final String	SHOCK_Z						= "SZ";

	public static final String	TENANT_ID					= "TI";

	public static final String	ROUTING						= "RT";

	public static final String	GPS_MOVING					= "CM";

	public static final String	GPS_TIME_BASED				= "CS";

	public static final String	GSM_MOVING					= "PM";

	public static final String	GSM_TIME_BASED				= "PS";

	public static final String	GEOFENCE_TYPE				= "GEOFENCE";

	public static final String	GEOFENCE_ID					= "geofence._id";

	public static final String	FORMATTED_ADDRESS			= "formatted_address";

	public static final String	NOTIFICATION_REASON			= "reason";

	public static final String	NOTIFICATION_REASON_NAME	= "reasonName";

	public static final String	NOTIFICATION_PRIORITY		= "priority";

	public static final String	ADRESS_ROUTE				= "address.address_components.route";

	public static final String	ADRESS_LOCALITY				= "address.address_components.locality";

	public static final String	ADRESS_POST_CODE			= "address.address_components.postal_code";

	public static final String	ADRESS_COUNTRY				= "address.address_components.country";

	public static final String	NOTIFICATION_ACKNOWLEDGED	= "acknowledged";

	public static final String	ADDRESS						= "address";

	public static final String	ADDRESS_COMPONENTS			= "address_components";

	public static final String	ADDRESS_ROUTE				= "route";

	public static final String	ADDRESS_STREET_NUMBER		= "street_number";

	public static final String	ADDRESS_POSTAL_CODE			= "postal_code";

	public static final String	ADDRESS_LOCALITY			= "locality";

	public static final String	ADDRESS_COUNTRY				= "country";

	public static final String	ALIAS						= "alias";

	public static final String	ALIAS_TO_LOWERCASE			= "aliasToLowerCase";

	public static final String	DATA_DATE					= "D.DA";

	public static final String	DATA_TIME					= "D.TM";

	public static final String	GEOFENCE_NAME				= "geofenceName";

	public static final String	GEOFENCE					= "geofence";

	public static final String	GEOFENCE_DESCRIPTION		= "geofenceDescription";

	public static final String	TIMESTAMP					= "timestamp";

	public static final String	GEOJSON_TYPE				= "type";

	public static final String	GEOJSON_COORDINATES			= "coordinates";

	public static final String	LOCATION					= "loc";

	public static final String	POLYGON						= "Polygon";

	public static final String	RULE_WAGONS					= "wagons";

	public static final String	ALARM_NAME					= "name";

	public static final String	ALARM_ACTIVE				= "active";

	public static final String	ALARM_INITIAL				= "initial";

	public static final String	ALARM_RULE_TYPE				= "ruleType";

	public static final String	ALARM_LIMIT					= "limit";

	public static final String	ALARM_UNIT					= "unit";

	public static final String	ALARM_CONDITION				= "condition";

	public static final String	ALARM_SEVERITY				= "severity";

	public static final String	RED							= "RED";

	public static final String	YELLOW						= "YELLOW";

	public static final String	GREEN						= "GREEN";

	public static final String	LESSER_THAN					= "lt";

	public static final String	GREATER_THAN				= "gt";

	public static final String	IN							= "in";

	public static final String	OUT							= "out";

	public static final String	NOT_EQUAL					= "ne";

	public static final String	EQUAL						= "eq";

	public static final String	MILEAGE						= "KM";

	public static final String	WAGON_ELEMENT				= "WN";

	public static final String	MESSAGE_ELEMENT				= "message";

	public static final String	TEXT						= "text";

	public static final String	TYPE						= "type";

	public static final String	CREATED_TIME				= "createdTime";

	public static final String	READ_TIME					= "readTime";

	public static final String	ACKNOWLEDGE					= "acknowledge";

}