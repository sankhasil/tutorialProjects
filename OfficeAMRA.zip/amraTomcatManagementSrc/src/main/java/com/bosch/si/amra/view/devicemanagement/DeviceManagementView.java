
package com.bosch.si.amra.view.devicemanagement;

import java.io.IOException;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bosch.si.amra.DashboardUI;
import com.bosch.si.amra.component.CustomisedDeviceManagementGrid;
import com.bosch.si.amra.component.TenantToDeviceAssignment;
import com.bosch.si.amra.entity.DeviceManagement;
import com.bosch.si.amra.event.DashboardEvent.BrowserResizeEvent;
import com.bosch.si.amra.event.DashboardEvent.ReceivedAllTenantsEvent;
import com.bosch.si.amra.event.DashboardEventBus;
import com.bosch.si.amra.im.login.Role;
import com.bosch.si.amra.im.login.Role.Roles;
import com.bosch.si.amra.provider.NewDataProvider;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.common.eventbus.Subscribe;
import com.vaadin.addon.contextmenu.GridContextMenu;
import com.vaadin.data.Container.Filterable;
import com.vaadin.data.fieldgroup.BeanFieldGroup;
import com.vaadin.data.fieldgroup.FieldGroup;
import com.vaadin.data.fieldgroup.FieldGroup.CommitEvent;
import com.vaadin.data.fieldgroup.FieldGroup.CommitException;
import com.vaadin.data.fieldgroup.FieldGroup.CommitHandler;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.data.util.converter.StringToDateConverter;
import com.vaadin.data.util.converter.StringToLongConverter;
import com.vaadin.data.util.filter.SimpleStringFilter;
import com.vaadin.event.ShortcutAction.KeyCode;
import com.vaadin.event.ShortcutListener;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.server.Responsive;
import com.vaadin.shared.MouseEventDetails.MouseButton;
import com.vaadin.shared.ui.grid.GridConstants.Section;
import com.vaadin.shared.ui.label.ContentMode;
import com.vaadin.ui.Component;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.Grid.GridContextClickEvent;
import com.vaadin.ui.Grid.HeaderCell;
import com.vaadin.ui.Grid.HeaderRow;
import com.vaadin.ui.Grid.SelectionMode;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Notification.Type;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

@Role ({ Roles.USER, Roles.FLEETADMIN, Roles.SYSTEMADMIN })
@SuppressWarnings ("serial")
public class DeviceManagementView extends VerticalLayout implements View
{
	private static final Logger				_log			= LoggerFactory
			.getLogger(DeviceManagementView.class);

	private CustomisedDeviceManagementGrid	grid;

	private Object[]						propertyIds		= new Object[] { "imei", "tenant",
			"alias", "iic", "sim", "initialVersion", "version", "hwVersion", "lastPost" };

	private static final String				HEADER_COLUMN	= "view.devicemanagement.columnheader.";

	private static final String				HEADER			= "view.devicemanagement.header.";

	private static final String				IMEI			= "imei";

	public DeviceManagementView()
	{
		setSizeFull();
		addStyleName("device");
		DashboardEventBus.register(this);

		addComponent(buildToolbar());

		grid = buildGrid();
		addComponent(grid);
		setExpandRatio(grid, 1);

	}

	@Override
	public void detach()
	{
		super.detach();
		DashboardEventBus.unregister(this);

	}

	private Component buildToolbar()
	{
		HorizontalLayout header = new HorizontalLayout();
		header.addStyleName("viewheader");
		header.setSpacing(true);
		Responsive.makeResponsive(header);

		Label title = new Label(
				DashboardUI.getMessageSource().getMessage("view.devicemanagement.caption"));
		title.setSizeUndefined();
		title.addStyleName(ValoTheme.LABEL_H1);
		title.addStyleName(ValoTheme.LABEL_NO_MARGIN);
		header.addComponent(title);

		return header;
	}

	private CustomisedDeviceManagementGrid buildGrid()
	{
		final BeanItemContainer<DeviceManagement> beanContainer = createContainer();
		grid = new CustomisedDeviceManagementGrid(propertyIds);

		grid.setContainerDataSource(beanContainer);
		grid.setSizeFull();

		grid.removeAllColumns();

		grid.setEditorSaveCaption(
				DashboardUI.getMessageSource().getMessage("view.devicemanagement.button.save"));
		grid.setEditorCancelCaption(
				DashboardUI.getMessageSource().getMessage("view.devicemanagement.button.cancel"));
		grid.setColumns(propertyIds);
		grid.setColumnOrder(propertyIds);
		grid.setFrozenColumnCount(1);
		grid.setSelectionMode(SelectionMode.SINGLE);
		HeaderRow filterRow = grid.appendHeaderRow();
		addFilterRow(beanContainer, filterRow);

		grid.setEditorFieldGroup(getFieldGroup());
		configureGridForPresentation();
		grid.setResponsive(true);
		grid.setColumnReorderingAllowed(true);
		buildDetailsGenerator();
		grid.addItemClickListener(event -> {

			if (!event.isCtrlKey() && !event.isAltKey() && !event.isDoubleClick()
					&& !event.isMetaKey() && !event.isShiftKey())
			{
				grid.setEditorEnabled(false);

				grid.setDetailsVisible(event.getItemId(),
						!grid.isDetailsVisible(event.getItemId()));
			}

		});

		GridContextMenu gridContext = new GridContextMenu(grid);
		grid.addContextClickListener(context -> {
			GridContextClickEvent gridEvent = (GridContextClickEvent) context;
			gridContext.removeItems();
			if (gridEvent.getButton().getName().equalsIgnoreCase(MouseButton.RIGHT.getName())
					&& gridEvent.getSection().equals(Section.BODY) && gridEvent.getItemId() != null)
			{
				grid.setEditorEnabled(true);
				gridContext.addItem("Edit", command -> {

					Arrays.asList(propertyIds).forEach(propertyId -> {
						grid.getColumn(propertyId).setHidable(false);

					});

					grid.editItem(gridEvent.getItemId());

				});
			}
		});

		grid.setCellStyleGenerator(cellReference -> {
			return null;
		});

		return grid;
	}

	private void buildDetailsGenerator()
	{
		grid.setDetailsGenerator(rowReference -> {
			SimpleDateFormat format = new SimpleDateFormat(
					DashboardUI.getMessageSource().getMessage("date.format"));
			// Find the bean to generate details for
			final DeviceManagement bean = (DeviceManagement) rowReference.getItemId();

			// A basic label with bean data
			Label productionDate = new Label("<b> "
					+ DashboardUI.getMessageSource()
							.getMessage("view.devicemanagement.lastpostdatetime")
					+ " : " + "</b>" + format.format(bean.getLastPost()), ContentMode.HTML);
			Label meesageId = new Label(
					"<b> " + DashboardUI.getMessageSource().getMessage(
							"view.devicemanagement.messageid") + " : " + "</b>" + bean.getMi(),
					ContentMode.HTML);
			SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss");
			String timeFormatted = formatter
					.format(System.currentTimeMillis() - bean.getLastPost().getTime());
			Label timeLastPost = new Label("<b> "
					+ DashboardUI.getMessageSource()
							.getMessage("view.devicemanagement.timesincelastpost")
					+ " : " + "</b>" + timeFormatted, ContentMode.HTML);

			FormLayout formLayout = new FormLayout(productionDate, meesageId, timeLastPost);

			// Wrap up all the parts into a vertical layout
			HorizontalLayout layout = new HorizontalLayout(formLayout);
			layout.setSpacing(true);
			layout.setMargin(true);
			return layout;
		});
	}

	private void configureGridForPresentation()
	{

		StringToDateConverter dateConverterWithAmraFormat = new StringToDateConverter()
		{
			@Override
			protected DateFormat getFormat(Locale locale)
			{
				SimpleDateFormat dateFormater = new SimpleDateFormat(
						DashboardUI.getMessageSource().getMessage("date.format"));
				dateFormater.setTimeZone(DashboardUI.getUserTimeZone());
				return dateFormater;
			}
		};

		Arrays.asList(propertyIds).forEach(propertyId -> {
			TextField propertyField = new TextField();
			propertyField.setNullRepresentation("");
			propertyField.setNullSettingAllowed(true);

			String propertyName = (String) propertyId;
			grid.getDefaultHeaderRow().getCell(propertyName).setStyleName("grid-header");
			grid.getDefaultHeaderRow().getCell(propertyName).setHtml(DashboardUI.getMessageSource()
					.getMessage(HEADER_COLUMN + propertyName.toString().toLowerCase()));

			switch (propertyName)
			{
				case "tenant":
				case "alias":
					grid.getColumn(propertyId).setHidable(true)
							.setHidingToggleCaption(DashboardUI.getMessageSource()
									.getMessage(HEADER + propertyId.toString().toLowerCase()));
					grid.getColumn(propertyId).setWidth(273);
					break;
				case "imei":

					renderGridColumn(propertyField, propertyId);
					grid.getColumn(propertyId).setWidth(232);

					break;

				case "iic":

				case "sim":
					renderGridColumn(propertyField, propertyId);
					grid.getColumn(propertyId).setWidth(190);

					grid.getColumn(propertyId).setHidable(true)
							.setHidingToggleCaption(DashboardUI.getMessageSource()
									.getMessage(HEADER + propertyId.toString().toLowerCase()));

					break;
				case "initialVersion":

				case "version":

				case "hwVersion":
					grid.getColumn(propertyId).setWidth(100);

					renderGridColumn(propertyField, propertyId);
					grid.getColumn(propertyId).setHidable(true)
							.setHidingToggleCaption(DashboardUI.getMessageSource()
									.getMessage(HEADER + propertyId.toString().toLowerCase()));
					break;
				case "lastPost":

					grid.getColumn(propertyId).setWidth(200);

					propertyField.setConverter(dateConverterWithAmraFormat);
					grid.getColumn(propertyId).setConverter(dateConverterWithAmraFormat);
					grid.getColumn(propertyId).setHidable(true)
							.setHidingToggleCaption(DashboardUI.getMessageSource()
									.getMessage(HEADER + propertyId.toString().toLowerCase()));
					break;

				default:
					break;
			}

			grid.getColumn(propertyId).setEditorField(propertyField);

		});

	}

	private void renderGridColumn(TextField propertyField, Object propertyId)
	{
		StringToLongConverter longConverterWithNoGrouping = new StringToLongConverter()
		{
			protected java.text.NumberFormat getFormat(Locale locale)
			{
				NumberFormat numberFormatWithNoGrouping = super.getFormat(locale);
				numberFormatWithNoGrouping.setGroupingUsed(false);
				return numberFormatWithNoGrouping;
			};
		};
		propertyField.setConverter(longConverterWithNoGrouping);
		grid.getColumn(propertyId).setConverter(longConverterWithNoGrouping);

	}

	private void addFilterRow(BeanItemContainer<DeviceManagement> container, HeaderRow filterRow)
	{

		for (Object pid : propertyIds)
		{
			HeaderCell cell = filterRow.getCell(pid);

			TextField filterField = new TextField();
			filterField.setWidth("100%");
			filterField.setHeight("75%");
			filterField.addShortcutListener(new ShortcutListener("Clear", KeyCode.ESCAPE, null)
			{
				@Override
				public void handleAction(Object sender, Object target)
				{
					if (target != null)
						((TextField) target).setValue("");

					((Filterable) grid.getContainerDataSource()).removeAllContainerFilters();
				}
			});
			filterField.addTextChangeListener(change -> {
				container.removeContainerFilters(pid);

				if (!change.getText().isEmpty())
					container.addContainerFilter(
							new SimpleStringFilter(pid, change.getText(), true, false));
			});
			cell.setComponent(filterField);
		}
	}

	private FieldGroup getFieldGroup()
	{
		BeanFieldGroup<DeviceManagement> beanFieldGroup = new BeanFieldGroup<DeviceManagement>(
				DeviceManagement.class);
		beanFieldGroup.addCommitHandler(new CommitHandler()
		{

			private static final long serialVersionUID = 6062316515368687380L;

			@Override
			public void preCommit(CommitEvent commitEvent) throws CommitException
			{
			}

			@Override
			public void postCommit(CommitEvent commitEvent) throws CommitException
			{
				DeviceManagement dev = beanFieldGroup.getItemDataSource().getBean();
				saveSelectedDevice(dev);
				Notification.show(DashboardUI.getMessageSource()
						.getMessage("view.devicemanagement.save.success"));
				Arrays.asList(propertyIds).forEach(propertyId -> {
					if (!IMEI.equals(propertyId.toString()))
						grid.getColumn(propertyId).setHidable(true);

				});
			}

		});

		return beanFieldGroup;
	}

	@Subscribe
	public void browserResized(BrowserResizeEvent event)
	{
	}

	private void saveSelectedDevice(DeviceManagement dev)
	{

		List<DeviceManagement> selectedDevicesList = new ArrayList<DeviceManagement>();
		selectedDevicesList.add(dev);

		NewDataProvider dataProvider = new NewDataProvider();
		try
		{
			dataProvider.postDevices(selectedDevicesList);
			Notification.show(DashboardUI.getMessageSource()
					.getMessage("view.devicemanagement.save.success"));
		}
		catch (JsonProcessingException e)
		{
			Notification.show(
					DashboardUI.getMessageSource().getMessage("view.devicemanagement.save.error"));
		}
		catch (IOException e)
		{
			Notification.show(
					DashboardUI.getMessageSource().getMessage("view.devicemanagement.save.error"));
		}
	}

	public void setDeviceList(ReceivedAllTenantsEvent event)
	{
		TenantToDeviceAssignment window = new TenantToDeviceAssignment();
		window.showTenants(event.getTenants().values());
		DashboardUI.getCurrent().addWindow(window);
	}

	/**
	 * Fetches the list of Devices from the REST Interface and sets it to the Bean Item Container
	 * 
	 * @return {@link BeanItemContainer<DeviceManagement>}
	 */
	private BeanItemContainer<DeviceManagement> createContainer()
	{

		NewDataProvider dataProvider = new NewDataProvider();
		List<DeviceManagement> devices = new ArrayList<DeviceManagement>();
		try
		{
			devices = dataProvider.getDevices();
		}
		catch (Exception e)
		{

			_log.error(e.getMessage());
			if (e.getCause().getClass().getName().equalsIgnoreCase("java.net.ConnectException"))
				Notification.show(DashboardUI.getMessageSource().getMessage(
						"error.errorhandler.device.server.error"), Type.WARNING_MESSAGE);
			else
				Notification.show(DashboardUI.getMessageSource()
						.getMessage("error.errorhandler.device.view.error"), Type.ERROR_MESSAGE);

		}
		return new BeanItemContainer<>(DeviceManagement.class, devices);
	}

	@Override
	public void enter(ViewChangeEvent event)
	{
	}

}
