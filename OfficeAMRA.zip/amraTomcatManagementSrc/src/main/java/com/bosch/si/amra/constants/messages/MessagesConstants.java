
package com.bosch.si.amra.constants.messages;

public class MessagesConstants
{
	public static final String	SEVERITY		= "message.severity";

	public static final String	BOX_ID			= "boxID";

	public static final String	ALIAS			= "wagon.alias";

	public static final String	TENANT_ID		= "tenantId";

	public static final String	CREATED_TIME	= "message.createdTime";

	public static final String	READ_TIME		= "message.readTime";

	public static final String	TYPE			= "message.type";

	public static final String	TEXT			= "message.text";

	public static final String	ACKNOWLEDGE		= "message.acknowledge";
}
